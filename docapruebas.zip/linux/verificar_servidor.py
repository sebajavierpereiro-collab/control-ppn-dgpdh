"""Chequeo del servidor antes (y después) de arrancar el sistema en Linux. No cambia nada: solo informa.

    cd /opt/dgpdh/dgpdh_web && sudo -u dgpdh /opt/dgpdh/venv/bin/python linux/verificar_servidor.py

Cada línea dice [OK], [AVISO] (funciona, pero conviene resolverlo) o [FALTA] (hay que resolverlo antes de usar el
sistema) y qué hacer. Termina con código 1 si hay algo en FALTA. También se puede correr en la PC con Windows.
"""
import configparser
import importlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
LINUX = sys.platform.startswith("linux")
PAQUETES = [("fastapi", "fastapi"), ("uvicorn", "uvicorn[standard]"), ("multipart", "python-multipart"), ("itsdangerous", "itsdangerous"),
            ("jinja2", "jinja2"), ("docx", "python-docx"), ("requests", "requests"), ("spellchecker", "pyspellchecker"),
            ("language_tool_python", "language-tool-python"), ("openpyxl", "openpyxl"), ("xlrd", "xlrd"), ("psutil", "psutil"),
            ("PIL", "Pillow"), ("cryptography", "cryptography"), ("pypdf", "pypdf (opcional)")]
RUTA_WINDOWS = re.compile(r"^([a-zA-Z]:\\|\\\\)")


class Informe:
    def __init__(self, imprimir=True):
        self.lineas, self.imprimir = [], imprimir

    def _l(self, estado, texto, hacer=""):
        self.lineas.append((estado, texto, hacer))
        if self.imprimir:
            print(f"[{estado}] {texto}" + (f"\n        → {hacer}" if hacer else ""))

    ok = lambda self, t, h="": self._l("OK", t)
    aviso = lambda self, t, h="": self._l("AVISO", t, h)
    falta = lambda self, t, h="": self._l("FALTA", t, h)

    @property
    def faltas(self):
        return [x for x in self.lineas if x[0] == "FALTA"]


def leer_config(app=APP):
    c = configparser.ConfigParser()
    ruta = Path(app) / "config.ini"
    if ruta.is_file():
        c.read(ruta, encoding="utf-8")
    return c, ruta


def chequear_python(inf):
    v = sys.version_info
    (inf.ok if v >= (3, 12) else inf.falta)(f"Python {v.major}.{v.minor}.{v.micro}", "Hace falta Python 3.12 o más nuevo (Ubuntu 24.04 trae 3.12; el código usa sintaxis de 3.12).")
    faltan = []
    for mod, paquete in PAQUETES:
        try:
            importlib.import_module(mod)
        except Exception:
            faltan.append(paquete)
    if not faltan:
        inf.ok("Paquetes de Python instalados")
    elif faltan == ["pypdf (opcional)"]:
        inf.aviso("Falta pypdf (opcional): los PDF archivados no se indexan para la búsqueda", "venv/bin/pip install pypdf")
    else:
        inf.falta("Faltan paquetes de Python: " + ", ".join(faltan), "/opt/dgpdh/venv/bin/pip install -r requirements.txt")


def chequear_config(inf, app=APP):
    c, ruta = leer_config(app)
    if not ruta.is_file():
        inf.falta("No está config.ini", "Copialo desde la PC actual (lleva la clave de las sesiones y la firma).")
        return
    inf.ok("config.ini presente")
    firma = c.get("firma", "archivo_firma", fallback="").strip()
    if not firma:
        inf.falta("config.ini: falta [firma] archivo_firma")
    elif RUTA_WINDOWS.match(firma) and LINUX:
        inf.falta(f"config.ini: la firma apunta a una ruta de Windows ({firma})",
                  "Cambiala por la carpeta montada, por ejemplo /mnt/firma/firma_director.PNG")
    elif not Path(firma).is_file():
        inf.falta(f"No encuentro el archivo de la firma: {firma}", "Revisá que la carpeta compartida esté montada (sudo mount -a).")
    else:
        inf.ok(f"Firma accesible: {firma}")
    for clave in ("carpeta", "copia_externa"):
        v = c.get("respaldos", clave, fallback="").strip()
        if not v:
            continue
        if RUTA_WINDOWS.match(v) and LINUX:
            inf.falta(f"config.ini: [respaldos] {clave} es una ruta de Windows ({v})", "Cambiala por /mnt/respaldos (o la carpeta montada).")
            continue
        p = Path(v)
        try:
            p.mkdir(parents=True, exist_ok=True)
            prueba = p / ".prueba_escritura"
            prueba.write_text("ok")
            prueba.unlink()
            inf.ok(f"Respaldos: se puede escribir en {v}")
        except Exception as e:
            inf.falta(f"Respaldos: no se puede escribir en {v} ({e})", "Montá la carpeta con permiso de escritura para el usuario dgpdh.")
    if not c.get("sesiones", "clave_secreta", fallback="").strip():
        inf.aviso("config.ini sin [sesiones] clave_secreta: se genera una nueva y todos tienen que volver a ingresar")
    return c


def chequear_datos(inf, app=APP):
    datos = Path(app) / "datos"
    base = datos / "dgpdh.db"
    if not base.is_file():
        inf.falta(f"No está la base de datos ({base})", "Descomprimí el .zip de exportar_datos.py en /opt/dgpdh/dgpdh_web/")
        return
    try:
        prueba = datos / ".prueba_escritura"
        prueba.write_text("ok")
        prueba.unlink()
    except Exception as e:
        inf.falta(f"No se puede escribir en {datos} ({e})", "sudo chown -R dgpdh:dgpdh /opt/dgpdh/dgpdh_web/datos")
        return
    try:
        con = sqlite3.connect(f"file:{base}?mode=ro", uri=True, timeout=10)
        ok = con.execute("PRAGMA quick_check").fetchone()[0]
        notas = con.execute("SELECT COUNT(*) FROM notas").fetchone()[0]
        try:
            personas = con.execute("SELECT COUNT(*) FROM detenidos").fetchone()[0]
        except sqlite3.OperationalError:
            personas = 0
        win = 0
        for col in ("ruta_original", "ruta_despacho_pdf"):
            try:
                win += con.execute(f"SELECT COUNT(*) FROM notas WHERE {col} LIKE '%:\\%' OR {col} LIKE '\\\\%'").fetchone()[0]
            except sqlite3.OperationalError:
                pass
        con.close()
    except Exception as e:
        inf.falta(f"No se pudo abrir la base: {e}")
        return
    (inf.ok if ok == "ok" else inf.falta)(f"Base de datos: {notas} nota(s), {personas} persona(s) detenida(s), verificación «{ok}»")
    if win and LINUX:
        inf.aviso(f"{win} ruta(s) de archivos guardadas con formato de Windows", "Se corrigen solas al arrancar el sistema por primera vez (reubicar_rutas).")
    for sub in ("originales", "firmados", "despacho"):
        if not (datos / sub).is_dir():
            inf.aviso(f"No está la carpeta datos/{sub}", "Si en la PC existía, copiala: los documentos de las notas viven ahí.")


def chequear_libreoffice(inf):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe and not LINUX:
        for c in (r"C:\Program Files\LibreOffice\program\soffice.exe", r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"):
            if Path(c).is_file():
                exe = c
    if not exe:
        (inf.falta if LINUX else inf.aviso)("No está LibreOffice: sin Word, es lo que convierte a PDF y abre los .doc",
                                             "sudo apt install libreoffice-writer-nogui")
        return
    try:
        from docx import Document
        with tempfile.TemporaryDirectory() as tmp:
            d = Document(); d.add_paragraph("Prueba de conversión a PDF."); d.save(Path(tmp) / "prueba.docx")
            perfil = (Path(tmp) / "perfil").resolve().as_uri()
            subprocess.run([exe, f"-env:UserInstallation={perfil}", "--headless", "--convert-to", "pdf", "--outdir", tmp,
                            str(Path(tmp) / "prueba.docx")], capture_output=True, timeout=180)
            if (Path(tmp) / "prueba.pdf").is_file():
                inf.ok("LibreOffice convierte a PDF")
            else:
                inf.falta("LibreOffice no generó el PDF de prueba", "Probá a mano: soffice --headless --convert-to pdf archivo.docx")
    except Exception as e:
        inf.falta(f"LibreOffice falló: {e}")


def chequear_fuentes(inf):
    if not LINUX:
        return
    if not shutil.which("fc-list"):
        inf.aviso("No pude listar las fuentes (falta fc-list)", "sudo apt install fontconfig")
        return
    salida = subprocess.run(["fc-list"], capture_output=True, text=True).stdout.lower()
    faltan = [n for n, claves in (("Arial/Times (o Liberation)", ("liberation", "arial")), ("Calibri/Cambria (o Carlito/Caladea)", ("carlito", "calibri")))
              if not any(k in salida for k in claves)]
    if faltan:
        inf.aviso("Faltan fuentes compatibles con Word: " + ", ".join(faltan) + " (los PDF pueden cambiar de diagramación)",
                  "sudo apt install fonts-liberation fonts-crosextra-carlito fonts-crosextra-caladea")
    else:
        inf.ok("Fuentes compatibles con Word instaladas")


def chequear_languagetool(inf):
    java = shutil.which("java")
    if not java:
        inf.aviso("No está Java: el corrector LanguageTool no va a funcionar (el resto sí)", "sudo apt install default-jre-headless")
    else:
        inf.ok("Java instalado (para LanguageTool)")
    lt = os.environ.get("LTP_PATH") or str(Path.home() / ".cache" / "language_tool_python")
    p = Path(lt)
    if p.is_dir() and any(x.name.lower().startswith("languagetool") for x in p.iterdir()):
        inf.ok(f"LanguageTool ya está en {p} (no se descarga de internet)")
    else:
        inf.aviso(f"LanguageTool no está en {p}: al arrancar intentaría descargarlo de internet",
                  "Copiá la carpeta «languagetool» del .zip de exportar_datos.py a /opt/dgpdh/languagetool")


def chequear_ollama(inf, c):
    url = (c.get("ollama", "url", fallback="http://127.0.0.1:11434/api/generate") if c else "http://127.0.0.1:11434/api/generate").strip()
    usar = c.getboolean("ollama", "usar_ia", fallback=True) if c else True
    if not usar:
        inf.ok("IA desactivada en config.ini (usar_ia = false)")
        return
    base = re.sub(r"localhost", "127.0.0.1", url.split("/api/")[0])
    try:
        with urllib.request.urlopen(base + "/api/tags", timeout=4) as r:
            modelos = {m.get("name", "") for m in json.loads(r.read().decode()).get("models", [])}
    except Exception as e:
        inf.aviso(f"Ollama no responde en {base} ({e}): el sistema funciona sin IA", "Instalá Ollama en el servidor y arrancalo (systemctl status ollama).")
        return
    pedidos = {c.get("ollama", "modelo", fallback="qwen2.5:7b")} if c else set()
    if c and c.has_section("ollama"):
        pedidos |= {v for k, v in c.items("ollama") if k.startswith("modelo_") and v.strip()}
    faltan = [m for m in pedidos if m not in modelos and f"{m}:latest" not in modelos]
    if faltan:
        inf.aviso("Ollama responde pero faltan modelos: " + ", ".join(faltan), "ollama pull " + " && ollama pull ".join(faltan))
    else:
        inf.ok(f"Ollama responde con los modelos configurados ({', '.join(sorted(pedidos))})")


def chequear_varios(inf, app=APP):
    if (Path(app) / "static" / "htmx.min.js").is_file():
        inf.ok("htmx local (las pantallas no piden nada a internet)")
    else:
        inf.aviso("Falta static/htmx.min.js: el navegador lo pide a internet",
                  "Descargá https://cdnjs.cloudflare.com/ajax/libs/htmx/1.9.12/htmx.min.js y guardalo en static/htmx.min.js")
    sh = Path(app) / "linux" / "iniciar.sh"
    if sh.is_file() and b"\r\n" in sh.read_bytes():
        inf.aviso("linux/iniciar.sh tiene saltos de línea de Windows", "sed -i 's/\\r$//' linux/iniciar.sh && chmod +x linux/iniciar.sh")
    if LINUX:
        tz = os.environ.get("TZ") or (Path("/etc/timezone").read_text().strip() if Path("/etc/timezone").is_file() else "")
        if not tz:  # Ubuntu nuevo ya no trae /etc/timezone: se mira a dónde apunta /etc/localtime
            try:
                tz = os.path.realpath("/etc/localtime").split("zoneinfo/", 1)[-1] if "zoneinfo/" in os.path.realpath("/etc/localtime") else ""
            except OSError:
                tz = ""
        if "Buenos_Aires" in tz:
            inf.ok(f"Zona horaria: {tz}")
        else:
            inf.aviso(f"Zona horaria «{tz or 'desconocida'}»: el servicio usa la de Buenos Aires, pero conviene que el servidor también",
                      "sudo timedatectl set-timezone America/Argentina/Buenos_Aires")


def verificar(app=APP, imprimir=True):
    inf = Informe(imprimir)
    if imprimir:
        print(f"Verificación del sistema DGPDH en {app} ({sys.platform})\n")
    chequear_python(inf)
    c = chequear_config(inf, app)
    chequear_datos(inf, app)
    chequear_libreoffice(inf)
    chequear_fuentes(inf)
    chequear_languagetool(inf)
    chequear_ollama(inf, c)
    chequear_varios(inf, app)
    if imprimir:
        print("\n" + ("Todo listo para arrancar." if not inf.faltas else f"Hay {len(inf.faltas)} punto(s) en FALTA para resolver antes de usar el sistema."))
    return inf


if __name__ == "__main__":
    sys.exit(1 if verificar().faltas else 0)
