# Migración del sistema DGPDH al servidor Linux (Ubuntu 24.04)

Esta carpeta trae todo lo necesario para mudar el sistema de la PC actual (Windows) al servidor:

| Archivo | Para qué |
|---|---|
| `exportar_datos.py` | En la **PC actual**: arma un .zip con la base (copia consistente y verificada), los documentos y el corrector LanguageTool. |
| `verificar_servidor.py` | En el **servidor**: revisa que esté todo (paquetes, LibreOffice, fuentes, Java, Ollama, firma, respaldos, base) y dice qué falta. No cambia nada. |
| `dgpdh.service` | Servicio de systemd (un solo proceso; arranca solo y se reinicia si se cae). |
| `nginx-dgpdh.conf` | HTTPS en el puerto 443 hacia la app. |
| `iniciar.sh` | Arranque manual para pruebas. |

La app es la misma en Windows y en Linux: no hay que cambiar código. En Linux, LibreOffice reemplaza a Word para los PDF y los .doc.

## 1. Preparar el servidor (una vez)

```bash
sudo apt update
sudo apt install -y python3-venv libreoffice-writer-nogui default-jre-headless fontconfig \
     fonts-liberation fonts-crosextra-carlito fonts-crosextra-caladea nginx cifs-utils unzip
sudo timedatectl set-timezone America/Argentina/Buenos_Aires
sudo useradd --system --home /opt/dgpdh --shell /usr/sbin/nologin dgpdh
sudo mkdir -p /opt/dgpdh && sudo chown dgpdh:dgpdh /opt/dgpdh
```

Las carpetas compartidas (firma y respaldos) se montan como dice la guía (sección A: `/mnt/firma` y `/mnt/respaldos`).

**IA local:** instalar Ollama en el servidor y bajar los mismos modelos que usa la PC (los que figuran en `config.ini`, sección `[ollama]`), por ejemplo `ollama pull phi3:mini`. Sin Ollama el sistema funciona igual, sin IA.

## 2. Instalar la aplicación

1. Copiar la carpeta `dgpdh_web` **sin `datos\`** a `/opt/dgpdh/dgpdh_web` (WinSCP o scp). Incluye `config.ini`.
2. Entorno de Python:
   ```bash
   sudo -u dgpdh python3 -m venv /opt/dgpdh/venv
   sudo -u dgpdh /opt/dgpdh/venv/bin/pip install -r /opt/dgpdh/dgpdh_web/requirements.txt
   ```
3. **htmx local:** guardar `htmx.min.js` en `/opt/dgpdh/dgpdh_web/static/` (ver la guía; si ya está en la PC, viaja con la carpeta).
4. Editar `/opt/dgpdh/dgpdh_web/config.ini` en el servidor:
   - `[firma] archivo_firma = /mnt/firma/firma_director.PNG` (la ruta de Windows `\\fsppn\...` no sirve en Linux);
   - `[respaldos] copia_externa = /mnt/respaldos` (si se usa);
   - no cambiar `[sesiones] clave_secreta` (así nadie tiene que volver a ingresar).

## 3. Mudar los datos (el día del cambio)

1. En la PC actual, **cerrar el sistema** (ventana de iniciar.bat) para que nadie cargue nada después de la copia.
2. En la PC, desde la carpeta `dgpdh_web`:
   ```
   python linux\exportar_datos.py
   ```
   Deja `migracion_dgpdh_AAAAMMDD_HHMM.zip` al lado de la carpeta `dgpdh_web` y muestra el MANIFIESTO (cantidad de archivos y huella de la base). Con `--con-respaldos` incluye también los respaldos viejos.
3. Copiar el .zip al servidor y descomprimir:
   ```bash
   cd /opt/dgpdh/dgpdh_web && sudo -u dgpdh unzip /ruta/migracion_dgpdh_*.zip
   sudo -u dgpdh mv languagetool /opt/dgpdh/languagetool
   sudo chown -R dgpdh:dgpdh /opt/dgpdh
   ```
   Las rutas de los documentos guardadas con formato de Windows se corrigen solas en el primer arranque.
4. Verificar:
   ```bash
   cd /opt/dgpdh/dgpdh_web && sudo -u dgpdh LTP_PATH=/opt/dgpdh/languagetool /opt/dgpdh/venv/bin/python linux/verificar_servidor.py
   ```
   Resolver todo lo que diga **[FALTA]**. Los **[AVISO]** se pueden dejar para después.

## 4. Arrancar

```bash
sudo cp /opt/dgpdh/dgpdh_web/linux/dgpdh.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now dgpdh
sudo systemctl status dgpdh          # debe decir active (running)
tail -f /opt/dgpdh/dgpdh_web/datos/registro_sistema.log
```

nginx y el certificado: ver `nginx-dgpdh.conf` (comentarios al principio).

Probar desde otra PC: ingresar, abrir una nota, generar un PDF, buscar una persona detenida, abrir Revisión de la base. Si todo anda, la PC vieja queda apagada (no borrar sus datos hasta pasada una semana).

**Volver atrás:** si algo falla el día del cambio, alcanza con volver a abrir iniciar.bat en la PC actual: sus datos no se tocaron.
