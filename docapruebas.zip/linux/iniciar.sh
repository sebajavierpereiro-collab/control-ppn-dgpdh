#!/usr/bin/env bash
# Arranque manual en Linux (para pruebas). En producción se usa el servicio dgpdh.service.
cd "$(dirname "$0")/.." || exit 1
export TZ=America/Argentina/Buenos_Aires LANG=C.UTF-8 PYTHONUNBUFFERED=1
export LTP_PATH="${LTP_PATH:-/opt/dgpdh/languagetool}"
exec ../venv/bin/python -m uvicorn main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips 127.0.0.1
