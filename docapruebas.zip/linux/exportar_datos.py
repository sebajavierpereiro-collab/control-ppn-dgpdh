"""Exporta los datos del sistema para llevarlos al servidor Linux (se corre en la PC actual, con Windows).

    python linux\\exportar_datos.py                  (deja el .zip al lado de la carpeta dgpdh_web)
    python linux\\exportar_datos.py --con-respaldos  (incluye también datos\\respaldos, que puede ser grande)

Qué hace:
  - Copia la base (datos\\dgpdh.db) con la copia en caliente de SQLite: queda consistente aunque el sistema esté
    funcionando. Igual conviene hacerlo con el sistema cerrado, para que nadie cargue nada después de la copia.
  - Verifica la copia (integrity_check) antes de guardarla.
  - Suma todas las carpetas de datos (originales, firmados, despacho, bases_cargadas, etc.), sin los archivos de trabajo
    del momento (-wal, -shm, trabajador.lock).
  - Suma la carpeta del corrector LanguageTool que ya está descargada en esta PC, para que el servidor no tenga que
    bajarla de internet.
  - Escribe un MANIFIESTO.txt con lo que se copió y la huella SHA-256 de la base.

Nada sale de la PC: el .zip queda en el disco y se lleva al servidor a mano (WinSCP, scp o un disco).
Tiene datos personales: guardalo y borralo con el mismo cuidado que la base.
"""
import argparse
import hashlib
import os
import sqlite3
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

APP = Path(__file__).resolve().parent.parent
DATOS = APP / "datos"
SALTEAR = {"dgpdh.db", "dgpdh.db-wal", "dgpdh.db-shm", "trabajador.lock"}


def carpeta_languagetool():
    """Donde language_tool_python guarda LanguageTool (LTP_PATH o ~/.cache/language_tool_python)."""
    p = os.environ.get("LTP_PATH")
    candidatos = [Path(p)] if p else []
    try:  # la propia librería sabe dónde lo guarda (cambia según la versión y el sistema)
        from language_tool_python import download_lt
        for nombre in ("get_language_tool_download_path", "get_download_path"):
            f = getattr(download_lt, nombre, None)
            if f:
                candidatos.append(Path(f()))
    except Exception:
        pass
    candidatos.append(Path.home() / ".cache" / "language_tool_python")
    for var in ("LOCALAPPDATA", "APPDATA"):  # Windows
        if os.environ.get(var):
            candidatos.append(Path(os.environ[var]) / "language_tool_python")
    return next((c for c in candidatos if c.is_dir() and any(c.iterdir())), None)


def copiar_base(origen, destino):
    o = sqlite3.connect(origen, timeout=30)
    try:
        d = sqlite3.connect(destino)
        with d:
            o.backup(d)
        ok = d.execute("PRAGMA integrity_check").fetchone()[0]
        # en el servidor arranca sin modo WAL pendiente: un solo archivo
        d.execute("PRAGMA journal_mode = DELETE")
        d.close()
    finally:
        o.close()
    if ok != "ok":
        raise RuntimeError(f"La copia de la base no pasó la verificación: {ok}")


def huella(ruta):
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest()


def exportar(destino_zip=None, con_respaldos=False, datos=DATOS, lt=None, avisar=print):
    datos = Path(datos)
    if not (datos / "dgpdh.db").is_file():
        raise FileNotFoundError(f"No encontré la base en {datos / 'dgpdh.db'}")
    destino_zip = Path(destino_zip or APP.parent / f"migracion_dgpdh_{datetime.now():%Y%m%d_%H%M}.zip")
    lt = lt if lt is not None else carpeta_languagetool()
    manifiesto = [f"Exportación para el servidor Linux — {datetime.now():%d/%m/%Y %H:%M}", f"Origen: {datos}"]
    archivos = 0
    with tempfile.TemporaryDirectory() as tmp:
        copia = Path(tmp) / "dgpdh.db"
        avisar("Copiando la base…")
        copiar_base(datos / "dgpdh.db", copia)
        manifiesto.append(f"dgpdh.db: {copia.stat().st_size} bytes · SHA-256 {huella(copia)}")
        with zipfile.ZipFile(destino_zip, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            z.write(copia, "datos/dgpdh.db")
            for raiz, carpetas, nombres in os.walk(datos):
                rel = Path(raiz).relative_to(datos)
                if not con_respaldos and rel.parts[:1] == ("respaldos",):
                    carpetas[:] = []
                    continue
                for n in nombres:
                    if rel == Path(".") and n in SALTEAR:
                        continue
                    z.write(Path(raiz) / n, (Path("datos") / rel / n).as_posix())
                    archivos += 1
            manifiesto.append(f"Archivos de datos (sin la base): {archivos}" + ("" if con_respaldos else " · sin datos/respaldos"))
            if lt:
                n_lt = 0
                for raiz, _, nombres in os.walk(lt):
                    for n in nombres:
                        z.write(Path(raiz) / n, (Path("languagetool") / Path(raiz).relative_to(lt) / n).as_posix())
                        n_lt += 1
                manifiesto.append(f"LanguageTool: {n_lt} archivo(s) de {lt} → /opt/dgpdh/languagetool")
            else:
                manifiesto.append("LanguageTool: no se encontró en esta PC (el servidor lo tendría que descargar)")
            z.writestr("MANIFIESTO.txt", "\n".join(manifiesto) + "\n")
    # el manifiesto también queda al lado del .zip, para revisarlo sin abrirlo
    try:
        Path(str(destino_zip) + ".MANIFIESTO.txt").write_text("\n".join(manifiesto) + "\n", encoding="utf-8")
    except Exception:
        pass
    avisar("\n".join(manifiesto))
    avisar(f"\nListo: {destino_zip}")
    return destino_zip


if __name__ == "__main__":
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--con-respaldos", action="store_true", help="incluir datos/respaldos")
    a.add_argument("--destino", help="ruta del .zip a generar")
    args = a.parse_args()
    try:
        exportar(args.destino, args.con_respaldos)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)
