"""Propuesta 93: esperado ajustado por los días disponibles de cada persona (no reemplaza al lineal ni cambia la meta)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import calendario as cal
from dgpdh.dominio import metas_calculo as mc


def test_dominio() -> None:
    hoy = date(2026, 6, 30)
    lic = {d for d in cal.dias(date(2026, 3, 1), date(2026, 4, 30)) if cal.es_habil(d)}
    base = mc.proyectar(100, 0, 2026, hoy).esperado_habil
    aj = mc.esperado_ajustado(100, 2026, hoy, (), lic)
    total = cal.habiles_entre(date(2026, 1, 1), date(2026, 12, 31))
    assert aj == (100 * (cal.habiles_entre(date(2026, 1, 1), hoy) - len(lic))) // total and aj < base
    assert mc.esperado_ajustado(100, 2026, hoy, (), ()) is None and mc.esperado_ajustado(0, 2026, hoy, (), lic) is None


def test_en_seguimiento(base: Any) -> None:
    import auth
    import metas
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    eq = db.crear_equipo("Eq Aj")
    a = db.obtener_usuario(db.crear_usuario("aj1", h, s, "Aj Uno", "ASESOR", eq))
    b = db.obtener_usuario(db.crear_usuario("aj2", h, s, "Aj Dos", "ASESOR", eq))
    metas.guardar_metas_anuales(2026, {eq: {"monitoreos": 100}}, direc)
    with db._conexion() as con:
        imp = con.execute("INSERT INTO personal_importaciones (archivo, creado_en) VALUES ('p.xlsx', 'x')").lastrowid
        for k in range(30):
            d = date(2026, 3, 2) + timedelta(days=k)
            con.execute("INSERT INTO personal_novedades (importacion_id, persona, usuario_id, fecha, novedad, clase) VALUES (?, 'Aj Uno', ?, ?, 'L', 'LICENCIA')",
                        (imp, a["id"], d.isoformat()))
    x = metas.seguimiento(2026, [{"id": eq, "nombre": "Eq Aj"}], date(2026, 6, 30))["equipos"][0]
    pp = {p["usuario"]["id"]: p for p in x["por_persona"]}
    da, db_ = pp[a["id"]]["indicadores"]["monitoreos"], pp[b["id"]]["indicadores"]["monitoreos"]
    assert da["esperado_ajustado"] is not None and da["esperado_ajustado"] < da["esperado"] and pp[a["id"]]["dias_ausente"] == 30
    assert db_["esperado_ajustado"] is None, "sin datos de Personal no se ajusta"
    assert da["meta"] == 100 and da["estado"] == db_["estado"], "el estado y la meta no cambian"
