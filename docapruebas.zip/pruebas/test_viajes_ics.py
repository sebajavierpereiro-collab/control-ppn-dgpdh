"""Propuesta 67: calendario .ics de mis viajes (RFC 5545)."""
from __future__ import annotations

from datetime import datetime, timezone

from dgpdh.dominio import calendario as cal
from dgpdh.dominio import ics


def test_calendario() -> None:
    e = [ics.Evento(5, "2026-11-17", "08:30", "14:00", "CPF I, Ezeiza", "CPF I; Ruta 205", "CONFIRMADO", 2, ("Ana Pérez", "Beto Ruiz")),
         ics.Evento(6, "2026-11-18", None, None, "U19", "", "A_CONFIRMAR", 0, ("Ana Pérez",)),
         ics.Evento(7, "2026-11-19", "09:00", "08:00", "U31", "", "CANCELADO", 1, ("Ana " * 30,))]
    t = ics.calendario(e, "Mis viajes", datetime(2026, 11, 14, 12, tzinfo=timezone.utc))
    assert t.startswith("BEGIN:VCALENDAR\r\n") and t.endswith("END:VCALENDAR\r\n")
    for x in ("UID:viaje-5@dgpdh", "DTSTART:20261117T083000", "DTEND:20261117T140000", "SUMMARY:Viaje a CPF I\\, Ezeiza",
              "STATUS:CONFIRMED", "SEQUENCE:2", "DTSTART:20261118T080000", "DTEND:20261118T120000", "STATUS:TENTATIVE", "STATUS:CANCELLED",
              "DTEND:20261119T130000", "LOCATION:CPF I\\; Ruta 205", "DTSTAMP:20261114T120000Z"):
        assert x in t, x
    assert all(len(linea.encode("utf-8")) <= 75 for linea in t.split("\r\n")), "líneas plegadas"
    assert [d.isoformat() for d, _ in cal.leer_ics(t)] == ["2026-11-17", "2026-11-18", "2026-11-19"], "se vuelve a leer bien"
