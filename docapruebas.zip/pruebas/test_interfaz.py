"""Propuestas 98–164 (interfaz): reglas puras y servicios de preferencias, sugerencias y borradores."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta, timezone
from importlib import util
from pathlib import Path

import pytest

from dgpdh.dominio import interfaz as dom
from dgpdh.errores import DatoInvalido
from dgpdh.servicios import interfaz as srv

RAIZ = Path(__file__).resolve().parent.parent


@pytest.fixture()
def con() -> sqlite3.Connection:
    c = sqlite3.connect(":memory:")
    c.execute("""CREATE TABLE auditoria (id INTEGER PRIMARY KEY, fecha TEXT, usuario_id INTEGER, usuario TEXT, accion TEXT, entidad TEXT,
                 entidad_id TEXT, antes TEXT, despues TEXT, motivo TEXT, ip TEXT, origen TEXT, hash TEXT, hash_previo TEXT)""")
    spec = util.spec_from_file_location("m0030", RAIZ / "dgpdh/persistencia/versiones/0030_interfaz.py")
    assert spec and spec.loader
    m = util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.aplicar(c)
    m.aplicar(c)  # se puede aplicar dos veces sin error
    return c


DIREC = {"id": 1, "nombre": "Director", "rol": "DIRECTOR"}
ASESORA = {"id": 2, "nombre": "Ana", "rol": "ASESOR"}


def test_etiquetas_sin_codigos_crudos() -> None:
    assert dom.etiqueta_estado("PARA_REMITIR") == "Para remitir (solo Mesa de Entradas)"
    assert dom.etiqueta_estado("ALGO_NUEVO") == "Algo nuevo"
    assert dom.etiqueta_estado(None) == "—"
    assert all("_" not in v for v in dom.ETIQUETAS_ESTADO.values())


def test_grupos_de_urgencia() -> None:
    hoy = date(2026, 11, 16)
    g = lambda v, p="NORMAL": dom.grupo_urgencia(v, p, hoy).clave  # noqa: E731
    assert g("2026-11-15") == "vencida" and g("2026-11-16") == "hoy" and g("2026-11-23") == "semana"
    assert g("2026-11-24") == "resto" and g(None, "URGENTE") == "urgente" and g("2026-12-30", "URGENTE") == "urgente"
    assert g("no es fecha") == "resto"
    filas = [{"id": 1, "vence": "2026-11-30"}, {"id": 2, "vence": "2026-11-16"}, {"id": 3, "vence": None, "prioridad_efectiva": "URGENTE"}]
    grupos = dom.agrupar_por_urgencia(filas, hoy)
    assert [x["grupo"] for x in grupos] == ["hoy", "urgente", "resto"]  # sin grupos vacíos y en orden fijo


def test_hace_y_antiguedad() -> None:
    ahora = datetime(2026, 11, 16, 12, 0, tzinfo=timezone.utc)
    assert dom.hace("2026-11-16T11:59:30+00:00", ahora) == "recién"
    assert dom.hace("2026-11-16T11:20:00+00:00", ahora) == "hace 40 min"
    assert dom.hace("2026-11-16T07:00:00", ahora) == "hace 5 h"
    assert dom.hace(ahora - timedelta(days=1, hours=1), ahora) == "ayer"
    assert dom.hace(ahora - timedelta(days=4), ahora) == "hace 4 días"
    assert dom.hace(ahora - timedelta(days=20), ahora) == "hace 2 semanas"
    assert dom.hace("", ahora) == "" and dom.hace("cualquier cosa", ahora) == ""
    assert dom.nivel_antiguedad(ahora - timedelta(days=8), ahora) == "rojo"
    assert dom.nivel_antiguedad(ahora - timedelta(days=3), ahora) == "ambar"


def test_mensajes_de_error_accionables() -> None:
    m = dom.mensaje_error(409, "Esta nota ya la firmó la Subdirectora.")
    assert m["actualizar"] and m["que_paso"].startswith("Esta nota") and "Actualizá" in m["que_hacer"]
    m = dom.mensaje_error(500, "Internal Server Error")
    assert m["que_paso"] == "Algo falló en el servidor." and "referencia" in m["que_hacer"]
    assert dom.mensaje_error(418)["que_hacer"]
    assert len(dom.referencia_soporte("x")) == 4


def test_destino_interno() -> None:
    assert dom.destino_interno("/traslados?x=1") == "/traslados?x=1"
    for malo in ("//evil.com", "https://x", "javascript:alert(1)", "/a\r\nSet-Cookie: x", "\\\\x", ""):
        assert dom.destino_interno(malo, "/") == "/"


def test_preferencias_por_defecto_y_guardado(con: sqlite3.Connection) -> None:
    assert srv.preferencias(con, DIREC)["atajos"] is True  # Dirección y Mesa: activados
    assert srv.preferencias(con, ASESORA)["atajos"] is False  # el resto: apagados
    p = srv.guardar_preferencias(con, ASESORA, {"atajos": True, "tema": "oscuro", "densidad": "compacta"})
    assert p["atajos"] and p["tema"] == "oscuro" and p["tema_guardado"] == "oscuro" and p["densidad"] == "compacta"
    assert srv.preferencias(con, ASESORA)["atajos"] is True
    assert con.execute("SELECT COUNT(*) FROM auditoria WHERE accion = 'Preferencias de pantalla'").fetchone()[0] == 1
    srv.guardar_preferencias(con, ASESORA, {"visto": {"resumen_dia": "2026-11-16"}})
    assert srv.preferencias(con, ASESORA)["vistos"] == {"resumen_dia": "2026-11-16"}
    assert con.execute("SELECT COUNT(*) FROM auditoria").fetchone()[0] == 1  # las marcas de lectura no ensucian la auditoría
    with pytest.raises(DatoInvalido):
        srv.guardar_preferencias(con, ASESORA, {"tema": "fucsia"})
    with pytest.raises(DatoInvalido):
        srv.guardar_preferencias(con, ASESORA, {"cualquiera": 1})


def test_sugerencias(con: sqlite3.Connection) -> None:
    sid = srv.registrar_sugerencia(con, ASESORA, "No encuentro el botón de subir", "/traslados")
    s = srv.listar_sugerencias(con)[0]
    assert s["id"] == sid and s["rol"] == "ASESOR" and s["url"] == "/traslados" and s["estado"] == "NUEVA"
    srv.registrar_sugerencia(con, ASESORA, "Algo más", "https://afuera")
    assert srv.listar_sugerencias(con)[0]["url"] == ""  # nunca guarda direcciones de afuera
    with pytest.raises(DatoInvalido):
        srv.registrar_sugerencia(con, ASESORA, "  ", "/")
    srv.atender_sugerencia(con, DIREC, sid)
    assert srv.listar_sugerencias(con, "ATENDIDA")[0]["atendida_por"] == "Director"


def test_borradores(con: sqlite3.Connection) -> None:
    assert srv.leer_borrador(con, ASESORA, "/traslados/nuevo") is None
    srv.guardar_borrador(con, ASESORA, "/traslados/nuevo", {"motivo": "Monitoreo"})
    b = srv.leer_borrador(con, ASESORA, "/traslados/nuevo")
    assert b and b["datos"] == {"motivo": "Monitoreo"}
    assert srv.leer_borrador(con, DIREC, "/traslados/nuevo") is None  # cada persona ve solo lo suyo
    srv.descartar_borrador(con, ASESORA, "/traslados/nuevo")
    assert srv.leer_borrador(con, ASESORA, "/traslados/nuevo") is None
    assert con.execute("SELECT COUNT(*) FROM ui_borradores").fetchone()[0] == 1  # baja lógica, la fila queda
    with pytest.raises(DatoInvalido):
        srv.guardar_borrador(con, ASESORA, "sin-barra", {})
    with pytest.raises(DatoInvalido):
        srv.guardar_borrador(con, ASESORA, "/x", {"t": "x" * (srv.MAX_BORRADOR + 1)})


def test_avisos_agrupados() -> None:
    hoy = date(2026, 11, 16)
    avisos = [{"id": 1, "texto": "Tenés 3 notas para firmar", "creada_en": "2026-11-16T13:00:00+00:00"},
              {"id": 2, "texto": "Se despachó tu nota", "creada_en": "2026-11-15T13:00:00+00:00"},
              {"id": 3, "texto": "Viaje para confirmar el martes", "creada_en": "2026-11-01T13:00:00+00:00"}]
    sec = dom.agrupar_avisos(avisos, hoy)
    assert [s["titulo"] for s in sec] == ["Te toca actuar", "Para que sepas"]
    assert [g["fecha"] for g in sec[0]["grupos"]] == ["Hoy", "Antes"] and sec[0]["grupos"][0]["avisos"][0]["accion"] == "Firmar"
    assert sec[1]["grupos"][0]["fecha"] == "Ayer"
    assert dom.normalizar("  GONZÁLEZ  Pérez ") == "gonzalez perez"
