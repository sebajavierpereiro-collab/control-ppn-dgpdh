"""Pedido del usuario: lo que Metas toma de los viajes se calcula una vez por día (foto) o a pedido; las cargas manuales se ven al
instante. Se mide cuántas consultas hace el panel."""
from __future__ import annotations

import time
from contextlib import contextmanager
from datetime import date, timedelta
from typing import Any


def _armar(db: Any) -> dict[str, Any]:
    import auth
    import metas
    import traslados as tr
    h, s = auth.generar_hash_clave("Clave1234")
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    eqs = []
    for k in range(12):
        e = db.crear_equipo(f"Equipo F{k}")
        eqs.append(e)
        for j in range(6):
            db.crear_usuario(f"f{k}_{j}", h, s, f"Persona {k} {j}", "ASESOR", e)
    us, un, hoy = db.listar_usuarios(), db.listar_unidades(), date.today()
    for d in range(1, 120, 3):
        f = hoy - timedelta(days=d)
        for k in range(0, 12, 2):
            p = [x for x in us if x.get("equipo_id") == eqs[k]][:2]
            tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": un[k]["id"]},
                           [{"usuario_id": x["id"], "nombre": x["nombre"], "equipo_nombre": f"Equipo F{k}", "auto_propio": 1} for x in p], p[0],
                           hoy=f - timedelta(days=9))
    metas.guardar_metas_anuales(hoy.year, {e: {"visitas_equipo": 40, "monitoreos": 20} for e in eqs}, direc)
    return {"eqs": eqs, "us": us, "direc": direc, "hoy": hoy}


def test_foto_y_consultas(base: Any) -> None:
    import metas
    import traslados as tr
    db = base
    g = _armar(db)
    hoy = g["hoy"]
    equipos = [e for e in db.listar_equipos() if e["id"] in g["eqs"]]
    cont = {"sql": 0, "con": 0}
    original = db._conexion

    @contextmanager
    def contado():  # type: ignore[no-untyped-def]
        cont["con"] += 1
        with original() as con:
            con.set_trace_callback(lambda q: cont.__setitem__("sql", cont["sql"] + 1))
            yield con
    db._conexion = contado
    try:
        metas.seguimiento(hoy.year, equipos)  # primer uso del día: arma la foto
        cont.update(sql=0, con=0)
        t = time.monotonic()
        s = metas.seguimiento(hoy.year, equipos)
        demora = time.monotonic() - t
        print(f"seguimiento de 12 equipos con la foto: {cont['con']} conexiones, {cont['sql']} sentencias, {demora:.3f} s")
        assert cont["con"] <= 12 and demora < 1.5, cont
    finally:
        db._conexion = original
    x = next(e for e in s["equipos"] if e["equipo"]["id"] == g["eqs"][0])
    hecho = next(f for f in x["filas"] if f["clave"] == "visitas_equipo")["hecho"]
    assert hecho > 0
    # un viaje nuevo de hoy no cambia la foto hasta el día siguiente o «Actualizar ahora»
    p = [u for u in g["us"] if u.get("equipo_id") == g["eqs"][0]][:1]
    ayer = hoy - timedelta(days=2) if (hoy - timedelta(days=2)).year == hoy.year else hoy
    tr.crear_viaje({"fecha": ayer.isoformat(), "unidad_id": db.listar_unidades()[5]["id"]},
                   [{"usuario_id": p[0]["id"], "nombre": p[0]["nombre"], "equipo_nombre": "Equipo F0", "auto_propio": 1}], p[0], hoy=ayer - timedelta(days=9))
    def visitas() -> int:
        e = metas.seguimiento(hoy.year, [x["equipo"]])["equipos"][0]
        return int(next(f for f in e["filas"] if f["clave"] == "visitas_equipo")["hecho"])
    assert visitas() == hecho, "la foto es del día"
    ok, msg = metas.actualizar_ahora(hoy.year, x["equipo"], {"nombre": "Ana"})
    assert not ok and "menos de un minuto" in msg
    with db._conexion() as con:
        con.execute("UPDATE metas_foto SET generado_en = ? WHERE equipo_id = ?", ((date.today() - timedelta(days=0)).isoformat() + "T00:00:00+00:00", x["equipo"]["id"]))
    ok, _ = metas.actualizar_ahora(hoy.year, x["equipo"], {"nombre": "Ana"})
    assert ok and visitas() in (hecho, hecho + 1)
    if ayer != hoy:
        assert visitas() == hecho + 1
    # las cargas manuales se ven al instante
    coo = [u for u in g["us"] if u.get("equipo_id") == g["eqs"][0]][1]
    metas.guardar_carga(g["eqs"][0], hoy.year, f"M{hoy.month:02d}", {(coo["id"], "monitoreos"): 3}, g["direc"])
    e = metas.seguimiento(hoy.year, [x["equipo"]])["equipos"][0]
    assert next(f for f in e["filas"] if f["clave"] == "monitoreos")["hecho"] == 3


def test_foto_de_otro_dia_se_rehace(base: Any) -> None:
    import metas
    db = base
    db.crear_equipo("Equipo Solo")
    metas.foto(2026)
    with db._conexion() as con:
        con.execute("UPDATE metas_foto SET generado_en = '2000-01-01T10:00:00+00:00'")
    metas.foto(2026)
    with db._conexion() as con:
        assert con.execute("SELECT MIN(generado_en) FROM metas_foto").fetchone()[0] > "2001"
