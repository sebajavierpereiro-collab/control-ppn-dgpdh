"""Propuestas 61 (odómetro) y 63 (rendimiento de combustible): avisan, no bloquean."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import flota_control as fc


def test_odometro() -> None:
    assert fc.avisos_odometro(1000, 1100, 900, None, 50) == []
    assert "menos que el último" in fc.avisos_odometro(800, 900, 1000, None, 50)[0]
    assert "distancia estimada" in fc.avisos_odometro(1000, 1400, None, 100.0, 50)[0]
    assert fc.avisos_odometro(1000, 1120, None, 100.0, 50) == []
    assert "regreso" in fc.avisos_odometro(1000, 900, None, None, 50)[0]
    assert fc.recorrido_km([(-34.6, -58.4)]) is None
    assert 40 < (fc.recorrido_km([(-34.60, -58.38), (-34.82, -58.53)], 1.0) or 0) < 70  # CABA–Ezeiza ida y vuelta


def test_rendimiento() -> None:
    cargas = [fc.Carga(f"R{i}", f"2026-01-{i + 1:02d}", 1000 + 400 * i, 40.0) for i in range(6)]
    cargas.append(fc.Carga("R9", "2026-01-20", 1000 + 400 * 5 + 150, 40.0))  # rinde 3,75 km/l (lo habitual es 10)
    r = fc.rendimientos(cargas, 25)
    assert [x.km_por_litro for x in r][:3] == [10.0, 10.0, 10.0] and not any(x.fuera for x in r[:5])
    assert r[-1].carga.id == "R9" and r[-1].fuera and r[-1].desvio_pct == -62
    assert fc.rendimientos(cargas[:3]) and fc.rendimientos(cargas[:3])[-1].mediana is None, "con pocas cargas no se compara"


def test_cierre_y_flota(base: Any) -> None:
    import auth
    import flota
    import operacion as op
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    coord = db.obtener_usuario(db.crear_usuario("cof", h, s, "Coord Flota", "ASESOR", db.crear_equipo("Eq F")))
    db.actualizar_usuario(coord["id"], "Coord Flota", "ASESOR", coord["equipo_id"], coordina_traslados=True)
    vid = tr.guardar_vehiculo(None, {"dominio": "FL100AA", "capacidad": "4"})
    hoy = date.today()
    for i in range(5):
        flota.registrar(vid, "COMBUSTIBLE", {"fecha": (hoy - timedelta(days=20 - i)).isoformat(), "km": str(1000 + 400 * i), "litros": "40"}, coord)
    flota.registrar(vid, "COMBUSTIBLE", {"fecha": hoy.isoformat(), "km": "2700", "litros": "40"}, coord)  # 2,5 km/l
    with db._conexion() as con:
        textos = [f[0] for f in con.execute("SELECT texto FROM notificaciones WHERE usuario_id = ?", (coord["id"],))]
    assert any(t.startswith("Revisar la carga de combustible de FL100AA") for t in textos), textos
    with db._conexion() as con:
        did = con.execute("INSERT INTO desplazamientos (fecha, vehiculo_id, creado_en) VALUES (?, ?, 'x')", (hoy.isoformat(), vid)).lastrowid
    avisos = op.cerrar_desplazamiento(did, {"km_salida": "2500", "km_regreso": "2600"}, "Chofer")
    assert any("menos que el último kilometraje" in a for a in avisos), avisos
    assert any("menos que el último kilometraje" in a["texto"] for a in op.anomalias(hoy.isoformat(), hoy.isoformat()))
