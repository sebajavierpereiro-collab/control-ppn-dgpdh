"""Propuesta 31: grupos de fichas conectadas (componentes)."""
from __future__ import annotations

from dgpdh.dominio import grupos as gr


def test_componentes() -> None:
    assert gr.componentes([(1, 2), (2, 3), (5, 4), (7, 7)]) == [[1, 2, 3], [4, 5]]
    assert gr.componentes([]) == []
    assert gr.sugerida([4, 5], lambda g: 5) == 5 and gr.sugerida([4, 5], lambda g: 99) == 4
