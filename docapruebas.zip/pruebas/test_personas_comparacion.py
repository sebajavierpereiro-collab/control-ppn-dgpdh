"""Propuestas 29, 32, 34 y 35: comparación de fichas de personas detenidas (frecuencia de nombres, clave fonética,
parecido y tolerancias en fechas). Datos ficticios."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

from dgpdh.dominio import personas as pe

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


@pytest.mark.parametrize(("a", "b"), [("vazquez", "basquez"), ("jimenez", "gimenez"), ("yanina", "llanina"), ("hernandez", "ernandez"),
                                      ("sosa", "zoza"), ("quiroga", "kiroga"), ("guerrero", "gerrero"), ("ascencio", "asencio"),
                                      ("barrios", "varrios"), ("cecilia", "sesilia")])
def test_clave_fonetica_iguala_errores_de_carga(a: str, b: str) -> None:
    assert pe.clave_fonetica(a) == pe.clave_fonetica(b)


def test_clave_fonetica_distingue_lo_que_suena_distinto() -> None:
    assert pe.clave_fonetica("gomez") != pe.clave_fonetica("lopez")
    assert pe.clave_fonetica("chavez") == "chabes" and pe.clave_fonetica("gonzalez") == "gonsales"
    assert pe.clave_fonetica("") == "" and pe.tokens_foneticos("") == frozenset()


def test_parecido() -> None:
    assert pe.parecido("juan perez", "perez juan") == 1.0
    assert 0.8 < pe.parecido("maria peres", "maria perez") < 1


def test_frecuencia() -> None:
    nombres = [f"juan gonzalez {i}" for i in range(300)] + ["kevin ramirez soto", "kevin ramirez"]
    f = pe.FrecuenciaNombres.desde(nombres)
    assert f.ajuste({"juan", "gonzalez"}) == (-10, "nombre muy común en la base (pesa menos)")
    assert f.ajuste({"kevin", "ramirez"})[0] == 8
    assert pe.FrecuenciaNombres.desde(["juan gonzalez"] * 10).ajuste({"juan", "gonzalez"}) == (0, None), "base chica: no ajusta"
    assert f.ajuste(set()) == (0, None)


@pytest.mark.parametrize(("a", "b", "esperado"), [
    ("1990-03-05", "1990-03-05", "igual"), ("1990-03-05", "1990-05-03", "invertida"), ("1990-03-05", "1991-03-05", "año"),
    ("1987-04-12", "1978-04-12", "año_invertido"), ("1905-04-12", "2005-04-12", "siglo"), ("1900-01-01", "1980-02-03", "dudosa"),
    ("1985-01-01", "1985-01-01", "dudosa"), ("1990-03-05", "1975-11-20", "distinta"), (None, "1990-01-01", None),
    ("1990-3-5", "1990-03-05", "distinta")])
def test_fechas(a: str | None, b: str | None, esperado: str | None) -> None:
    assert pe.comparar_fechas(a, b) == esperado


def _ficha(i: int, nombre: str, **k: Any) -> dict[str, Any]:
    import detenidos
    base = {"id": i, "nombre_completo": nombre, "nombre_norm": detenidos.norm_nombre(nombre), "dni": None, "lpu_norm": None,
            "doc_extranjero": None, "fecha_nacimiento": None, "nacionalidad": None, "unidad_id": None, "activo": 1}
    base.update(k)
    return base


def test_revision_encuentra_apellidos_que_suenan_igual() -> None:
    import revision_ia as ria
    a = _ficha(1, "Walter Vázquez", dni="30111222", fecha_nacimiento="1980-05-06")
    b = _ficha(2, "Walter Básquez", dni="30111221", fecha_nacimiento="1980-05-06", activo=0)
    c = _ficha(3, "Yanina Jiménez", lpu_norm="123456", fecha_nacimiento="1990-02-03")
    d = _ficha(4, "Llanina Giménez", fecha_nacimiento="1990-02-03")
    e = _ficha(5, "Walter Vega", dni="40999888", fecha_nacimiento="1999-09-09")
    pares, _ = ria.candidatos([a, c], [a, b, c, d, e])
    hallados = {frozenset((x["id"], y["id"])): m for x, y, p, m in pares}
    assert frozenset((1, 2)) in hallados and "nombre que suena igual (posible error de carga)" in hallados[frozenset((1, 2))]
    assert frozenset((3, 4)) in hallados, "las dos palabras suenan igual"
    assert not any(5 in par for par in hallados)


def test_frecuencia_y_fechas_en_comparar() -> None:
    import revision_ia as ria
    comunes = [_ficha(100 + i, f"Juan Carlos Gonzalez {i}") for i in range(300)]
    frec = pe.FrecuenciaNombres.desde([f["nombre_norm"] for f in comunes] + ["juan carlos gonzalez", "kevin ramirez soto"] * 2)
    x = _ficha(1, "Juan Carlos González", fecha_nacimiento="1987-04-12")
    y = _ficha(2, "Gonzalez Juan Carlos", fecha_nacimiento="1978-04-12")
    p_sin, _ = ria.comparar(x, y)
    p_con, motivos = ria.comparar(x, y, frec)
    assert p_con == p_sin - 10 and "nombre muy común en la base (pesa menos)" in motivos
    assert "fecha de nacimiento con los dígitos del año invertidos" in motivos
    k1, k2 = _ficha(3, "Kevin Ramírez Soto", nacionalidad="argentina"), _ficha(4, "Kevin Ramirez Soto", nacionalidad="paraguaya")
    p_raro, motivos = ria.comparar(k1, k2, frec)
    assert p_raro == 58 and "nombre poco frecuente en la base" in motivos
    assert ria.comparar(k1, k2)[0] == 0, "sin la frecuencia, la nacionalidad distinta lo dejaba afuera"
    r1, r2 = _ficha(5, "Pedro López", fecha_nacimiento="1970-01-01"), _ficha(6, "Pedro López", fecha_nacimiento="1999-09-09")
    assert "fecha de nacimiento dudosa (de relleno): no se tiene en cuenta" in ria.comparar(r1, r2)[1], "la fecha de relleno no resta"


def test_cuil_en_la_carga_solo_avisa(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import detenidos
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    dni, ext, aviso = detenidos.clasificar_documento("20-30123456-3")
    assert dni is None and ext == "20-30123456-3" and "contiene el DNI 30123456" in (aviso or ""), "no cambia cómo se guarda"
    assert "dígito verificador" in (detenidos.clasificar_documento("20301234561")[2] or "")
    assert "más de 8 dígitos" in (detenidos.clasificar_documento("1024538298")[2] or "")
    _, errores, _ = detenidos.validar({"nombre_completo": "Ana Gómez", "dni": "20301234563"})
    assert errores and "el DNI es 30123456" in errores[0]
    _, errores, avisos = detenidos.validar({"nombre_completo": "Ana Gómez", "dni": "31000000", "doc_extranjero": "20-30123456-3"})
    assert not errores and any("distinto del DNI de la ficha" in a for a in avisos)
    _, _, avisos = detenidos.validar({"nombre_completo": "Ana Gómez", "dni": "30123456", "doc_extranjero": "20-30123456-3"})
    assert not any("CUIL" in a for a in avisos)
