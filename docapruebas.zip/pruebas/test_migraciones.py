from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

import pytest

from dgpdh.persistencia import migraciones as mg


def _conectar(ruta: Path):  # type: ignore[no-untyped-def]
    @contextmanager
    def conectar() -> Iterator[sqlite3.Connection]:
        con = sqlite3.connect(ruta)
        try:
            yield con
            con.commit()
        finally:
            con.close()
    return conectar


def _carpeta(tmp: Path, archivos: dict[str, str]) -> Path:
    c = tmp / "versiones"
    c.mkdir(exist_ok=True)
    for nombre, texto in archivos.items():
        (c / nombre).write_text(texto, encoding="utf-8")
    return c


def test_aplica_en_orden_una_sola_vez(tmp_path: Path) -> None:
    carpeta = _carpeta(tmp_path, {
        "0002_tabla.sql": "-- tabla de prueba\nCREATE TABLE prueba (id INTEGER PRIMARY KEY, nombre TEXT);",
        "0001_base.py": "def aplicar(con):\n    con.execute('CREATE TABLE base (x INTEGER)')\n",
        "0003_columna.sql": "ALTER TABLE prueba ADD COLUMN extra TEXT; INSERT INTO prueba (nombre) VALUES ('a')",
        "notas.txt": "se ignora",
    })
    conectar = _conectar(tmp_path / "t.db")
    respaldos: list[int] = []
    hechas = mg.aplicar_pendientes(conectar, antes_de_migrar=lambda: respaldos.append(1), carpeta=carpeta)
    assert [h.numero for h in hechas] == [1, 2, 3] and respaldos == [1]
    assert mg.aplicar_pendientes(conectar, antes_de_migrar=lambda: respaldos.append(1), carpeta=carpeta) == []
    assert respaldos == [1], "sin pendientes no se hace respaldo"
    with conectar() as con:
        assert con.execute("SELECT nombre, extra FROM prueba").fetchall() == [("a", None)]
    assert mg.estado(conectar, carpeta) == {"version": 3, "aplicadas": 3, "pendientes": []}


def test_falla_deshace_solo_esa_y_frena(tmp_path: Path) -> None:
    carpeta = _carpeta(tmp_path, {
        "0001_ok.sql": "CREATE TABLE a (x INTEGER)",
        "0002_rota.sql": "CREATE TABLE b (x INTEGER); INSERT INTO tabla_que_no_existe VALUES (1)",
        "0003_despues.sql": "CREATE TABLE c (x INTEGER)",
    })
    conectar = _conectar(tmp_path / "t.db")
    with pytest.raises(mg.ErrorMigracion) as e:
        mg.aplicar_pendientes(conectar, carpeta=carpeta)
    assert "0002_rota.sql" in e.value.mensaje
    with conectar() as con:
        tablas = {f[0] for f in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    assert "a" in tablas and "b" not in tablas and "c" not in tablas, tablas
    assert mg.estado(conectar, carpeta)["pendientes"] == ["0002_rota", "0003_despues"]


def test_migracion_editada_despues_de_aplicada(tmp_path: Path) -> None:
    carpeta = _carpeta(tmp_path, {"0001_a.sql": "CREATE TABLE a (x INTEGER)"})
    conectar = _conectar(tmp_path / "t.db")
    mg.aplicar_pendientes(conectar, carpeta=carpeta)
    (carpeta / "0001_a.sql").write_text("CREATE TABLE a (x INTEGER, y INTEGER)", encoding="utf-8")
    with pytest.raises(mg.ErrorMigracion, match="cambió después de aplicada"):
        mg.aplicar_pendientes(conectar, carpeta=carpeta)


def test_numero_repetido_y_py_sin_aplicar(tmp_path: Path) -> None:
    carpeta = _carpeta(tmp_path, {"0001_a.sql": "SELECT 1", "0001_b.sql": "SELECT 1"})
    with pytest.raises(mg.ErrorMigracion, match="dos migraciones con el número 0001"):
        mg.disponibles(carpeta)
    carpeta2 = _carpeta(tmp_path / "otra", {}) if (tmp_path / "otra").mkdir() is None else tmp_path
    (carpeta2 / "0001_x.py").write_text("X = 1\n", encoding="utf-8")
    with pytest.raises(mg.ErrorMigracion, match="no tiene la función aplicar"):
        mg.aplicar_pendientes(_conectar(tmp_path / "t2.db"), carpeta=carpeta2)


def test_versiones_reales_del_proyecto() -> None:
    reales = mg.disponibles()
    nums = [m.numero for m in reales]
    assert reales and nums[0] == 1 and nums == sorted(set(nums)), "numeración creciente y sin repetidos (puede haber huecos: rangos por área)"


def test_con_la_base_real_del_sistema(tmp_path: Path) -> None:
    """database.inicializar_db() + migraciones con la conexión real (WAL, PRAGMA) y respaldo antes de migrar."""
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import database as db
    anterior = db.RUTA_DB
    db.RUTA_DB = tmp_path / "dgpdh.db"
    try:
        llamados: list[int] = []
        db.inicializar_db(antes_de_migrar=lambda: llamados.append(1))  # aplica las migraciones al final
        assert llamados == [1] and mg.estado(db._conexion)["pendientes"] == [] and mg.estado(db._conexion)["version"] >= 2
        db.inicializar_db(antes_de_migrar=lambda: llamados.append(1))
        assert llamados == [1], "sin migraciones pendientes no se respalda de nuevo"
        assert mg.aplicar_pendientes(db._conexion) == []
        with db._conexion() as con:
            assert con.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] >= 1, "el esquema histórico sigue intacto"
            con.execute("INSERT INTO ausencias (usuario_id, desde, hasta, delegado_id, creada_en) VALUES (1, '2026-11-01', '2026-11-05', 1, 'x')")
            aid = con.execute("SELECT MAX(id) FROM ausencias").fetchone()[0]
            assert db.borrar_con_registro(con, "ausencias", "id = ?", (aid,), motivo="prueba") == 1
            fila = con.execute("SELECT accion, entidad, antes FROM auditoria ORDER BY id DESC LIMIT 1").fetchone()
            assert (fila["accion"], fila["entidad"]) == ("Baja", "ausencias") and '"desde": "2026-11-01"' in fila["antes"]
    finally:
        db.RUTA_DB = anterior
