"""Propuestas 72 (llegué / ingresamos / salimos por parada) y 73 (constancia de que el viaje se hizo)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest

from dgpdh.errores import Conflicto, DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import viajes_campo as vc

HOY = date.today()
CHOFER = vc.Permiso(coordina=False, es_chofer_del_viaje=True, viaja=False)
VIAJERO = vc.Permiso(coordina=False, es_chofer_del_viaje=False, viaja=True)
COORD = vc.Permiso(coordina=True, es_chofer_del_viaje=False, viaja=False)
AJENO = vc.Permiso(coordina=False, es_chofer_del_viaje=False, viaja=False)


def _gente(db: Any) -> dict[str, Any]:
    import auth
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Campo")
    ana = db.obtener_usuario(db.crear_usuario("anac", h, s, "Ana Campo", "ASESOR", eq))
    return {"ana": ana, "eq": eq, "unidad": db.listar_unidades()[0]["id"]}


def _viaje(db: Any, g: dict[str, Any], fecha: date) -> int:
    import traslados as tr
    return int(tr.crear_viaje({"fecha": fecha.isoformat(), "unidad_id": g["unidad"], "hora_salida": "08:00", "hora_regreso": "14:00"},
                              [{"usuario_id": g["ana"]["id"], "nombre": g["ana"]["nombre"], "equipo_nombre": "Equipo Campo", "auto_propio": 1}],
                              g["ana"], hoy=fecha - timedelta(days=10)))


def test_eventos_de_parada(base: Any) -> None:
    db = base
    g = _gente(db)
    vid = _viaje(db, g, HOY)
    a = au.Actor(g["ana"]["id"], g["ana"]["nombre"])
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            vc.registrar_evento(con, a, AJENO, vid, "llegada", "09:10", HOY)
        with pytest.raises(DatoInvalido):
            vc.registrar_evento(con, a, VIAJERO, vid, "otra", "09:10", HOY)
        with pytest.raises(DatoInvalido):
            vc.registrar_evento(con, a, VIAJERO, vid, "llegada", "9.10", HOY)
        assert vc.registrar_evento(con, a, VIAJERO, vid, "llegada", "09:10", HOY) == "09:10"
        with pytest.raises(Conflicto, match="ya se marcó"):
            vc.registrar_evento(con, a, VIAJERO, vid, "llegada", "09:20", HOY)
        with pytest.raises(DatoInvalido, match="orden"):
            vc.registrar_evento(con, a, VIAJERO, vid, "ingreso", "09:00", HOY)
        vc.registrar_evento(con, a, VIAJERO, vid, "ingreso", "10:25", HOY)
        with pytest.raises(PermisoDenegado):
            vc.registrar_evento(con, a, VIAJERO, vid, "llegada", "09:00", HOY, correccion=True)
        vc.registrar_evento(con, au.Actor(9, "Coord"), COORD, vid, "llegada", "09:05", HOY, correccion=True)
        vc.registrar_evento(con, a, CHOFER, vid, "salida", "13:40", HOY)
        f = con.execute("SELECT llegada_unidad, ingreso_unidad, salida_unidad, constancia_origen FROM viajes WHERE id = ?", (vid,)).fetchone()
        assert tuple(f) == ("09:05", "10:25", "13:40", "CHOFER"), "«Salimos» del chofer deja la constancia"
        acciones = [x[0] for x in con.execute("SELECT accion FROM auditoria WHERE entidad = 'viaje' AND entidad_id = ? ORDER BY id", (str(vid),))]
        assert acciones[:3] == ["Llegamos a la unidad (registro)", "Ingresamos (registro)", "Llegamos a la unidad (corrección)"]
        assert "Constancia de realización" in acciones
        linea = [x[0] for x in con.execute("SELECT accion FROM traslados_auditoria WHERE entidad = 'viaje' AND entidad_id = ?", (vid,))]
        assert "Corrección: llegamos a la unidad" in linea and "Constancia: el viaje se hizo" in linea


def test_solo_el_dia_del_viaje_salvo_coordinacion(base: Any) -> None:
    db = base
    g = _gente(db)
    ayer = _viaje(db, g, HOY - timedelta(days=1))
    manana = _viaje(db, g, HOY + timedelta(days=1))
    a = au.Actor(1, "Ana")
    with db._conexion() as con:
        with pytest.raises(Conflicto, match="mismo día"):
            vc.registrar_evento(con, a, VIAJERO, ayer, "llegada", "09:00", HOY)
        vc.registrar_evento(con, a, COORD, ayer, "llegada", "09:00", HOY)
        with pytest.raises(Conflicto):
            vc.registrar_evento(con, a, COORD, manana, "llegada", "09:00", HOY)


def test_constancia_y_sin_constancia(base: Any) -> None:
    import tablero_direccion as td
    import traslados as tr
    db = base
    g = _gente(db)
    with db._conexion() as con:
        con.execute("UPDATE ajustes SET valor = ? WHERE clave = 'viajes_constancia_desde'", ((HOY - timedelta(days=60)).isoformat(),))
    viejo, reciente, otro = (_viaje(db, g, HOY - timedelta(days=20)), _viaje(db, g, HOY - timedelta(days=2)), _viaje(db, g, HOY - timedelta(days=30)))
    with db._conexion() as con:
        assert reciente not in vc.sin_constancia(con, HOY, 7) and vc.sin_constancia(con, HOY, 7) == [otro, viejo], "el de hace 2 días está en plazo"
        with pytest.raises(PermisoDenegado):
            vc.confirmar_realizado(con, au.Actor(1, "x"), AJENO, viejo, HOY)
        assert vc.confirmar_realizado(con, au.Actor(1, "Ana"), VIAJERO, viejo, HOY) is True
        assert vc.confirmar_realizado(con, au.Actor(1, "Ana"), VIAJERO, viejo, HOY) is False, "una sola constancia"
        assert vc.sin_constancia(con, HOY, 7) == [otro]
    # cargar las audiencias también deja la constancia (quien viajó)
    v = tr.obtener_viaje(otro)
    td.guardar_entrevistas(otro, {v["participantes"][0]["id"]: "3"}, g["ana"])
    with db._conexion() as con:
        assert vc.sin_constancia(con, HOY, 7) == []
        assert con.execute("SELECT constancia_origen FROM viajes WHERE id = ?", (otro,)).fetchone()[0] == "VIAJERO"
    t = td.tablero((HOY - timedelta(days=90)).isoformat(), HOY.isoformat())
    assert t["sin_constancia"] == [] and t["dias_constancia"] == 7
    _viaje(db, g, HOY - timedelta(days=15))
    t = td.tablero((HOY - timedelta(days=90)).isoformat(), HOY.isoformat())
    assert len(t["sin_constancia"]) == 1


def test_los_viajes_anteriores_a_la_version_no_se_marcan(base: Any) -> None:
    db = base
    g = _gente(db)
    _viaje(db, g, HOY - timedelta(days=20))
    with db._conexion() as con:
        assert vc.constancia_desde(con) == HOY.isoformat()
        assert vc.sin_constancia(con, HOY, 7) == [], "lo cargado antes de la puesta en marcha no se marca"


def test_cerrar_la_salida_deja_constancia(base: Any) -> None:
    import operacion as op
    import traslados as tr
    db = base
    g = _gente(db)
    vid = _viaje(db, g, HOY - timedelta(days=1))
    with db._conexion() as con:
        cur = con.execute("INSERT INTO desplazamientos (fecha, creado_en) VALUES (?, ?)", ((HOY - timedelta(days=1)).isoformat(), "x"))
        did = cur.lastrowid
        con.execute("UPDATE viajes SET desplazamiento_id = ? WHERE id = ?", (did, vid))
    op.cerrar_desplazamiento(did, {"salida_real": "08:00", "regreso_real": "14:00"}, "Pedro Chofer")
    assert tr.obtener_viaje(vid)["constancia_origen"] == "CIERRE"
