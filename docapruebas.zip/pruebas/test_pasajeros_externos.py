"""Modificación 4: pasajeros externos (ABM con baja lógica, categorías editables, vínculo con el viaje, nunca cuentan para metas)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest

from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import pasajeros_externos as px

A = au.Actor(1, "Coord")


def test_abm(base: Any) -> None:
    db = base
    with db._conexion() as con:
        cats = px.categorias(con)
        assert [c["nombre"] for c in cats] == ["Estudiante práctico Trabajo Social UBA", "Estudiante práctico Derecho", "Personal externo", "Invitado"]
        with pytest.raises(PermisoDenegado):
            px.guardar(con, A, False, {"nombre": "Ana", "apellido": "Pérez", "documento": "30111222", "categoria_id": str(cats[0]["id"])})
        for d, msg in (({"nombre": "A"}, "nombre y apellido"), ({"documento": "12"}, "documento"), ({"categoria_id": "999"}, "categoría")):
            base_d = {"nombre": "Ana", "apellido": "Pérez", "documento": "30.111.222", "categoria_id": str(cats[0]["id"])}
            with pytest.raises(DatoInvalido, match=msg):
                px.guardar(con, A, True, dict(base_d, **d))
        pid = px.guardar(con, A, True, {"nombre": "Ana", "apellido": "Pérez", "documento": "30.111.222", "categoria_id": str(cats[0]["id"]), "institucion": "UBA"})
        assert px.obtener(con, pid)["documento"] == "30111222"
        with pytest.raises(Conflicto):
            px.guardar(con, A, True, {"nombre": "Otra", "apellido": "Persona", "documento": "30111222", "categoria_id": str(cats[1]["id"])})
        assert px.etiqueta(px.obtener(con, pid)) == "Pérez, Ana · DNI 30111222 · Estudiante práctico Trabajo Social UBA"
        assert px.desde_etiqueta(con, "Pérez, Ana · DNI 30111222 · x")["id"] == pid and px.desde_etiqueta(con, "30111222")["id"] == pid
        assert px.listar(con, texto="pére") and not px.listar(con, texto="zzz")
        with pytest.raises(DatoInvalido):
            px.cambiar_activo(con, A, True, pid, False, "")
        px.cambiar_activo(con, A, True, pid, False, "Terminó la práctica")
        assert px.listar(con) == [] and px.desde_etiqueta(con, "30111222") is None and len(px.listar(con, True)) == 1
        px.cambiar_activo(con, A, True, pid, True)
        cid = px.guardar_categoria(con, A, True, "Perito de parte")
        with pytest.raises(Conflicto):
            px.guardar_categoria(con, A, True, "perito de parte")
        px.baja_categoria(con, A, True, cid)
        with pytest.raises(NoEncontrado):
            px.baja_categoria(con, A, True, cid)
        assert px.guardar_categoria(con, A, True, "Perito de parte") == cid, "se reactiva, no se duplica"
        assert con.execute("SELECT COUNT(*) FROM auditoria WHERE entidad IN ('pasajero_externo', 'pasajero_categoria')").fetchone()[0] == 6


def test_vinculo_ocupa_lugar_y_no_cuenta_para_metas(base: Any) -> None:
    import auth
    import metas
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Ext")
    ana = db.obtener_usuario(db.crear_usuario("anax", h, s, "Ana Ext", "ASESOR", eq))
    f = date.today() - timedelta(days=3)
    vid = tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": db.listar_unidades()[0]["id"]},
                         [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Equipo Ext", "auto_propio": 1},
                          {"nombre": "Lucía estudiante", "equipo_nombre": "Equipo Ext", "auto_propio": 0}], ana, hoy=f - timedelta(days=9))
    with db._conexion() as con:  # como si la coordinación le hubiera asignado chofer
        con.execute("UPDATE viajes SET estado = 'CONFIRMADO' WHERE id = ?", (vid,))
    v = tr.obtener_viaje(vid)
    p = next(x for x in v["participantes"] if not x["usuario_id"])
    with db._conexion() as con:
        cat = px.categorias(con)[0]["id"]
        pid = px.guardar(con, A, True, {"nombre": "Lucía", "apellido": "Gómez", "documento": "40222333", "categoria_id": str(cat)})
        with pytest.raises(PermisoDenegado):
            px.vincular(con, A, False, vid, int(p["id"]), pid)
        with pytest.raises(Conflicto):
            px.vincular(con, A, True, vid, next(x["id"] for x in v["participantes"] if x["usuario_id"]), pid)
        assert px.vincular(con, A, True, vid, int(p["id"]), pid) == "Lucía Gómez"
    v = tr.obtener_viaje(vid)
    q = next(x for x in v["participantes"] if x["id"] == p["id"])
    assert q["pasajero_externo_id"] == pid and q["equipo_nombre"] is None and q["usuario_id"] is None
    assert v["con_transporte"] == 1, "ocupa lugar en el vehículo"
    with metas.cache_de_pedido():
        via = metas.desde_viajes(f.year, date.today())
    assert not any(k[0] is None for k in via["persona"]) and sum(n for k, n in via["equipo"].items() if k[2] == "visitas_equipo") == 1
    import detenidos
    assert not hasattr(detenidos, "pasajeros_externos"), "no se cruza con la base de personas detenidas"
