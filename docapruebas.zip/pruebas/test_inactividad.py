"""Modificación 2: avisos cada 7 días y archivo a los 15, contados desde la última actividad (bordes)."""
from __future__ import annotations

from datetime import date, timedelta

import pytest

from dgpdh.dominio.inactividad import evaluar

D0 = date(2026, 11, 1)


@pytest.mark.parametrize(("dia", "aviso", "esperado"), [
    (0, None, "mantener"), (6, None, "mantener"), (7, None, "avisar"), (8, 7, "mantener"), (13, 7, "mantener"), (14, 7, "avisar"),
    (14, None, "avisar"), (15, 14, "archivar"), (15, None, "archivar"), (30, None, "archivar")])
def test_bordes(dia: int, aviso: int | None, esperado: str) -> None:
    d = evaluar(D0, D0 + timedelta(days=aviso) if aviso is not None else None, D0 + timedelta(days=dia))
    assert d.accion == esperado and d.dias == dia


def test_actividad_nueva_reinicia() -> None:
    nueva = D0 + timedelta(days=10)          # hubo un movimiento el día 10 (después del aviso del día 7)
    assert evaluar(nueva, D0 + timedelta(days=7), D0 + timedelta(days=15)).accion == "mantener", "no se archiva: la cuenta reinició"
    assert evaluar(nueva, D0 + timedelta(days=7), D0 + timedelta(days=17)).accion == "avisar", "el aviso viejo no cuenta"
    assert evaluar(nueva, None, D0 + timedelta(days=25)).accion == "archivar"
    assert "15 días" in evaluar(D0, None, D0 + timedelta(days=15)).motivo


def test_plazos_configurables() -> None:
    assert evaluar(D0, None, D0 + timedelta(days=3), dias_aviso=3, dias_archivo=5).accion == "avisar"
    assert evaluar(D0, None, D0 + timedelta(days=5), dias_aviso=3, dias_archivo=5).motivo == "Vencimiento por inactividad (5 días)"
