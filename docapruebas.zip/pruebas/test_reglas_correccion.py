"""Propuesta 16: cuenta de rechazos por regla de corrección, propuesta a la Dirección y desactivación (la decide una persona)."""
from __future__ import annotations

import asyncio
import sqlite3
import sys
import types
from pathlib import Path
from typing import Any

import pytest

from dgpdh.errores import DatoInvalido
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import reglas_correccion as rc

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
DIR = au.Actor(1, "Director General")


@pytest.fixture()
def con(tmp_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(tmp_path / "t.db")
    for m in mg.disponibles():
        m.aplicar(c)
    return c


def test_cuenta_y_propuesta(con: sqlite3.Connection) -> None:
    for i in range(12):
        rc.registrar_decision(con, nota_id=i, ubicacion="body:1", reglas=["lt:COMMA_PARENTHESIS", "dic:interno"], decision="rechazar",
                              motivo="no_era_error" if i % 2 else "inventado", usuario="Director")
    for i in range(3):
        rc.registrar_decision(con, nota_id=i, ubicacion="body:2", reglas=["lt:COMMA_PARENTHESIS"], decision="aceptar", motivo="sentido",
                              usuario="Director")
    rc.registrar_decision(con, nota_id=1, ubicacion="b", reglas=["ia:qwen2.5:7b"] * 2, decision="rechazar", motivo=None, usuario="x")
    usos = {u.regla: u for u in rc.resumen(con)}
    lt = usos["lt:COMMA_PARENTHESIS"]
    assert (lt.aceptadas, lt.rechazadas, lt.total) == (3, 12, 15) and lt.motivos == {"no_era_error": 6}, "motivo inválido o de aceptación no se guarda"
    assert usos["ia:qwen2.5:7b"].rechazadas == 1, "una regla repetida en el mismo párrafo cuenta una vez"
    props = [u.regla for u in rc.propuestas(con)]
    assert props == ["dic:interno", "lt:COMMA_PARENTHESIS"] or set(props) == {"dic:interno", "lt:COMMA_PARENTHESIS"}
    assert "ia:qwen2.5:7b" not in props
    assert not rc.propuestas(con, minimo=13)
    assert lt.etiqueta == "Regla de ortografía y gramática: COMMA_PARENTHESIS"
    with pytest.raises(DatoInvalido):
        rc.registrar_decision(con, nota_id=1, ubicacion=None, reglas=["x:y"], decision="otra", motivo=None, usuario=None)


def test_desactivar_y_reactivar_quedan_en_la_auditoria(con: sqlite3.Connection) -> None:
    rc.cambiar_estado(con, "lt:COMMA_PARENTHESIS", desactivar=True, actor=DIR, motivo="marca mal los paréntesis")
    assert rc.desactivadas(con) == {"lt:COMMA_PARENTHESIS"}
    rc.cambiar_estado(con, "lt:COMMA_PARENTHESIS", desactivar=False, actor=DIR)
    assert rc.desactivadas(con) == set()
    acciones = [r[0] for r in con.execute("SELECT accion FROM auditoria WHERE entidad = 'regla_correccion' ORDER BY id")]
    assert acciones == ["Desactivar regla de corrección", "Reactivar regla de corrección"]
    for mala in ("", "sinprefijo", "ia:phi3:mini"):
        with pytest.raises(DatoInvalido):
            rc.cambiar_estado(con, mala, desactivar=True, actor=DIR)


class _Match:
    def __init__(self, offset: int, largo: int, reemplazo: str, regla: str) -> None:
        self.offset, self.errorLength, self.replacements, self.ruleId = offset, largo, [reemplazo], regla


class _LT:
    def check(self, texto: str) -> list[_Match]:
        i = texto.find("echo")
        return [_Match(i, 4, "hecho", "ES_HECHO")] if i >= 0 else []


def test_la_correccion_anota_y_respeta_las_reglas(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import nucleo
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    monkeypatch.setattr(nucleo, "USAR_LANGUAGETOOL", True)
    monkeypatch.setattr(nucleo, "tool", _LT())
    monkeypatch.setattr(nucleo, "ia_disponible", lambda p: False)
    monkeypatch.setattr(nucleo, "REGLAS_DESACTIVADAS", set())
    texto = "El interno denunció el echo ante la Unidad."
    final, cambios, _ = nucleo.generar_propuesta_parrafo(texto)
    reglas = {r for c in cambios for r in c.get("reglas", [])}
    assert "lt:ES_HECHO" in reglas and "dic:interno" in reglas and "hecho" in final
    with db._conexion() as c:
        rc.cambiar_estado(c, "lt:ES_HECHO", desactivar=True, actor=DIR)
        rc.cambiar_estado(c, "dic:interno", desactivar=True, actor=DIR)
    assert nucleo.recargar_reglas_desactivadas() == {"lt:ES_HECHO", "dic:interno"}
    final, cambios, _ = nucleo.generar_propuesta_parrafo(texto)
    assert final == texto and not cambios, "las reglas desactivadas no se proponen"
    # al aplicar la revisión se cuentan las reglas de los párrafos con propuesta
    import rutas_notas_ia
    decisiones = [{"id": 0, "ubicacion": "body:0", "decision": "rechazar", "original": "a", "propuesto": "b", "reglas": ["lt:OTRA", "dic:x"]},
                  {"id": 1, "ubicacion": "body:1", "decision": "aceptar", "original": "c", "propuesto": "d", "reglas": ["lt:OTRA"]},
                  {"id": 2, "ubicacion": "body:2", "decision": "rechazar", "original": "e", "propuesto": "e", "reglas": ["lt:NADA"]}]
    rutas_notas_ia.registrar_reglas_revision(7, decisiones, {0: "nombre_propio"}, {"nombre": "Director General"})
    with db._conexion() as c:
        usos = {u.regla: u for u in rc.resumen(c)}
    assert usos["lt:OTRA"].rechazadas == 1 and usos["lt:OTRA"].aceptadas == 1 and usos["lt:OTRA"].motivos == {"nombre_propio": 1}
    assert "lt:NADA" not in usos, "sin propuesta no hay nada que contar"


def test_rutas_solo_direccion(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import rutas_notas_ia
    from starlette import responses
    fa = types.ModuleType("fastapi")
    fa.Request = object  # type: ignore[attr-defined]
    fa.HTTPException = type("HTTPException", (Exception,), {})  # type: ignore[attr-defined]
    fr = types.ModuleType("fastapi.responses")
    fr.RedirectResponse = responses.RedirectResponse  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "fastapi", fa)
    monkeypatch.setitem(sys.modules, "fastapi.responses", fr)
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    rutas: dict[str, Any] = {}

    class App:
        def post(self, ruta: str, **k: Any) -> Any:
            def deco(f: Any) -> Any:
                rutas[ruta] = f
                return f
            return deco

        def get(self, ruta: str, **k: Any) -> Any:
            return lambda f: rutas.setdefault("GET " + ruta, f)

    class Prohibido(Exception):
        pass

    def exigir_rol(u: dict[str, Any] | None) -> None:
        if not u or u.get("rol") != "DIRECTOR":
            raise Prohibido()
    plantillas = types.SimpleNamespace(env=types.SimpleNamespace(globals={}))
    rutas_notas_ia.registrar(App(), {"templates": plantillas, "usuario_actual": lambda r: r.usuario, "exigir_rol": exigir_rol})

    def pedido(usuario: dict[str, Any], datos: dict[str, str]) -> Any:
        async def form() -> dict[str, str]:
            return datos
        return types.SimpleNamespace(usuario=usuario, session={}, form=form)
    with pytest.raises(Prohibido):
        asyncio.run(rutas["/admin/ia/reglas/desactivar"](pedido({"rol": "ASESOR", "nombre": "Ana"}, {"regla": "lt:X"})))
    r = pedido({"id": 1, "rol": "DIRECTOR", "nombre": "Director General"}, {"regla": "lt:X", "motivo": "molesta"})
    asyncio.run(rutas["/admin/ia/reglas/desactivar"](r))
    assert "desactivada" in r.session["flash_admin"]
    r = pedido({"id": 1, "rol": "DIRECTOR", "nombre": "Director General"}, {"regla": "ia:modelo"})
    asyncio.run(rutas["/admin/ia/reglas/desactivar"](r))
    assert "no se puede desactivar" in r.session["flash_admin"]
    datos = plantillas.env.globals["reglas_correccion_datos"]()
    assert [u.regla for u in datos["desactivadas"]] == []  # sin usos registrados no aparece en el resumen, pero sí en el estado
    with db._conexion() as c:
        assert rc.desactivadas(c) == {"lt:X"}
