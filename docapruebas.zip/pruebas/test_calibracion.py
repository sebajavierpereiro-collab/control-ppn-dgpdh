"""Propuestas 30 y 41: calibración con lo decidido (informe) y orden «para decidir primero»."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from dgpdh.dominio import calibracion as cal

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_incertidumbre() -> None:
    dudosa = cal.incertidumbre(58, "dudosa", 50, ambas_activas=True, umbral=55)
    clara = cal.incertidumbre(98, "misma", 95, ambas_activas=False, umbral=55)
    choque = cal.incertidumbre(90, "distinta", 80, ambas_activas=True, umbral=55)
    assert dudosa > clara and choque > clara
    assert cal.incertidumbre(None, None, None, ambas_activas=False, umbral=55) >= 0


def test_pesos_y_umbral() -> None:
    decisiones = ([(["mismo nombre", "DNI con un dígito distinto (1 / 2)"], True)] * 15 + [(["mismo nombre", "DNI distintos"], False)] * 10)
    w = {p.motivo: p for p in cal.pesos(decisiones)}
    assert w["DNI con un dígito distinto"].peso > 2 and w["DNI distintos"].peso < -2 and abs(w["mismo nombre"].peso) < 0.5
    assert cal.motivo_base("LPU con un dígito distinto (55 / 56)") == "LPU con un dígito distinto"
    u = cal.umbral_sugerido([(90, True)] * 15 + [(60, False)] * 10, 55)
    assert u and u.aciertos_actual == 0.6 and u.aciertos_sugerido == 1.0 and 61 <= u.sugerido <= 90
    assert cal.umbral_sugerido([(90, True)] * 5, 55) is None


def test_en_la_revision(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import revision_ia as ria
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    with db._conexion() as con:
        for i in range(25):
            misma = i < 15
            con.execute("""INSERT INTO detenidos_ia_propuestas (det_a, det_b, clave, puntaje, reglas, estado, decision, creado_en)
                           VALUES (?,?,?,?,?,?,?,?)""", (i, i + 100, f"dup:{i}:{i + 100}", 90 if misma else 60,
                                                        json.dumps(["mismo nombre", "DNI con un dígito distinto" if misma else "DNI distintos"]),
                                                        "ACEPTADA" if misma else "RECHAZADA", "unificar" if misma else "distintas", "x"))
    c = ria.calibracion()
    assert c["decisiones"] == 25 and c["umbral"].sugerido > 60 and c["pesos"][0].motivo in ("DNI con un dígito distinto", "DNI distintos")
    al = [{"propuesta": {"puntaje": 99, "veredicto": "misma", "confianza": 99}, "personas": [{"activo": 1}, {"activo": 0}]},
          {"propuesta": {"puntaje": 57, "veredicto": "dudosa", "confianza": 50}, "personas": [{"activo": 1}, {"activo": 1}]}]
    assert ria.ordenar_para_decidir_primero(al)[0]["propuesta"]["puntaje"] == 57
