"""Propuestas 4, 7 y 12: integraciones optativas con programas locales. Apagadas, no cambian nada; prendidas, solo localhost."""
from __future__ import annotations

import configparser
import os
import stat
import sys
from pathlib import Path

import pytest

from dgpdh.servicios import herramientas_locales as hl

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def _config(texto: str) -> configparser.ConfigParser:
    cp = configparser.ConfigParser()
    cp.read_string(texto)
    return cp


@pytest.fixture(autouse=True)
def limpio(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(hl, "UNOSERVER", dict(hl.UNOSERVER))
    monkeypatch.setattr(hl, "OCR", dict(hl.OCR))
    monkeypatch.setattr(hl, "LANGUAGETOOL", dict(hl.LANGUAGETOOL))


def _falso(carpeta: Path, nombre: str, script: str) -> Path:
    ruta = carpeta / nombre
    ruta.write_text("#!/bin/sh\n" + script, encoding="utf-8")
    ruta.chmod(ruta.stat().st_mode | stat.S_IEXEC)
    return ruta


def test_apagadas_por_defecto(tmp_path: Path) -> None:
    hl.configurar(_config(""), tmp_path)
    assert not hl.UNOSERVER["activo"] and not hl.OCR["activo"] and hl.LANGUAGETOOL["servidor"] is None
    assert hl.unoconvert(tmp_path / "a.doc", tmp_path / "a.docx", "docx") is False
    assert hl.copia_ocr(tmp_path / "a.pdf") is None


def test_solo_servicios_locales(tmp_path: Path) -> None:
    hl.configurar(_config("[libreoffice]\nunoserver = true\nunoserver_host = 10.1.2.3\n[languagetool]\nservidor = https://api.languagetool.org\n"), tmp_path)
    assert hl.UNOSERVER["host"] == "127.0.0.1" and hl.LANGUAGETOOL["servidor"] is None, "nada sale a la red"
    hl.configurar(_config("[languagetool]\nservidor = http://127.0.0.1:8081\n"), tmp_path)
    assert hl.LANGUAGETOOL["servidor"] == "http://127.0.0.1:8081"
    assert hl.es_local("http://localhost:8081") and not hl.es_local("http://192.168.0.2") and not hl.es_local(None)


def test_unoconvert_con_programa_falso(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    bin_ = tmp_path / "bin"
    bin_.mkdir()
    _falso(bin_, "unoconvert", 'eval ultimo=\\${$#}; echo convertido > "$ultimo"\n')
    monkeypatch.setenv("PATH", f"{bin_}{os.pathsep}{os.environ['PATH']}")
    hl.configurar(_config("[libreoffice]\nunoserver = true\n"), tmp_path)
    origen = tmp_path / "a.doc"
    origen.write_text("x")
    assert hl.unoconvert(origen, tmp_path / "a.docx", "docx") and (tmp_path / "a.docx").read_text().strip() == "convertido"
    _falso(bin_, "unoconvert", "exit 1\n")
    assert hl.unoconvert(origen, tmp_path / "b.docx", "docx") is False, "si falla, se sigue con LibreOffice"
    monkeypatch.setitem(hl.UNOSERVER, "comando", "no-existe-xyz")
    assert hl.unoconvert(origen, tmp_path / "c.docx", "docx") is False


def test_ocr_copia_aparte(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from pypdf import PdfWriter
    bin_ = tmp_path / "bin"
    bin_.mkdir()
    _falso(bin_, "ocrmypdf", 'eval entrada=\\${$(($#-1))}; eval salida=\\${$#}; cp "$entrada" "$salida"; echo "$@" > "$salida.args"\n')
    monkeypatch.setenv("PATH", f"{bin_}{os.pathsep}{os.environ['PATH']}")
    pdf = tmp_path / "escaneado.pdf"
    w = PdfWriter()
    w.add_blank_page(100, 100)
    with pdf.open("wb") as f:
        w.write(f)
    antes = pdf.read_bytes()
    hl.configurar(_config("[ocr]\nactivo = true\n"), tmp_path)
    copia = hl.copia_ocr(pdf)
    assert copia and copia.parent == tmp_path / "ocr" and copia != pdf and pdf.read_bytes() == antes, "el original no se toca"
    assert "-l spa" in Path(str(copia) + ".args").read_text() and "--output-type pdfa" in Path(str(copia) + ".args").read_text()
    assert hl.copia_ocr(pdf) == copia, "una sola vez por contenido"
    assert hl.texto_pdf(pdf) == ""  # la página en blanco no tiene texto ni con OCR falso
    assert hl.texto_pdf(pdf, permitir_ocr=False) == ""
