"""Lectura de las planillas trimestrales de salud mental y salud médica (datos sintéticos con el mismo formato)."""
from __future__ import annotations

from dgpdh.dominio import planillas_salud as ps

MENTAL = [(None, None, None, "Trimestre : 3 trimestre 2026", None, None),
          ("Detalle", "Junio/Julio", "Agosto", "Septiembre", None, "Total"),
          ("Cantidad de viajes", 4, 5, 6, None, 15),
          ("Entrevistas presenciales a PPL", 10, 11, 12, None, 33),
          ("Entrevistas telefónicas a PPL", 1, 0, 2, None, 3),
          ("Recorridas", 2, 1, 0, None, 3),
          ("Reuniones de trabajo", 3, 3, 3, None, 9),
          ("Monitoreo asistencial/entrevistas psicológicas y otros", 20, 21, 22, None, 63),
          ("Monitoreo de las prácticas de los equipos del SPF", 5, 6, 7, None, 18),
          ("Articulación de las demandas de salud mental de las PPL", 30, 31, 32, None, 93),
          ("Fila inventada", 1, 1, 1, None, 3)]

MEDICA = [(None, "MEDICOS", "Trimestre", "MES", "Entrevistas", "Relevamientos de historias clínicas", "Intervenciones", "Recomendaciones", "TOTAL"),
          (None, "PEREZ", 3, "JULIO", 5, 1, 2, 3, 11), (None, None, None, "AGOSTO", 6, 0, 0, 1, 7), (None, None, None, "SEPTIEMBRE", 0, 0, 0, 0, 0),
          (None, "GOMEZ", 3, "JULIO", 1, 2, 3, 4, 10), (None, None, None, "AGOSTO", 0, 0, 0, 0, 0), (None, None, None, "SEPTIEMBRE", 2, 2, 2, 2, 8),
          (None, "TOTAL", None, None, 14, 5, 7, 10, 36),
          (None, None, None, None, None, None, None, None, None),
          (None, "VISITAS A LAS UNIDADES", None, None, "INFORMES GOLPEADOS ", None),
          (None, "UNIDAD/COMPLEJO /HTAL", "3º TRIMESTRE ", None, "UNIDAD O COMPLEJO ", "3º TRIMESTRE "),
          (None, "CPF I", 7, None, "CPF I", 2), (None, "CPF II", 3, None, "CABA", 1), (None, "TOTAL", 10, None, "TOTAL", 3),
          (None, None, None, None, None, None),
          (None, "Casos individuales trabajados por nota", None, None, None, None, None, "Respuestas individuales recibida por el SPF"),
          (None, "COMPLEJOS", "Julio", "Agosto", "Septembre", "Total Individual", "Total Colectiva", "Julio", "Agosto", "Septiembre", "Total Respuesta"),
          (None, "CPF I", 3, 4, 5, 12, 2, 1, 0, 1, 2), (None, "U19", 0, 1, 0, 1, 0, 0, 0, 0, 0),
          (None, "Total general", 3, 5, 5, 13, 2, 1, 0, 1, 2),
          (None, None, None, None),
          (None, "REUNIONES DE EQUIPO Y/O CON OTROS EQUIPOS", None, "10")]


def test_salud_mental() -> None:
    lec = ps.leer(list(MENTAL))
    assert (lec.formato, lec.anio, lec.trimestre) == ("salud_mental", 2026, 3)
    assert ("M07", "visitas_equipo", 4) in lec.equipo and ("M09", "sm_articulacion", 32) in lec.equipo
    assert len(lec.equipo) == 8 * 3 and any("Fila inventada" in a for a in lec.avisos)
    assert ps.mes_de("Junio/Julio", 3) == 7 and ps.mes_de("Junio/Julio", 2) == 6


def test_salud_medica() -> None:
    lec = ps.leer(list(MEDICA), anio=2026)
    assert (lec.formato, lec.anio, lec.trimestre) == ("salud_medica", 2026, 3)
    assert ("PEREZ", "M08", "med_entrevistas", 6) in lec.persona and ("GOMEZ", "M09", "med_recomendaciones", 2) in lec.persona
    assert len(lec.persona) == 6 * 4
    assert ("T3", "med_informes_golpeados", "CABA", 1) in lec.unidad and not any(u[2] == "TOTAL" for u in lec.unidad)
    assert ("M08", "med_casos_individuales", "CPF I", 4) in lec.unidad and ("T3", "med_casos_colectivos", "CPF I", 2) in lec.unidad
    assert ("M09", "med_respuestas_spf", "CPF I", 1) in lec.unidad and not any("Total" in u[2] for u in lec.unidad)
    assert ("T3", "med_reuniones", 10) in lec.equipo
    assert any(c.startswith("Visitas a CPF I: la planilla dice 7") for c in lec.control)


def test_formato_desconocido() -> None:
    assert ps.leer([("hola", "mundo")]).formato == "desconocido"
