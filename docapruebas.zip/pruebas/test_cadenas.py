"""Propuesta 50: registros históricos encadenados (detecta filas cambiadas o borradas) y «solo agregar» donde no rompe nada."""
from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import cadenas

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
CLAVE = b"k" * 32


@pytest.fixture()
def con(tmp_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(tmp_path / "t.db")
    c.execute("CREATE TABLE historial_estados (id INTEGER PRIMARY KEY AUTOINCREMENT, nota_id INTEGER, estado TEXT, fecha TEXT)")
    c.execute("CREATE TABLE seguridad_eventos (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT, detalle TEXT, fecha TEXT)")
    for m in mg.disponibles():
        m.aplicar(c)
    c.executemany("INSERT INTO historial_estados (nota_id, estado, fecha) VALUES (?,?,?)", [(i, "SUBIDA", f"2026-11-{i:02d}") for i in range(1, 8)])
    c.executemany("INSERT INTO seguridad_eventos (tipo, detalle, fecha) VALUES (?,?,?)", [("DETENIDO_VER", f"#{i}", "2026-11-14") for i in range(3)])
    c.commit()
    return c


def test_sellar_y_verificar(con: sqlite3.Connection) -> None:
    hechos = cadenas.sellar_todas(con, CLAVE)
    assert hechos["historial_estados"][:2] == (7, 7) and hechos["seguridad_eventos"][0] == 3 and hechos["ia_registro"] == (0, 0, "")
    assert cadenas.sellar(con, "historial_estados", CLAVE)[0] == 0, "no se vuelve a sellar"
    assert all(r.ok for r in cadenas.verificar_todas(con, CLAVE))
    con.execute("INSERT INTO historial_estados (nota_id, estado, fecha) VALUES (9, 'FIRMADA', 'x')")
    assert cadenas.verificar(con, "historial_estados", CLAVE).ok, "una fila nueva todavía sin sellar no es una alteración"
    con.execute("ALTER TABLE historial_estados ADD COLUMN usuario TEXT")
    assert cadenas.verificar(con, "historial_estados", CLAVE).ok, "una columna nueva vacía no rompe la cadena"
    con.execute("UPDATE historial_estados SET fecha = '2020-01-01' WHERE id = 3")
    con.execute("DELETE FROM historial_estados WHERE id = 5")
    r = cadenas.verificar(con, "historial_estados", CLAVE)
    assert not r.ok and r.modificadas == (3,) and r.borradas == (5,) and "ALTERADA" in r.texto
    assert not cadenas.verificar(con, "historial_estados", b"otra" * 8).ok, "sin la clave no se puede recalcular"


def test_solo_agregar_y_reinicio(con: sqlite3.Connection) -> None:
    with pytest.raises(sqlite3.IntegrityError, match="inalterable"):
        con.execute("UPDATE seguridad_eventos SET detalle = 'x' WHERE id = 1")
    with pytest.raises(sqlite3.IntegrityError, match="inalterable"):
        con.execute("DELETE FROM seguridad_eventos")
    cadenas.sellar_todas(con, CLAVE)
    con.execute("DELETE FROM historial_estados")  # «Limpiar notas», excepción consciente
    cadenas.reiniciar(con, "historial_estados", "Limpiar notas · Director · 7 nota(s)")
    assert cadenas.verificar(con, "historial_estados", CLAVE).ok
    motivo = con.execute("SELECT motivo_reinicio FROM cadenas_registro WHERE tabla = 'historial_estados'").fetchone()[0]
    assert motivo.startswith("Limpiar notas")
    with pytest.raises(ValueError):
        cadenas.sellar(con, "notas", CLAVE)


def test_sellado_desde_la_app_con_ancla(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import rutas_notas_ia
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "app.db")
    db.inicializar_db()
    with db._conexion() as c:
        c.execute("INSERT INTO seguridad_eventos (usuario, tipo, detalle, fecha) VALUES ('Ana', 'DETENIDO_VER', '#1', '2026-11-14')")
    ancla = tmp_path / "ancla.txt"
    rutas_notas_ia.sellar_registros(CLAVE, ancla)
    assert "CADENA:seguridad_eventos" in ancla.read_text(encoding="utf-8")
    assert all(r.ok for r in rutas_notas_ia.verificar_registros(CLAVE))
    from dgpdh.seguridad import auditoria
    assert auditoria.leer_ancla(ancla) == (None, 0), "las líneas de las cadenas no confunden al ancla de la auditoría"
