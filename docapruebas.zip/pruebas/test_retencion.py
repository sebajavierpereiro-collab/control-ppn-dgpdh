"""Propuesta 5: retención sin borrado físico (solo marca, autorización con motivo y «retirado»)."""
from __future__ import annotations

import sqlite3
from datetime import date
from pathlib import Path

import pytest

from dgpdh.errores import Conflicto, DatoInvalido
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import retencion as rt

DIR = au.Actor(1, "Director General")


def test_retencion(tmp_path: Path) -> None:
    con = sqlite3.connect(tmp_path / "t.db")
    con.execute("CREATE TABLE notas (id INTEGER PRIMARY KEY, nombre_original TEXT, estado TEXT, tipo_documental TEXT, fecha_nota TEXT, creado_en TEXT, nro_nota TEXT)")
    for m in mg.disponibles():
        m.aplicar(con)
    con.executemany("INSERT INTO notas (id, nombre_original, estado, tipo_documental, fecha_nota, creado_en) VALUES (?,?,?,?,?,?)", [
        (1, "Vieja", "DESPACHADA", "COMUNICACION_INTERNA", "2016-02-29", "2016-02-29"),
        (2, "Nueva", "DESPACHADA", "COMUNICACION_INTERNA", "2025-01-01", "2025-01-01"),
        (3, "Informe", "FIRMADA", "INFORME", "2010-01-01", "2010-01-01"),
        (4, "En curso", "SUBIDA", "COMUNICACION_INTERNA", "2010-01-01", "2010-01-01")])
    assert rt.marcar_vencidos(con, date(2026, 11, 14)) == 0, "sin series no se marca nada"
    rt.guardar_serie(con, tipo="COMUNICACION_INTERNA", plazo_anios=10, destino="BAJA", actor=DIR)
    rt.guardar_serie(con, tipo="INFORME", plazo_anios=5, destino="PERMANENTE", actor=DIR)
    with pytest.raises(DatoInvalido):
        rt.guardar_serie(con, tipo="NOTA", plazo_anios=0, destino="BAJA", actor=DIR)
    assert rt.marcar_vencidos(con, date(2026, 11, 14)) == 1 and rt.marcar_vencidos(con, date(2026, 11, 14)) == 0
    assert [v["nota_id"] for v in rt.listado(con)] == [1] and rt.listado(con)[0]["vence_en"] == "2026-02-28"
    with pytest.raises(DatoInvalido):
        rt.autorizar_retiro(con, 1, actor=DIR, motivo="")
    rt.autorizar_retiro(con, 1, actor=DIR, motivo="Resolución DGPDH 12/2026")
    m = rt.de_nota(con, 1)
    assert m and m.estado == "RETIRADA" and m.autorizado_por == "Director General"
    with pytest.raises(Conflicto):
        rt.autorizar_retiro(con, 1, actor=DIR, motivo="otra vez")
    assert con.execute("SELECT estado FROM notas WHERE id = 1").fetchone()[0] == "DESPACHADA", "el documento no se toca"
    assert con.execute("SELECT COUNT(*) FROM notas").fetchone()[0] == 4
    assert con.execute("SELECT COUNT(*) FROM auditoria WHERE origen = 'retencion'").fetchone()[0] == 3
