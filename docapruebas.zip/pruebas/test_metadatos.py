"""Propuesta 1: campos por tipo documental, validación y propuestas desde lo leído del texto."""
from __future__ import annotations

import pytest

from dgpdh.dominio import metadatos as md
from dgpdh.errores import DatoInvalido


def test_campos_y_validacion() -> None:
    assert [c.clave for c in md.campos_de("NOTA_PPL")] == ["persona_detenida", "unidad"]
    assert md.campos_de(None) == md.campos_de("NOTA") == md.campos_de("RARO")
    fecha = next(c for c in md.campos_de("PEDIDO_INFORME") if c.tipo == "fecha")
    numero = next(c for c in md.campos_de("PEDIDO_INFORME") if c.tipo == "numero")
    assert md.normalizar(fecha, "01/12/2026") == "2026-12-01" and md.normalizar(fecha, "2026-12-01") == "2026-12-01"
    assert md.normalizar(numero, " 010 ") == "10" and md.normalizar(numero, "") is None
    for c, v in ((fecha, "31/02/2026"), (numero, "diez"), (md.campos_de("NOTA_PPL")[0], "Juan")):
        with pytest.raises(DatoInvalido):
            md.normalizar(c, v)


def test_propuestas() -> None:
    ents = {"UNIDAD": [{"valor": "CPF I", "norm": "u:7"}], "PERSONA": [{"valor": "DNI 30123456", "norm": "dni:30123456"}],
            "JUZGADO": [{"valor": "Juzgado Federal 3", "norm": "x"}]}
    p = md.propuestas(md.campos_de("OFICIO"), ents, {"30123456": 41}, 5, "Al Sr. Juez")
    assert p == {"organismo_requerido": "Al Sr. Juez", "juzgado": "Juzgado Federal 3", "persona_detenida": "41", "plazo_dias": "5"}
    assert md.propuestas(md.campos_de("NOTA_PPL"), ents, {}, None, None) == {"unidad": "7"}
