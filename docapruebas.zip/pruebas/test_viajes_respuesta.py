"""Propuesta 74: semáforo de espera de los pedidos y mediana de horas hábiles hasta la asignación."""
from __future__ import annotations

from datetime import date, datetime, timezone

from dgpdh.dominio import respuesta as rp


def test_horas_habiles() -> None:
    v = datetime(2026, 11, 13, 12, tzinfo=timezone.utc)  # viernes 12 h
    assert rp.horas_habiles(v, datetime(2026, 11, 16, 12, tzinfo=timezone.utc)) == 24.0, "el fin de semana no cuenta"
    assert rp.horas_habiles(v, datetime(2026, 11, 16, 12, tzinfo=timezone.utc), {date(2026, 11, 16)}) == 12.0
    assert rp.horas_habiles(v, v) == 0.0


def test_semaforo_y_mediana() -> None:
    assert rp.semaforo(5, 100)[0] == "ok" and rp.semaforo(30, 100)[0] == "medio" and rp.semaforo(50, 100)[0] == "alto"
    assert rp.semaforo(1, 20) == ("alto", "espera 1 h hábiles · el viaje es en menos de 48 h")
    assert rp.mediana_por_mes([("2026-10", 4), ("2026-10", 10), ("2026-11", 2)]) == [
        {"mes": "2026-10", "pedidos": 2, "mediana_h": 7.0}, {"mes": "2026-11", "pedidos": 1, "mediana_h": 2.0}]
