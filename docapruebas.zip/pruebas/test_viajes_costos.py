"""Propuesta 62: reparto del importe de cada salida entre paradas y equipos."""
from __future__ import annotations

from dgpdh.dominio import costos as dc


def test_reparto() -> None:
    r = dc.repartir(900, [dc.Parada("CPF I", ("A", "B")), dc.Parada("U19", ("A",)), dc.Parada("CPF II", ())])
    assert [x[1] for x in r] == [300, 300, 300] and r[0][2] == {"A": 150, "B": 150} and r[2][2] == {"(sin equipo)": 300}
    r = dc.repartir(100, [dc.Parada("X", ("A",), 30.0), dc.Parada("Y", ("B",), 10.0)])
    assert [x[1] for x in r] == [75, 25], "por km si se conocen todos"
    assert dc.repartir(0, [dc.Parada("X", ("A",))]) == []
    c = dc.acumular([("2026-02-10", 900, [dc.Parada("CPF I", ("A", "B")), dc.Parada("U19", ("A",))]), ("2026-05-01", 100, [dc.Parada("CPF I", ("B",))])])
    assert c == {"unidad": {"CPF I": 550, "U19": 450}, "equipo": {"A": 675, "B": 325}, "trimestre": {"2026-T1": 900, "2026-T2": 100}}
