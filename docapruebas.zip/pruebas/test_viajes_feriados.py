"""Propuesta 69: calendario único de feriados (dominio, servicio, precarga de frecuentes, recordatorio del jueves y plazos)."""
from __future__ import annotations

import sqlite3
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import pytest

from dgpdh.dominio import calendario as cal
from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import feriados as srv

DIR = au.Actor(1, "Director General")
JUL9 = date(2026, 7, 9)  # jueves


def test_dias_habiles() -> None:
    fer = {JUL9, date(2026, 7, 10)}
    assert cal.es_habil(date(2026, 7, 8), fer) and not cal.es_habil(JUL9, fer) and not cal.es_habil(date(2026, 7, 11))
    assert cal.habiles_entre(date(2026, 7, 6), date(2026, 7, 12), fer) == 3
    assert cal.habiles_entre(date(2026, 7, 12), date(2026, 7, 6)) == 0
    assert cal.habil_anterior_o_igual(date(2026, 7, 10), fer) == date(2026, 7, 8)
    assert cal.habil_anterior(date(2026, 7, 8), fer) == date(2026, 7, 7)
    assert cal.sumar_habiles(date(2026, 7, 8), 1, fer) == date(2026, 7, 13)
    assert cal.primeros_habiles_del_mes(2026, 3, 2, {date(2026, 3, 2)}) == [date(2026, 3, 3), date(2026, 3, 4)]
    assert cal.fraccion_habil(date(2026, 7, 6), date(2026, 7, 10), date(2026, 7, 7)) == pytest.approx(2 / 5)
    assert cal.fraccion_habil(date(2026, 7, 6), date(2026, 7, 10), date(2026, 7, 1)) == 0.0
    assert cal.fraccion_habil(date(2026, 7, 6), date(2026, 7, 10), date(2026, 7, 30)) == 1.0


def test_leer_ics() -> None:
    texto = ("BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20260709\r\nSUMMARY:Día de la\r\n  Independencia\r\nEND:VEVENT\r\n"
             "BEGIN:VEVENT\nDTSTART;VALUE=DATE:20260720\nDTEND;VALUE=DATE:20260722\nSUMMARY:Feria\\, invierno\nEND:VEVENT\n"
             "BEGIN:VEVENT\nDTSTART:2026XX01\nEND:VEVENT\nBEGIN:VEVENT\nDTSTART:20260101\nDTEND:20261231\nEND:VEVENT\nEND:VCALENDAR")
    assert cal.leer_ics(texto) == [(JUL9, "Día de la Independencia"), (date(2026, 7, 20), "Feria, invierno"), (date(2026, 7, 21), "Feria, invierno")]
    assert cal.leer_ics("cualquier cosa") == []


@pytest.fixture()
def con(tmp_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(tmp_path / "t.db")
    for m in mg.disponibles():
        m.aplicar(c)
    return c


def test_servicio_alta_baja_reactivacion_y_permisos(con: sqlite3.Connection) -> None:
    with pytest.raises(PermisoDenegado):
        srv.guardar(con, DIR, False, "2026-07-09", "Independencia")
    for fecha, motivo, tipo, msg in (("", "Independencia", "NACIONAL", "fecha"), ("2026-07-09", "x", "NACIONAL", "motivo"),
                                     ("2026-07-09", "Independencia", "OTRO", "tipo")):
        with pytest.raises(DatoInvalido, match=msg):
            srv.guardar(con, DIR, True, fecha, motivo, tipo)
    fid = srv.guardar(con, DIR, True, "2026-07-09", "Día de la Independencia")
    assert srv.conjunto(con) == {JUL9}
    with pytest.raises(DatoInvalido):
        srv.dar_de_baja(con, DIR, True, fid, "")
    srv.dar_de_baja(con, DIR, True, fid, "Se cargó por error")
    with pytest.raises(NoEncontrado):
        srv.dar_de_baja(con, DIR, True, fid, "otra vez")
    assert srv.conjunto(con) == frozenset() and srv.listar(con, 2026) == []
    assert srv.listar(con, 2026, incluir_bajas=True)[0]["motivo_baja"] == "Se cargó por error", "no se borra: queda dado de baja"
    assert srv.guardar(con, DIR, True, "2026-07-09", "Independencia", "NACIONAL") == fid, "volver a cargarlo lo reactiva"
    acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'feriado' ORDER BY id")]
    assert acciones == ["Feriado cargado", "Feriado dado de baja", "Feriado reactivado"]


def test_importar_ics(con: sqlite3.Connection) -> None:
    srv.guardar(con, DIR, True, "2026-07-09", "Independencia")
    ics = "BEGIN:VEVENT\nDTSTART;VALUE=DATE:20260709\nSUMMARY:Indep.\nEND:VEVENT\nBEGIN:VEVENT\nDTSTART;VALUE=DATE:20261208\nSUMMARY:Inmaculada\nEND:VEVENT"
    assert srv.importar_ics(con, DIR, True, ics) == {"nuevos": 1, "ya_estaban": 1, "leidos": 2}
    with pytest.raises(DatoInvalido):
        srv.importar_ics(con, DIR, True, "no es un calendario")
    with pytest.raises(PermisoDenegado):
        srv.importar_ics(con, DIR, False, ics)
    assert srv.conjunto(con, date(2026, 12, 1), date(2026, 12, 31)) == {date(2026, 12, 8)}


def test_sin_tabla_no_falla(tmp_path: Path) -> None:
    c = sqlite3.connect(tmp_path / "vieja.db")
    assert srv.conjunto(c) == frozenset() and srv.listar(c) == []


def _cargar(db: Any, fecha: date, motivo: str = "Feriado de prueba") -> None:
    with db._conexion() as c:
        srv.guardar(c, DIR, True, fecha.isoformat(), motivo)


def test_frecuentes_no_se_precargan_en_feriados(base: Any) -> None:
    import auth
    import frecuentes as fr
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Feriados")
    ana = db.obtener_usuario(db.crear_usuario("anaf", h, s, "Ana Feriado", "ASESOR", eq))
    amba = next(x for x in db.listar_unidades() if (x.get("zona") or "") == "AMBA")
    hoy = date(2026, 7, 1)  # miércoles: la ventana va del 2 al 12 de julio
    fid = fr.crear({"circuito": "AMBA", "unidad_id": amba["id"], "dias": [3], "frecuencia": "SEMANAL", "desde": hoy.isoformat()},
                   [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Equipo Feriados"}], ana)
    _cargar(db, JUL9, "Día de la Independencia")
    assert fr.generar(hoy=hoy) == 1
    fechas = [v["fecha"] for v in tr.listar_viajes(desde="2026-07-01", hasta="2026-07-31") if v.get("frecuente_id") == fid]
    assert fechas == ["2026-07-02"], "el jueves 9 es feriado: no se precarga"


def test_recordatorio_se_adelanta_si_el_jueves_es_feriado(base: Any) -> None:
    import traslados as tr
    db = base
    mie, jue = date(2026, 7, 8), JUL9
    assert tr.toca_recordatorio(mie) == ("Mañana jueves", jue) and tr.toca_recordatorio(jue) == ("Hoy", jue)
    assert tr.toca_recordatorio(date(2026, 7, 7)) is None
    _cargar(db, jue)
    assert tr.toca_recordatorio(date(2026, 7, 7)) == ("Mañana miércoles", mie)
    assert tr.toca_recordatorio(mie) == ("Hoy", mie) and tr.toca_recordatorio(jue) is None
    assert tr.es_inmediato("2026-07-13", mie) is False and tr.es_inmediato("2026-07-13", jue) is False, "el plazo formal no cambia"
    assert tr.feriados_iso() == {"2026-07-09"}


def test_plazos_de_notas_descuentan_feriados(base: Any) -> None:
    import agentes
    import traslados as tr
    _cargar(base, JUL9)
    assert agentes.sumar_habiles(date(2026, 7, 8), 1, tr.feriados_iso()) == date(2026, 7, 10)
    assert agentes.sumar_habiles(date(2026, 7, 8), 1) == JUL9
    assert tr.feriados_entre(date(2026, 7, 1), date(2026, 7, 5)) == frozenset()
    assert (JUL9 - timedelta(days=1)).isoformat() not in tr.feriados_iso()
