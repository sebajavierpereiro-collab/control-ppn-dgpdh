"""Propuesta 65: órdenes de trabajo de taller."""
from __future__ import annotations

from typing import Any

import pytest

from dgpdh.dominio import ordenes_taller as ot


def test_etapas() -> None:
    assert ot.validar("NUEVA", "EN_CURSO", None) is None and ot.validar("NUEVA", "HECHA", None)
    assert ot.validar("EN_CURSO", "CANCELADA", " ") and ot.validar("EN_CURSO", "CANCELADA", "No había repuesto") is None
    assert ot.validar("HECHA", "EN_CURSO", None) and ot.validar("CANCELADA", "NUEVA", None)
    assert ot.pone_en_taller("NUEVA", "EN_CURSO") and not ot.pone_en_taller("NUEVA", "CANCELADA")
    assert ot.ofrece_volver("EN_CURSO", "HECHA", 0) and not ot.ofrece_volver("EN_CURSO", "HECHA", 1) and not ot.ofrece_volver("NUEVA", "CANCELADA", 0)
    assert ot.importe("12.500,50") == 12500.5 and ot.importe("300.5") == 300.5 and ot.importe("") is None
    with pytest.raises(ValueError):
        ot.importe("-3")


def test_flujo(base: Any) -> None:
    import flota
    import traslados as tr
    from dgpdh.errores import DatoInvalido, PermisoDenegado
    from dgpdh.seguridad import auditoria as au
    from dgpdh.servicios import ordenes_taller as srv
    db = base
    vid = tr.guardar_vehiculo(None, {"dominio": "AA065AA", "capacidad": "4"})
    vid = vid if isinstance(vid, int) else vid["id"]
    r1 = flota.registrar(vid, "NOVEDAD", {"detalle": "Ruido en frenos", "gravedad": "MODERADA"}, {"nombre": "Coord"})
    r2 = flota.registrar(vid, "NOVEDAD", {"detalle": "Luz de giro", "gravedad": "LEVE"}, {"nombre": "Coord"})
    a = au.Actor(None, "Coord")
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            srv.crear(con, a, False, vid, {"descripcion": "x"}, [])
        with pytest.raises(DatoInvalido):
            srv.crear(con, a, True, vid, {"descripcion": ""}, [])
        oid = srv.crear(con, a, True, vid, {"descripcion": "Frenos", "taller": "Taller Sur", "presupuesto": "45.000,00"}, [r1, 9999])
        o2 = srv.crear(con, a, True, vid, {"descripcion": "Giro"}, [r2])
        with pytest.raises(DatoInvalido):
            srv.cambiar_etapa(con, a, True, oid, "HECHA")
        r = srv.cambiar_etapa(con, a, True, oid, "EN_CURSO")
        assert r["poner_en_taller"] and not r["ofrecer_disponible"]
        assert con.execute("SELECT estado_novedad FROM vehiculo_registros WHERE id = ?", (r1,)).fetchone()[0] == "EN_REPARACION"
        srv.cambiar_etapa(con, a, True, o2, "EN_CURSO")
        srv.editar(con, a, True, oid, {"taller": "Taller Sur", "presupuesto": "45000", "repuestos": "Pastillas", "costo_final": ""})
        r = srv.cambiar_etapa(con, a, True, oid, "HECHA", "Cambio de pastillas", "47.300")
        assert not r["ofrecer_disponible"], "queda otra orden en curso del mismo vehículo"
        assert con.execute("SELECT resuelta FROM vehiculo_registros WHERE id = ?", (r1,)).fetchone()[0] == 1
        with pytest.raises(DatoInvalido):
            srv.editar(con, a, True, oid, {"repuestos": "otra cosa"})
        with pytest.raises(DatoInvalido):
            srv.cambiar_etapa(con, a, True, o2, "CANCELADA", "")
        r = srv.cambiar_etapa(con, a, True, o2, "CANCELADA", "Se hará con otra orden")
        assert r["ofrecer_disponible"]
        assert con.execute("SELECT resuelta FROM vehiculo_registros WHERE id = ?", (r2,)).fetchone()[0] == 0, "cancelar no repara la novedad"
        lista = srv.del_vehiculo(con, vid)
        assert {o["etapa"] for o in lista} == {"HECHA", "CANCELADA"}, "la cancelada se conserva"
        hecha = next(o for o in lista if o["id"] == oid)
        assert hecha["costo_final"] == 47300 and hecha["repuestos"] == "Pastillas" and len(hecha["historial"]) == 3 and hecha["novedades"][0]["id"] == r1
        acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'orden_trabajo'")]
    assert acciones.count("Orden de trabajo: etapa") == 4 and "Orden de trabajo: alta" in acciones and "Orden de trabajo: datos" in acciones
