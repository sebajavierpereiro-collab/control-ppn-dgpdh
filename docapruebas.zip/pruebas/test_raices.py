"""Propuesta 11: búsqueda por raíces de palabras en castellano (solo suma resultados)."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dgpdh.dominio.raices import raices, raiz

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


@pytest.mark.parametrize("palabras", [("traslado", "traslados", "trasladaron", "trasladar"), ("colchón", "colchones"),
                                      ("sanción", "sanciones"), ("información", "informaciones")])
def test_misma_raiz(palabras: tuple[str, ...]) -> None:
    assert len({raiz(p) for p in palabras}) == 1


def test_texto() -> None:
    assert raices("Se TRASLADARON los colchones.") == "se traslad los colchon"
    assert raiz("sol") == "sol" and raices(None) == ""


def test_busqueda(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    if not db.FTS_DISPONIBLE:
        pytest.skip("SQLite sin FTS5")
    with db._conexion() as con:
        eq = con.execute("SELECT id FROM equipos LIMIT 1").fetchone()[0]
        for i in (1, 2, 3):
            con.execute("INSERT INTO notas (id, nombre_original, equipo_id, ruta_original, creado_en, actualizado_en) VALUES (?,?,?,?,?,?)",
                        (i, f"n{i}", eq, "x", "2026", "2026"))
    db.indexar_texto(1, "Se pide el traslado de la persona a la Unidad 6.")
    db.indexar_texto(2, "Ayer lo trasladaron sin aviso previo.")
    db.indexar_texto(3, "Pedido de colchones para el pabellón.")
    ids = [i for i, _ in db.buscar_texto("traslado")]
    assert ids[0] == 1 and set(ids) == {1, 2}, "lo exacto primero y además lo que comparte la raíz"
    frag = dict(db.buscar_texto("traslado"))[2]
    assert "\x02trasladaron\x03" in frag
    assert [i for i, _ in db.buscar_texto("colchón")] == [3]
