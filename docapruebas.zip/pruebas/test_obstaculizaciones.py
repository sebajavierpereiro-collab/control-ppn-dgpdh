from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pytest

from dgpdh.dominio import obstaculizaciones as dom
from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.persistencia import migraciones as mg
from dgpdh.servicios import obstaculizaciones as srv

HOY = date(2026, 11, 14)
DIR = dom.Persona(1, "Director General", "DIRECTOR", None, es_direccion=True)
ANA = dom.Persona(2, "Ana Asesora", "ASESOR", 10)
BETO = dom.Persona(3, "Beto Asesor", "ASESOR", 10)
COO = dom.Persona(4, "Cora Coordinadora", "COORDINADOR", 10)
COO2 = dom.Persona(5, "Coordinador CPF", "COORDINADOR", 20)
LEGAL = dom.Persona(6, "Área Legal", "ASESOR", 30, consulta=True)
CHOFER = dom.Persona(7, "Pedro Chofer", "CHOFER", None)
OTRO = dom.Persona(8, "Otra Asesora", "ASESOR", 20)


@pytest.fixture()
def con(tmp_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(tmp_path / "t.db")
    c.executescript("""
        CREATE TABLE equipos (id INTEGER PRIMARY KEY, nombre TEXT);
        INSERT INTO equipos VALUES (10, 'Equipo Salud'), (20, 'Equipo CPF I'), (30, 'Legales');
        CREATE TABLE unidades (id INTEGER PRIMARY KEY, nombre TEXT);
        INSERT INTO unidades VALUES (100, 'CPF I'), (200, 'Unidad 19'), (300, 'CPF II');
        CREATE TABLE fuerzas (id INTEGER PRIMARY KEY, nombre TEXT);
        INSERT INTO fuerzas VALUES (1, 'Servicio Penitenciario Federal');
        CREATE TABLE usuarios (id INTEGER PRIMARY KEY, nombre TEXT);
        CREATE TABLE viajes_frecuentes (id INTEGER PRIMARY KEY, unidad_id INTEGER, equipo_nombre TEXT, activo INTEGER);
        INSERT INTO viajes_frecuentes VALUES (1, 200, 'equipo cpf i ', 1), (2, 300, 'Equipo CPF I', 0);
    """)
    for m in mg.disponibles():
        m.aplicar(c)
    c.commit()
    return c


def datos(**k: object) -> dict[str, object]:
    base: dict[str, object] = {"fecha_hecho": "2026-11-13", "hora_hecho": "09:40", "unidad_id": "100", "sector": "Módulo III, pabellón 5",
                               "tipo_id": "1", "equipo_id": "10", "fuerza_id": "1", "autoridad": "Jefe de turno",
                               "descripcion": "El ingreso se demoró dos horas sin explicación por parte del personal de guardia.",
                               "subsanado": "NO", "demora_minutos": "120", "agentes": [(2, "Ana Asesora")],
                               "vinculos": [("VIAJE", 55, None), ("EXPEDIENTE", None, "ET 6116/26")]}
    base.update(k)
    return base


def test_tipos_iniciales_y_abm(con: sqlite3.Connection) -> None:
    tipos = srv.listar_tipos(con)
    assert len(tipos) == 6 and tipos[0]["nombre"].startswith("Demora injustificada")
    with pytest.raises(PermisoDenegado):
        srv.guardar_tipo(con, COO, "Nuevo tipo")
    nuevo = srv.guardar_tipo(con, DIR, "Impedimento de acceso a la historia clínica")
    with pytest.raises(Conflicto):
        srv.guardar_tipo(con, DIR, "impedimento de acceso a la historia clínica")
    srv.guardar_tipo(con, DIR, "Impedimento de acceso a historias clínicas", tipo_id=nuevo)
    srv.cambiar_estado_tipo(con, DIR, nuevo, False)
    assert nuevo not in srv.ids_tipos_activos(con) and any(t["id"] == nuevo and not t["activo"] for t in srv.listar_tipos(con, False))
    acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'obstaculizacion_tipo'")]
    assert acciones == ["Tipo de obstaculización creado", "Tipo de obstaculización modificado", "Tipo de obstaculización dado de baja"]


def test_validacion_de_la_carga(con: sqlite3.Connection) -> None:
    activos = srv.ids_tipos_activos(con)
    c = dom.validar(datos(tipos_extra=["2", "1", "99"]), tipos_activos=activos, hoy=HOY)
    assert c.tipos_extra == (2,) and c.agentes == ((2, "Ana Asesora"),) and c.vinculos == (("VIAJE", 55, None), ("EXPEDIENTE", None, "ET 6116/26"))
    for cambio, msg in (({"fecha_hecho": "2026-11-20"}, "posterior a hoy"), ({"hora_hecho": "25:00"}, "hora"),
                        ({"unidad_id": "", "lugar_otro": ""}, "establecimiento"), ({"tipo_id": "99"}, "tipo"),
                        ({"equipo_id": "", "agentes": []}, "equipo"), ({"fuerza_id": "", "autoridad": ""}, "fuerza o autoridad"),
                        ({"descripcion": "corto"}, "más detalle"), ({"subsanado": ""}, "subsanar"),
                        ({"subsanado": "SI", "como_se_subsano": ""}, "cómo se subsanó"), ({"demora_minutos": "abc"}, "Demora")):
        with pytest.raises(DatoInvalido, match=msg):
            dom.validar(datos(**cambio), tipos_activos=activos, hoy=HOY)
    otro = dom.validar(datos(unidad_id="", lugar_otro="Juzgado Federal de Lomas"), tipos_activos=activos, hoy=HOY)
    assert otro.unidad_id is None and otro.lugar_otro == "Juzgado Federal de Lomas"


def test_numeracion_y_visibilidad_por_rol(con: sqlite3.Connection) -> None:
    activos = srv.ids_tipos_activos(con)
    a, na = srv.crear(con, ANA, dom.validar(datos(), tipos_activos=activos, hoy=HOY))                                   # equipo 10, CPF I
    b, nb = srv.crear(con, OTRO, dom.validar(datos(equipo_id="20", unidad_id="200", agentes=[]), tipos_activos=activos, hoy=HOY))  # equipo 20, U19
    c, nc = srv.crear(con, OTRO, dom.validar(datos(equipo_id="20", unidad_id="300", agentes=[(3, "Beto Asesor")]), tipos_activos=activos, hoy=HOY))
    assert (na, nb, nc) == ("OB-2026-0001", "OB-2026-0002", "OB-2026-0003")
    ve = lambda p: {f["id"] for f in srv.listar(con, p)}  # noqa: E731
    assert ve(DIR) == ve(LEGAL) == {a, b, c}, "Dirección y el permiso de consulta ven todo"
    assert ve(ANA) == {a}, "la asesora ve lo suyo"
    assert ve(BETO) == {c}, "y lo que la nombra como interviniente"
    assert ve(COO) == {a}, "la coordinación ve su equipo"
    assert ve(COO2) == {b, c}, "su equipo y las unidades de sus frecuentes activos (U19); CPF II tiene el frecuente pausado"
    assert ve(CHOFER) == set()
    with pytest.raises(PermisoDenegado):
        srv.obtener(con, ANA, b)
    with pytest.raises(PermisoDenegado):
        srv.crear(con, CHOFER, dom.validar(datos(), tipos_activos=activos, hoy=HOY))
    f = srv.obtener(con, COO2, b)
    assert f["lugar"] == "Unidad 19" and f["vinculos"][1]["ref_texto"] == "ET 6116/26" and f["tipo_nombre"].startswith("Demora")
    # filtros combinados
    assert {x["id"] for x in srv.listar(con, DIR, srv.Filtros(unidad_id=100))} == {a}
    assert {x["id"] for x in srv.listar(con, DIR, srv.Filtros(equipo_id=20, subsanado=False))} == {b, c}
    assert {x["id"] for x in srv.listar(con, DIR, srv.Filtros(vinculo="EXPEDIENTE", texto="dos horas"))} == {a, b, c}
    assert srv.listar(con, DIR, srv.Filtros(desde="2026-11-14")) == []
    r = srv.resumen(srv.listar(con, DIR))
    assert r["total"] == 3 and r["subsanadas"] == 0 and r["demora_media"] == 120


def test_edicion_anulacion_y_adjuntos(con: sqlite3.Connection, tmp_path: Path) -> None:
    activos = srv.ids_tipos_activos(con)
    a, _ = srv.crear(con, ANA, dom.validar(datos(), tipos_activos=activos, hoy=HOY))
    srv.editar(con, ANA, a, dom.validar(datos(subsanado="SI", como_se_subsano="Intervino el director de la unidad"), tipos_activos=activos, hoy=HOY))
    assert srv.obtener(con, ANA, a)["subsanado"] == 1
    tarde = datetime.now(timezone.utc) + timedelta(hours=73)
    with pytest.raises(PermisoDenegado, match="72 horas"):
        srv.editar(con, ANA, a, dom.validar(datos(), tipos_activos=activos, hoy=HOY), ahora=tarde)
    srv.editar(con, COO, a, dom.validar(datos(sector="Módulo IV"), tipos_activos=activos, hoy=HOY), ahora=tarde)  # la coordinación sí
    with pytest.raises(DatoInvalido, match="mismo año"):
        srv.editar(con, DIR, a, dom.validar(datos(fecha_hecho="2025-12-30"), tipos_activos=activos, hoy=HOY))
    # adjuntos: tipo, tamaño, huella; quitar no borra el archivo
    carpeta = tmp_path / "obst"
    with pytest.raises(DatoInvalido, match="no admitido"):
        srv.agregar_adjunto(con, ANA, a, "virus.exe", b"x", carpeta, 1000)
    with pytest.raises(DatoInvalido, match="máximo"):
        srv.agregar_adjunto(con, ANA, a, "acta.pdf", b"x" * 2000, carpeta, 1000)
    aid = srv.agregar_adjunto(con, ANA, a, "Acta de ingreso.pdf", b"%PDF-1.4 contenido", carpeta, 10_000)
    adj = srv.adjunto(con, ANA, a, aid)
    assert Path(adj["ruta"]).read_bytes() == b"%PDF-1.4 contenido" and len(adj["sha256"]) == 64
    with pytest.raises(PermisoDenegado):
        srv.adjunto(con, OTRO, a, aid)
    srv.desactivar_adjunto(con, ANA, a, aid)
    assert Path(adj["ruta"]).exists() and srv.obtener(con, ANA, a)["adjuntos"] == 0
    # informe generado: ya no se edita; anular solo la Dirección
    srv.marcar_informe(con, ANA, a, nota_id=77)
    with pytest.raises(PermisoDenegado):
        srv.editar(con, COO, a, dom.validar(datos(), tipos_activos=activos, hoy=HOY))
    with pytest.raises(PermisoDenegado):
        srv.anular(con, ANA, a, "me equivoqué")
    with pytest.raises(DatoInvalido):
        srv.anular(con, DIR, a, " ")
    srv.anular(con, DIR, a, "cargado dos veces")
    assert srv.listar(con, DIR) == [] and srv.listar(con, DIR, srv.Filtros(estado="ANULADO"))[0]["motivo_anulacion"] == "cargado dos veces"
    with pytest.raises(NoEncontrado):
        srv.obtener(con, DIR, 999)
    acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'obstaculizacion' ORDER BY id")]
    assert acciones[0] == "Obstaculización registrada" and "Obstaculización anulada" in acciones and "Informe generado" in acciones


def test_revision_seguridad_reglas() -> None:
    from datetime import datetime, timedelta, timezone
    from dgpdh.dominio import obstaculizaciones as d
    ahora = datetime.now(timezone.utc)
    chofer_con_consulta = d.Persona(id=9, nombre="Chofer", rol="CHOFER", consulta=True, tiene_notas=False)
    sin_notas = d.Persona(id=8, nombre="X", rol="ASESOR", consulta=True, tiene_notas=False)
    assert not chofer_con_consulta.ve_todo and not sin_notas.ve_todo, "«Consulta» no saltea las exclusiones"
    autor = d.Persona(id=1, nombre="Ana", rol="ASESOR", equipo_id=10)
    viejo = d.Registro(cargado_por_id=1, equipo_id=10, unidad_id=None, creado_en=(ahora - timedelta(hours=80)).isoformat(),
                       estado="REGISTRADO", informe_nota_id=None)
    assert not d.puede_anular(autor, viejo, ahora) and not d.puede_adjuntar(autor, viejo, ahora), "fuera de plazo: ni anula ni adjunta"
    consulta = d.Persona(id=5, nombre="Legales", rol="ASESOR", consulta=True)
    nuevo = d.Registro(cargado_por_id=1, equipo_id=10, unidad_id=None, creado_en=ahora.isoformat(), estado="REGISTRADO", informe_nota_id=None)
    assert consulta.ve_todo and not d.puede_adjuntar(consulta, nuevo, ahora), "«Consulta» es solo lectura"
    assert d.equipo_permitido(autor, 10) and not d.equipo_permitido(autor, 11) and d.equipo_permitido(d.Persona(id=3, nombre="D", rol="DIRECTOR", es_direccion=True), 11)
