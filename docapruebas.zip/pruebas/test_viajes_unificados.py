"""Modificación 6: en una salida con varias paradas, un subbloque por unidad de destino (sin mezclar destinos)."""
from __future__ import annotations

from dgpdh.dominio import salidas as sl


def _v(i: int, unidad: int, destino: str, hora: str, otros: list[int], gente: list[str]) -> dict[str, object]:
    return {"id": i, "unidad_id": unidad, "destino": destino, "hora_salida": hora, "hora_regreso": "14:00", "con_transporte": len(gente),
            "misma_salida": [{"id": o} for o in otros], "participantes": [{"nombre": g, "equipo_nombre": "Eq"} for g in gente]}


def test_agrupar() -> None:
    viajes = [_v(1, 10, "CPF I", "09:00", [2, 3], ["Ana"]), _v(2, 20, "U19", "08:30", [1], ["Beto"]), _v(3, 10, "CPF I", "10:00", [1], ["Caro"]),
              _v(4, 30, "CPF II", "11:00", [], ["Dani"])]
    items = sl.agrupar_dia(viajes)
    assert [x["tipo"] for x in items] == ["salida", "viaje"]
    s = items[0]
    assert s["cabecera"]["id"] == 2 and s["hora_salida"] == "08:30" and s["personas"] == 3
    assert [(p["destino"], p["viajes"], [x["nombre"] for x in p["participantes"]]) for p in s["paradas"]] == [
        ("U19", [2], ["Beto"]), ("CPF I", [1, 3], ["Ana", "Caro"])], "un subbloque por unidad, sin mezclar"
    assert sl.paradas([_v(5, 10, "CPF I", "09:00", [], ["Ana"])], lambda i: [8, 9])[0]["pedidos"] == [5, 8, 9]
