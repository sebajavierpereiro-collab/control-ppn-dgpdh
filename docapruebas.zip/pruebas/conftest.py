"""Fixtures compartidas de las pruebas nuevas. `base` arma una base real del sistema (esquema histórico + migraciones) en una
carpeta temporal, con datos ficticios, y la deja como base activa de `database` mientras dura la prueba."""
from __future__ import annotations

import sys
from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


@pytest.fixture()
def base(tmp_path: Path) -> Iterator[Any]:
    import database as db
    anterior = db.RUTA_DB
    db.RUTA_DB = tmp_path / "dgpdh.db"
    try:
        db.inicializar_db()
        yield db
    finally:
        db.RUTA_DB = anterior
        db.USUARIO_ACTUAL.set(None)
