"""Propuesta 46: exportación mínima o completa, motivo, constancia en el archivo, aviso por volumen y campos de la API."""
from __future__ import annotations

import io
import sys
from pathlib import Path

import pytest

from dgpdh.dominio import exportaciones as ex

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_dominio() -> None:
    todas = [("id", "ID"), ("nombre_completo", "Nombre"), ("dni", "DNI"), ("situacion_procesal", "Situación"), ("centro", "Centro")]
    assert [c[0] for c in ex.columnas("minima", todas)] == ["id", "nombre_completo", "dni", "centro"]
    assert ex.columnas("completa", todas) == todas and ex.columnas("rara", todas) == todas
    assert ex.cantidad_exportada(["xlsx: 120 persona(s) · EXP-1", "csv: 3 persona(s)", "otra cosa"]) == 123
    assert ex.campos_api({"id": 1, "dni": "1", "juzgado": "x"}, ["dni"]) == {"id": 1, "dni": "1"}
    assert ex.campos_api({"id": 1, "dni": "1"}, []) == {"id": 1, "dni": "1"}
    assert ex.identificador().startswith("EXP-") and ex.identificador() != ex.identificador()


def test_preparar_y_archivo(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import openpyxl

    import database as db
    import detenidos as det
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    direc = next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")
    mesa = {"id": 99, "nombre": "Marta Mesa", "rol": "MESA_ASESOR"}
    monkeypatch.setitem(det.EXTERNO, "exigir_motivo_exportacion", True)
    monkeypatch.setitem(det.EXTERNO, "aviso_exportacion_fichas", 100)
    cols, const, error = det.preparar_exportacion(mesa, "completa", "", 10)
    assert error and cols is None, "la completa pide motivo si así se configuró"
    cols, const, error = det.preparar_exportacion(mesa, "minima", "", 60)
    assert not error and len(cols) < len(det.COLUMNAS_EXPORTACION) and dict(const)["Perfil"] == "mínima"
    cols, const, error = det.preparar_exportacion(mesa, "completa", "Pedido del Juzgado Federal 3", 60)
    assert not error and cols == det.COLUMNAS_EXPORTACION and dict(const)["Motivo"].startswith("Pedido")
    with db._conexion() as con:
        n = con.execute("SELECT COUNT(*) FROM notificaciones WHERE usuario_id = ? AND texto LIKE '%exportó hoy 120 fichas%'",
                        (direc["id"],)).fetchone()[0]
        eventos = con.execute("SELECT COUNT(*) FROM seguridad_eventos WHERE tipo = 'DETENIDOS_EXPORTAR'").fetchone()[0]
    assert n == 1 and eventos == 2, (n, eventos)
    i, _, _ = det.guardar({"nombre_completo": "Ana Torres", "dni": "25000111", "situacion_procesal": "Procesada"}, mesa)
    wb = openpyxl.load_workbook(io.BytesIO(det.exportar_excel([det.obtener(i)], det.COLUMNAS_EXPORTACION[:4], const)))
    assert wb.sheetnames == ["Personas detenidas", "Constancia"] and wb["Constancia"]["A1"].value == "Exportación"
    assert [c.value for c in wb.active[1]] == ["ID", "Nombre completo", "DNI", "LPU"]
    csv_ = det.exportar_csv([det.obtener(i)], [("nombre_completo", "Nombre completo")]).decode("utf-8-sig")
    assert csv_.splitlines() == ["Nombre completo", "Ana Torres"]
