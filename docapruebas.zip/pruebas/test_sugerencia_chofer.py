"""Modificación 5: sugerencia de chofer por ruta compartida (dominio y su uso en traslados.sugerencias)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import sugerencia_chofer as sc

CH = [sc.Chofer(1, "Ana", 0), sc.Chofer(2, "Beto", 3), sc.Chofer(3, "Caro", 1), sc.Chofer(4, "Dani", 0, True, "de vacaciones"),
      sc.Chofer(5, "Eli", 5)]


def test_prioridades() -> None:
    viajes = [sc.ViajeDelDia(10, 2, 9 * 60, True, 3), sc.ViajeDelDia(11, 3, 9 * 60 + 30, False, 4), sc.ViajeDelDia(12, 5, 9 * 60, True, 1),
              sc.ViajeDelDia(13, 4, 9 * 60, True, 6)]
    r = sc.ordenar(CH, viajes, personas=2, salida_min=9 * 60 + 40)
    assert [(s.chofer_id, s.prioridad) for s in r] == [(2, 1), (1, 2), (3, 3), (5, 3), (4, 4)]
    assert r[0].preseleccionar and r[0].etiqueta == "comparte viaje #10 (3 plazas libres)" and not any(s.preseleccionar for s in r[1:])
    assert "otra zona" in r[2].etiqueta and "sin lugar" in r[3].etiqueta and r[4].etiqueta == "de vacaciones"


def test_ventana_de_una_hora_y_sin_compartible() -> None:
    lejos = [sc.ViajeDelDia(10, 2, 7 * 60, True, 3, se_pisa=False)]
    r = sc.ordenar(CH[:3], lejos, personas=1, salida_min=9 * 60 + 1)
    assert [s.chofer_id for s in r] == [1, 3, 2] and r[0].preseleccionar, "fuera de ±1 h no comparte: gana el libre con menos salidas"
    assert r[2].prioridad == 2, "no se pisa: sigue libre"
    solo_bloqueados = sc.ordenar([sc.Chofer(4, "Dani", 0, True, "licencia")], [], 1, None)
    assert not solo_bloqueados[0].preseleccionar


def test_en_sugerencias(base: Any) -> None:
    import auth
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Eq Sug")
    ana = db.obtener_usuario(db.crear_usuario("anas", h, s, "Ana Sug", "ASESOR", eq))
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    for n in ("sa", "sb"):
        db.crear_usuario(n, h, s, f"Chofer {n.upper()}", "CHOFER", None, acceso_notas=False)
    tr.sincronizar_choferes()
    ch = {c["nombre"]: c["id"] for c in tr.listar_choferes()}
    v8 = tr.guardar_vehiculo(None, {"dominio": "SG800AA", "capacidad": "8"})
    tr.guardar_vehiculo(None, {"dominio": "SG400AA", "capacidad": "4"})
    amba = [u for u in db.listar_unidades() if tr.es_amba(u["id"])]
    f = (date.today() + timedelta(days=30)).isoformat()
    def viaje(hora: str) -> int:
        return int(tr.crear_viaje({"fecha": f, "unidad_id": amba[0]["id"], "hora_salida": hora, "hora_regreso": "14:00"},
                                  [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Eq Sug"}], ana))
    primero = viaje("09:00")
    tr.asignar(primero, ch["Chofer SB"], v8, direc, forzar=True)
    nuevo = viaje("09:30")
    sug = tr.sugerencias(nuevo)
    top = sug["choferes"][0]
    assert top["id"] == ch["Chofer SB"] and top["sugerido"] and f"comparte viaje #{primero} (7 plazas libres)" in top["motivo"], top
    assert not any(c.get("sugerido") for c in sug["choferes"][1:])
