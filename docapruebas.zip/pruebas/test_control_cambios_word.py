"""Propuesta 10: copia con las correcciones como control de cambios real de Word (w:ins / w:del)."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_segmentos() -> None:
    import control_cambios_word as cw
    assert cw.segmentos("el interno pidió", "la persona detenida pidió") == [
        ("quitado", "el"), ("agregado", "la"), ("igual", " "), ("quitado", "interno"), ("agregado", "persona detenida"), ("igual", " pidió")]
    assert cw.segmentos("igual", "igual") == [("igual", "igual")]


def test_documento(tmp_path: Path) -> None:
    from docx import Document
    from docx.shared import Pt

    import control_cambios_word as cw
    d = Document()
    d.add_paragraph("Al Sr. Director")
    r = d.add_paragraph().add_run("El interno manifesto que no recibio atencion.")
    r.bold, r.font.size = True, Pt(12)
    d.add_paragraph("Párrafo que cambió después del análisis.")
    origen, salida = tmp_path / "o.docx", tmp_path / "s.docx"
    d.save(str(origen))
    props = [{"ubicacion": "body:1", "original": "El interno manifesto que no recibio atencion.",
              "propuesto": "La persona detenida manifestó que no recibió atención."},
             {"ubicacion": "body:0", "original": "Al Sr. Director", "propuesto": "Al Sr. Director"},
             {"ubicacion": "body:2", "original": "Otro texto", "propuesto": "Otro texto cambiado"}]
    assert cw.generar(origen, salida, props) == 1, "sin cambio o con el párrafo distinto no se marca"
    xml = zipfile.ZipFile(salida).read("word/document.xml").decode()
    assert xml.count("<w:ins ") >= 3 and xml.count("<w:del ") >= 3 and 'w:author="Corrección automática"' in xml
    assert "<w:delText xml:space=\"preserve\">manifesto</w:delText>" in xml and "manifestó" in xml and "<w:b/>" in xml
    assert Document(str(origen)).paragraphs[1].text == props[0]["original"], "el original no se toca"
