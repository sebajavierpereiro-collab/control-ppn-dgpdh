"""Propuestas 13, 14 y 17: legibilidad INFLESZ, control de lenguaje claro y perfil por tipo documental (solo avisa)."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dgpdh.dominio import lenguaje_claro as lc

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

LARGA = ("Me dirijo a usted con el objeto de poner en su conocimiento que durante la visita realizada al establecimiento "
         "se constató que las personas alojadas en el pabellón no contaban con agua caliente ni con elementos de higiene "
         "suficientes desde hacía varias semanas.")


def test_oraciones_y_parrafos() -> None:
    avisos = lc.revisar(LARGA)
    assert [a.regla for a in avisos] == ["oracion_larga"] and "30 palabras" in avisos[0].porque
    assert avisos[0].fragmento.endswith("…")
    assert not lc.revisar("La Unidad informó el traslado. Pedimos que nos avise.")
    parrafo = " ".join(["El organismo pidió informes a la unidad."] * 20)
    assert "parrafo_largo" in {a.regla for a in lc.revisar(parrafo)}
    assert "varias_ideas" in {a.regla for a in lc.revisar("Primero esto; después aquello; por último lo otro.")}
    assert lc.revisar("") == [] and lc.revisar(None) == []


def test_pasiva_doble_negacion_y_formulas() -> None:
    reglas = [a.regla for a in lc.revisar("El pedido fue rechazado por la Unidad. Se han realizado gestiones. No es improbable que vuelva.")]
    assert reglas.count("pasiva") == 2 and "doble_negacion" in reglas
    assert "pasiva" not in {a.regla for a in lc.revisar("Se solicita informe. Fue a la unidad. Será necesario.")}, "fórmulas y verbos sin participio"
    assert "doble_negacion" in {a.regla for a in lc.revisar("La situación no deja de ser grave.")}


def test_perfiles_por_tipo() -> None:
    texto = ("Le contamos que a los fines de su pedido conforme lo hablado vamos a pedir a la unidad que le den una respuesta "
             "lo antes posible. Gracias.")
    ppl = lc.perfil_de("NOTA_PPL")
    assert ppl.max_palabras_oracion == 20 and ppl.controlar_tecnicismos
    regl = {a.regla for a in lc.revisar(texto, ppl)}
    assert {"oracion_larga", "tecnicismo"} <= regl, "más exigente para la nota a persona detenida"
    assert "tecnicismo" not in {a.regla for a in lc.revisar(texto, lc.perfil_de("OFICIO"))}
    assert not lc.revisar(LARGA, lc.perfil_de("PRESENTACION_JUDICIAL")), "la presentación judicial admite oraciones más largas"
    assert lc.perfil_de("raro") is lc.PERFIL_GENERAL and lc.perfil_de(None).proponer_ia
    sin = lc.perfil_de("OFICIO", frozenset({"OFICIO"}))
    assert not sin.proponer_ia and sin.max_palabras_oracion == 40
    assert not lc.perfil_de("NOTA", frozenset({"NOTA"})).proponer_ia


def test_observaciones_explican() -> None:
    obs = lc.observaciones(LARGA + " " + LARGA, lc.PERFIL_GENERAL)
    assert len(obs) == 1 and obs[0].startswith("Lenguaje claro: 2 oración(es) larga(s)") and "releer" in obs[0]
    assert lc.interpretacion_inflesz(30) == "muy difícil" and lc.interpretacion_inflesz(60) == "normal" and lc.interpretacion_inflesz(90) == "muy fácil"
    assert lc.interpretacion_inflesz(None) == ""


def test_en_la_correccion_de_una_nota(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import nucleo
    from docx import Document
    ruta = tmp_path / "Nota prueba.docx"
    doc = Document()
    for p in ("Al Sr. Director del Complejo Penitenciario Federal I", LARGA, "El pedido fue rechazado por la Unidad sin explicación alguna."):
        doc.add_paragraph(p)
    doc.save(str(ruta))
    llamadas: list[str] = []
    monkeypatch.setattr(nucleo, "ia_disponible", lambda p: True)
    monkeypatch.setattr(nucleo, "corregir_con_ia", lambda t: llamadas.append(t) or t)
    r = nucleo.generar_propuestas_documento(ruta, "Nota prueba.docx")
    obs = " | ".join(r["observaciones"])
    assert "Legibilidad (INFLESZ)" in obs and "Lenguaje claro: 1 oración(es) larga(s)" in obs and "voz pasiva" in obs
    assert llamadas, "la IA corrige como siempre"
    llamadas.clear()
    monkeypatch.setitem(nucleo.LENGUAJE_CLARO, "sin_ia", frozenset({"OFICIO"}))
    with nucleo.con_tipo_documental("OFICIO"):
        r = nucleo.generar_propuestas_documento(ruta, "Nota prueba.docx")
    assert not llamadas, "propuesta 17: para este tipo no corre la IA"
    assert "voz pasiva" not in " | ".join(r["observaciones"]), "el oficio no controla pasivas"
    monkeypatch.setitem(nucleo.LENGUAJE_CLARO, "activo", False)
    r = nucleo.generar_propuestas_documento(ruta, "Nota prueba.docx")
    assert not any(o.startswith(("Lenguaje claro", "Legibilidad")) for o in r["observaciones"]), "se apaga en config.ini"
