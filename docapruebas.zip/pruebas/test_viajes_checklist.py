"""Propuesta 60: control del vehículo antes de salir."""
from __future__ import annotations

from datetime import date
from typing import Any

import pytest

from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import checklist as ck

A = au.Actor(1, "Coord")


def test_control(base: Any) -> None:
    db = base
    with db._conexion() as con:
        items = ck.items(con)
        assert len(items) == 7 and items[0]["texto"] == "Luces y balizas"
        with pytest.raises(PermisoDenegado):
            ck.agregar_item(con, A, False, "Gato")
        nuevo = ck.agregar_item(con, A, True, "Gato y llave de rueda")
        ck.baja_item(con, A, True, nuevo)
        with pytest.raises(NoEncontrado):
            ck.baja_item(con, A, True, nuevo)
        assert len(ck.items(con)) == 7 and len(ck.items(con, True)) == 8
        did = con.execute("INSERT INTO desplazamientos (fecha, creado_en) VALUES (?, 'x')", (date.today().isoformat(),)).lastrowid
        i1, i2 = int(items[0]["id"]), int(items[2]["id"])
        with pytest.raises(PermisoDenegado):
            ck.registrar(con, A, False, did, [ck.Respuesta(i1, "OK", "")])
        with pytest.raises(DatoInvalido, match="Contá"):
            ck.registrar(con, A, True, did, [ck.Respuesta(i1, "NO_APTO", "")])
        with pytest.raises(DatoInvalido):
            ck.registrar(con, A, True, did, [ck.Respuesta(nuevo, "OK", "")])
        with pytest.raises(NoEncontrado):
            ck.registrar(con, A, True, 999999, [ck.Respuesta(i1, "OK", "")])
        no = ck.registrar(con, A, True, did, [ck.Respuesta(i1, "OK", ""), ck.Respuesta(i2, "NO_APTO", "Vencido")])
        assert len(no) == 1 and no[0]["item"] == "Matafuego"
        ck.registrar(con, A, True, did, [ck.Respuesta(i2, "OK", "")])
        ult = {c["item_id"]: c["resultado"] for c in ck.ultimo(con, did)}
        assert ult == {i1: "OK", i2: "OK"}
        assert con.execute("SELECT COUNT(*) FROM checklist_controles").fetchone()[0] == 3, "el control anterior se conserva"
