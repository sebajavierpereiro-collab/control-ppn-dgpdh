"""Propuestas 92 (ficha técnica), 95 (exportación para publicar) y 97 (controles de calidad de datos de metas)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import metas_fichas as mf
from dgpdh.servicios import metas_calidad as mcal


def test_ficha() -> None:
    import metas
    for i in metas.INDICADORES + [x for p in metas.PERFILES.values() for x in (p["indicadores"] or [])]:
        f = mf.ficha(i)
        assert all(f[k] for k in ("definicion", "formula", "fuente", "frecuencia", "responsable", "desde", "cambios")), i["clave"]
    v = mf.ficha(metas.POR_CLAVE["visitas_equipo"])
    assert v["responsable"].startswith("Sistema") and "Un día + una unidad + un equipo" in v["formula"]
    assert mf.ficha(metas.POR_CLAVE["monitoreos"])["responsable"] == "Coordinación del equipo"


def test_controles(base: Any) -> None:
    import auth
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Eq Calidad")
    ana = db.obtener_usuario(db.crear_usuario("anaqc", h, s, "Ana Calidad", "ASESOR", eq))
    hoy = date.today()
    un = db.listar_unidades()

    def viaje(f: date, unidad: int, salida: str) -> int:
        return int(tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": unidad, "hora_salida": salida, "hora_regreso": "13:00"},
                                  [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Eq Calidad", "auto_propio": 1}], ana,
                                  hoy=f - timedelta(days=10)))
    with db._conexion() as con:
        vacios = mcal.controles(con, hoy.year, hoy)
    assert all(not c.filas for c in vacios), "con datos sanos, todo vacío"
    f = hoy - timedelta(days=5) if (hoy - timedelta(days=5)).year == hoy.year else hoy
    a, b = viaje(f, un[0]["id"], "09:00"), viaje(f, un[1]["id"], "10:00")
    futuro = viaje(hoy + timedelta(days=5), un[0]["id"], "09:00")
    with db._conexion() as con:
        con.execute("UPDATE viaje_participantes SET entrevistas = 3, ingreso_pabellones = 1 WHERE viaje_id = ?", (futuro,))
        if hoy.month < 12:
            con.execute("""INSERT INTO metas_realizado (equipo_id, usuario_id, anio, periodo, indicador, cantidad) VALUES (?, ?, ?, ?, 'monitoreos', 2)""",
                        (eq, ana["id"], hoy.year, f"M{hoy.month + 1:02d}"))
        c = {x.clave: x for x in mcal.controles(con, hoy.year, hoy)}
    assert len(c["audiencias_sin_viaje"].filas) == 1 and len(c["pabellones_sin_viaje"].filas) == 1
    if f != hoy:
        assert len(c["dos_unidades_a_la_vez"].filas) == 1 and f"#{a}" in str(c["dos_unidades_a_la_vez"].filas[0]["texto"]) and b
    assert len(c["carga_futura"].filas) == (1 if hoy.month < 12 else 0)
