"""Propuesta 53: números GDE como referencia externa de la nota, con el vínculo propuesto."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dgpdh.dominio import referencias as rf

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_formatos() -> None:
    t = ("En respuesta a la NO-2025-12345678-APN-DGPDH#PPN, y en el marco del EX-2025-00123456- -APN-DD#MJ, se informa. "
         "Ver también IF-2024-987654-APN-SSGA#MSG y la nota NO-2025-12345678-APN-DGPDH#PPN.")
    refs = {r.numero: r for r in rf.gde_del_texto(t)}
    assert set(refs) == {"NO-2025-12345678", "EX-2025-00123456", "IF-2024-00987654"}
    assert refs["NO-2025-12345678"].vinculo == "responde a" and refs["NO-2025-12345678"].reparticion == "DGPDH#PPN"
    assert refs["EX-2025-00123456"].tipo == "Expediente" and refs["EX-2025-00123456"].vinculo is None
    assert rf.gde_del_texto("Reiteramos lo pedido en NO-2026-1111-APN-X#Y")[0].vinculo == "reitera a"
    assert rf.gde_del_texto("EP 1234/2025, DNI 30.123.456, ley 24.660") == [], "el expediente propio y otros números no son GDE"
    assert rf.gde_del_texto(None) == []


def test_en_entidades_y_antecedentes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import agentes
    import database as db
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    ent = agentes.entidades("En respuesta a la NO-2025-12345678-APN-DGPDH#PPN informamos.")
    assert ent["GDE"] == [{"valor": "NO-2025-12345678-APN-DGPDH#PPN (responde a)", "norm": "NO-2025-12345678"}]
    with db._conexion() as con:
        eq = con.execute("SELECT id FROM equipos LIMIT 1").fetchone()[0]
        for i in (1, 2, 3):
            con.execute("INSERT INTO notas (id, nombre_original, equipo_id, ruta_original, creado_en, actualizado_en) VALUES (?,?,?,?,?,?)",
                        (i, f"n{i}.docx", eq, "x", "2026-11-14", "2026-11-14"))
    db.guardar_entidades(1, [("GDE", "NO-2025-12345678-APN-DGPDH#PPN", "NO-2025-12345678")])
    db.guardar_entidades(2, [("GDE", "NO-2025-12345678", "NO-2025-12345678")])
    db.guardar_entidades(3, [("GDE", "NO-2025-99999999", "NO-2025-99999999")])
    assert [a["id"] for a in db.antecedentes(1)] == [2], "la otra nota que cita el mismo documento GDE"
