"""Perfiles de indicadores de Metas: el general no cambia; salud mental (por equipo) y salud médica (por profesional y por
unidad o complejo), con la meta del equipo trasladada a cada profesional y propuesta de casos desde las notas."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest


def _base(db: Any) -> dict[str, Any]:
    import auth
    h, s = auth.generar_hash_clave("Clave1234")
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    eq = db.crear_equipo("Equipo Salud Médica")
    p1 = db.obtener_usuario(db.crear_usuario("medica1", h, s, "Laura Ejemplo", "ASESOR", eq))
    p2 = db.obtener_usuario(db.crear_usuario("medica2", h, s, "Mario Prueba", "ASESOR", eq))
    coo = db.obtener_usuario(db.crear_usuario("coomed", h, s, "Coord Médica", "COORDINADOR", eq))
    return {"direc": direc, "eq": eq, "p1": p1, "p2": p2, "coo": coo, "e": {"id": eq, "nombre": "Equipo Salud Médica"}}


def test_general_no_cambia_y_perfil_auditado(base: Any) -> None:
    import metas
    db = base
    g = _base(db)
    assert metas.perfil_de(g["eq"]) == "general" and metas.indicadores_de(g["eq"]) == metas.INDICADORES
    with pytest.raises(PermissionError):
        metas.guardar_perfil(g["eq"], "salud_medica", g["coo"])
    with pytest.raises(ValueError):
        metas.guardar_perfil(g["eq"], "otro", g["direc"])
    assert metas.guardar_perfil(g["eq"], "salud_medica", g["direc"]) is True
    assert metas.guardar_perfil(g["eq"], "salud_medica", g["direc"]) is False
    assert [i["clave"] for i in metas.indicadores_de(g["eq"])][:4] == ["med_entrevistas", "med_historias_clinicas", "med_intervenciones", "med_recomendaciones"]
    otro = db.crear_equipo("Equipo General")
    assert metas.indicadores_de(otro) == metas.INDICADORES, "los demás equipos no cambian"
    with db._conexion() as con:
        a = con.execute("SELECT antes, despues FROM auditoria WHERE accion = 'Perfil de metas del equipo'").fetchone()
    assert '"general"' in a["antes"] and '"salud_medica"' in a["despues"]


def test_salud_medica_persona_unidad_y_meta_individual(base: Any) -> None:
    import metas
    db = base
    g = _base(db)
    metas.guardar_perfil(g["eq"], "salud_medica", g["direc"])
    metas.guardar_metas_anuales(2026, {g["eq"]: {"med_entrevistas": 40}}, g["direc"])
    metas.guardar_carga(g["eq"], 2026, "M07", {(g["p1"]["id"], "med_entrevistas"): 30, (g["p2"]["id"], "med_entrevistas"): 15,
                                               (g["p1"]["id"], "monitoreos"): 9}, g["coo"])
    u1 = db.listar_unidades()[0]
    n = metas.guardar_dim(g["eq"], 2026, "M07", {("med_casos_individuales", metas.clave_unidad(u1["id"]), u1["nombre"]): 12,
                                                 ("med_casos_individuales", metas.clave_unidad(texto="Alcaidía 3"), "Alcaidía 3"): 2,
                                                 ("med_reuniones", "", None): 4, ("visitas_equipo", "", None): 99, ("monitoreos", "", None): 5}, g["coo"])
    assert n == 3, "lo que sale de los viajes y lo de otros perfiles no se carga a mano"
    metas.guardar_dim(g["eq"], 2026, "T3", {("med_informes_golpeados", metas.clave_unidad(u1["id"]), u1["nombre"]): 4}, g["coo"])
    x = metas.seguimiento(2026, [g["e"]], date(2026, 9, 30))["equipos"][0]
    f = {r["clave"]: r for r in x["filas"]}
    assert f["med_entrevistas"]["hecho"] == 45 and f["med_entrevistas"]["estado"] == "cumplida", "el equipo cumple con el total"
    assert "monitoreos" not in f, "con el perfil de salud médica no se siguen los indicadores generales"
    assert f["med_casos_individuales"]["hecho"] == 14 and f["med_reuniones"]["hecho"] == 4 and f["med_informes_golpeados"]["hecho"] == 4
    assert [(r["unidad"], r["total"]) for r in f["med_casos_individuales"]["unidades"]] == [(u1["nombre"], 12), ("Alcaidía 3", 2)]
    assert f["med_informes_golpeados"]["unidades"][0]["trimestres"] == [0, 0, 4, 0]
    pp = {p["usuario"]["id"]: p for p in x["por_persona"]}
    assert pp[g["p1"]["id"]]["indicadores"]["med_entrevistas"]["estado"] == "en_camino"
    assert pp[g["p2"]["id"]]["indicadores"]["med_entrevistas"]["estado"] == "atrasada", "la meta del equipo es la de cada profesional"
    assert "med_casos_individuales" not in pp[g["p1"]["id"]]["indicadores"], "lo que va por unidad no lleva estado individual"
    assert f["med_casos_colectivos"]["estado"] == "sin_meta", "las metas de salud quedan sin cargar hasta que las fije la Dirección"
    libro = metas.exportar_planilla(2026, g["e"], date(2026, 9, 30))
    assert "Metas y avance" in libro.sheetnames


def test_salud_mental_viajes_o_carga(base: Any) -> None:
    import metas
    import traslados as tr
    db = base
    g = _base(db)
    metas.guardar_perfil(g["eq"], "salud_mental", g["direc"])
    assert all(metas.dimension_de(i) == "equipo" for i in metas.indicadores_de(g["eq"]))
    metas.guardar_dim(g["eq"], 2026, "M07", {("entrevistas", "", None): 37, ("sm_recorridas", "", None): 2}, g["coo"])
    metas.guardar_dim(g["eq"], 2026, "M08", {("entrevistas", "", None): 34}, g["coo"])
    hoy = date.today()
    f = date(hoy.year, 8, 10) if hoy.year == 2026 and hoy.month > 8 else None
    if f:  # agosto con audiencias informadas en los viajes: manda el viaje y lo cargado no se suma
        vid = tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": db.listar_unidades()[0]["id"]},
                             [{"usuario_id": g["p1"]["id"], "nombre": g["p1"]["nombre"], "equipo_nombre": "Equipo Salud Médica", "auto_propio": 1}],
                             g["p1"], hoy=f - timedelta(days=10))
        with db._conexion() as con:
            con.execute("UPDATE viaje_participantes SET entrevistas = 5 WHERE viaje_id = ?", (vid,))
        metas.armar_foto(2026, hoy)
    x = metas.seguimiento(2026, [g["e"]], date(2026, 9, 30))["equipos"][0]
    fl = {r["clave"]: r for r in x["filas"]}
    assert fl["entrevistas"]["hecho"] == (37 + 5 if f else 71) and fl["sm_recorridas"]["hecho"] == 2
    assert x["por_persona"] == [], "salud mental no tiene indicadores por persona"
    assert fl["visitas_equipo"]["nombre"] == "Cantidad de viajes"


def test_propuesta_de_casos_desde_las_notas(base: Any) -> None:
    import metas
    db = base
    g = _base(db)
    metas.guardar_perfil(g["eq"], "salud_medica", g["direc"])
    u1 = db.listar_unidades()[0]
    with db._conexion() as con:
        cols = {f[1] for f in con.execute("PRAGMA table_info(notas)")}
    for k, alcance in enumerate(("INDIVIDUAL", None, "COLECTIVO")):
        nid = db.crear_nota(f"Nota {k}.docx", g["eq"], "x.docx", usuario_id=g["p1"]["id"])
        with db._conexion() as con:
            con.execute("UPDATE notas SET unidad_id = ?, fecha_nota = ?, estado = 'FIRMADA', es_nota = 1" + (", clasif_alcance = ?" if "clasif_alcance" in cols else "")
                        + " WHERE id = ?", ((u1["id"], f"2026-07-1{k}", alcance, nid) if "clasif_alcance" in cols else (u1["id"], f"2026-07-1{k}", nid)))
    prop = metas.propuesta_notas(g["eq"], 2026, "M07")
    k = metas.clave_unidad(u1["id"])
    assert prop[("med_casos_individuales", k)] == (u1["nombre"], 2) and prop[("med_casos_colectivos", k)] == (u1["nombre"], 1), prop
