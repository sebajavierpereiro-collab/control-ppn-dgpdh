"""Propuesta 57: horarios de ingreso estructurados por unidad (versiones, baja lógica, aviso que no bloquea)."""
from __future__ import annotations

from datetime import date
from typing import Any

import pytest

from dgpdh.dominio import ventanas as dom
from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import ventanas as srv

DIR = au.Actor(1, "Director General")
MAR = date(2026, 11, 17)  # martes


def test_dominio() -> None:
    v1 = dom.Ventana(1, 9, 1, "09:00", "15:00", "AUDIENCIAS", "2026-01-01")
    v2 = dom.Ventana(2, 9, 1, "10:00", "13:00", "AUDIENCIAS", "2026-12-01")  # cambio que todavía no rige
    v3 = dom.Ventana(3, 9, 3, "09:00", "12:00", "VISITA", "2026-01-01")
    assert dom.vigentes([v1, v2, v3], MAR) == [v1, v3]
    assert dom.vigentes([v1, v2, v3], date(2026, 12, 1)) == [v2, v3]
    assert dom.aviso([v1, v3], MAR, "08:00") is None
    assert dom.aviso([v1, v3], MAR, "16:00") == "El horario de ingreso de ese día termina a las 15:00 y la salida está prevista a las 16:00."
    assert dom.aviso([v1, v3], date(2026, 11, 16), "08:00") == "La unidad no tiene horario de ingreso los lunes (recibe: martes, jueves)."
    assert dom.aviso([], MAR, "16:00") is None, "sin horarios cargados no se avisa nada"
    assert v1.texto == "martes de 09:00 a 15:00 (audiencias)"


def test_servicio(base: Any) -> None:
    db = base
    uid = db.listar_unidades()[0]["id"]
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            srv.guardar(con, DIR, False, uid, [1], "09:00", "15:00", "AUDIENCIAS", "")
        for args, msg in ((([], "09:00", "15:00", "AUDIENCIAS"), "día"), (([1], "15:00", "09:00", "AUDIENCIAS"), "horario"),
                          (([1], "9", "15:00", "AUDIENCIAS"), "horario"), (([1], "09:00", "15:00", "OTRO"), "para qué")):
            with pytest.raises(DatoInvalido, match=msg):
                srv.guardar(con, DIR, True, uid, *args, "")  # type: ignore[arg-type]
        with pytest.raises(NoEncontrado):
            srv.guardar(con, DIR, True, 999999, [1], "09:00", "15:00", "AUDIENCIAS", "")
        ids = srv.guardar(con, DIR, True, uid, [1, 3], "09:00", "15:00", "AUDIENCIAS", "2026-01-01")
        assert len(ids) == 2 and len(srv.listar(con, uid)) == 2
        assert srv.aviso_para_viaje(con, uid, MAR.isoformat(), "16:30") is not None
        assert srv.aviso_para_viaje(con, uid, MAR.isoformat(), "08:00") is None
        assert srv.aviso_para_viaje(con, None, MAR.isoformat(), "16:30") is None
        with pytest.raises(DatoInvalido):
            srv.dar_de_baja(con, DIR, True, ids[0], "")
        assert srv.dar_de_baja(con, DIR, True, ids[0], "Cambió el horario") == uid
        with pytest.raises(NoEncontrado):
            srv.dar_de_baja(con, DIR, True, ids[0], "otra vez")
        assert len(srv.listar(con, uid)) == 1 and len(srv.listar(con, uid, incluir_bajas=True)) == 2
        assert srv.aviso_para_viaje(con, uid, MAR.isoformat(), "08:00") is not None, "sin el martes, avisa que ese día no recibe"
        acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'unidad_ventana' ORDER BY id")]
    assert acciones == ["Horario de ingreso cargado", "Horario de ingreso cargado", "Horario de ingreso dado de baja"]
