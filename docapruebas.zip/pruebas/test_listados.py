"""Propuesta 37: comparar un listado de personas detenidas con el anterior de la misma fuerza (solo avisa)."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dgpdh.dominio import listados as dl

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def _regs(por_unidad: dict[object, int], sin_dni: int = 0, con_lpu: bool = True) -> list[dict[str, object]]:
    salida: list[dict[str, object]] = []
    for u, n in por_unidad.items():
        for i in range(n):
            r: dict[str, object] = {"nombre_completo": f"P {u} {i}", "dni": "" if len(salida) < sin_dni else str(30000000 + len(salida))}
            r["unidad_id" if isinstance(u, int) else "centro_otro"] = u
            if con_lpu:
                r["lpu"] = str(100000 + len(salida))
            salida.append(r)
    return salida


def test_perfil() -> None:
    p = dl.perfil(_regs({1: 3, "Comisaría 7": 1}, sin_dni=1))
    assert p["filas"] == 4 and p["por_unidad"] == {"u:1": 3, "o:comisaria 7": 1} and p["sin_dni_pct"] == 25.0
    assert "lpu" in p["columnas"] and dl.perfil([])["sin_dni_pct"] == 0.0


def test_comparar() -> None:
    anterior = dl.perfil(_regs({1: 40, 2: 30, 3: 5}))
    normal = dl.comparar(dl.perfil(_regs({1: 38, 2: 31, 3: 1})), anterior)
    assert normal == [], "variaciones chicas y unidades chicas no alertan"
    raro = dl.comparar(dl.perfil(_regs({1: 20}, sin_dni=8, con_lpu=False)), anterior, fecha_nuevo="2026-11-01", fecha_anterior="2026-11-10",
                       fecha_ultima="2026-11-10", nombres={"u:2": "CPF II"}, etiquetas={"lpu": "LPU"})
    tipos = [a.tipo for a in raro]
    assert tipos.count("unidad") == 2 and {"fecha", "total", "sin_dni", "columnas"} <= set(tipos)
    textos = " | ".join(a.mensaje for a in raro)
    assert "CPF II: no figura nadie (tenía 30" in textos and "baja del 50 %" in textos and "LPU" in textos
    assert dl.comparar(dl.perfil(_regs({1: 1})), None) == []


def test_en_la_base(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import json

    import database as db
    import detenidos
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    u1 = db.listar_unidades()[0]
    assert detenidos.alertas_listado(_regs({u1["id"]: 3}), 1, "2026-11-01") == [], "sin listado anterior no hay contra qué comparar"
    with db._conexion() as con:
        con.execute("INSERT INTO detenidos_listados (fuerza_id, fecha_listado, filas, informe, creado_en) VALUES (1, '2026-11-01', 40, ?, 'x')",
                    (json.dumps({"perfil": dl.perfil(_regs({u1["id"]: 40}))}),))
        con.execute("INSERT INTO detenidos_listados (fuerza_id, fecha_listado, filas, creado_en, anulado_en) VALUES (1, '2026-11-08', 400, 'x', 'y')")
    alertas = detenidos.alertas_listado(_regs({u1["id"]: 10}), 1, "2026-11-05")
    assert any(u1["nombre"] in a for a in alertas) and any("Trae 10 personas contra 40" in a for a in alertas), "el anulado no cuenta"
    assert detenidos.alertas_listado(_regs({u1["id"]: 10}), None, "2026-11-05") == []
    with db._conexion() as con:  # listado viejo sin perfil: se compara solo el total
        con.execute("UPDATE detenidos_listados SET informe = NULL WHERE fecha_listado = '2026-11-01'")
    assert detenidos.alertas_listado(_regs({u1["id"]: 10}), 1, "2026-11-05") == ["Trae 10 personas contra 40 del listado anterior (2026-11-01) (baja del 75 %)."]
