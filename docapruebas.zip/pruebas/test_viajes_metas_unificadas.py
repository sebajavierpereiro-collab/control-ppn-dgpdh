"""Propuesta 82: una sola meta de visitas por equipo (migración sin pérdida de datos, lectura del tablero y elección)."""
from __future__ import annotations

from datetime import date
from typing import Any

import pytest

from dgpdh.errores import NoEncontrado, PermisoDenegado
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import metas_visitas as mv

DIR = au.Actor(1, "Director General")


def _migracion_0023() -> mg.Migracion:
    return next(m for m in mg.disponibles() if m.numero == 23)


def test_migracion_copia_conserva_y_anota_diferencias(base: Any) -> None:
    db = base
    a, b, c, d = (db.crear_equipo(n) for n in ("Eq A", "Eq B", "Eq C", "Eq D"))
    with db._conexion() as con:
        for eid, tri in ((a, (3, 3, 2, 2)), (b, (1, 1, 1, 1)), (c, (5, 0, 0, 0)), (d, (0, 0, 0, 0))):
            for t, m in enumerate(tri, 1):
                con.execute("INSERT INTO metas_viajes (equipo_id, anio, trimestre, minimo) VALUES (?, 2026, ?, ?)", (eid, t, m))
        con.execute("INSERT INTO metas_anuales (equipo_id, anio, indicador, meta) VALUES (?, 2026, 'visitas_equipo', 4)", (b,))  # coincide
        con.execute("INSERT INTO metas_anuales (equipo_id, anio, indicador, meta) VALUES (?, 2026, 'visitas_equipo', 12)", (c,))  # difiere
        _migracion_0023().aplicar(con)
        _migracion_0023().aplicar(con)  # dos veces no duplica nada
        m = mv.metas(con, 2026)
        assert m[a] == {1: 3, 2: 3, 3: 2, 4: 2, "anual": 10}, "sin meta anual: se copia la del tablero con su reparto"
        assert m[b] == {1: 1, 2: 1, 3: 1, 4: 1, "anual": 4}
        assert m[c] == {1: 3, 2: 3, 3: 3, 4: 3, "anual": 12}, "difieren: manda la de Metas"
        assert d not in m, "un tablero en cero no crea meta"
        difs = mv.diferencias(con, 2026)
        assert [(x["equipo_id"], x["meta_anual"], x["meta_tablero"], x["trimestres"]) for x in difs] == [(c, 12, 5, [5, 0, 0, 0])]
        assert con.execute("SELECT COUNT(*) FROM metas_viajes").fetchone()[0] == 16, "la tabla vieja queda intacta"
    import metas
    import tablero_direccion as td
    assert metas.metas_anuales(2026)[a]["visitas_equipo"] == 10 and td.metas(2026)[c]["anual"] == 12


def test_elegir_y_fijar(base: Any) -> None:
    db = base
    c, e = db.crear_equipo("Eq C"), db.crear_equipo("Eq E")
    with db._conexion() as con:
        for t, m in enumerate((5, 0, 0, 0), 1):
            con.execute("INSERT INTO metas_viajes (equipo_id, anio, trimestre, minimo) VALUES (?, 2026, ?, ?)", (c, t, m))
        con.execute("INSERT INTO metas_anuales (equipo_id, anio, indicador, meta) VALUES (?, 2026, 'visitas_equipo', 12)", (c,))
        _migracion_0023().aplicar(con)
        with pytest.raises(PermisoDenegado):
            mv.resolver(con, DIR, False, c, 2026, "TABLERO")
        mv.resolver(con, DIR, True, c, 2026, "TABLERO")
        assert mv.metas(con, 2026)[c] == {1: 5, 2: 0, 3: 0, 4: 0, "anual": 5} and mv.diferencias(con) == []
        with pytest.raises(NoEncontrado):
            mv.resolver(con, DIR, True, c, 2026, "ANUAL")
        with pytest.raises(PermisoDenegado):
            mv.fijar(con, DIR, False, 2026, {e: [1, 1, 1, 1]})
        mv.fijar(con, DIR, True, 2026, {e: [2, 2, 1, 1]})
        con.execute("UPDATE metas_anuales SET meta = 8 WHERE equipo_id = ? AND indicador = 'visitas_equipo'", (e,))
        assert mv.metas(con, 2026)[e] == {1: 2, 2: 2, 3: 2, 4: 2, "anual": 8}, "si cambia la anual en Metas, el reparto viejo no vale"
        acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'metas_visitas' ORDER BY id")]
    assert acciones == ["Meta de visitas fijada", "Diferencia de metas resuelta", "Meta de visitas fijada"]


def test_metas_y_tablero_ven_lo_mismo(base: Any) -> None:
    import auth
    import metas
    import tablero_direccion as td
    db = base
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    eq = db.crear_equipo("Eq Única")
    anio = date.today().year
    td.guardar_metas(anio, {eq: [1, 2, 3, 4]}, direc)
    assert metas.metas_anuales(anio)[eq]["visitas_equipo"] == 10
    metas.guardar_metas_anuales(anio, {eq: {"visitas_equipo": 20}}, direc)
    assert td.metas(anio)[eq] == {1: 5, 2: 5, 3: 5, 4: 5, "anual": 20}
    h, s = auth.generar_hash_clave("Clave1234")
    coord = db.obtener_usuario(db.crear_usuario("coou", h, s, "Coord Única", "COORDINADOR", eq))
    with pytest.raises(PermisoDenegado):
        td.guardar_metas(anio, {eq: [1, 1, 1, 1]}, coord)
    with db._conexion() as con:
        assert con.execute("SELECT COUNT(*) FROM auditoria WHERE entidad = 'metas_anuales'").fetchone()[0] == 1
