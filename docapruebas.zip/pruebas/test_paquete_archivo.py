"""Propuesta 6: paquete de archivo verificable por año o expediente."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import zipfile
from pathlib import Path

import pytest

from dgpdh.errores import DatoInvalido
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import paquete_archivo as pa


def test_paquete(tmp_path: Path) -> None:
    con = sqlite3.connect(tmp_path / "t.db")
    con.execute("""CREATE TABLE notas (id INTEGER PRIMARY KEY, nombre_original TEXT, estado TEXT, nro_nota TEXT, nro_expte TEXT, fecha_nota TEXT,
                   creado_en TEXT, ruta_firmada TEXT, ruta_despacho_pdf TEXT, sha256_firmado TEXT, sha256_despacho TEXT)""")
    con.execute("CREATE TABLE historial_estados (id INTEGER PRIMARY KEY, nota_id INTEGER, estado TEXT, fecha TEXT, usuario TEXT, comentario TEXT)")
    for m in mg.disponibles():
        m.aplicar(con)
    docs = []
    for i, contenido in enumerate((b"uno", b"dos", b"tres"), 1):
        r = tmp_path / f"doc{i}.pdf"
        r.write_bytes(contenido)
        docs.append(r)
    sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731
    con.executemany("INSERT INTO notas (id, nombre_original, estado, nro_nota, nro_expte, fecha_nota, creado_en, ruta_firmada, ruta_despacho_pdf, "
                    "sha256_firmado, sha256_despacho) VALUES (?,?,?,?,?,?,?,?,?,?,?)", [
        (1, "Nota 1", "DESPACHADA", "10", "EP 1/2026", "2026-03-01", "2026-03-01", None, str(docs[0]), None, sha(b"uno")),
        (2, "Nota 2", "FIRMADA", None, "EP 2/2026", "2026-04-01", "2026-04-01", str(docs[1]), None, sha(b"otra cosa"), None),
        (3, "Nota 3", "FIRMADA", None, None, "2026-05-01", "2026-05-01", str(tmp_path / "no_existe.pdf"), None, None, None),
        (4, "Nota 4", "EN_REVISION", None, None, "2026-05-01", "2026-05-01", str(docs[2]), None, None, None),
        (5, "Nota 5", "FIRMADA", None, None, "2025-05-01", "2025-05-01", str(docs[2]), None, None, None)])
    con.execute("INSERT INTO historial_estados (nota_id, estado, fecha, usuario) VALUES (1, 'DESPACHADA', '2026-03-02', 'Mesa')")
    r = pa.generar(con, tmp_path / "out" / "p.zip", anio=2026, actor=au.Actor(1, "Director"))
    assert (r.documentos, r.faltantes, r.alterados) == (3, 1, 1)
    with zipfile.ZipFile(r.ruta) as z:
        nombres = set(z.namelist())
        assert {"MANIFIESTO.sha256", "manifiesto.json", "historial_estados.csv", "LEEME.txt"} <= nombres
        for linea in z.read("MANIFIESTO.sha256").decode().splitlines():
            h, nombre = linea.split("  ", 1)
            assert hashlib.sha256(z.read(nombre)).hexdigest() == h, "se puede volver a verificar"
        man = json.loads(z.read("manifiesto.json"))
        assert [d["id"] for d in man["documentos"]] == [1, 2, 3] and "no coincide" in man["documentos"][1]["problema"]
        assert "DESPACHADA" in z.read("historial_estados.csv").decode("utf-8-sig")
    assert pa.generar(con, tmp_path / "q.zip", expediente="ep 1/2026", actor=au.Actor(1, "Director")).documentos == 1
    assert con.execute("SELECT COUNT(*) FROM auditoria WHERE accion = 'Paquete de archivo'").fetchone()[0] == 2
    with pytest.raises(DatoInvalido):
        pa.generar(con, tmp_path / "x.zip", actor=au.Actor(1, "Director"))
