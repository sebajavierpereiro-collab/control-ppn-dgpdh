"""Propuestas 58 (requisitos y habilidades) y 59 (descanso mínimo del chofer entre jornadas)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import habilidades as hab


def test_dominio() -> None:
    req = hab.etiquetas("Ruta larga, licencia D1; ")
    assert req == {"ruta larga", "licencia d1"}
    assert hab.faltantes(req, frozenset(), frozenset({"licencia d1"})) == {"licencia d1"}, "«ruta larga» no es de choferes"
    assert hab.faltantes(req, frozenset({"licencia d1"}), frozenset({"licencia d1"})) == frozenset()
    assert hab.sin_quien_cumpla(req, frozenset({"licencia d1"}), frozenset()) == {"ruta larga"}
    assert hab.descanso_horas("22:00", "06:00") == 8.0 and hab.descanso_horas(None, "06:00") is None


def test_sugeridor_y_anomalias(base: Any) -> None:
    import auth
    import operacion as op
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Hab")
    ana = db.obtener_usuario(db.crear_usuario("anah", h, s, "Ana Hab", "ASESOR", eq))
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    for n in ("cha", "chb"):
        db.crear_usuario(n, h, s, f"Chofer {n.upper()}", "CHOFER", None, acceso_notas=False)
    tr.sincronizar_choferes()
    ch = {c["nombre"]: c["id"] for c in tr.listar_choferes()}
    a, b = ch["Chofer CHA"], ch["Chofer CHB"]
    v4 = tr.guardar_vehiculo(None, {"dominio": "HA100AA", "capacidad": "4"})
    v7 = tr.guardar_vehiculo(None, {"dominio": "HB200BB", "capacidad": "7"})
    with db._conexion() as con:
        con.execute("UPDATE choferes SET habilidades = 'licencia d1' WHERE id = ?", (b,))
        con.execute("UPDATE vehiculos SET habilidades = 'ruta larga' WHERE id = ?", (v7,))
    amba = [u for u in db.listar_unidades() if tr.es_amba(u["id"])]
    f1 = date.today() + timedelta(days=21)
    f0 = f1 - timedelta(days=1)

    def viaje(fecha: date, salida: str, regreso: str) -> int:
        return int(tr.crear_viaje({"fecha": fecha.isoformat(), "unidad_id": amba[0]["id"], "hora_salida": salida, "hora_regreso": regreso},
                                  [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Equipo Hab"}], ana))
    vid = viaje(f1, "06:00", "12:00")
    with db._conexion() as con:
        con.execute("UPDATE viajes SET requisitos = 'licencia d1, ruta larga' WHERE id = ?", (vid,))
    sug = tr.sugerencias(vid)
    cho = {c["id"]: c for c in sug["choferes"]}
    assert not cho[a]["apto"] and "no cumple: licencia d1" in cho[a]["motivo"] and cho[b]["apto"]
    veh = {x["id"]: x for x in sug["vehiculos"]}
    assert "no cumple: ruta larga" in (veh[v4]["aviso"] or "") and "no cumple" not in (veh[v7]["aviso"] or "")
    # 59: el chofer B volvió tarde el día anterior
    previo = viaje(f0, "15:00", "23:00")
    tr.asignar(previo, b, v4, direc, forzar=True)
    cho = {c["id"]: c for c in tr.sugerencias(vid)["choferes"]}
    assert "descanso de 7 h desde el regreso" in cho[b]["motivo"] and cho[b]["descanso_corto"]
    tr.asignar(vid, b, v7, direc, forzar=True)
    assert any("descansa 7 h" in x["texto"] for x in op.anomalias(f0.isoformat(), f1.isoformat()))
