from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from dgpdh.errores import DatoInvalido
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au


@pytest.fixture()
def con(tmp_path: Path) -> sqlite3.Connection:
    c = sqlite3.connect(tmp_path / "t.db")
    for m in mg.disponibles():
        m.aplicar(c)
    c.execute("CREATE TABLE ausencias (id INTEGER PRIMARY KEY, usuario_id INTEGER, desde TEXT)")
    c.executemany("INSERT INTO ausencias (usuario_id, desde) VALUES (?, ?)", [(7, "2026-11-01"), (7, "2026-11-10"), (8, "2026-11-02")])
    c.commit()
    return c


ANA = au.Actor.desde({"id": 3, "nombre": "Ana Pérez"}, ip="10.0.0.5")


def test_registrar_y_historial(con: sqlite3.Connection) -> None:
    au.registrar(con, accion="Asignación", entidad="viaje", entidad_id=12, antes={"chofer": None}, despues={"chofer": "Pedro"}, actor=ANA)
    au.registrar(con, accion="Cancelación", entidad="viaje", entidad_id=12, motivo="Clima")
    h = au.historial(con, "viaje", 12)
    assert [x["accion"] for x in h] == ["Asignación", "Cancelación"]
    assert h[0]["usuario"] == "Ana Pérez" and h[0]["usuario_id"] == 3 and h[0]["ip"] == "10.0.0.5" and h[0]["despues"] == {"chofer": "Pedro"}
    assert h[1]["usuario"] == au.SISTEMA and h[1]["motivo"] == "Clima"
    with pytest.raises(DatoInvalido):
        au.registrar(con, accion=" ", entidad="viaje")


def test_registro_va_con_la_transaccion(con: sqlite3.Connection) -> None:
    try:
        with con:
            con.execute("UPDATE ausencias SET desde = '2026-12-01' WHERE id = 1")
            au.registrar(con, accion="Edición", entidad="ausencias", entidad_id=1, actor=ANA)
            raise RuntimeError("falla después")
    except RuntimeError:
        pass
    assert con.execute("SELECT COUNT(*) FROM auditoria").fetchone()[0] == 0, "si el cambio se deshace, el registro también"


def test_borrar_con_registro_guarda_la_fila_completa(con: sqlite3.Connection) -> None:
    n = au.borrar_con_registro(con, "ausencias", "usuario_id = ?", (7,), actor=ANA, motivo="cargada por error")
    assert n == 2 and con.execute("SELECT COUNT(*) FROM ausencias").fetchone()[0] == 1
    h = au.historial(con, "ausencias", 2)
    assert h[0]["accion"] == "Baja" and h[0]["antes"] == {"id": 2, "usuario_id": 7, "desde": "2026-11-10"} and h[0]["motivo"] == "cargada por error"
    assert au.borrar_con_registro(con, "ausencias", "usuario_id = ?", (99,)) == 0
    with pytest.raises(DatoInvalido):
        au.borrar_con_registro(con, "ausencias; DROP TABLE x", "1 = 1")


def test_sellado_y_verificacion_detectan_alteraciones(con: sqlite3.Connection) -> None:
    for i in range(5):
        au.registrar(con, accion="Edición", entidad="nota", entidad_id=i, actor=ANA)
    assert au.verificar(con) == au.Verificacion(True, 0, 5)
    assert au.sellar(con) == 5 and au.sellar(con) == 0
    au.registrar(con, accion="Firma", entidad="nota", entidad_id=9, actor=ANA)
    v = au.verificar(con)
    assert v.ok and v.selladas == 5 and v.sin_sellar == 1 and "íntegra" in v.texto
    assert au.sellar(con) == 1 and au.verificar(con).selladas == 6
    con.execute("UPDATE auditoria SET usuario = 'Otra persona' WHERE id = 3")  # alteración por fuera del sistema
    v = au.verificar(con)
    assert not v.ok and v.rota_en == 3 and "#3" in v.texto
    con.execute("UPDATE auditoria SET usuario = 'Ana Pérez' WHERE id = 3")
    assert au.verificar(con).ok
    con.execute("DELETE FROM auditoria WHERE id = 2")  # borrar una fila intermedia también se detecta
    assert au.verificar(con).rota_en == 3


def test_no_cambia_la_configuracion_de_la_conexion(con: sqlite3.Connection) -> None:
    con.row_factory = None
    au.registrar(con, accion="X", entidad="y")
    au.sellar(con); au.verificar(con); au.historial(con, "y", None)
    assert con.row_factory is None


def test_clave_y_ancla_detectan_borrados_y_reescrituras(con: sqlite3.Connection, tmp_path: Path) -> None:
    clave, ancla = b"k" * 32, tmp_path / "ancla.txt"
    for i in range(10):
        au.registrar(con, accion="Edición", entidad="nota", entidad_id=i, actor=ANA)
    assert au.sellar(con, clave, ancla) == 10 and au.verificar(con, clave, ancla).ok
    # Q1: borrar las últimas filas
    con.execute("DELETE FROM auditoria WHERE id > 8")
    v = au.verificar(con, clave, ancla)
    assert not v.ok and "últimos" in v.motivo
    # Q2: editar la cola y dejarla «por sellar» para que se vuelva a sellar
    for i in range(9, 11):
        au.registrar(con, accion="Edición", entidad="nota", entidad_id=i, actor=ANA)
    au.sellar(con, clave, ancla)
    con.execute("UPDATE auditoria SET usuario = 'Otro', hash = NULL WHERE id >= 10")
    v = au.verificar(con, clave, ancla)
    assert not v.ok and "sin sello" in v.motivo
    # Q3: recalcular toda la cadena sin la clave no sirve
    con.execute("UPDATE auditoria SET hash = NULL")
    au.sellar(con)  # sin clave
    assert not au.verificar(con, clave, ancla).ok


def test_legado_sin_clave_sigue_verificando(con: sqlite3.Connection, tmp_path: Path) -> None:
    ancla = tmp_path / "ancla.txt"
    for i in range(3):
        au.registrar(con, accion="X", entidad="y", entidad_id=i)
    au.sellar(con)  # antes de existir la clave (como en la v38 instalada)
    ancla.write_text("LEGADO 3\n", encoding="utf-8")
    au.registrar(con, accion="X", entidad="y", entidad_id=9)
    assert au.sellar(con, b"c" * 32, ancla) == 1
    v = au.verificar(con, b"c" * 32, ancla)
    assert v.ok and v.selladas == 4, v
