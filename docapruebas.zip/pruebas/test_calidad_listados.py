"""Propuesta 42: tablero de calidad de los listados por fuerza y trimestre."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from dgpdh.dominio import calidad_listados as cl

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_tablero() -> None:
    inc = lambda filas, prob, sd: {"filas": filas, "filas_con_problemas": prob, "por_tipo": {"sin_dni": sd}}  # noqa: E731
    t = cl.tablero([{"fuerza": "SPF", "fecha_listado": "2026-02-10", "inconsistencias": inc(100, 20, 10)},
                    {"fuerza": "SPF", "fecha_listado": "2026-03-10", "inconsistencias": inc(100, 10, 5)},
                    {"fuerza": "SPF", "fecha_listado": "2026-05-01", "inconsistencias": inc(200, 10, 2)},
                    {"fuerza": "SPB", "fecha_listado": "2026-05-01", "inconsistencias": inc(50, 25, 0)},
                    {"fuerza": "SPF", "fecha_listado": None, "inconsistencias": inc(9, 9, 9)},
                    {"fuerza": "SPF", "fecha_listado": "2026-05-01", "inconsistencias": None}])
    assert [(p.fuerza, p.trimestre, p.listados, p.pct) for p in t] == [("SPB", "2026-T2", 1, 50.0), ("SPF", "2026-T1", 2, 15.0), ("SPF", "2026-T2", 1, 5.0)]
    assert t[2].tendencia == -10.0 and t[1].tendencia is None and t[1].pct_tipo("sin_dni") == 7.5
    assert cl.trimestre("2026-12-31") == "2026-T4" and cl.trimestre("x") is None


def test_en_la_base(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import detenidos
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    with db._conexion() as con:
        for fecha, prob, anulado in (("2026-01-05", 30, None), ("2026-04-05", 10, None), ("2026-04-06", 99, "x")):
            con.execute("INSERT INTO detenidos_listados (fuerza_id, fecha_listado, filas, informe, creado_en, anulado_en) VALUES (1, ?, 100, ?, 'x', ?)",
                        (fecha, json.dumps({"inconsistencias": {"filas": 100, "filas_con_problemas": prob, "por_tipo": {}}}), anulado))
    t = detenidos.calidad_por_fuerza()
    assert [p.pct for p in t] == [30.0, 10.0] and t[1].tendencia == -20.0, "la carga anulada no cuenta"
    texto = detenidos.calidad_csv(t).decode("utf-8-sig")
    assert texto.splitlines()[0].startswith("Fuerza;Trimestre") and "No contiene datos de personas" in texto
