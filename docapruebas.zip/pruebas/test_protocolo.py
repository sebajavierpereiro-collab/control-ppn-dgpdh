from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

import pytest

from dgpdh.dominio import clasificacion as cl
from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado
from dgpdh.persistencia import migraciones as mg
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import protocolo as pr

TIPOS = {"NOTA": "Nota", "INFORME": "Informe", "PROVEIDO": "Proveído"}
DIR = au.Actor(1, "Director General")
SUB = au.Actor(2, "Subdirectora")


@pytest.fixture()
def ruta(tmp_path: Path) -> Path:
    r = tmp_path / "t.db"
    con = sqlite3.connect(r)
    con.execute("CREATE TABLE notas (id INTEGER PRIMARY KEY, nombre_original TEXT)")
    con.executemany("INSERT INTO notas (id, nombre_original) VALUES (?, ?)", [(i, f"doc{i}") for i in range(1, 30)])
    for m in mg.disponibles():
        m.aplicar(con)
    con.commit()
    con.close()
    return r


def test_validar_clasificacion() -> None:
    c = cl.validar({"tipo": "informe", "alcance": "colectivo", "confidencialidad": "reservado", "destinatario": " Sr.  Juez ",
                    "expediente": "ET 6116/26"}, TIPOS)
    assert c == cl.Clasificacion(tipo="INFORME", subtipo="GENERAL", alcance="COLECTIVO", confidencialidad="RESERVADO",
                                 destinatario="Sr. Juez", expediente="ET 6116/26")
    assert c.lleva_protocolo and c.etiqueta_subtipo() == "Informe"
    n = cl.validar({"tipo": "NOTA", "alcance": "COLECTIVO", "subtipo": "OBSTACULIZACION", "confidencialidad": "PUBLICO", "destinatario": "Unidad 19"}, TIPOS)
    assert n.alcance is None and n.subtipo is None and not n.lleva_protocolo, "alcance y subtipo solo donde corresponden"
    for falta, msg in (({"tipo": "OTRO"}, "tipo"), ({"tipo": "INFORME", "confidencialidad": "PUBLICO", "destinatario": "x"}, "individual o colectivo"),
                       ({"tipo": "NOTA", "confidencialidad": "SECRETO", "destinatario": "x"}, "interno, reservado o público"),
                       ({"tipo": "NOTA", "confidencialidad": "INTERNO", "destinatario": " "}, "destinatario"),
                       ({"tipo": "INFORME", "subtipo": "XX", "alcance": "INDIVIDUAL", "confidencialidad": "INTERNO", "destinatario": "x"}, "subtipo")):
        with pytest.raises(DatoInvalido, match=msg):
            cl.validar(falta, TIPOS)


def test_formato_y_area() -> None:
    assert cl.formato_numero("INF", "DGPDH", 2026, 1) == "INF-DGPDH-2026-0001"
    assert cl.formato_numero("INF", "SGPDH", 2026, 12345) == "INF-SGPDH-2026-12345"
    assert cl.area_de_firmante("DIRECTOR") == "DGPDH" and cl.area_de_firmante("SUBDIRECTOR") == "SGPDH"
    with pytest.raises(DatoInvalido):
        cl.area_de_firmante("ASESOR")
    assert cl.parece_numero(" inf-dgpdh-2026-0001 ") and not cl.parece_numero("Nota 123")


def test_correlativo_por_area_y_anio_y_sin_repetir(ruta: Path) -> None:
    con = sqlite3.connect(ruta)
    a = pr.asignar(con, nota_id=1, tipo="INFORME", area="DGPDH", anio=2026, actor=DIR)
    b = pr.asignar(con, nota_id=2, tipo="INFORME", area="DGPDH", anio=2026, actor=DIR)
    c = pr.asignar(con, nota_id=3, tipo="INFORME", area="SGPDH", anio=2026, actor=SUB)
    d = pr.asignar(con, nota_id=4, tipo="INFORME", area="DGPDH", anio=2027, actor=DIR)
    assert (a, b, c, d) == ("INF-DGPDH-2026-0001", "INF-DGPDH-2026-0002", "INF-SGPDH-2026-0001", "INF-DGPDH-2027-0001")
    assert pr.asignar(con, nota_id=1, tipo="INFORME", area="DGPDH", anio=2026, actor=DIR) == a, "volver a firmar el mismo documento conserva el número"
    assert con.execute("SELECT protocolo_numero FROM notas WHERE id = 2").fetchone()[0] == b
    with pytest.raises(DatoInvalido):
        pr.asignar(con, nota_id=5, tipo="NOTA", area="DGPDH", anio=2026, actor=DIR)
    # anulado: no se reutiliza, la nota queda sin número vigente y una nueva firma toma el siguiente
    anulado = pr.anular(con, b, "falló la impresión de la firma", DIR)
    con.commit()
    assert anulado.estado == "ANULADO" and con.execute("SELECT protocolo_numero FROM notas WHERE id = 2").fetchone()[0] is None
    assert pr.asignar(con, nota_id=2, tipo="INFORME", area="DGPDH", anio=2026, actor=DIR) == "INF-DGPDH-2026-0003"
    assert [x.estado for x in pr.de_nota(con, 2)] == ["ANULADO", "ASIGNADO"]
    with pytest.raises(DatoInvalido):
        pr.anular(con, a, "  ", DIR)
    with pytest.raises(Conflicto):
        pr.anular(con, b, "otra vez", DIR)
    with pytest.raises(NoEncontrado):
        pr.anular(con, "INF-DGPDH-2026-9999", "x", DIR)
    assert {x.numero for x in pr.buscar(con, "dgpdh-2026")} == {"INF-DGPDH-2026-0001", "INF-DGPDH-2026-0002", "INF-DGPDH-2026-0003"}
    acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria ORDER BY id")]
    assert acciones.count("Protocolo asignado") == 5 and acciones.count("Protocolo anulado") == 1
    with pytest.raises(sqlite3.IntegrityError):  # la base misma impide repetir número o correlativo
        con.execute("INSERT INTO protocolo (numero, sigla, area, anio, correlativo, asignado_por, asignado_en) VALUES ('X', 'INF', 'DGPDH', 2026, 1, 'a', 'b')")


def test_firmas_simultaneas_no_repiten(ruta: Path) -> None:
    numeros: list[str] = []
    errores: list[BaseException] = []

    def firmar(nota_id: int) -> None:
        con = sqlite3.connect(ruta, timeout=30)
        try:
            numeros.append(pr.asignar(con, nota_id=nota_id, tipo="INFORME", area="DGPDH", anio=2026, actor=DIR))
        except BaseException as e:  # pragma: no cover - se informa abajo
            errores.append(e)
        finally:
            con.close()

    hilos = [threading.Thread(target=firmar, args=(i,)) for i in range(5, 25)]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join()
    assert not errores, errores
    assert sorted(numeros) == [f"INF-DGPDH-2026-{i:04d}" for i in range(1, 21)]
