"""Propuesta 38: historial de alojamiento por persona y aviso en la prerrevisión si la nota menciona otra unidad."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from dgpdh.dominio import alojamiento as al

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


def test_tramos() -> None:
    cambios = [{"id": 1, "campo": "unidad_id", "antes": "1", "despues": "2", "fecha": "2026-03-10T12:00:00", "listado_id": 7},
               {"id": 2, "campo": "unidad_id", "antes": "2", "despues": None, "fecha": "2026-06-01T09:00:00", "listado_id": None},
               {"id": 3, "campo": "centro_otro", "antes": None, "despues": "Comisaría 7", "fecha": "2026-06-01T09:00:00", "listado_id": None},
               {"id": 4, "campo": "modulo", "antes": "I", "despues": "II", "fecha": "2026-07-01T09:00:00", "listado_id": None}]
    t = al.tramos({"unidad_id": None, "centro_otro": "Comisaría 7"}, cambios, {7: "2026-03-01"})
    assert [(x.unidad_id, x.centro_otro, x.desde, x.hasta) for x in t] == [
        (None, "Comisaría 7", "2026-06-01", None), (2, None, "2026-03-01", "2026-06-01"), (1, None, None, "2026-03-01")]
    assert al.en_fecha(t, "2026-04-15").unidad_id == 2 and al.en_fecha(t, "2025-01-01").unidad_id == 1
    assert t[0].lugar({}) == "Comisaría 7" and t[1].lugar({2: "CPF II"}) == "CPF II"
    assert al.tramos({"unidad_id": 3}, []) == [al.Tramo(3, None, None, None, None)]
    assert al.tramos({}, []) == []


def test_ficha_y_prerrevision(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import agentes
    import database as db
    import detenidos as det
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    u = db.listar_unidades()
    a, b = u[0], u[1]
    i, err, _ = det.guardar({"nombre_completo": "Juan Gómez", "dni": "30123456", "unidad_id": str(a["id"])}, {"nombre": "Mesa"})
    assert not err
    det.guardar(dict(det.obtener(i), unidad_id=str(b["id"])), {"nombre": "Mesa"}, i)
    t = det.historial_alojamiento(i)
    assert [x.unidad_id for x in t] == [b["id"], a["id"]]
    nota = {"id": 1, "nombre_original": "Nota.docx", "tipo": "NOTA"}
    texto_otro = f"Al Director de {a['nombre']}. Me dirijo por Juan Gómez, DNI 30.123.456, alojado en {a['nombre']}."
    avisos = agentes.verificar_alojamiento(nota, texto_otro)
    assert len(avisos) == 1 and "DNI 30123456" in avisos[0]["detalle"] and b["nombre"] in avisos[0]["detalle"]
    assert any(h["dato"] == "Unidad de la persona" for h in agentes.prerrevision(nota, texto_otro))
    texto_bien = f"Me dirijo por Juan Gómez, DNI 30123456, alojado en la {b['nombre']}."
    assert {x["id"] for x in db.proponer_unidades(texto_bien, 3)} == {b["id"]}
    assert agentes.verificar_alojamiento(nota, texto_bien) == []
    assert agentes.verificar_alojamiento(nota, "DNI 30123456 sin unidad mencionada") == []
