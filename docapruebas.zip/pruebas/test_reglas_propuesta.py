"""Propuesta 2: reglas «si pasa esto, proponé aquello» (validación y condiciones)."""
from __future__ import annotations

import pytest

from dgpdh.dominio import reglas_propuesta as rp
from dgpdh.errores import DatoInvalido

BASE = {"nombre": "R", "disparador": "SUBIDA", "condicion": "texto_contiene", "condicion_valor": "Huelga de Hambre", "accion": "prioridad",
        "accion_valor": "urgente"}


def test_validar() -> None:
    assert rp.validar(BASE)["accion_valor"] == "URGENTE"
    for cambio in ({"nombre": ""}, {"disparador": "X"}, {"accion_valor": "ya"}, {"accion": "plazo_dias", "accion_valor": "cinco"},
                   {"condicion": "unidad", "condicion_valor": "CPF"}, {"accion": "aviso_equipo", "accion_valor": "Salud"}):
        with pytest.raises(DatoInvalido):
            rp.validar(dict(BASE, **cambio))


def test_cumple() -> None:
    r = rp.Regla(1, "R", "SUBIDA", "texto_contiene", "huelga de hambre", "prioridad", "URGENTE")
    k = {"tipo_documental": None, "unidades": [], "equipo_id": None}
    assert rp.cumple(r, disparador="SUBIDA", texto="Inició una HUELGA DE  HAMBRE", **k)
    assert not rp.cumple(r, disparador="FIRMA", texto="huelga de hambre", **k)
    assert not rp.cumple(rp.Regla(1, "R", "SUBIDA", "texto_contiene", "huelga", "prioridad", "URGENTE", activa=False),
                         disparador="SUBIDA", texto="huelga", **k)
    assert rp.cumple(rp.Regla(2, "U", "ENVIO", "unidad", "7", "aviso_equipo", "3"), disparador="ENVIO", texto="", tipo_documental=None,
                     unidades=[7], equipo_id=None)
    assert rp.cumple(rp.Regla(3, "T", "FIRMA", "tipo_documental", "oficio", "etiqueta", "judicial"), disparador="FIRMA", texto="",
                     tipo_documental="OFICIO", unidades=[], equipo_id=None)
    assert "Al subir" in r.descripcion
