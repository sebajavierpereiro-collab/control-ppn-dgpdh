"""Propuesta 82 (aclaración del usuario): la meta anual del equipo es también la meta individual de cada integrante. El equipo
puede tener la meta cumplida y una persona no."""
from __future__ import annotations

from datetime import date
from typing import Any


def test_equipo_cumplido_con_una_persona_sin_cumplir_y_meta_cero(base: Any) -> None:
    import io

    import auth
    import metas
    import openpyxl
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo CPF I")
    ana = db.obtener_usuario(db.crear_usuario("anap", h, s, "Ana Pérez", "ASESOR", eq))
    beto = db.obtener_usuario(db.crear_usuario("betop", h, s, "Beto Ruiz", "ASESOR", eq))
    coo = db.obtener_usuario(db.crear_usuario("coop", h, s, "Cora Coord", "COORDINADOR", eq))
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    metas.guardar_metas_anuales(2026, {eq: {"monitoreos": 40, "informes_generales": 0}}, direc)
    hoy = date(2026, 7, 1)
    metas.guardar_carga(eq, 2026, "M01", {(ana["id"], "monitoreos"): 30, (beto["id"], "monitoreos"): 5, (coo["id"], "monitoreos"): 5}, coo)
    metas.guardar_carga(eq, 2026, "M02", {(ana["id"], "monitoreos"): 12}, coo)
    x = metas.seguimiento(2026, [{"id": eq, "nombre": "Equipo CPF I"}], hoy)["equipos"][0]
    fila = next(f for f in x["filas"] if f["clave"] == "monitoreos")
    assert (fila["meta"], fila["hecho"], fila["estado"]) == (40, 52, "cumplida"), "el equipo cumplió con el total"
    pp = {p["usuario"]["id"]: p for p in x["por_persona"]}
    a, b = pp[ana["id"]]["indicadores"]["monitoreos"], pp[beto["id"]]["indicadores"]["monitoreos"]
    assert (a["meta"], a["hecho"], a["estado"]) == (40, 42, "cumplida")
    assert (b["meta"], b["hecho"], b["estado"]) == (40, 5, "atrasada") and b["esperado"] == 19, "la persona tiene la meta del equipo"
    assert pp[beto["id"]]["resumen"] == {"atrasada": 1}
    assert pp[ana["id"]]["indicadores"]["informes_generales"]["estado"] == "sin_meta", "meta 0: sin meta, también por persona"
    assert pp[ana["id"]]["indicadores"]["videollamadas"] == {"meta": 0, "hecho": 0, "esperado": 0, "estado": "sin_meta", "pct": None, "esperado_ajustado": None}
    libro = metas.exportar_planilla(2026, {"id": eq, "nombre": "Equipo CPF I"}, hoy)
    hoja = libro["Estado por persona"]
    filas = [[c.value for c in r] for r in hoja.iter_rows(min_row=2)]
    assert ["Beto Ruiz", "Monitoreos", 40, 5, 19, 12, "Atrasada"] in filas and ["Ana Pérez", "Monitoreos", 40, 42, 19, 100, "Cumplida"] in filas
    assert not any(r[1] == "Informes generales / temáticos" for r in filas), "con meta 0 no hay estado que exportar"
    buf = io.BytesIO(); libro.save(buf); assert openpyxl.load_workbook(buf)


def test_personas_anteriores_sin_estado_e_indicadores_por_equipo(base: Any) -> None:
    import metas
    db = base
    eq = db.crear_equipo("Equipo X")
    assert metas.indicadores_de({"id": eq}) == metas.INDICADORES
    metas.INDICADORES_POR_EQUIPO[eq] = ["monitoreos", "inexistente"]
    try:
        assert [i["clave"] for i in metas.indicadores_de({"id": eq})] == ["monitoreos"]
        assert metas.indicadores_de({"id": eq + 1}) == metas.INDICADORES, "los demás equipos no cambian"
        x = metas.seguimiento(2026, [{"id": eq, "nombre": "Equipo X"}], date(2026, 7, 1))["equipos"][0]
        assert [f["clave"] for f in x["filas"]] == ["monitoreos"]
    finally:
        metas.INDICADORES_POR_EQUIPO.pop(eq, None)
    with db._conexion() as con:  # planilla importada: una persona anterior (por sigla) y lo del equipo sin asignar
        cid = con.execute("INSERT INTO metas_cargas (equipo_id, creado_en) VALUES (?, 'x')", (eq,)).lastrowid
        con.execute("INSERT INTO metas_importado (carga_id, equipo_id, anio, periodo, indicador, sigla, cantidad) VALUES (?, ?, 2026, 'M01', 'monitoreos', 'GF', 4)", (cid, eq))
        con.execute("INSERT INTO metas_importado (carga_id, equipo_id, anio, periodo, indicador, sin_asignar, cantidad) VALUES (?, ?, 2026, 'M01', 'monitoreos', 1, 2)", (cid, eq))
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    metas.guardar_metas_anuales(2026, {eq: {"monitoreos": 10}}, direc)
    x = metas.seguimiento(2026, [{"id": eq, "nombre": "Equipo X"}], date(2026, 7, 1))["equipos"][0]
    anteriores = [p for p in x["por_persona"] if p.get("anterior")]
    assert len(anteriores) == 2 and all(p["indicadores"] == {} and p["resumen"] == {} for p in anteriores), "sin estado individual"
    assert next(f for f in x["filas"] if f["clave"] == "monitoreos")["hecho"] == 6
