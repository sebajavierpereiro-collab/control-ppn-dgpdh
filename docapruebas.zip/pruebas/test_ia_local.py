"""Propuestas 19, 20, 21, 22, 26, 27 y 47: pedidos a la IA local (Ollama) con esquema, ventana de contexto, versión del modelo,
filtro contra invenciones y documentos tapados en el registro. Ollama se simula: no sale nada a la red."""
from __future__ import annotations

import configparser
import json
import sqlite3
import sys
from pathlib import Path
from typing import Any

import pytest

from dgpdh.dominio import anti_invencion as ai
from dgpdh.dominio import datos_personales as dp
from dgpdh.ia import contexto, esquemas, modelos

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))


# ---------------------------------------------------------------- 20: ventana de contexto
def test_medir_ventana_automatica_y_fija() -> None:
    corto = contexto.medir("x" * 350, 100, maximo=8192)
    assert corto.num_ctx == 4096 and not corto.cerca_del_limite and corto.aviso() is None
    largo = contexto.medir("x" * 3500 * 7, 600, maximo=8192)  # ≈7000 tokens + respuesta
    assert largo.num_ctx == 8192 and largo.cerca_del_limite and "%" in (largo.aviso() or "")
    enorme = contexto.medir("x" * 3500 * 10, 600, maximo=8192)
    assert enorme.excede and "no entra" in (enorme.aviso() or "")
    fijo = contexto.medir("x" * 35, 50, maximo=8192, fijo=16384)
    assert fijo.num_ctx == 16384 and not fijo.excede
    assert contexto.medir("x" * 3500 * 5, 50, maximo=8192, fijo=2048).excede, "la ventana fija no se agranda sola"
    assert contexto.medir("", None, maximo=1000).num_ctx == 4096, "nunca menos que 4096"


# ---------------------------------------------------------------- 19: esquemas
def test_esquema_y_validacion() -> None:
    e = esquemas.esquema(esquemas.OpinionDuplicado)
    assert e["properties"]["veredicto"]["enum"] == ["misma", "distinta", "dudosa"]
    assert e["properties"]["confianza"]["maximum"] == 100 and "title" not in e
    ok = esquemas.validar(esquemas.OpinionDuplicado, '{"veredicto": "misma", "confianza": 80, "motivo": " igual "}')
    assert ok is not None and ok.veredicto == "misma" and ok.motivo == "igual"
    assert esquemas.validar(esquemas.OpinionDuplicado, 'Respuesta: {"veredicto": "dudosa", "confianza": 3} fin') is not None
    for mal in ('{"veredicto": "mismo", "confianza": 80}', '{"veredicto": "misma", "confianza": 180}', "basura", "", None):
        assert esquemas.validar(esquemas.OpinionDuplicado, mal) is None, mal
    assert esquemas.validar(esquemas.Resumen, '{"lineas": ["una"]}') is None, "mínimo dos líneas"
    assert esquemas.validar(esquemas.Resumen, '{"lineas": ["a", "b", "c", "d"]}') is None
    assert esquemas.validar(esquemas.Proveido, '{"texto": "corto"}') is None


# ---------------------------------------------------------------- 22 y 27: modelos
TAGS = {"models": [
    {"name": "phi3:mini", "digest": "aaa111", "details": {"parameter_size": "3.8B"}},
    {"name": "qwen2.5:7b", "digest": "bbb222", "details": {"parameter_size": "7.6B"}},
    {"name": "raro", "digest": "ccc333"},
]}


def test_tamano_y_advertencia() -> None:
    info = modelos.info_desde_tags(TAGS)
    assert modelos.tamano_desde_texto("494.35M") == pytest.approx(0.49435)
    assert modelos.tamano_desde_texto("llama3.1:8b-instruct-q4_K_M") == 8.0
    assert modelos.tamano_de("phi3:mini") == 3.8, "conocido aunque Ollama no responda"
    assert "chico" in (modelos.advertencia("correccion", "phi3:mini", info) or "")
    assert "qwen2.5:7b" in (modelos.advertencia("redaccion", "phi3:mini", info) or ""), "da la recomendación"
    assert modelos.advertencia("redaccion", "qwen2.5:7b", info) is None
    assert modelos.advertencia("clasificacion", "phi3:mini", info) is None, "solo los procesos que redactan"
    assert "No se sabe" in (modelos.advertencia("correccion", "raro", info) or "")
    assert modelos.digest_de("raro", info) == "ccc333" and modelos.digest_de("otro", info) is None
    nuevos = modelos.info_desde_tags({"models": [{"name": "qwen2.5:7b", "digest": "zzz999"}]})
    assert modelos.cambios_de_digest({"qwen2.5:7b": "bbb222"}, nuevos, ["qwen2.5:7b", "phi3:mini"]) == [("qwen2.5:7b", "bbb222", "zzz999")]
    assert modelos.version_prompt("a") == modelos.version_prompt("a") != modelos.version_prompt("b")


# ---------------------------------------------------------------- 26: anti invención
FUENTE = ("Me dirijo a usted a fin de solicitar atención médica para el Sr. Juan GÓMEZ, DNI 30.123.456, alojado en el "
          "Complejo Penitenciario Federal I, en el marco del Expte. EP 1234/2025. Se pide respuesta en 5 días hábiles desde el 3 de marzo de 2025.")


def test_anti_invencion() -> None:
    bien = ["Pide atención médica para Juan Gómez (DNI 30123456).", "Alojado en el Complejo Penitenciario Federal I, expediente 1234/2025.",
            "Plazo: 5 días hábiles desde el 3 de marzo."]
    assert ai.datos_inventados(bien, FUENTE) == []
    malo = ["Pide atención médica para Juan Gómez (DNI 30123457).", "Alojado en la Unidad 19 de Ezeiza, causa Pereyra."]
    faltan = ai.datos_inventados(malo, FUENTE)
    assert "número 30123457" in faltan and "número 19" in faltan and "nombre ezeiza" in faltan and "nombre pereyra" in faltan
    assert ai.datos_inventados("Vence el 9 de abril.", FUENTE) == ["fecha 9-abril"]
    assert ai.datos_inventados("Notifíquese. Remítase a la Procuración Penitenciaria de la Nación.", "") == [], "fórmulas institucionales"
    assert ai.datos_inventados("Le escribe la Defensoría.", "", permitidas=["Defensoría"]) == []


# ---------------------------------------------------------------- 40 y 47: documentos
def test_cuil_y_tapado() -> None:
    assert dp.digito_verificador("2030123456") == 3
    c = dp.analizar_cuil("20-30123456-3")
    assert c and c.valido and c.dni == "30123456"
    malo = dp.analizar_cuil("20301234561")
    assert malo and not malo.valido and "debería ser 3" in (malo.motivo or "")
    assert dp.analizar_cuil("30123456") is None and dp.analizar_cuil("99301234561") is None
    assert dp.avisos_cuil("20-30123456-3", "30.123.456") == []
    assert any("distinto del DNI" in a for a in dp.avisos_cuil("20-30123456-3", "31000000"))
    assert dp.avisos_cuil("", "30123456") == []
    assert dp.tapar("30.123.445") == "30.xxx.x45" and dp.tapar("12345") == "12345"
    t = dp.tapar_documentos("DNI 30.123.456 y LPU 123456, expte 1234/2025, el 14/11/2026, CUIL 20-30123456-3.")
    assert "30.xxx.x56" in t and "12xx56" in t and "1234/2025" in t and "14/11/2026" in t and "20-xxxxxxx6-3" in t


# ---------------------------------------------------------------- integración con nucleo (Ollama simulado)
class _Resp:
    def __init__(self, codigo: int, cuerpo: dict[str, Any]) -> None:
        self.status_code, self._cuerpo = codigo, cuerpo

    def json(self) -> dict[str, Any]:
        return self._cuerpo


@pytest.fixture()
def nucleo_simulado(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Any:
    import database as db
    import nucleo
    import trazabilidad_ia
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    monkeypatch.setattr(nucleo, "ia_disponible", lambda p: True)
    monkeypatch.setattr(nucleo, "INFO_MODELOS", modelos.info_desde_tags(TAGS))
    monkeypatch.setattr(nucleo, "OLLAMA_MODELOS", {"revision_detenidos": "qwen2.5:7b", "redaccion": "phi3:mini"})
    monkeypatch.setattr(nucleo, "ESQUEMAS_JSON", [True])
    monkeypatch.setattr(trazabilidad_ia, "TAPAR_DOCUMENTOS", True)
    return nucleo


def _registro(db_ruta: Path) -> list[dict[str, Any]]:
    con = sqlite3.connect(db_ruta)
    con.row_factory = sqlite3.Row
    filas = [dict(f) for f in con.execute("SELECT * FROM ia_registro ORDER BY id")]
    con.close()
    return filas


def test_consultar_ollama_con_esquema_y_registro(nucleo_simulado: Any, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    nucleo = nucleo_simulado
    pedidos: list[dict[str, Any]] = []

    def post(url: str, json: dict[str, Any], timeout: int) -> _Resp:
        pedidos.append(json)
        return _Resp(200, {"response": '{"veredicto": "misma", "confianza": 90, "motivo": "DNI 30123456 igual"}', "done_reason": "stop"})
    monkeypatch.setattr(nucleo.requests, "post", post)
    esquema = esquemas.esquema(esquemas.OpinionDuplicado)
    salida = nucleo.consultar_ollama("revision_detenidos", "PROMPT " * 10, num_predict=200, formato_json=True, esquema=esquema,
                                     version_prompt="v1")
    assert salida and pedidos[0]["format"] == esquema and pedidos[0]["options"]["num_ctx"] == 4096
    fila = _registro(tmp_path / "t.db")[-1]
    assert fila["modelo_digest"] == "bbb222" and fila["version_prompt"] == "v1" and fila["num_ctx"] == 4096
    assert json.loads(fila["parametros"])["format"] == "esquema" and json.loads(fila["parametros"])["temperature"] == 0.0
    assert "30123456" not in fila["salida"] and "30xxxx56" in fila["salida"], "propuesta 47: documento tapado en el registro"
    assert fila["aviso_ctx"] is None


def test_ollama_viejo_sin_esquemas_reintenta_con_json(nucleo_simulado: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    nucleo = nucleo_simulado
    formatos: list[Any] = []

    def post(url: str, json: dict[str, Any], timeout: int) -> _Resp:
        formatos.append(json.get("format"))
        if isinstance(json.get("format"), dict):
            return _Resp(400, {"error": "invalid format"})
        return _Resp(200, {"response": '{"lineas": ["a", "b"]}', "done_reason": "stop"})
    monkeypatch.setattr(nucleo.requests, "post", post)
    esquema = esquemas.esquema(esquemas.Resumen)
    assert nucleo.consultar_ollama("redaccion", "x", esquema=esquema) == '{"lineas": ["a", "b"]}'
    assert isinstance(formatos[0], dict) and formatos[1] == "json"
    assert nucleo.consultar_ollama("redaccion", "x", esquema=esquema)
    assert formatos[2] == "json", "no vuelve a mandar el esquema a un Ollama que no lo acepta"


def test_pedido_que_no_entra_queda_registrado(nucleo_simulado: Any, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    nucleo = nucleo_simulado
    monkeypatch.setattr(nucleo, "MAX_CTX", 8192)
    monkeypatch.setattr(nucleo.requests, "post", lambda url, json, timeout: _Resp(200, {"response": "ok", "done_reason": "stop"}))
    nucleo.consultar_ollama("redaccion", "x" * 40000, num_predict=600)
    fila = _registro(tmp_path / "t.db")[-1]
    assert fila["num_ctx"] == 8192 and fila["tokens_estimados"] > 8192 and "no entra" in fila["aviso_ctx"]
    import trazabilidad_ia
    assert trazabilidad_ia.avisos_de_contexto()[0]["id"] == fila["id"]


def test_config_num_ctx_keep_alive_y_digest(nucleo_simulado: Any, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import automatico
    nucleo = nucleo_simulado
    cp = configparser.ConfigParser()
    cp.read_string("[ollama]\nnum_ctx_consistencia = 12288\nnum_ctx_redaccion = nada\nkeep_alive_noche = 30m\nkeep_alive_dia = 5m\n"
                   "esquemas_json = false\n[ia]\ntapar_documentos_registro = false\n")
    monkeypatch.setattr(nucleo, "NUM_CTX_POR_PROCESO", {})
    for k in ("num_ctx_consistencia", "num_ctx_redaccion"):
        try:
            fijo = cp.getint("ollama", k, fallback=0)
        except ValueError:
            fijo = 0
        if fijo:
            nucleo.NUM_CTX_POR_PROCESO[k.removeprefix("num_ctx_")] = fijo
    assert nucleo.ventana_contexto("x", 10, "consistencia") == 12288 and nucleo.ventana_contexto("x", 10, "redaccion") == 4096
    monkeypatch.setattr(automatico, "CONFIG", dict(automatico.CONFIG))
    automatico.configurar(cp)
    nucleo._configurar_keep_alive(cp)
    monkeypatch.setattr(automatico, "en_ventana", lambda *a, **k: True)
    assert nucleo.KEEP_ALIVE[0] and nucleo.KEEP_ALIVE[0]() == "30m"
    monkeypatch.setattr(automatico, "en_ventana", lambda *a, **k: False)
    assert nucleo.KEEP_ALIVE[0]() == "5m"
    vacio = configparser.ConfigParser()
    vacio.read_string("[ollama]\n")
    nucleo._configurar_keep_alive(vacio)
    assert nucleo.KEEP_ALIVE[0] is None, "sin configurar no se manda keep_alive"
    # 27: el digest de un modelo en uso cambia → queda la constancia
    nucleo._registrar_info_modelos(TAGS)
    nucleo._registrar_info_modelos({"models": [{"name": "qwen2.5:7b", "digest": "nuevo999"}]})
    cambios = nucleo.cambios_de_version_modelos()
    assert [c["modelo"] for c in cambios] == ["qwen2.5:7b"] and cambios[0]["digest_anterior"] == "bbb222"
    filas = {f["proceso"]: f for f in nucleo.estado_modelos_ia(refrescar=False)}
    assert filas["redaccion"]["advertencia"] and not filas["clasificacion"]["advertencia"]


def test_orden_de_la_cola_por_modelo(nucleo_simulado: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    import automatico
    import database as db
    monkeypatch.setattr(db, "prioridades_por_bloque", lambda: {})
    monkeypatch.setattr(automatico, "ULTIMO_MODELO", ["phi3:mini"])
    t = [{"id": 1, "tipo": "CLASIFICAR", "prioridad": "NORMAL", "creado_en": "1", "bloque_id": None},
         {"id": 2, "tipo": "RESUMEN", "prioridad": "NORMAL", "creado_en": "2", "bloque_id": None},
         {"id": 3, "tipo": "CLASIFICAR", "prioridad": "URGENTE", "creado_en": "3", "bloque_id": None}]
    assert [x["id"] for x in automatico._orden_trabajos(t, agrupar_modelo=False)] == [3, 1, 2]
    assert [x["id"] for x in automatico._orden_trabajos(t, agrupar_modelo=True)] == [3, 2, 1], "a igual prioridad, el modelo cargado"


def test_resumen_y_proveido_descartan_invenciones(nucleo_simulado: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    import agentes
    nucleo = nucleo_simulado
    respuesta = {"r": ""}
    monkeypatch.setattr(nucleo, "consultar_ollama", lambda proceso, prompt, **k: respuesta["r"])
    monkeypatch.setattr(nucleo, "USAR_IA", True)
    respuesta["r"] = json.dumps({"lineas": ["Pide atención médica para Juan Gómez.", "Expediente EP 1234/2025, plazo 5 días."]})
    assert agentes.resumen_ia(FUENTE)
    respuesta["r"] = json.dumps({"lineas": ["Pide atención médica para Juan Gómez.", "Expediente EP 9999/2025, Unidad Ezeiza."]})
    assert agentes.resumen_ia(FUENTE) is None, "número y nombre inventados: queda el resumen por reglas"
    respuesta["r"] = "no es json"
    assert agentes.resumen_ia(FUENTE) is None
    base = "VISTO la Nota N° 55 dirigida a Juzgado Federal, obrante en el Expediente EP 1234/2025, y CONSIDERANDO: que corresponde. Cúmplase."
    respuesta["r"] = json.dumps({"texto": base + " Remítase por correo electrónico al Juzgado Federal, dejando constancia del envío."})
    assert agentes.proveido_ia({}, FUENTE, "CORREO", base)
    respuesta["r"] = json.dumps({"texto": base + " Remítase al Dr. Fernández por correo, con copia a la Unidad 28."})
    assert agentes.proveido_ia({}, FUENTE, "CORREO", base) is None
