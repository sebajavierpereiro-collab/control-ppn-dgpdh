"""Propuestas 86 (balance trimestral versionado con respuesta de la Dirección) y 88 (frecuencia mínima de visita por unidad)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest

from dgpdh.errores import DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import frecuencia_unidades as fq
from dgpdh.servicios import revision_trimestral as rv

A = au.Actor(3, "Coord")


def test_sugerencia() -> None:
    assert rv.sugerir([]) == "VERDE" and rv.sugerir(["sin_meta", "cumplida"]) == "VERDE"
    assert rv.sugerir(["atrasada", "en_camino", "cumplida"]) == "AMBAR"
    assert rv.sugerir(["atrasada", "sin_carga", "cumplida"]) == "ROJO"


def test_balance_versionado(base: Any) -> None:
    db = base
    eq = db.crear_equipo("Eq Rev")
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            rv.guardar(con, A, False, eq, 2026, 3, "VERDE", "VERDE", "Todo bien en el trimestre", "", "")
        with pytest.raises(DatoInvalido):
            rv.guardar(con, A, True, eq, 2026, 3, "VERDE", "VERDE", "corto", "", "")
        with pytest.raises(DatoInvalido):
            rv.responder(con, A, True, eq, 2026, 3, "¿Qué pasó?")
        rv.guardar(con, A, True, eq, 2026, 3, "AMBAR", "ROJO", "Hubo dos licencias largas en agosto.", "Licencias", "Redistribuir unidades")
        rv.guardar(con, A, True, eq, 2026, 3, "ROJO", "ROJO", "Se sumó el cierre del CPF II en septiembre.", "", "")
        vs = rv.versiones(con, eq, 2026, 3)
        assert [v["version"] for v in vs] == [2, 1] and vs[1]["obstaculos"] == "Licencias", "la versión anterior se conserva"
        with pytest.raises(PermisoDenegado):
            rv.responder(con, A, False, eq, 2026, 3, "Ok")
        rv.responder(con, au.Actor(1, "Director"), True, eq, 2026, 3, "Hablemos el lunes.")
        assert rv.respuestas(con, eq, 2026, 3)[0]["texto"] == "Hablemos el lunes."


def test_frecuencias(base: Any) -> None:
    import auth
    import traslados as tr
    db = base
    eq = db.crear_equipo("Eq Frec")
    h, s = auth.generar_hash_clave("Clave1234")
    ana = db.obtener_usuario(db.crear_usuario("anaq", h, s, "Ana Frec", "ASESOR", eq))
    u1, u2, u3 = (x["id"] for x in db.listar_unidades()[:3])
    with db._conexion() as con:
        if not con.execute("SELECT 1 FROM equipo_unidades WHERE equipo_id = ?", (eq,)).fetchone():
            con.executemany("INSERT INTO equipo_unidades (equipo_id, unidad_id, orden) VALUES (?, ?, ?)", [(eq, u1, 1), (eq, u2, 2)])
    hoy = date.today()
    f = hoy - timedelta(days=10)
    tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": u1},
                   [{"usuario_id": ana["id"], "nombre": ana["nombre"], "equipo_nombre": "Eq Frec", "auto_propio": 1}], ana, hoy=f - timedelta(days=9))
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            fq.guardar(con, A, False, eq, {u1: (30, "BAJO")})
        with pytest.raises(DatoInvalido):
            fq.guardar(con, A, True, eq, {u1: (12, None)})
        assert fq.guardar(con, A, True, eq, {u1: (7, "ALTO"), u2: (30, None), u3: (7, None)}) == 2, "u3 no está a cargo del equipo"
        assert fq.guardar(con, A, True, eq, {u1: (7, "ALTO")}) == 0, "sin cambios no audita"
        e = fq.estado(con, eq, "Eq Frec", hoy, {u2: 2})
    por = {x["unidad_id"]: x for x in e["unidades"]}
    assert por[u1]["vencida"] and por[u1]["atraso"] == 3 and por[u1]["dias_desde"] == 10
    assert por[u2]["vencida"] and por[u2]["ultima"] is None and por[u2]["riesgo_sugerido"] == "ALTO"
    assert e["pct"] == 0 and [x["unidad_id"] for x in e["vencidas"]] == [u2, u1]
