"""Propuesta 79: indicador de obstáculos para ingresar a la unidad (novedades, horas de la parada y Registro de Obstaculizaciones)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.servicios import ingreso_unidades as ing

HOY = date.today()


def test_indicador(base: Any) -> None:
    import auth
    import operacion as op
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Ingreso")
    ana = db.obtener_usuario(db.crear_usuario("anai", h, s, "Ana Ingreso", "ASESOR", eq))
    beto = db.obtener_usuario(db.crear_usuario("betoi", h, s, "Beto Ingreso", "ASESOR", eq))
    u1, u2 = db.listar_unidades()[0], db.listar_unidades()[1]

    def viaje(fecha: date, unidad: int, quien: Any) -> int:
        return int(tr.crear_viaje({"fecha": fecha.isoformat(), "unidad_id": unidad},
                                  [{"usuario_id": quien["id"], "nombre": quien["nombre"], "equipo_nombre": "Equipo Ingreso", "auto_propio": 1}],
                                  quien, hoy=fecha - timedelta(days=10)))
    d1, d2, d3 = HOY - timedelta(days=40), HOY - timedelta(days=39), HOY - timedelta(days=38)
    a = viaje(d1, u1["id"], ana)
    b = viaje(d1, u1["id"], beto)  # mismo día y unidad: una sola visita
    c = viaje(d2, u1["id"], ana)
    viaje(d3, u1["id"], ana)
    e = viaje(d2, u2["id"], ana)
    viaje(HOY + timedelta(days=2), u1["id"], ana)  # futuro: no cuenta
    op.agregar_novedad(a, "DEMORA_INGRESO", "", "50", "Ana")
    op.agregar_novedad(b, "INGRESO_DENEGADO", "", "", "Beto")
    op.agregar_novedad(e, "SIN_ESPACIO", "", "", "Ana")  # no es un obstáculo para ingresar
    with db._conexion() as con:
        con.execute("UPDATE viajes SET llegada_unidad = '09:00', ingreso_unidad = '09:40' WHERE id = ?", (c,))
        con.execute("""INSERT INTO obstaculizaciones (numero, anio, correlativo, fecha_hecho, hora_hecho, unidad_id, tipo_id, descripcion, subsanado,
                       demora_minutos, cargado_por_id, cargado_por, creado_en) VALUES ('O-1', 2026, 1, ?, '10:00', ?, 1, 'x', 1, 90, 1, 'x', 'x')""",
                    (d3.isoformat(), u1["id"]))
        con.execute("""INSERT INTO obstaculizaciones (numero, anio, correlativo, fecha_hecho, hora_hecho, unidad_id, tipo_id, descripcion, subsanado,
                       demora_minutos, cargado_por_id, cargado_por, creado_en, estado) VALUES ('O-2', 2026, 2, ?, '10:00', ?, 1, 'x', 1, 999, 1, 'x', 'x', 'ANULADO')""",
                    (d2.isoformat(), u2["id"]))
        desde = (HOY - timedelta(days=60)).isoformat()
        sin = {(f["unidad_id"], f["mes"]): f for f in ing.indicador(con, desde, HOY.isoformat(), HOY)}
        con_obst = ing.resumen_por_unidad(con, desde, HOY.isoformat(), HOY, incluir_obstaculizaciones=True)
        sin_obst = ing.resumen_por_unidad(con, desde, HOY.isoformat(), HOY)
        solo_u2 = ing.indicador(con, desde, HOY.isoformat(), HOY, unidad_id=u2["id"], incluir_obstaculizaciones=True)
    r1 = next(f for f in sin_obst if f["unidad_id"] == u1["id"])
    assert (r1["visitas"], r1["con_obstaculos"], r1["denegaciones"], r1["mediana_min"]) == (3, 2, 1, 45), r1
    r1o = next(f for f in con_obst if f["unidad_id"] == u1["id"])
    assert (r1o["con_obstaculos"], r1o["pct_obstaculos"], r1o["mediana_min"], r1o["con_minutos"]) == (3, 100, 50, 3), r1o
    assert con_obst[0]["unidad_id"] == u1["id"], "primero las unidades con más obstáculos"
    assert len(solo_u2) == 1 and solo_u2[0]["con_obstaculos"] == 0, "la novedad «sin espacio» y el hecho anulado no cuentan"
    assert sum(int(str(f["visitas"])) for k, f in sin.items() if k[0] == u1["id"]) == 3


def test_csv_y_sin_tablas(tmp_path: Any) -> None:
    import sqlite3
    c = sqlite3.connect(tmp_path / "v.db")
    c.executescript("""CREATE TABLE unidades (id INTEGER PRIMARY KEY, nombre TEXT);
                       CREATE TABLE viajes (id INTEGER PRIMARY KEY, unidad_id INTEGER, fecha TEXT, estado TEXT);
                       INSERT INTO unidades VALUES (1, 'CPF I');
                       INSERT INTO viajes VALUES (1, 1, '2026-01-10', 'CONFIRMADO');""")
    filas = ing.indicador(c, "2026-01-01", "2026-12-31", date(2026, 11, 14), incluir_obstaculizaciones=True)
    assert filas == [{"unidad_id": 1, "unidad": "CPF I", "visitas": 1, "con_obstaculos": 0, "pct_obstaculos": 0, "denegaciones": 0,
                      "mediana_min": None, "con_minutos": 0, "mes": "2026-01"}]
    assert ing.csv_filas(filas)[1] == ["CPF I", "2026-01", 1, 0, 0, 0, "", 0]
