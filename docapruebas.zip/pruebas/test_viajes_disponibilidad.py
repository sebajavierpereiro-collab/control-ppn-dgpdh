"""Propuesta 66: días por estado y % de disponibilidad de cada vehículo."""
from __future__ import annotations

from datetime import date

from dgpdh.dominio import disponibilidad as dd


def test_dias_por_mes() -> None:
    d = dd.dias_por_mes(date(2026, 1, 10), "DISPONIBLE", [(date(2026, 1, 20), "TALLER"), (date(2026, 2, 5), "DISPONIBLE")],
                        date(2026, 1, 1), date(2026, 2, 28))
    assert d["2026-01"] == {"DISPONIBLE": 10, "TALLER": 12} and d["2026-02"] == {"TALLER": 4, "DISPONIBLE": 24}
    assert dd.pct_disponible(d["2026-01"]) == 45
    b = dd.dias_por_mes(date(2025, 1, 1), "TALLER", [(date(2025, 12, 1), "DISPONIBLE"), (date(2026, 3, 1), "BAJA")], date(2026, 1, 1), date(2026, 3, 31))
    assert b["2026-01"] == {"DISPONIBLE": 31} and b["2026-03"] == {"BAJA": 31} and dd.pct_disponible(b["2026-03"]) is None
    assert dd.estado_de_texto("TALLER — cambio de embrague") == "TALLER" and dd.estado_de_texto("raro") is None
