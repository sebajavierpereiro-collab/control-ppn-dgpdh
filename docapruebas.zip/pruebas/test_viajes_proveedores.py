"""Propuesta 64: proveedores, responsable de cada control, días de aviso por tipo y aviso interno al responsable."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest

from dgpdh.dominio import avisos_flota as af


def test_dias_y_pendientes() -> None:
    assert (af.dias_aviso("VTV"), af.dias_aviso("SEGURO"), af.dias_aviso("MATAFUEGO"), af.dias_aviso("FRENOS")) == (45, 30, 15, 30)
    assert af.dias_aviso("VTV", {"VTV": 60}) == 60 and af.validar_dias(" ") is None and af.validar_dias("20") == 20
    for malo in ("0", "400", "x"):
        with pytest.raises(ValueError):
            af.validar_dias(malo)
    hoy = date(2026, 11, 14)
    c = [{"id": 1, "tipo": "VTV", "vence_fecha": "2026-12-20", "responsable_id": 5},      # 36 días: dentro de 45
         {"id": 2, "tipo": "MATAFUEGO", "vence_fecha": "2026-12-20", "responsable_id": 5},  # fuera de 15
         {"id": 3, "tipo": "SEGURO", "vence_fecha": "2026-11-01", "responsable_id": 6},
         {"id": 4, "tipo": "SEGURO", "vence_fecha": "2026-11-01", "responsable_id": None}]
    p = af.pendientes(c, {}, hoy, set())
    assert [(x["control_id"], x["nivel"]) for x in p] == [(1, "pronto"), (3, "vencido")]
    assert [x["control_id"] for x in af.pendientes(c, {}, hoy, {(1, 5, "pronto")})] == [3]


def test_flujo(base: Any) -> None:
    import auth
    import flota
    import traslados as tr
    from dgpdh.errores import DatoInvalido, PermisoDenegado
    from dgpdh.seguridad import auditoria as au
    from dgpdh.servicios import proveedores as srv
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    resp = db.obtener_usuario(db.crear_usuario("resp64", h, s, "Responsable Flota", "ASESOR", db.crear_equipo("Eq 64")))
    a = au.Actor(None, "Coord")
    with db._conexion() as con:
        with pytest.raises(PermisoDenegado):
            srv.guardar(con, a, False, {"nombre": "X"})
        with pytest.raises(DatoInvalido):
            srv.guardar(con, a, True, {"nombre": " "})
        pid = srv.guardar(con, a, True, {"nombre": "Aseguradora Uno", "tipo": "ASEGURADORA"})
        srv.guardar(con, a, True, {"nombre": "Aseguradora Uno SA", "tipo": "RARO"}, pid)
        assert srv.listar(con)[0]["tipo"] == "OTRO"
        assert srv.guardar_dias(con, a, True, ["MATAFUEGO", "VTV"], {"MATAFUEGO": "40", "VTV": ""}) == 1
        assert srv.dias_configurados(con) == {"MATAFUEGO": 40}
    veh = tr.guardar_vehiculo(None, {"dominio": "AA064AA", "capacidad": "4"})
    vid = veh if isinstance(veh, int) else veh["id"]
    hoy = date.today()
    flota.registrar_control(vid, {"tipo": "MATAFUEGO", "fecha": hoy.isoformat(), "vence_fecha": (hoy + timedelta(days=35)).isoformat(),
                                  "proveedor_id": str(pid), "referencia": "Póliza 123", "responsable_id": str(resp["id"])}, {"nombre": "Coord"})
    c = flota.controles(vid)[0]
    assert c["proveedor_nombre"] == "Aseguradora Uno SA" and c["referencia"] == "Póliza 123" and c["responsable_nombre"] == "Responsable Flota"
    v = next(x for x in tr.listar_vehiculos() if x["id"] == vid)
    fila = next(f for f in flota.estado_vehiculo(v)["controles"] if f["tipo"] == "MATAFUEGO")
    assert fila["nivel"] == "pronto" and fila["dias_aviso"] == 40, "con 40 días configurados, 35 ya es «pronto»"
    assert flota.avisar_responsables(hoy) == 1 and flota.avisar_responsables(hoy) == 0 and flota.avisar_responsables(hoy, forzar=True) == 0
    with db._conexion() as con:
        n = con.execute("SELECT texto FROM notificaciones WHERE usuario_id = ?", (resp["id"],)).fetchall()
        assert len(n) == 1 and "Sos la persona responsable" in n[0][0]
        srv.dar_de_baja(con, a, True, pid, "Ya no trabajamos")
        assert srv.listar(con) == [] and len(srv.listar(con, True)) == 1
        acciones = {f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad IN ('proveedor', 'control_tipo')")}
    assert {"Alta de proveedor", "Edición de proveedor", "Baja de proveedor", "Días de aviso de control"} <= acciones
    assert flota.controles(vid)[0]["proveedor_activo"] == 0, "el control sigue citando al proveedor dado de baja"
    import traslados
    with pytest.raises(traslados.ErrorTraslado):
        flota.registrar_control(vid, {"tipo": "SEGURO", "proveedor_id": str(pid)}, {"nombre": "Coord"})
    assert not [c for c in flota.controles(vid) if c["tipo"] == "SEGURO"], "si falla, no queda el control a medias"
