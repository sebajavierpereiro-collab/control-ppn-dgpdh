"""v41: la ficha no espera a Word, la firma repetida no da error y el estado de Metas del menú se calcula aparte."""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import menu_paneles  # noqa: E402
import nucleo  # noqa: E402


def test_conversion_previa_se_reutiliza(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    doc = tmp_path / "nota.doc"
    doc.write_bytes(b"viejo")
    assert nucleo.docx_convertido(doc) is None
    hecho = Path(str(doc) + "x")
    hecho.write_bytes(b"convertido")
    assert nucleo.docx_convertido(doc) == hecho
    llamadas: list[Path] = []
    monkeypatch.setattr(nucleo, "convertir_doc_a_docx", lambda r: llamadas.append(r) or hecho)
    assert nucleo._asegurar_docx(doc) == hecho and llamadas == [], "no vuelve a abrir Word"
    viejo = time.time() - 3600
    os.utime(hecho, (viejo, viejo))
    assert nucleo.docx_convertido(doc) is None, "si el .doc es más nuevo, se convierte de nuevo"
    assert nucleo.docx_convertido(tmp_path / "otra.docx") is None


def test_vista_previa_sin_esperar_no_llama_a_word(tmp_path: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    doc = tmp_path / "n.doc"
    doc.write_bytes(b"x")
    pedidos: list[Path] = []
    monkeypatch.setattr(nucleo, "WIN32_DISPONIBLE", True)
    monkeypatch.setattr(nucleo, "convertir_en_segundo_plano", lambda r: pedidos.append(Path(r)))
    monkeypatch.setattr(nucleo, "convertir_doc_a_docx", lambda r: (_ for _ in ()).throw(AssertionError("no tiene que esperar a Word")))
    parrafos, aviso = nucleo.obtener_vista_previa(doc, sin_esperar=True)
    assert parrafos is None and "se está preparando" in (aviso or "") and pedidos == [doc]


def test_metas_del_menu_no_frena_la_pagina(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    menu_paneles.limpiar()
    lento = {"n": 0}

    def calculo() -> dict[str, object]:
        lento["n"] += 1
        time.sleep(0.3)
        return {"texto": "Avance 50 %", "alerta": False}

    t = time.monotonic()
    assert menu_paneles._cache(("metas", 1), 600, calculo) is None, "la primera vez no espera"
    assert time.monotonic() - t < 0.2
    for _ in range(50):
        if menu_paneles._CACHE.get(("metas", 1)):
            break
        time.sleep(0.02)
    assert menu_paneles._cache(("metas", 1), 600, calculo) == {"texto": "Avance 50 %", "alerta": False}
    assert lento["n"] == 1
    menu_paneles.limpiar()


def test_el_arranque_sigue_registrado() -> None:
    """v41b: el decorador de arranque tiene que quedar sobre al_iniciar (respaldo, migraciones, tareas de fondo)."""
    src = (Path(__file__).resolve().parent.parent / "main.py").read_text(encoding="utf-8")
    assert '@app.on_event("startup")\ndef al_iniciar():' in src
    assert src.count('@app.on_event("startup")') == 1


def test_al_iniciar_no_usa_nombres_locales_antes_de_definirlos() -> None:
    """v41b: al_iniciar importa threading adentro; usar ese nombre antes del import rompe el arranque (UnboundLocalError)."""
    import symtable
    src = (Path(__file__).resolve().parent.parent / "main.py").read_text(encoding="utf-8")
    tabla = symtable.symtable(src, "main.py", "exec")
    f = next(c for c in tabla.get_children() if c.get_name() == "al_iniciar")
    cuerpo = src[src.index("def al_iniciar():"):]
    for nombre in f.get_locals():
        import re
        m = re.search(r"(?<![\w.])" + re.escape(nombre) + r"\.", cuerpo)
        uso = m.start() if m else -1
        definicion = min([i for i in (cuerpo.find(f"import {nombre}"), cuerpo.find(f"{nombre} =")) if i >= 0] or [len(cuerpo)])
        assert uso == -1 or uso > definicion, f"«{nombre}» se usa antes de definirse en al_iniciar"
