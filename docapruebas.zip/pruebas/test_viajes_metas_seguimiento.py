"""Propuestas 83 (proyección), 84 (aviso al pasar a atrasada), 89 (calidad de la visita) y 91 (completitud de la carga)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import metas_calculo as mc


def test_proyeccion() -> None:
    p = mc.proyectar(120, 30, 2026, date(2026, 4, 30))
    assert p.meses_restantes == 9 and p.por_mes == 10 and 85 <= (p.proyeccion or 0) <= 95 and p.pct_proyeccion == round(100 * (p.proyeccion or 0) / 120)
    assert 28 <= p.esperado_habil <= 40
    con_feriados = mc.proyectar(120, 30, 2026, date(2026, 4, 30), {date(2026, 4, d) for d in range(1, 30)})
    assert (con_feriados.proyeccion or 0) > (p.proyeccion or 0), "los feriados no cuentan como días de trabajo"
    assert mc.proyectar(0, 5, 2026, date(2026, 6, 1)).por_mes is None
    assert mc.proyectar(10, 12, 2026, date(2026, 6, 1)).por_mes == 0
    futuro = mc.proyectar(10, 0, 2027, date(2026, 6, 1))
    assert futuro.proyeccion is None and futuro.meses_restantes == 12 and futuro.por_mes == 1
    pasado = mc.proyectar(10, 4, 2025, date(2026, 6, 1))
    assert pasado.proyeccion == 4 and pasado.por_mes is None and pasado.meses_restantes == 0


def test_completitud_y_estado() -> None:
    c = mc.completitud(2026, date(2026, 5, 10), ["M01", "T2", "M03"])
    assert c.cerrados == (1, 2, 3, 4) and c.cargados == (1, 3, 4) and c.faltan == (2,) and c.nivel == "medio"
    assert mc.completitud(2026, date(2026, 1, 15), []).nivel == "sin"
    vacio = mc.completitud(2026, date(2026, 5, 10), [])
    assert vacio.nivel == "alto"
    assert mc.estado_con_carga("atrasada", "carga", 0, vacio) == "sin_carga"
    assert mc.estado_con_carga("atrasada", "carga", 0, c) == "atrasada", "con algún mes cargado, un 0 es un 0"
    assert mc.estado_con_carga("atrasada", "viajes", 0, vacio) == "atrasada", "lo que sale de los viajes no depende de la carga"
    assert mc.estado_con_carga("atrasada", "carga", 2, vacio) == "atrasada"


def test_aviso_solo_al_cambiar() -> None:
    assert not mc.pasa_a_atrasada(None, "atrasada"), "la primera evaluación no avisa"
    assert mc.pasa_a_atrasada("en_camino", "atrasada") and mc.pasa_a_atrasada("sin_carga", "atrasada")
    assert not mc.pasa_a_atrasada("atrasada", "atrasada") and not mc.pasa_a_atrasada("en_camino", "cumplida")


def test_calidad() -> None:
    q = mc.calidad([mc.Visita(True, 4, True, False), mc.Visita(False, 0, True, True), mc.Visita(False, 0, False, False), mc.Visita(True, 0, False, False)])
    assert q == {"visitas": 4, "pct_pabellones": 50, "audiencias_por_visita": 2.0, "pct_obstaculos": 25, "pct_informadas": 50}
    assert mc.calidad([])["pct_pabellones"] is None


def _equipo(db: Any, nombre: str = "Equipo Metas") -> dict[str, Any]:
    import auth
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo(nombre)
    k = nombre.split()[-1].lower()
    return {"eq": eq, "nombre": nombre,
            "ase": db.obtener_usuario(db.crear_usuario(f"ase{k}", h, s, f"Ase {nombre}", "ASESOR", eq)),
            "coo": db.obtener_usuario(db.crear_usuario(f"coo{k}", h, s, f"Coo {nombre}", "COORDINADOR", eq)),
            "dir": db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])}


def _avisos(db: Any, uid: int) -> list[str]:
    with db._conexion() as con:
        return [f[0] for f in con.execute("SELECT texto FROM notificaciones WHERE usuario_id = ? ORDER BY id", (uid,))]


def test_seguimiento_sin_carga_completitud_y_proyeccion(base: Any) -> None:
    import metas
    db = base
    g = _equipo(db)
    hoy = date(2026, 5, 10)
    metas.guardar_metas_anuales(2026, {g["eq"]: {"monitoreos": 12, "informes_generales": 6}}, g["dir"])
    s = metas.seguimiento(2026, [{"id": g["eq"], "nombre": g["nombre"]}], hoy)
    eq = s["equipos"][0]
    f = {x["clave"]: x for x in eq["filas"]}
    assert f["monitoreos"]["estado"] == "sin_carga" and eq["completitud"]["nivel"] == "alto" and eq["resumen"].get("sin_carga") == 2
    assert f["monitoreos"]["por_mes"] == 2 and f["monitoreos"]["proyeccion"] == 0
    # la coordinación carga abril en 0: ya no es «sin carga», es un 0
    metas.guardar_carga(g["eq"], 2026, "M04", {(g["ase"]["id"], "monitoreos"): 0}, g["coo"])
    eq = metas.seguimiento(2026, [{"id": g["eq"], "nombre": g["nombre"]}], hoy)["equipos"][0]
    f = {x["clave"]: x for x in eq["filas"]}
    assert f["monitoreos"]["estado"] == "atrasada" and eq["completitud"]["faltan"] == ["Enero", "Febrero", "Marzo"]
    metas.guardar_carga(g["eq"], 2026, "M01", {(g["ase"]["id"], "monitoreos"): 3}, g["coo"])
    eq = metas.seguimiento(2026, [{"id": g["eq"], "nombre": g["nombre"]}], hoy)["equipos"][0]
    assert eq["completitud"]["faltan"] == ["Febrero", "Marzo"] and {x["clave"]: x for x in eq["filas"]}["monitoreos"]["hecho"] == 3
    libro = metas.exportar_planilla(2026, {"id": g["eq"], "nombre": g["nombre"]}, hoy)
    assert "Metas y avance" in libro.sheetnames


def test_avisos_de_fondo(base: Any) -> None:
    import metas
    db = base
    g = _equipo(db, "Equipo Avisos")
    metas.guardar_metas_anuales(2026, {g["eq"]: {"monitoreos": 120}}, g["dir"])
    metas.guardar_carga(g["eq"], 2026, "M01", {(g["ase"]["id"], "monitoreos"): 20}, g["coo"])
    assert metas.avisos_de_fondo(date(2026, 2, 10)) == 0, "primera evaluación: en camino, sin aviso"
    assert metas.avisos_de_fondo(date(2026, 2, 10)) == 0, "una vez por día"
    assert metas.avisos_de_fondo(date(2026, 4, 14)) == 1
    textos = _avisos(db, g["coo"]["id"])
    assert any("«Monitoreos» de Equipo Avisos pasó a atrasada" in t for t in textos), textos
    assert metas.avisos_de_fondo(date(2026, 4, 15)) == 0, "sigue atrasada: no se repite"
    assert not _avisos(db, g["ase"]["id"]), "el aviso es para la coordinación"
    n = metas.avisos_de_fondo(date(2026, 4, 20))  # lunes: resumen a la Dirección
    assert n == 1 and any(t.startswith("Resumen semanal de metas: 1 indicador(es)") for t in _avisos(db, g["dir"]["id"]))
    # recordatorio de carga: primer día hábil de mayo, abril sin cargar
    antes = len(_avisos(db, g["coo"]["id"]))
    metas.avisos_de_fondo(date(2026, 5, 4))
    nuevos = _avisos(db, g["coo"]["id"])[antes:]
    assert any("falta cargar lo realizado por Equipo Avisos en abril 2026" in t for t in nuevos), nuevos
    antes = len(_avisos(db, g["coo"]["id"]))
    metas.avisos_de_fondo(date(2026, 5, 5))
    assert not any("falta cargar" in t for t in _avisos(db, g["coo"]["id"])[antes:]), "una vez por mes"


def test_calidad_desde_los_viajes(base: Any) -> None:
    import metas
    import operacion as op
    import tablero_direccion as td
    import traslados as tr
    db = base
    g = _equipo(db, "Equipo Calidad")
    u = db.listar_unidades()[0]["id"]
    hoy = date.today()
    ids = []
    for k in (10, 9):
        f = hoy - timedelta(days=k)
        if f.year != hoy.year:
            return  # a principios de enero no hay visitas del año todavía
        ids.append(tr.crear_viaje({"fecha": f.isoformat(), "unidad_id": u},
                                  [{"usuario_id": g["ase"]["id"], "nombre": g["ase"]["nombre"], "equipo_nombre": g["nombre"], "auto_propio": 1}],
                                  g["ase"], hoy=f - timedelta(days=10)))
    v = tr.obtener_viaje(ids[0])
    td.guardar_entrevistas(ids[0], {v["participantes"][0]["id"]: "6"}, g["ase"], pabellones={v["participantes"][0]["id"]: True})
    op.agregar_novedad(ids[1], "INGRESO_DENEGADO", "", "", "Ase")
    q = metas.calidad_visitas(hoy.year, [{"id": g["eq"], "nombre": g["nombre"]}])[g["eq"]]
    assert q == {"visitas": 2, "pct_pabellones": 50, "audiencias_por_visita": 6.0, "pct_obstaculos": 50, "pct_informadas": 50}
