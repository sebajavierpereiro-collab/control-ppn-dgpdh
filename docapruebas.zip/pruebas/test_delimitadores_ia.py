from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import nucleo  # noqa: E402


def test_saca_delimitadores_en_los_bordes() -> None:
    assert nucleo._quitar_delimitadores("<<<TEXTO>>>\nEste organismo tomó conocimiento.\n<<<FIN>>>") == "Este organismo tomó conocimiento."
    assert nucleo._quitar_delimitadores("  Texto sin marcas.  ") == "Texto sin marcas."
    assert nucleo._quitar_delimitadores("") == ""


def test_eco_del_pedido_se_sigue_descartando() -> None:
    salida = nucleo._quitar_delimitadores("REGLAS OBLIGATORIAS\n<<<TEXTO>>>\nHola\n<<<FIN>>>")
    ok, motivo = nucleo._respuesta_ia_valida("Hola", salida)
    assert not ok and motivo == "repite el prompt"
    ok, _ = nucleo._respuesta_ia_valida("Hola", "Hola <<<FIN>>> texto")
    assert not ok
