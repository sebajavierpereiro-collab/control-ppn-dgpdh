"""Propuesta 96: la IA local solo redacta; las cifras se insertan desde los datos y una respuesta con números propios se descarta."""
from __future__ import annotations

from dgpdh.dominio import lectura_metas as lm

FILAS = [{"nombre": "Visitas", "meta": 40, "hecho": 10, "esperado": 20, "estado": "atrasada", "trimestres": [4, 6, 0, 0]},
         {"nombre": "Monitoreos", "meta": 12, "hecho": 9, "esperado": 6, "estado": "en_camino", "trimestres": [5, 4, 0, 0]},
         {"nombre": "Reuniones", "meta": 0, "hecho": 3, "esperado": 0, "estado": "sin_meta", "trimestres": [3, 0, 0, 0]}]


def test_hechos_y_armado() -> None:
    h = lm.hechos("Eq", FILAS, 2)
    assert len(h) == 2 and h[0].startswith("Visitas: 10 en el año (50 % de lo esperado a la fecha, atrasada); 6 en el 2.º trimestre")
    assert "No escribas ningún número" in lm.prompt("Eq", 2, 2026, h) and "[H2] = Monitoreos" in lm.prompt("Eq", 2, 2026, h)
    texto, ia = lm.armar("Las visitas vienen atrasadas [H1], mientras que los monitoreos avanzan [H2].", "Eq", 2, 2026, h)
    assert ia and "(Visitas: 10 en el año" in texto and "[H" not in texto
    for mala in ("Las visitas son 12 [H1].", "Todo bien.", None, ""):
        texto, ia = lm.armar(mala, "Eq", 2, 2026, h)
        assert not ia and texto.startswith("Lectura del 2.º trimestre 2026 de Eq."), mala
    assert lm.armar("x [H1]", "Eq", 2, 2026, []) == ("Eq no tiene metas cargadas para 2026.", False)
