"""Propuesta 39: vínculo nota ↔ ficha de persona detenida, propuesto por el sistema y confirmado por una persona."""
from __future__ import annotations

import asyncio
import sys
import types
from pathlib import Path
from typing import Any

import pytest

from dgpdh.errores import DatoInvalido
from dgpdh.seguridad import auditoria as au
from dgpdh.servicios import nota_persona as np_

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
ANA = {"id": 5, "nombre": "Ana Pérez", "rol": "ASESOR", "acceso_notas": 1}


@pytest.fixture()
def base(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Any:
    import database as db
    import detenidos as det
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    with db._conexion() as con:
        eq = con.execute("SELECT id FROM equipos LIMIT 1").fetchone()[0]
        for i in (1, 2):
            con.execute("INSERT INTO notas (id, nombre_original, equipo_id, ruta_original, estado, creado_en, actualizado_en) VALUES (?,?,?,?,?,?,?)",
                        (i, f"Nota {i}.docx", eq, "x", "FIRMADA", "2026-11-14", "2026-11-14"))
    ids = {}
    for nombre, dni in (("Juan Carlos Gómez", "30123456"), ("Walter Básquez", None), ("Juan Carlos Gomez Ruiz", "40111222")):
        i, err, _ = det.guardar({"nombre_completo": nombre, "dni": dni}, {"nombre": "Mesa"})
        assert not err, err
        ids[nombre] = i
    db.guardar_entidades(1, [("PERSONA", "DNI 30123456", "dni:30123456"), ("PERSONA", "Walter Vázquez", "walter vazquez")])
    db.guardar_entidades(2, [("PERSONA", "GOMEZ, Juan Carlos", "gomez juan carlos")])
    return db, det, ids


def test_proponer_y_decidir(base: Any) -> None:
    db, det, ids = base
    with db._conexion() as con:
        props = np_.proponer(con, 1)
        assert [(p.detenido_id, p.puntaje) for p in props][:2] == [(ids["Juan Carlos Gómez"], 100), (ids["Walter Básquez"], 50)]
        p2 = {p.detenido_id: p for p in np_.proponer(con, 2)}
        assert p2[ids["Juan Carlos Gómez"]].puntaje == 65 and p2[ids["Juan Carlos Gomez Ruiz"]].puntaje == 40
        np_.decidir(con, nota_id=2, detenido_id=ids["Juan Carlos Gómez"], accion="confirmar", actor=au.Actor(5, "Ana Pérez"), puntaje=65)
        np_.decidir(con, nota_id=2, detenido_id=ids["Juan Carlos Gomez Ruiz"], accion="descartar", actor=au.Actor(5, "Ana Pérez"))
        assert np_.proponer(con, 2) == [], "lo decidido no se vuelve a proponer"
        assert [c["id"] for c in np_.confirmadas_de_nota(con, 2)] == [ids["Juan Carlos Gómez"]]
        assert con.execute("SELECT COUNT(*) FROM auditoria WHERE entidad = 'nota' AND entidad_id = '2'").fetchone()[0] == 2
        with pytest.raises(DatoInvalido):
            np_.decidir(con, nota_id=2, detenido_id=ids["Walter Básquez"], accion="otra", actor=au.Actor(5, "Ana"))
    rel = det.notas_relacionadas(det.obtener(ids["Juan Carlos Gómez"]))
    assert {n["id"]: n["confirmada"] for n in rel} == {1: False, 2: True}
    with db._conexion() as con:
        np_.decidir(con, nota_id=1, detenido_id=ids["Juan Carlos Gómez"], accion="descartar", actor=au.Actor(5, "Ana Pérez"))
    assert [n["id"] for n in det.notas_relacionadas(det.obtener(ids["Juan Carlos Gómez"]))] == [2], "la descartada no aparece aunque tenga el DNI"


def test_ruta_y_permisos(base: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    db, det, ids = base
    import rutas_notas_ia
    from starlette import responses
    fa = types.ModuleType("fastapi")
    fa.Request = object  # type: ignore[attr-defined]

    class HTTPException(Exception):
        def __init__(self, status_code: int = 500, detail: str = "") -> None:
            self.status_code = status_code
    fa.HTTPException = HTTPException  # type: ignore[attr-defined]
    fr = types.ModuleType("fastapi.responses")
    fr.RedirectResponse = responses.RedirectResponse  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "fastapi", fa)
    monkeypatch.setitem(sys.modules, "fastapi.responses", fr)
    rutas: dict[str, Any] = {}

    class App:
        def post(self, ruta: str, **k: Any) -> Any:
            return lambda f: rutas.setdefault(ruta, f)

        def get(self, ruta: str, **k: Any) -> Any:
            return lambda f: rutas.setdefault("GET " + ruta, f)
    plantillas = types.SimpleNamespace(env=types.SimpleNamespace(globals={}))
    rutas_notas_ia.registrar(App(), {"templates": plantillas, "usuario_actual": lambda r: r.usuario, "exigir_rol": lambda u: None,
                                     "clave_auditoria": lambda: (b"k", None), "puede_ver_nota": lambda u, n: u["id"] == 5,
                                     "tiene_notas": lambda u: True})

    def pedido(u: dict[str, Any], datos: dict[str, str]) -> Any:
        async def form() -> dict[str, str]:
            return datos
        return types.SimpleNamespace(usuario=u, session={}, form=form)
    r = asyncio.run(rutas["/nota/{nota_id}/persona"](pedido(ANA, {"detenido_id": str(ids["Walter Básquez"]), "accion": "confirmar"}), 1))
    assert r.status_code == 303
    otro = dict(ANA, id=6)
    with pytest.raises(HTTPException) as e:
        asyncio.run(rutas["/nota/{nota_id}/persona"](pedido(otro, {"detenido_id": "1", "accion": "confirmar"}), 1))
    assert e.value.status_code == 404, "quien no ve la nota no la vincula"
    chofer = dict(ANA, rol="CHOFER")
    with pytest.raises(HTTPException):
        asyncio.run(rutas["/nota/{nota_id}/persona"](pedido(chofer, {"detenido_id": "1", "accion": "confirmar"}), 1))
    datos = plantillas.env.globals["personas_de_nota"]({"id": 1}, ANA)
    assert [c["id"] for c in datos["confirmadas"]] == [ids["Walter Básquez"]]
    assert plantillas.env.globals["personas_de_nota"]({"id": 1}, chofer) is None
