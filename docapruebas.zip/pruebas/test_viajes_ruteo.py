"""Propuestas 55 (orden sugerido de paradas) y 54 (OSRM local optativo: nunca un servidor público; sin OSRM, línea recta)."""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any

from dgpdh.dominio import ruteo
from dgpdh.servicios import distancias, opciones_viajes

PUNTOS = {0: (0.0, 0.0), 1: (0.0, 10.0), 2: (0.0, 1.0), 3: (0.0, 5.0)}


def _d(a: int, b: int) -> float:
    return abs(PUNTOS[a][1] - PUNTOS[b][1])


def test_sugerir() -> None:
    assert ruteo.sugerir([1, 2, 3], _d, origen=0) == [2, 3, 1]
    assert ruteo.largo([1, 2, 3], _d, 0) == 10 + 9 + 4 + 5 and ruteo.largo([2, 3, 1], _d, 0) == 20
    assert ruteo.sugerir([5], _d) == [5] and ruteo.sugerir([], _d) == []


def test_solo_osrm_local() -> None:
    assert distancias.es_local("http://127.0.0.1:5000") and distancias.es_local("http://192.168.1.20:5000") and distancias.es_local("http://localhost:5000")
    assert not distancias.es_local("https://router.project-osrm.org") and not distancias.es_local("http://8.8.8.8:5000")


def test_osrm_optativo(tmp_path: Path, monkeypatch: Any) -> None:
    class H(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            cuerpo = json.dumps({"routes": [{"distance": 42500.0, "duration": 3000.0}]}).encode()
            self.send_response(200)
            self.end_headers()
            self.wfile.write(cuerpo)

        def log_message(self, *a: object) -> None:
            pass
    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        cfg = tmp_path / "config.ini"
        cfg.write_text(f"[viajes]\nosrm_url = http://127.0.0.1:{srv.server_port}\nfactor_ruta = 1,5\n", encoding="utf-8")
        monkeypatch.setattr(opciones_viajes, "RUTA_CONFIG", cfg)
        distancias._CACHE.clear()
        assert distancias.ruta([(-34.6, -58.4), (-34.8, -58.5)]) == (42.5, 50, "OSRM local")
        cfg.write_text("[viajes]\nosrm_url = https://router.project-osrm.org\nfactor_ruta = 1,5\n", encoding="utf-8")
        km, minutos, fuente = distancias.ruta([(-34.6, -58.4), (-34.8, -58.5)])
        assert minutos is None and fuente == "línea recta × 1.5", "un servidor público nunca se usa"
        cfg.write_text("[viajes]\nosrm_url = http://127.0.0.1:1\n", encoding="utf-8")
        distancias._CACHE.clear()
        assert distancias.ruta([(-34.6, -58.4), (-34.8, -58.5)])[2] == "línea recta × 1.3", "si OSRM no responde, sigue todo igual"
    finally:
        srv.shutdown()
