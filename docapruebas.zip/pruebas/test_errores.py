from dgpdh import errores as e


def test_jerarquia_y_codigos() -> None:
    for clase, codigo in ((e.DatoInvalido, 400), (e.NoEncontrado, 404), (e.PermisoDenegado, 403), (e.Conflicto, 409),
                          (e.IntegracionDeshabilitada, 503)):
        err = clase("Mensaje para la persona", detalle="técnico")
        assert isinstance(err, e.ErrorDGPDH) and err.codigo_http == codigo
        assert str(err) == err.mensaje == "Mensaje para la persona" and err.detalle == "técnico"
