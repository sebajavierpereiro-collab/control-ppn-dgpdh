"""Propuesta 36 (sin Pandera): esquema por fuerza con control completo (fila y columna)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from dgpdh.dominio import esquema_listados as el

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
REGS = [{"nombre_completo": "Ana Torres", "dni": "25.000.111", "fecha_nacimiento": "02/01/1980", "situacion_procesal": "Condenado/a"},
        {"nombre_completo": "", "dni": "123", "fecha_nacimiento": "31/02/1980", "condena_meses": "14", "situacion_procesal": "Libre"},
        {"nombre_completo": "Pedro", "dni": "sin dato", "condena_anios": "dos"}]


def test_control_completo() -> None:
    f = el.controlar(REGS)
    assert all(x.fila != 1 for x in f), "la fila buena no tiene problemas"
    problemas = {(x.fila, x.columna) for x in f}
    assert {(2, "Nombre completo"), (2, "DNI"), (2, "Fecha de nacimiento"), (2, "Meses de condena"), (2, "Situación procesal"),
            (3, "DNI"), (3, "Años de condena")} == problemas, "junta todos los problemas, no para en el primero"
    assert el.resumen(f)["DNI"] == 2


def test_esquema_propio(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import detenidos
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    (tmp_path / "esquemas_listados.json").write_text(json.dumps({"1": {"nombre": "SPF", "columnas": [
        {"clave": "lpu", "etiqueta": "LPU", "tipo": "documento", "obligatoria": True, "minimo": 5, "maximo": 8}]}}), encoding="utf-8")
    r = detenidos.controlar_esquema([{"nombre_completo": "Ana"}], fuerza_id=1)
    assert r["esquema"] == "SPF" and [(x.columna, x.problema) for x in r["fallas"]] == [("LPU", "falta (es obligatoria)")]
    assert detenidos.controlar_esquema([{"nombre_completo": "Ana"}], fuerza_id=2)["esquema"] == "General"
    assert el.esquema_desde({"columnas": "x"}) is el.GENERAL
