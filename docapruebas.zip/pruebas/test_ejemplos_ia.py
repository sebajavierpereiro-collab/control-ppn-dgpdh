"""Propuesta 18: ejemplos de correcciones aprobadas elegidos por parecido (optativo)."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import pytest

from dgpdh.ia import ejemplos as ej

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))
PARES = [ej.Par("El interno solicito colchon.", "La persona detenida solicitó un colchón."),
         ej.Par("Se constato falta de agua caliente en el pabellon.", "Se constató la falta de agua caliente en el pabellón."),
         ej.Par("Igual.", "Igual."), ej.Par("x " * 300, "y")]


def test_elegir() -> None:
    assert ej.elegir("Falta agua caliente en el pabellón 4", PARES, 2) == [PARES[1]]
    assert ej.elegir("algo sin relación", PARES, 2) == [] and ej.elegir("agua", PARES, 0) == []
    assert "Aprobado:" in ej.bloque([PARES[0]]) and ej.bloque([]) == ""


class _Resp:
    status_code = 200

    def __init__(self, texto: str) -> None:
        self.texto = texto

    def json(self) -> dict[str, Any]:
        return {"response": self.texto, "done_reason": "stop"}


def test_en_el_pedido(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import database as db
    import nucleo
    monkeypatch.setattr(db, "RUTA_DB", tmp_path / "t.db")
    db.inicializar_db()
    monkeypatch.setattr(nucleo, "ia_disponible", lambda p: True)
    monkeypatch.setattr(nucleo, "_CACHE_EJEMPLOS", {"hasta": 1e18, "pares": PARES})
    pedidos: list[str] = []
    texto = "Se constato la falta de agua caliente en el pabellon numero cuatro durante la visita de ayer a la unidad."
    monkeypatch.setattr(nucleo.requests, "post", lambda url, json, timeout: (pedidos.append(json["prompt"]), _Resp(texto))[1])
    monkeypatch.setattr(nucleo, "EJEMPLOS_CORRECCION", [0])
    nucleo.corregir_con_ia(texto)
    assert "YA APROBÓ" not in pedidos[-1], "apagado: el pedido queda como hoy"
    monkeypatch.setattr(nucleo, "EJEMPLOS_CORRECCION", [2])
    nucleo.corregir_con_ia(texto)
    assert "YA APROBÓ" in pedidos[-1] and "Se constató la falta de agua caliente en el pabellón." in pedidos[-1]
    assert pedidos[-1].index("YA APROBÓ") < pedidos[-1].index("<<<TEXTO>>>")
