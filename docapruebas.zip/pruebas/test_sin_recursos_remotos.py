"""Propuestas 98 y 99: las pantallas no cargan nada desde internet (scripts, estilos, fuentes, imágenes). Los enlaces que la
persona elige abrir (<a href="https://...">) sí están permitidos."""
from __future__ import annotations

import base64
import hashlib
import re
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
REMOTO = re.compile(
    r"""<(?:script|img|iframe|source|video|audio|embed)\b[^>]*\bsrc\s*=\s*["']?\s*(?:https?:)?//"""
    r"""|<link\b[^>]*\bhref\s*=\s*["']?\s*(?:https?:)?//"""
    r"""|@import\s+(?:url\()?\s*["']?(?:https?:)?//"""
    r"""|url\(\s*["']?(?:https?:)?//""", re.I)
HTMX_SHA384 = "ujb1lZYygJmzgSwoxRggbCHcjc0rB2XoQrxeTUQyRjrOnlCoYta87iKBWq3EsdM2"  # htmx 1.9.12 oficial


def test_plantillas_y_estaticos_sin_recursos_remotos() -> None:
    hallados = []
    for ruta in list((RAIZ / "templates").rglob("*.html")) + [p for p in (RAIZ / "static").rglob("*") if p.suffix in (".css", ".js", ".html")]:
        if ruta.name == "htmx.min.js":
            continue
        texto = ruta.read_text(encoding="utf-8", errors="replace")
        for m in REMOTO.finditer(texto):
            hallados.append(f"{ruta.relative_to(RAIZ)}: {texto[max(0, m.start() - 20):m.end() + 40]!r}")
    assert not hallados, "Recursos cargados desde internet:\n" + "\n".join(hallados)


def test_htmx_local_es_el_oficial() -> None:
    ruta = RAIZ / "static" / "htmx.min.js"
    assert ruta.is_file(), "falta static/htmx.min.js"
    assert base64.b64encode(hashlib.sha384(ruta.read_bytes()).digest()).decode() == HTMX_SHA384
    base = (RAIZ / "templates" / "base.html").read_text(encoding="utf-8")
    assert '<script src="/static/htmx.min.js' in base and "cdnjs" not in base
