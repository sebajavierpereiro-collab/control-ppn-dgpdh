"""Propuesta 43: copias anonimizadas, consistentes y que no tocan la base. Datos ficticios."""
from __future__ import annotations

import csv
import sqlite3
import sys
from pathlib import Path

import pytest

from dgpdh.dominio.anonimizar import Anonimizador, restos_sospechosos

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

TEXTO = ("Me dirijo a usted por el Sr. Juan Carlos Gómez, DNI 30.123.456, LPU N° 123456, alojado en el Complejo Penitenciario "
         "Federal I, en el marco del Expte. EP 1234/2025 y de la NO-2025-12345678-APN-DGPDH#PPN. PEREYRA, Marta Inés (CUIL 27-28999111-4) "
         "pidió lo mismo. Se reitera lo pedido para el interno Juan Carlos Gómez (DNI 30123456).")


def test_texto() -> None:
    an = Anonimizador(semilla="s", nombres_conocidos=["Juan Carlos Gómez"])
    t = an.texto(TEXTO)
    for dato in ("Gómez", "30.123.456", "30123456", "123456", "1234/2025", "12345678", "PEREYRA", "Marta", "28999111"):
        assert dato not in t, dato
    assert t.count("[PERSONA_1]") == 2 and "[PERSONA_2]" in t, "la misma persona, el mismo reemplazo"
    assert "Complejo Penitenciario Federal I" in t and "Sr. [PERSONA_1]" in t and "EP " in t and "NO-2025-" in t
    assert an.texto(TEXTO) == t, "determinista"
    assert Anonimizador(semilla="otra", nombres_conocidos=["Juan Carlos Gómez"]).texto(TEXTO) != t
    r = an.resumen()
    assert r["personas_distintas"] == 2 and r["dni"] >= 2 and r["lpu"] >= 1 and r["expediente"] >= 1 and r["gde"] >= 1 and r["cuil"] >= 1
    g = Anonimizador(lugares=["Complejo Penitenciario Federal I"], generalizar_lugares=True).texto(TEXTO)
    assert "[UNIDAD]" in g and "Complejo Penitenciario Federal I" not in g
    assert restos_sospechosos("DNI 30123456 de GOMEZ PEREZ") == ["30123456", "GOMEZ PEREZ"]
    assert an.sospechosos(t) == [] and restos_sospechosos(t)


def test_ficha() -> None:
    an = Anonimizador()
    f = an.ficha({"id": 9, "nombre_completo": "Ana Torres", "dni": "25000111", "lpu": "555", "fecha_nacimiento": "1985-06-17",
                  "apellido": "Torres", "alias": "La Negra", "situacion_procesal": "Procesada", "observaciones": "Hermana de la Sra. Rosa Torres"})
    assert f["nombre_completo"] == "[PERSONA_1]" and f["dni"] != "25000111" and len(f["dni"]) == 8 and f["apellido"] is None and f["alias"] is None
    assert f["fecha_nacimiento"][:4] == "1985" and f["fecha_nacimiento"] != "1985-06-17" and "Rosa" not in f["observaciones"]
    assert f["situacion_procesal"] == "Procesada"


def test_comando_no_toca_la_base(tmp_path: Path) -> None:
    from herramientas import anonimizar as cmd
    base = tmp_path / "datos" / "dgpdh.db"
    base.parent.mkdir()
    con = sqlite3.connect(base)
    con.execute("CREATE TABLE notas_texto (nota_id INTEGER PRIMARY KEY, contenido TEXT)")
    con.execute("CREATE TABLE detenidos (id INTEGER PRIMARY KEY, nombre_completo TEXT, dni TEXT, lpu TEXT, fecha_nacimiento TEXT, nacionalidad TEXT, "
                "unidad_id INTEGER, centro_otro TEXT, modulo TEXT, pabellon TEXT, situacion_procesal TEXT, juzgado TEXT, tribunal TEXT, activo INTEGER, "
                "motivo_baja TEXT, observaciones TEXT)")
    con.execute("CREATE TABLE unidades (id INTEGER PRIMARY KEY, nombre TEXT)")
    con.execute("INSERT INTO notas_texto VALUES (1, ?)", (TEXTO,))
    con.execute("INSERT INTO detenidos (id, nombre_completo, dni) VALUES (1, 'Juan Carlos Gómez', '30123456')")
    con.commit()
    antes = base.read_bytes()
    con.close()
    with pytest.raises(SystemExit):
        cmd.generar(base, tmp_path / "datos" / "copia")
    r = cmd.generar(base, tmp_path / "copia")
    assert r["notas"] == 1 and r["fichas"] == 1 and base.read_bytes() == antes
    nota = (tmp_path / "copia" / "notas" / "0001.txt").read_text(encoding="utf-8")
    assert "Gómez" not in nota and "[PERSONA_1]" in nota
    fila = next(csv.DictReader((tmp_path / "copia" / "fichas.csv").open(encoding="utf-8")))
    assert fila["nombre_completo"] == "[PERSONA_1]" and fila["dni"] != "30123456"
    assert "revisa" in (tmp_path / "copia" / "MUESTRA_PARA_REVISAR.txt").read_text(encoding="utf-8")


def test_testar() -> None:
    from dgpdh.dominio.anonimizar import a_testar, testar
    t = "Por el Sr. Juan Gómez, DNI 30.123.456 (LPU 123456), con VIH. GOMEZ, Juan pidió atención."
    items = a_testar(t)
    assert ("DNI", "30.123.456") in items and ("LPU", "123456") in items and ("Salud", "VIH") in items and ("Persona", "Juan Gómez") in items
    assert len(items) == len({v.lower() for _, v in items}), "sin repetidos"
    assert testar(t, ["Juan Gómez", "30.123.456"]) == "Por el Sr. [TESTADO], DNI [TESTADO] (LPU 123456), con VIH. GOMEZ, Juan pidió atención."
