"""Propuesta 80: en Autos PPN no se borra nada (licencias, precargados de frecuentes y vínculos de equipos del historial)."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

import pytest


def _usuarios(db: Any) -> dict[str, Any]:
    import auth
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Equipo Bajas")
    return {"eq": eq, "ana": db.obtener_usuario(db.crear_usuario("anab", h, s, "Ana Bajas", "ASESOR", eq)),
            "chofer": db.obtener_usuario(db.crear_usuario("chob", h, s, "Chofer Bajas", "CHOFER", None, acceso_notas=False))}


def test_licencias_se_anulan_y_recuperan(base: Any) -> None:
    import operacion as op
    import traslados as tr
    db = base
    g = _usuarios(db)
    tr.sincronizar_choferes()
    cid = next(c["id"] for c in tr.listar_choferes() if c["usuario_id"] == g["chofer"]["id"])
    hoy = date.today()
    op.agregar_licencia(cid, hoy.isoformat(), (hoy + timedelta(days=3)).isoformat(), "VACACIONES", "", "Coord")
    lic = op.licencias(chofer_id=cid)[0]
    assert op.licencia_en(cid, hoy.isoformat())
    op.anular_licencia(lic["id"], "Coord", "Se cargó mal")
    assert op.licencias(chofer_id=cid) == [] and op.licencia_en(cid, hoy.isoformat()) is None
    anuladas = op.licencias(chofer_id=cid, anuladas=True)
    assert anuladas[0]["motivo_anulacion"] == "Se cargó mal" and anuladas[0]["anulada_por"] == "Coord"
    with pytest.raises(tr.ErrorTraslado):
        op.anular_licencia(lic["id"], "Coord")
    assert op.recuperar_licencia(lic["id"], "Coord") == []
    assert op.licencia_en(cid, hoy.isoformat())["id"] == lic["id"]
    with pytest.raises(tr.ErrorTraslado):
        op.recuperar_licencia(lic["id"], "Coord")
    op.borrar_licencia(lic["id"])  # nombre histórico: también anula
    with db._conexion() as con:
        assert con.execute("SELECT COUNT(*) FROM chofer_licencias").fetchone()[0] == 1, "la fila sigue en la base"
        acciones = [f[0] for f in con.execute("SELECT accion FROM auditoria WHERE entidad = 'chofer_licencias' ORDER BY id")]
    assert acciones == ["Licencia de chofer anulada", "Licencia de chofer recuperada", "Licencia de chofer anulada"]


def test_precargados_se_descartan_y_vuelven(base: Any) -> None:
    import frecuentes as fr
    import traslados as tr
    db = base
    g = _usuarios(db)
    amba = next(x for x in db.listar_unidades() if (x.get("zona") or "") == "AMBA")
    hoy = date.today()
    fid = fr.crear({"circuito": "AMBA", "unidad_id": amba["id"], "dias": [0, 1, 2, 3, 4], "frecuencia": "SEMANAL", "desde": hoy.isoformat()},
                   [{"usuario_id": g["ana"]["id"], "nombre": g["ana"]["nombre"], "equipo_nombre": "Equipo Bajas"}], g["ana"])
    n = fr.generar(hoy=hoy)
    assert n >= 5

    def visibles() -> list[dict[str, Any]]:
        return [v for v in tr.listar_viajes(desde=hoy.isoformat()) if v.get("frecuente_id") == fid]
    ids = sorted(v["id"] for v in visibles())
    fr.cambiar_estado(fid, "pausar", g["ana"])
    assert visibles() == [], "pausado: no se listan (como antes)"
    descartados = [v for v in tr.listar_viajes(desde=hoy.isoformat(), incluir_descartados=True) if v.get("frecuente_id") == fid]
    assert sorted(v["id"] for v in descartados) == ids and all(v["motivo_cancelacion"] == tr.MOTIVO_DESCARTADO for v in descartados)
    assert all(v["participantes"] for v in descartados), "las personas siguen cargadas"
    fr.cambiar_estado(fid, "activar", g["ana"])
    assert fr.generar(hoy=hoy) == n
    assert sorted(v["id"] for v in visibles()) == ids and all(v["estado"] == "A_CONFIRMAR" for v in visibles()), "vuelven los mismos viajes"
    fin = (hoy + timedelta(days=2)).isoformat()
    fr.fijar_fin(fid, fin, g["ana"])
    assert all(v["fecha"] <= fin for v in visibles())
    hist = tr.historial("viaje", ids[-1])
    assert [h["accion"] for h in hist][:3] == ["Descartado (viaje frecuente)", "Recuperado (viaje frecuente reactivado)", "Descartado (viaje frecuente)"]


def test_vinculo_de_equipo_se_da_de_baja_y_se_reactiva(base: Any) -> None:
    import traslados as tr
    db = base
    g = _usuarios(db)
    tr.vincular_equipo_historial("equipo bajas viejo", g["eq"], {"nombre": "Coord"})
    assert tr.equipo_por_alias("Equipo Bajas Viejo")["id"] == g["eq"]
    tr.deshacer_vinculo_equipo("equipo bajas viejo", {"nombre": "Coord"})
    assert tr.equipo_por_alias("Equipo Bajas Viejo") is None and tr.equipos_del_historial()[1] == []
    with db._conexion() as con:
        f = con.execute("SELECT anulado_por FROM equipos_alias WHERE alias = 'equipo bajas viejo'").fetchone()
    assert f["anulado_por"] == "Coord", "queda dado de baja, no borrado"
    tr.vincular_equipo_historial("equipo bajas viejo", g["eq"], {"nombre": "Coord"})
    assert tr.equipo_por_alias("Equipo Bajas Viejo")["id"] == g["eq"]
