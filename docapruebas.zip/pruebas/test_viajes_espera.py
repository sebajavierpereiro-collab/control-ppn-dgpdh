"""Propuesta 75: lista de espera con motivo tipificado; urgencias primero, después antigüedad; la coordinación puede reordenar."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import espera as de


def test_orden() -> None:
    l = [{"id": 1, "motivo": "RUTINA", "creado_en": "a"}, {"id": 2, "motivo": "HUELGA_HAMBRE", "creado_en": "b"},
         {"id": 3, "motivo": None, "creado_en": "c"}, {"id": 4, "motivo": "PEDIDO_JUDICIAL", "creado_en": "d"}]
    assert [e["id"] for e in de.ordenar(l)] == [2, 4, 1, 3]
    assert de.mover([2, 4, 1, 3], 1, "subir") == [2, 1, 4, 3] and de.mover([2, 4], 2, "subir") == [2, 4] and de.mover([2, 4], 9, "bajar") == [2, 4]
    m = [dict(e, orden_manual=k) for k, e in enumerate([l[2], l[0], l[1], l[3]], 1)]
    assert [e["id"] for e in de.ordenar(m)] == [3, 1, 2, 4], "si la coordinación reordenó, manda ese orden"


def test_espera_y_aviso(base: Any) -> None:
    import auth
    import operacion as op
    import traslados as tr
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    eq = db.crear_equipo("Eq Espera")
    us = [db.obtener_usuario(db.crear_usuario(f"es{k}", h, s, f"Espera {k}", "ASESOR", eq)) for k in range(4)]
    vid = tr.crear_viaje({"fecha": (date.today() + timedelta(days=20)).isoformat(), "unidad_id": db.listar_unidades()[0]["id"]},
                         [{"usuario_id": us[0]["id"], "nombre": us[0]["nombre"], "equipo_nombre": "Eq Espera", "auto_propio": 1}], us[0])
    op.anotar_en_espera(vid, us[1])
    op.anotar_en_espera(vid, us[2], "HABEAS_CORPUS", "Hábeas en trámite")
    op.anotar_en_espera(vid, us[3], "OTRO")
    lista = op.espera_de(vid)
    assert [e["usuario_id"] for e in lista] == [us[2]["id"], us[1]["id"], us[3]["id"]] and lista[0]["motivo_etiqueta"] == "Hábeas corpus"
    assert lista[2]["motivo"] == "RUTINA", "un motivo desconocido queda como rutina"
    coord = {"nombre": "Coord"}
    assert op.reordenar_espera(vid, lista[1]["id"], "subir", coord) is True
    assert [e["usuario_id"] for e in op.espera_de(vid)] == [us[1]["id"], us[2]["id"], us[3]["id"]]
    assert op.reordenar_espera(vid, lista[1]["id"], "subir", coord) is False
    assert any(x["accion"] == "Orden de la lista de espera" for x in tr.historial("viaje", vid))
    assert op.avisar_lugar_libre(vid) == us[1]["id"], "se avisa al primero del orden vigente"
