"""Propuestas 85 (tendencia por indicador) y 94 (comparación normalizada entre equipos)."""
from __future__ import annotations

from datetime import date
from typing import Any


def test_tendencia_y_comparacion(base: Any) -> None:
    import auth
    import metas
    db = base
    h, s = auth.generar_hash_clave("Clave1234")
    direc = db.obtener_usuario(next(x for x in db.listar_usuarios() if x["rol"] == "DIRECTOR")["id"])
    eq = db.crear_equipo("Eq Tend")
    a = db.obtener_usuario(db.crear_usuario("tend1", h, s, "Tend Uno", "ASESOR", eq))
    db.crear_usuario("tend2", h, s, "Tend Dos", "ASESOR", eq)
    e = {"id": eq, "nombre": "Eq Tend"}
    for anio, mes, n in ((2025, 5, 10), (2026, 2, 4), (2026, 5, 15)):
        metas.guardar_carga(eq, anio, f"M{mes:02d}", {(a["id"], "monitoreos"): n}, direc)
    metas.guardar_carga(eq, 2026, "T3", {(a["id"], "informes_generales"): 1}, direc)
    hoy = date(2026, 6, 15)
    serie = metas.serie_mensual(2026, e, hoy)
    assert serie["monitoreos"][1] == 4 and serie["monitoreos"][4] == 15 and serie["informes_generales"][8] == 1
    filas = metas.seguimiento(2026, [e], hoy)["equipos"][0]["filas"]
    t = metas.tendencias(2026, e, filas, hoy)["monitoreos"]
    assert t["valores"] == [0, 4, 0, 0, 15, 0] and t["vs_trimestre"] == 275 and t["vs_anio"] == 50 and t["trimestre"] == 2
    assert t["puntos"].startswith("0.0,22.0") and metas.variacion(5, 0) is None
    with db._conexion() as con:
        con.execute("INSERT INTO equipo_unidades (equipo_id, unidad_id, orden) VALUES (?, ?, 1)", (eq, db.listar_unidades()[0]["id"]))
    c = metas.comparacion(metas.seguimiento(2026, [e], hoy)["equipos"])[0]
    assert c["integrantes"] == 2 and c["unidades"] == 1 and c["valores"]["Informes"] == 1 and c["poco"]["Informes"] and c["por_integrante"]["Informes"] == 0.5
