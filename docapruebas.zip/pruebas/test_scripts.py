"""Corre con pytest los scripts de prueba históricos de tests/ (cada uno arma su propio entorno, así que va en un proceso
aparte). Se ejecutan en paralelo una sola vez por sesión y cada script es un caso de pytest.

    python -m pytest pruebas -q                      # todo
    python -m pytest pruebas -q -k misma_salida      # uno solo
    DGPDH_PRUEBAS_PARALELO=1 python -m pytest pruebas  # en serie (para depurar)
"""
from __future__ import annotations

import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
SCRIPTS = sorted((RAIZ / "tests").glob("test_*.py"))
TIEMPO_MAXIMO = int(os.environ.get("DGPDH_PRUEBAS_TIEMPO", "900"))


@dataclass(frozen=True)
class Resultado:
    codigo: int
    salida: str


def _correr(script: Path) -> Resultado:
    entorno = dict(os.environ, PYTHONIOENCODING="utf-8")
    try:
        r = subprocess.run([sys.executable, str(script)], cwd=RAIZ, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=TIEMPO_MAXIMO, env=entorno)
    except subprocess.TimeoutExpired:
        return Resultado(-1, f"Superó {TIEMPO_MAXIMO} s")
    return Resultado(r.returncode, (r.stdout or "") + (r.stderr or ""))


@pytest.fixture(scope="session")
def resultados(request: pytest.FixtureRequest) -> dict[str, Resultado]:
    elegidos = [item.callspec.params["script"] for item in request.session.items
                if hasattr(item, "callspec") and "script" in item.callspec.params]
    hilos = max(1, int(os.environ.get("DGPDH_PRUEBAS_PARALELO", str(os.cpu_count() or 2))))
    with ThreadPoolExecutor(max_workers=hilos) as pool:
        return dict(zip([s.name for s in elegidos], pool.map(_correr, elegidos), strict=True))


@pytest.mark.parametrize("script", SCRIPTS, ids=[s.stem for s in SCRIPTS])
def test_script(script: Path, resultados: dict[str, Resultado]) -> None:
    r = resultados[script.name]
    assert r.codigo == 0, f"{script.name} terminó con código {r.codigo}:\n{r.salida[-4000:]}"
