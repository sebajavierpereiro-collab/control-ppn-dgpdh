"""Propuesta 70: vista del día por recurso (barras, huecos libres y superposiciones)."""
from __future__ import annotations

from dgpdh.dominio import recursos_dia as rd


def test_fila() -> None:
    f = rd.Fila(1, "AB123CD", "", "/x")
    f.bloques += [rd.bloque("08:00", "12:00", "salida", "CPF I"), rd.bloque("11:00", "13:00", "reserva", "Procurador")]
    assert f.choques and [b.horario for b in f.huecos] == ["06:00–08:00", "13:00–22:00"]
    b = f.bloques[0]
    assert b.izq == 12.5 and b.ancho == 25.0
    assert rd.bloque(None, None, "salida", "x").horario == "08:00–12:00", "sin horario: 8 a 12"
    g = rd.Fila(2, "Pedro", "", "/y", [rd.todo_el_dia("licencia", "Vacaciones")])
    assert g.todo_el_dia and g.huecos == [] and not g.choques
    assert len(rd.horas()) == 16
