"""v41c: textos con tiras largas de espacios (habituales en .doc convertidos) no pueden trabar las búsquedas por patrón.

La nota 436 tenía «ex» seguido de miles de espacios: la búsqueda de expediente tardaba horas y congelaba todo el sistema."""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import agentes  # noqa: E402
import despacho  # noqa: E402
import mesa_entradas  # noqa: E402
from dgpdh.dominio import anonimizar  # noqa: E402

RELLENOS = (" " * 5000, "\t" * 5000, "  " * 2500)


def _rapido(fn, *args) -> None:  # type: ignore[no-untyped-def]
    t = time.perf_counter()
    fn(*args)
    assert time.perf_counter() - t < 1.0, fn


def test_expediente_y_destinatario() -> None:
    for r in RELLENOS:
        for pre in ("ex", "Expte. N°", "E.T.", "EX-2026-1-", "s /"):
            texto = pre + r + "x"
            _rapido(despacho.proponer_expediente, texto, "")
            _rapido(despacho.proponer_destinatario, "Al Sr. Director" + r + "x")
            _rapido(lambda t: list(despacho._EXPTE_TIPO.finditer(t)), texto)


def test_lpu_y_expediente_en_agentes_y_anonimizar() -> None:
    for r in RELLENOS:
        for pre in ("LPU", "legajo penitenciario", "expte", "L.P.U. N°"):
            texto = pre + r + "x"
            _rapido(lambda t: list(agentes._RE_LPU.finditer(t)), texto)
            _rapido(lambda t: list(agentes._RE_EXPTE_TXT.finditer(t)), texto)
            _rapido(lambda t: list(anonimizar._LPU.finditer(t)), texto)
            _rapido(mesa_entradas.parsear, texto)


def test_siguen_encontrando_lo_mismo() -> None:
    assert despacho.proponer_expediente("Ref. Expte. N° : 1234/25 y algo", "") == "1234/25"
    assert despacho.proponer_expediente("según E.T.: 6116/26 informado", "") == "ET 6116/26"
    assert despacho.proponer_destinatario("Al Sr. Jefe del Complejo S/D") == "Al Sr. Jefe del Complejo"
    assert [m.group(1) for m in agentes._RE_LPU.finditer("LPU N° 123.456")] == ["123.456"]
    assert mesa_entradas.parsear("EP 1234/2025") is not None


def test_palabras_con_tiras_de_signos() -> None:
    import analisis
    from dgpdh.dominio import anti_invencion
    texto = "Hola " + "." * 200000 + " Juan Pérez " + "_" * 100000
    _rapido(analisis._mayusculas_internas, texto)
    for nombre in dir(anti_invencion):
        f = getattr(anti_invencion, nombre)
        if callable(f) and nombre.startswith("_") and "mayus" in nombre.lower():
            _rapido(f, texto)
