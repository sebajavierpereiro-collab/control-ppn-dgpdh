"""Propuesta 77: cuadro «propuesto vs. asignado»."""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from dgpdh.dominio import propuesto_asignado as pa


def _km(p: list[pa.Punto]) -> float | None:
    return 10.0 * len(p)


def test_comparar() -> None:
    v = [{"id": 1, "fecha": "2026-11-02", "hora_salida": "08:00", "hora_regreso": "12:00", "chofer_id": 1, "vehiculo_id": 1, "lat": -34.0, "lng": -58.0},
         {"id": 2, "fecha": "2026-11-02", "hora_salida": "09:00", "hora_regreso": "13:00", "chofer_id": 2, "vehiculo_id": 2, "lat": -34.1, "lng": -58.1},
         {"id": 3, "fecha": "2026-11-03", "hora_salida": "08:00", "hora_regreso": "10:00", "chofer_id": None, "vehiculo_id": None, "lat": None, "lng": None},
         {"id": 4, "fecha": "2026-11-03", "hora_salida": "08:00", "hora_regreso": "10:00", "chofer_id": 1, "vehiculo_id": 1, "lat": -34.0, "lng": -58.0}]
    prop = {1: {"clave": "a", "chofer_id": 1, "vehiculo_id": 1}, 2: {"clave": "a", "chofer_id": 1, "vehiculo_id": 1},
            3: {"clave": "b", "chofer_id": None, "vehiculo_id": 1}}
    r = pa.comparar(v, prop, _km)
    p, a = r["propuesto"], r["asignado"]
    assert (p.salidas, p.km, p.horas, p.sin_cubrir) == (1, 20.0, 5.0, 1)
    assert (a.salidas, a.km, a.horas, a.sin_cubrir) == (2, 20.0, 8.0, 1)
    assert r["comparados"] == 3 and r["sin_propuesta"] == 1 and r["salidas_iguales"] == 0
    assert r["diferencia"] == {"salidas": 1, "km": 0.0, "horas": 3.0, "sin_cubrir": 0}


def test_guardar_y_cuadro(base: Any) -> None:
    import database as db
    from dgpdh.servicios import propuesto_asignado as srv
    lunes = date.today() - timedelta(days=date.today().weekday() + 7)
    with db._conexion() as con:
        cur = con.execute("SELECT id FROM unidades LIMIT 1").fetchone()
        uid = cur[0]
        ids = []
        for h in ("08:00", "09:00"):
            ids.append(con.execute("""INSERT INTO viajes (fecha, hora_salida, hora_regreso, unidad_id, modalidad, estado, circuito, creado_en, actualizado_en)
                                      VALUES (?, ?, '12:00', ?, 'CHOFER', 'SOLICITADO', 'AMBA', 'x', 'x')""", (lunes.isoformat(), h, uid)).lastrowid)
        g = {"fecha": lunes.isoformat(), "clave": f"{ids[0]}-{ids[1]}", "viajes": [{"id": ids[0]}, {"id": ids[1]}],
             "chofer": {"id": 7}, "vehiculo": {"id": 8}}
        assert srv.guardar(con, lunes, [g]) == 2 and srv.guardar(con, lunes, [g]) == 2, "se pisa, no se duplica"
        assert con.execute("SELECT COUNT(*) FROM planificador_propuesto").fetchone()[0] == 2
        r = srv.cuadro(con, lunes)
    assert r["comparados"] == 2 and r["propuesto"].salidas == 1 and r["asignado"].sin_cubrir == 2 and r["cerrada"]
