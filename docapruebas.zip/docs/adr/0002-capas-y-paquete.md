# ADR-0002 — Capas y paquete `dgpdh/`, sin ORM

- **Estado:** aceptada (14/11/2026)
- **Contexto:** las reglas de negocio están dentro de las rutas y 33 módulos abren la base directamente, lo que dificulta probar,
  auditar y pasar a PostgreSQL.
- **Decisión:** capas dominio / persistencia / servicios / ia / integracion / seguridad / web (ver ARCHITECTURE.md).
  Persistencia con `sqlite3` y repositorios con SQL portable (parámetros `?`, sin funciones propias de SQLite en las consultas
  nuevas), no con un ORM.
- **Por qué no un ORM (SQLAlchemy/SQLModel):** suma una dependencia grande y otra forma de escribir consultas cuando ya hay ≈80
  tablas en SQL plano. El beneficio principal, la portabilidad, se logra con repositorios y migraciones propias (ADR-0003). Se
  revisa si se migra a PostgreSQL con muchas consultas nuevas.
- **Consecuencias:** las consultas quedan explícitas y fáciles de auditar; el SQL portable se controla con pruebas contra las dos bases cuando exista el servidor PostgreSQL.
