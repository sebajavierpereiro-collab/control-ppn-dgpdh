# ADR-0008 — Auditoría única encadenada y bajas con registro

- **Estado:** aceptada; primera parte implementada (14/11/2026)
- **Contexto:** la auditoría está repartida en 6 tablas con formatos distintos. La revisión de viajes encontró además DELETE
  sobre datos cargados por personas (participantes, licencias de choferes, ausencias, términos del glosario, modelos de nota,
  alias de equipos, novedades de Personal, precargados de frecuentes), lo que choca con la regla «nada se borra físicamente».
- **Decisión:**
  1. Tabla `auditoria` (migración 0002): fecha, persona, acción, entidad, id, antes y después en JSON, motivo, IP y origen.
     El registro se escribe **en la misma transacción** que el cambio.
  2. **Sellado diferido:** un proceso cada 10 minutos encadena las filas nuevas con SHA-256 (cada hash incluye el anterior).
     Encadenar en el momento de escribir obligaría a leer la última fila dentro de cada transacción y, con WAL, dos escrituras
     simultáneas chocarían. `verificar()` detecta filas editadas o borradas en el medio de la cadena.
  3. **`borrar_con_registro`** reemplaza a los DELETE de datos de personas: la fila completa queda en `auditoria` (acción «Baja»)
     antes de quitarla. El comportamiento de las pantallas no cambia y la información se puede recuperar.
  4. Las 6 tablas históricas se mantienen. Los módulos que pasen a `dgpdh/servicios/` escriben en `auditoria`, y la pantalla de historial lee las dos fuentes.
- **Excepciones conscientes:** índices y datos derivados que se regeneran (búsqueda de texto, entidades de notas, hallazgos
  recalculados, sugerencias pendientes, ingresos pendientes del portal) y la herramienta «Limpiar notas» de Administración, que
  exige un respaldo previo y queda registrada en `ajustes`.
- **Sello con clave y ancla (14/11, revisión de seguridad):**
  - El sello es un HMAC-SHA256 con una clave guardada **fuera de la base** (`datos/clave_auditoria.key`). Sin la clave no se puede recalcular la cadena.
  - Cada sellado agrega el último id y hash a un archivo de solo agregado (`datos/auditoria_ancla.txt`). Así se detecta que se borraron las últimas filas o que se reescribieron y se dejaron «por sellar».
  - Las filas selladas antes de la clave se verifican con SHA-256 simple (línea «LEGADO n» del ancla).
  - La clave y el ancla se copian en cada respaldo (`respaldos/documentos/_auditoria`).
