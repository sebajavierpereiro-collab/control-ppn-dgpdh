# ADR-0004 — IA local con una cola de trabajos persistente única

- **Estado:** aceptada para el hito 5 (14/11/2026)
- **Contexto:** el 12/11 un lote de ≈86 notas quedó días en «aplicando correcciones». Cada corrección corría en su propio hilo,
  competían por Ollama y LanguageTool, y los reinicios las perdían. La v37 lo resolvió con una cola única en memoria que se
  reconstruye al arrancar, pero conviven dos mecanismos (esa cola y `trabajos_ia`).
- **Decisión:** un solo mecanismo, `dgpdh/ia/cola.py`, sobre una tabla de trabajos con estado, prioridad, intentos, inicio, fin y
  error. Un trabajador consume de a un trabajo por recurso (Ollama, LanguageTool), con tiempo máximo y reintento acotado. Un
  único cliente de Ollama tiene timeout y registra el modelo usado. La IA nunca cambia datos: guarda propuestas que una persona acepta o rechaza.
- **Consecuencias:** un reinicio no pierde trabajos y se ve en pantalla qué se está procesando y qué espera. La firma sin corrección de IA (v37) se mantiene como salida manual.
