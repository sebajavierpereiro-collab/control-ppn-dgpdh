# ADR-0003 — Migraciones numeradas propias

- **Estado:** aceptada para el hito 2 (14/11/2026)
- **Contexto:** hoy el esquema se ajusta al arrancar con 43 `ALTER TABLE` dentro de try/except. No queda registro de qué
  versión tiene cada base y un error real se confunde con «la columna ya existía».
- **Opciones:** (a) Alembic; (b) un ejecutor propio: tabla `schema_migrations` y archivos `NNNN_descripcion.sql|py` aplicados en orden, cada uno en una transacción.
- **Decisión:** (b), porque no suma dependencias, funciona igual en SQLite y en PostgreSQL y es suficiente para un equipo chico.
  La migración 0001 «absorbe» el esquema actual: sobre una base existente solo se marca como aplicada.
- **Consecuencias:** cada cambio de esquema es un archivo revisable y probado (base vacía y copia anonimizada). Antes de migrar se hace un respaldo automático, como ya hace `respaldo.py`.
