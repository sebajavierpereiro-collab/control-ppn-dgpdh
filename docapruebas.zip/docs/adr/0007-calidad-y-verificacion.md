# ADR-0007 — Línea de base de calidad: ruff, mypy y pytest

- **Estado:** aceptada (14/11/2026)
- **Contexto:** 0 de ≈1.600 funciones tienen tipos; ruff marcaba 248 avisos; las pruebas son 39 scripts sueltos con un sustituto propio de FastAPI.
- **Decisión:**
  - ruff (reglas F, E9 y B) con **línea de base**: `herramientas/verificar.py` falla solo si aparecen avisos nuevos. El código histórico se limpia al pasar a `dgpdh/`, no de golpe.
  - mypy **estricto solo en `dgpdh/`**.
  - pytest como punto único: `pruebas/test_scripts.py` corre cada script histórico en su propio proceso, en paralelo. Las pruebas nuevas son pytest normales.
  - Python mínimo 3.12: `rutas_circuito.py` usa f-strings con barra invertida, una sintaxis de 3.12. `linux/verificar_servidor.py` lo controla.
- **Consecuencias:** se puede exigir «sin avisos nuevos» desde ya, sin un cambio masivo que arriesgue el comportamiento.
