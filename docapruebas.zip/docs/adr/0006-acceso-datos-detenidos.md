# ADR-0006 — Quién accede a los datos de personas detenidas

- **Estado:** aceptada (14/11/2026). Decisión del usuario: «los ven las personas que están habilitadas al sistema de gestión de notas».
- **Regla:** ver y cargar: toda persona con el sistema de Notas habilitado, salvo el rol Chofer (`detenidos.puede_ver`).
  Administrar (bajas, importación, exportación, anulación de cargas): Dirección y Mesa de Entradas (`puede_administrar`).
  Mantenimiento de la base (revisión con IA, decisiones sobre duplicados): permiso individual «Mantenimiento de bases» (`puede_mantener`).
- **Ya implementado así** en v37. En el hito 3 pasa a la matriz única de permisos, con pruebas por rol, y cada consulta de una ficha queda registrada (quién vio a quién y cuándo).
- **Pendiente de definir más adelante:** plazo de conservación de los listados originales y de los datos de personas egresadas.
