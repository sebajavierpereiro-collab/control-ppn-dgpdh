# ADR-0005 — Integración futura con ppn-sso, ppn-mesa-entradas y ppn-storage

- **Estado:** aceptada (14/11/2026). Decisión del usuario: la integración es a futuro; el sistema solo tiene que quedar preparado.
- **Contexto:** el organismo usa ppn-sso (portal e ingreso único), ppn-mesa-entradas y ppn-storage. Ya existen `sso.py`,
  `mesa_entradas.py` y `almacen_ppn.py`, desactivados. La regla es que nada salga del sistema automáticamente.
- **Decisión:** en `dgpdh/integracion/`, un **puerto** (interfaz tipada) por sistema externo y un **adaptador** real
  deshabilitado por defecto en config.ini, más un adaptador simulado para las pruebas. Todo envío hacia afuera pasa por una
  **bandeja de salida**: el sistema arma el mensaje (por ejemplo «nota firmada N°… para el expediente…»), que queda pendiente hasta que
  una persona habilitada lo aprueba. Recién ahí se envía, y queda auditado. Las lecturas (consultar un expediente, validar
  identidad con ppn-sso) no pasan por la bandeja, pero también se registran.
- **Por qué la bandeja con aprobación:** respeta «nada sale solo». Si en el futuro se quisiera el envío automático, es un cambio de configuración por tipo de mensaje, con su propio ADR.
- **Consecuencias:** las funciones de negocio no conocen los sistemas externos, solo los puertos, y se pueden probar sin red.
