# ADR-0001 — Migración gradual (estrangulamiento), sin reescritura

- **Estado:** aceptada (14/11/2026)
- **Contexto:** el sistema está en uso diario (≈70 personas en Notas y ≈200 en Autos PPN) y se muda a un servidor Ubuntu. Hay
  deuda técnica: `main.py` con ≈5.700 líneas, SQL fuera de la capa de datos y 21 importaciones circulares directas.
- **Opciones:** (a) reescribir en un proyecto nuevo y cambiar todo de una vez; (b) migrar módulo por módulo dentro del mismo proyecto.
- **Decisión:** (b). Cada módulo pasa a `dgpdh/` con pruebas de caracterización previas. El módulo viejo queda como
  reexportación mientras haga falta, y cada paso se entrega como una versión que se instala con «genera nueva versión».
- **Consecuencias:** durante un tiempo conviven las dos estructuras. A cambio, nunca hay una versión a medio hacer en producción
  y cada paso se puede revertir copiando los archivos anteriores.
