# ADR-0010 — Registro de Obstaculizaciones

- **Estado:** aceptada (14/11/2026). Es el primer módulo hecho entero en `dgpdh/`: dominio, servicio, migración 0004 y router `rutas_obstaculizaciones.py`.
- **Qué hace:** carga, sistematización y consulta de los hechos que obstaculizan tareas en territorio. Cada carga genera un informe, que va a la firma ya clasificado como «Informe de obstaculización» y se protocoliza al firmar (ADR-0009). Las gestiones posteriores las hacen otras áreas.
- **Visibilidad:**
  - Agente: lo propio y aquello en lo que figura como interviniente.
  - Coordinación: su equipo y las unidades de los viajes frecuentes activos de su equipo.
  - Dirección: todo.
  - Permiso individual «Consulta de obstaculizaciones»: todo, solo lectura.
  - Choferes y personas sin Notas: nunca, aunque tengan el permiso.
- **Modificar** (editar y adjuntar): el autor durante 72 h; la coordinación del equipo; la Dirección. En todos los casos, solo mientras no haya informe.
- **Anular:** las mismas personas que pueden modificar, con motivo. La Dirección puede anular también después del informe.
- **Equipo del registro:** quien no es de la Dirección registra solo para su propio equipo.
- **Evidencia:** los adjuntos se guardan sin modificar, con su SHA-256 (PDF, imágenes, Word, audio). Se suben hasta 10 por envío y nunca más del máximo configurado en memoria. Se incluyen en el respaldo (`datos/obstaculizaciones`).
- **Exportaciones** (CSV, Excel y PDF): cada persona exporta solo lo que ve. Los textos que empiezan con `= + - @` se neutralizan para que no se ejecuten como fórmulas al abrirlos en Excel.
- **Un solo informe por hecho:** el registro se reserva con una transacción inmediata.
- **Revisión independiente (14/11):** los 15 hallazgos de la revisión de seguridad se corrigieron (3 altos, 6 medios y bajos) y las pruebas de ataque ya no los reproducen. Quedan como mejora la IP en cada registro de auditoría y la visibilidad propia de los viajes.
