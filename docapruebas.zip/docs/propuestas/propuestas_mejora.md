# Propuestas de mejora de dgpdh_web

164 propuestas en tres áreas, armadas a partir de proyectos abiertos y guías públicas: gestión documental, IA local, vinculación de datos, flota y ruteo, monitoreo de lugares de detención (APT), Poncho, GOV.UK, WCAG 2.2 y lenguaje claro (ANDIS).
Todas respetan las reglas del sistema: IA solo local, nada sale solo al exterior, la IA propone y decide una persona, no se borra nada.

**Cómo elegir:** respondé con los números, por ejemplo «sí 1, 5, 98; no 12; después 140», como en la devolución de reformas anterior.

Esfuerzo: **S** = menos de un día · **M** = de 1 a 3 días · **L** = más de 3 días.

## Recomendadas para la primera tanda

**Soberanía y fallas silenciosas (arreglar ya)**

- **98.** htmx siempre local, sin respaldo en CDN (alto, S)
- **99.** Prueba automática de «cero recursos remotos» (alto, S)
- **20.** Ventana de contexto explícita (num_ctx) y control del tamaño del pedido (alto, S)
- **22.** Elegir el modelo por cómo anda en español (hoy config.ini usa phi3:mini) (alto, S)
- **13.** Índice de legibilidad con fórmula para español (medio, S)
- **33.** Deshacer una unificación de fichas (alto, M)
- **69.** Calendario único de feriados y días no laborables (alto, S)

**IA local más confiable**

- **19.** Respuestas con esquema JSON validado (alto, S)
- **26.** Validar contra el texto también los resúmenes y proveídos (alto, S)
- **16.** Usar los rechazos de párrafo para apagar reglas que molestan (alto, S)
- **4.** OCR local para PDF escaneados (alto, S)

**Personas detenidas: duplicados mejor detectados**

- **29.** Pesar los nombres según qué tan comunes son (alto, S)
- **32.** Clave fonética para apellidos en español (alto, S)

**Autos PPN y metas**

- **72.** «Llegué / salí» por parada, con un toque (alto, S)
- **73.** Doble confirmación de que el viaje se hizo (alto, S)
- **79.** Demora para ingresar a la unidad como indicador de obstáculos al monitoreo (alto, S)
- **82.** Una sola meta de visitas por equipo (alto, S)
- **83.** Proyección al cierre y lo que falta por mes (alto, S)
- **84.** Aviso interno cuando una meta pasa a «atrasada» (alto, S)
- **89.** Indicadores de calidad de la visita, no solo de cantidad (alto, S)
- **91.** Completitud de la carga de metas (alto, S)

**Interfaz: rápidas de alto impacto**

- **116.** Los avisos de error no se borran solos (alto, S)
- **125.** Filtros aplicados como chips removibles (alto, S)
- **136.** Confirmar solo lo irreversible, con botones que digan qué hacen (alto, S)
- **137.** Lenguaje claro en la interfaz: glosario y sin códigos internos (alto, S)
- **138.** Errores del servidor que explican qué hacer (alto, S)
- **141.** Que el foco nunca quede tapado por barras fijas (alto, S)
- **142.** Tamaño mínimo de lo que se toca (alto, S)
- **143.** Atajos de una tecla que se pueden apagar (alto, S)
- **110.** Bandeja ordenada por urgencia real, con cortes visibles (alto, S)

**Interfaz: bandejas de trabajo**

- **102.** Inicio como bandeja única «qué tengo que hacer hoy» (alto, M)
- **107.** Firma en serie con progreso, «saltear» y resumen final (alto, M)
- **108.** Vista dividida: lista a la izquierda, documento a la derecha (alto, M)
- **113.** Mesa de Entradas: cada bloque como lista de tareas (alto, M)
- **114.** Aprobación por lote para Coordinación (medio, M)

**Interfaz: formularios, choferes y búsqueda**

- **115.** Resumen de errores arriba y error junto a cada campo (alto, M)
- **118.** «Solicitar viaje» en pasos, con revisión antes de enviar (alto, M)
- **120.** Autocompletar accesible para unidades, personas y agentes (alto, M)
- **122.** Protección contra pérdida de cambios y «Guardado hace 1 min» (alto, M)
- **148.** «Mis salidas» pensada primero para el celular (alto, M)
- **149.** Barra inferior en el celular para los choferes (medio, S)
- **134.** Paleta de comandos con Ctrl+K y «/» (alto, M)

**Hallazgos de la revisión que ya se están atendiendo**

- **htmx desde internet:** en la PC falta `static/htmx.min.js`, así que cada página pide htmx a cdnjs.cloudflare.com (propuesta 98). No se puede bajar desde acá: hay que guardarlo una vez a mano. Después se quita la alternativa por internet y se agrega la prueba de «cero recursos remotos» (propuesta 99).
- **Borrados físicos en Autos PPN, ausencias, glosario y modelos** (propuesta 80): ya preparado. Cada fila queda completa en la auditoría antes de quitarla.
- **La meta de visitas por equipo está en dos tablas** (propuesta 82): un equipo puede figurar cumplido en un tablero y atrasado en el otro.
- **Legibilidad con fórmula para inglés y modelo de IA chico entrenado en inglés** (propuestas 13 y 22).

## Notas, IA local y personas detenidas


### A. Módulo de notas: circuito y gestión documental

**1. Metadatos propios por tipo documental** · impacto alto · esfuerzo M
Hoy: `tipos_documentales.py` ya clasifica en 13 tipos (Oficio, Pedido de informe, Nota a persona detenida…), pero todas las notas tienen los mismos campos fijos.
Propuesta: definir, por tipo documental, una lista corta de campos (texto, fecha, número, vínculo a persona detenida, vínculo a unidad, vínculo a otra nota).

**2. Reglas «si pasa esto, proponé aquello», editables por la Dirección** · impacto medio · esfuerzo M
Hoy: las reglas de clasificación y prerrevisión están en el código (`agentes.py`, `analisis.prioridad_por_palabras`) o en `datos/temas.json`.
Propuesta: pantalla de reglas con disparador (al subir, al enviar a Coordinación, al firmar), condición (texto contiene, tipo documental, unidad, equipo) y acción propuesta (prioridad, equipo, etiqueta, plazo, aviso).

**3. Vínculos con tipo entre documentos** · impacto medio · esfuerzo M
Hoy: hoy hay bloques, versiones, respuestas cargadas, reiteraciones sugeridas y la carpeta del caso (`/caso`), pero cada relación vive en una tabla distinta.
Propuesta: una tabla `vinculos_documentos(origen, destino, tipo, quien, fecha)` con tipos fijos: responde a, reitera a, amplía, anexo de, reemplaza a.

**4. OCR local para PDF escaneados** · impacto alto · esfuerzo S
Hoy: los PDF archivados se indexan con `pypdf` solo si traen texto (README, «Archivo directo de PDF»).
Propuesta: pasar los PDF sin texto por OCRmyPDF con Tesseract en español, en la cola nocturna.

**5. Plan de retención sin borrado físico** · impacto medio · esfuerzo M
Hoy: el README dice que la retención es una «decisión pendiente de la institución».
Propuesta: cargar una tabla de series documentales (tipo, plazo de guarda, destino final: conservación permanente o «en condiciones de baja»).

**6. Paquete de archivo por expediente o por año** · impacto medio · esfuerzo S
Hoy: ya hay PDF/A por nota (`[archivo] pdfa_en_despacho`) y respaldos, pero no hay una entrega ordenada a Archivo con un inventario verificable.
Propuesta: «Exportar paquete de archivo»: una carpeta o un .zip por expediente o por año con los PDF/A firmados, un manifiesto con la huella SHA-256 de cada archivo (las de `integridad.py`), el historial de estados en CSV y los metadatos.

**7. Conversión de Word con LibreOffice siempre abierto (para Ubuntu)** · impacto medio · esfuerzo S
Hoy: en Linux no hay Word.
Propuesta: dejar un servicio unoserver corriendo (systemd, solo en 127.0.0.1) y convertir con `unoconvert`.

**8. Plantillas con condiciones y tablas** · impacto medio · esfuerzo S
Hoy: las plantillas con campos (`«Campo»` o `[[Campo]]`, ola 3, #61) solo reemplazan texto.
Propuesta: sumar plantillas docxtpl (Jinja dentro del Word), con `{% if %}` y tablas que se repiten.

**9. Asistente de redacción en pasos (entrevista guiada)** · impacto alto · esfuerzo L
Hoy: «Completar y usar» pide los campos de corrido.
Propuesta: un formulario en pasos por tipo de pedido (¿a quién va?, ¿qué persona detenida?, se elige de la base, ¿qué se pide?, ¿hay plazo?), que arma el borrador con la plantilla del #8 y valida contra la base de personas y el catálogo de unidades.

**10. Correcciones exportadas como control de cambios de Word** · impacto medio · esfuerzo M
Hoy: el control de cambios se ve en la web (`control_cambios.py`, verde y rojo), pero el .docx procesado que descarga el asesor trae el texto ya cambiado.
Propuesta: botón «Descargar con control de cambios»: genera una copia con marcas reales de Word (`w:ins`/`w:del`) con autor «Corrección automática» o el nombre de quien decidió.

**11. Búsqueda en español con raíces de palabras (al pasar a PostgreSQL)** · impacto medio · esfuerzo S
Hoy: `notas_fts` usa FTS5 con `unicode61 remove_diacritics 2` (`database.py`).
Propuesta: en la migración a PostgreSQL (ya planeada, #98) usar `tsvector` con la configuración `spanish` y el diccionario `unaccent`.


### B. Corrección y redacción en español

**12. LanguageTool como servicio local fijo** · impacto medio · esfuerzo S
Hoy: `nucleo.inicializar_languagetool()` levanta LanguageTool dentro del proceso con `language_tool_python`.
Propuesta: correr el servidor HTTP de LanguageTool como servicio propio (systemd, versión fija, solo `127.0.0.1:8081`, sin `--public`) y que la app lo consulte por HTTP.

**13. Índice de legibilidad con fórmula para español** · impacto medio · esfuerzo S
Hoy: `nucleo.calcular_legibilidad()` usa la fórmula de Flesch para inglés (206,835 − 1,015 × palabras por oración − 84,6 × sílabas por palabra).
Propuesta: reemplazarla por Fernández-Huerta o Szigriszt-Pazos (escala INFLESZ), que están adaptadas al español, y mostrar la interpretación en palabras («algo difícil», «normal»).

**14. Control de lenguaje claro según la guía del Estado** · impacto alto · esfuerzo M
Hoy: `evaluar_claridad()` solo marca oraciones de más de 35 palabras y el promedio.
Propuesta: un control «Lenguaje claro» por reglas (largo de oración y de párrafo, pasivas con «se + participio» y «fue + participio», dobles negaciones, tecnicismos de un glosario con su alternativa común).

**15. Diccionario Hunspell es_AR en vez de pyspellchecker** · impacto medio · esfuerzo S
Hoy: `evaluar_ortografia()` usa `pyspellchecker`, que trabaja con una lista de frecuencias de español general sin flexiones ni variante argentina.
Propuesta: usar el diccionario es_AR del proyecto RLA-ES (el mismo de LibreOffice) con un diccionario personal institucional que se arma solo con los términos de `referencia_ia.terminos_institucionales()` y el glosario.

**16. Usar los rechazos de párrafo para apagar reglas que molestan** · impacto alto · esfuerzo S
Hoy: `aprendizaje.py` solo mira las modificaciones del Director.
Propuesta: al rechazar un cambio, ofrecer un motivo opcional de un clic (cambió el sentido, nombre propio, fórmula institucional, no era un error).

**17. Perfil de corrección por tipo documental** · impacto medio · esfuerzo S
Hoy: la corrección (`generar_propuesta_parrafo`) es la misma para un oficio judicial que para una nota a una persona detenida.
Propuesta: un perfil por tipo documental: qué reglas se aplican, umbrales de claridad (#14), si se proponen reformulaciones y qué fórmulas están protegidas.

**18. Ejemplos elegidos por parecido para la IA (few-shot)** · impacto medio · esfuerzo M
Hoy: la etapa 7 del plan (few-shot con ejemplos reales) sigue pendiente.
Propuesta: guardar pares «original → texto final aprobado por el Director» y, para cada párrafo nuevo, darle a la IA los 2 o 3 pares más parecidos (buscados como en el #24).


### C. IA local (Ollama)

**19. Respuestas con esquema JSON validado** · impacto alto · esfuerzo S
Hoy: `consultar_ollama(..., formato_json=True)` manda `"format": "json"`.
Propuesta: pasar en `format` el esquema (con `enum` para veredicto o prioridad, rangos para confianza) generado con Pydantic, y validar la respuesta con el mismo modelo.

**20. Ventana de contexto explícita (num_ctx) y control del tamaño del pedido** · impacto alto · esfuerzo S
Hoy: `consultar_ollama` no fija `num_ctx`, así que Ollama usa su valor por defecto de 4096 tokens.
Propuesta: calcular el tamaño aproximado en tokens antes de llamar, fijar `num_ctx` por proceso en `config.ini` (por ejemplo 8192 para consistencia y redacción) y registrar en `ia_registro` cuando el pedido supera el 90% del contexto.

**21. Menos cambios de modelo en memoria** · impacto medio · esfuerzo S
Hoy: hay un modelo por proceso (`modelo_correccion`, `modelo_clasificacion`, `modelo_consistencia`, `modelo_redaccion`, `revision_detenidos`).
Propuesta: ordenar la cola nocturna por modelo (todos los trabajos de un modelo seguidos), usar `keep_alive` largo dentro de la ventana nocturna y 0 en horario de oficina, y fijar en el servidor `OLLAMA_MAX_LOADED_MODELS=1` y `OLLAMA_NUM_PARALLEL=1`.

**22. Elegir el modelo por cómo anda en español (hoy config.ini usa phi3:mini)** · impacto alto · esfuerzo S
Hoy: el `config.ini` de la PC tiene `modelo = phi3:mini`, mientras el README y `nucleo.OLLAMA_MODEL` hablan de `qwen2.5:7b` y recomiendan 8B o más para redacción.
Propuesta: decidir con el examen del #23 entre candidatos que se ejecutan en Ollama, por ejemplo qwen2.5:7b y Salamandra 7B Instruct (del Barcelona Supercomputing Center, Apache-2.0, ajustado sobre todo para español), con versiones GGUF.

**23. Examen propio de los modelos antes de cambiarlos** · impacto alto · esfuerzo M
Hoy: el tablero por modelo (Administración → IA → Calidad) mide la aceptación después de usarlo con notas reales, y los tests usan respuestas simuladas.
Propuesta: un conjunto fijo y anonimizado (ver #43): unos 100 párrafos con su corrección esperada, 30 pares de documentos con contradicciones conocidas, 50 pares de fichas ya decididas y 20 intentos de instrucciones escondidas.

**24. Búsqueda por significado con embeddings locales** · impacto medio · esfuerzo M
Hoy: `referencia_ia.parecidos()` usa TF-IDF con similitud coseno, escrito a mano, y en memoria.
Propuesta: calcular embeddings con un modelo multilingüe servido por Ollama (`/api/embed`) y guardarlos en sqlite-vec mientras siga SQLite, o en pgvector después de migrar.

**25. Antecedentes con citas verificadas (RAG local)** · impacto medio · esfuerzo L
Hoy: «Consultar» (#14 de la ola 5) pasa la pregunta a filtros y cuenta.
Propuesta: un modo «Buscar antecedentes»: recupera los fragmentos más parecidos (#24) de lo firmado que la persona puede ver y la IA redacta 3 o 4 líneas, cada una con su cita literal.

**26. Validar contra el texto también los resúmenes y proveídos** · impacto alto · esfuerzo S
Hoy: las mejoras desde el informe y los hallazgos de consistencia se validan contra el texto (citas literales, números).
Propuesta: aplicar a resumen y proveído el mismo filtro contra invenciones: cada número, fecha, DNI, LPU y nombre propio de la salida tiene que estar en el texto fuente.

**27. Registrar la versión exacta del modelo y del prompt** · impacto medio · esfuerzo S
Hoy: `ia_registro` guarda el nombre del modelo (`qwen2.5:7b`), la huella del pedido y la salida recortada.
Propuesta: guardar en cada llamada el *digest* del modelo (lo informa Ollama al listar modelos), un identificador de versión del prompt (huella del template) y los parámetros (`temperature`, `num_ctx`).

**28. llama.cpp como motor de respaldo en el servidor** · impacto bajo · esfuerzo M
Hoy: toda la IA depende de Ollama.
Propuesta: dejar documentado y probado `llama-server` (llama.cpp) con los mismos GGUF, solo en localhost, como alternativa configurable en `[ollama] url`.


### D. Base de personas detenidas: calidad y vinculación

**29. Pesar los nombres según qué tan comunes son** · impacto alto · esfuerzo S
Hoy: `revision_ia.comparar()` suma +55 por «mismo nombre» sin importar si es «Juan Carlos González» (muy repetido en una población penitenciaria) o un nombre raro.
Propuesta: contar la frecuencia de cada apellido y nombre en la base y ajustar los puntos: menos puntos para coincidencias muy comunes y más para las raras.

**30. Calibrar el puntaje con las decisiones ya tomadas** · impacto alto · esfuerzo M
Hoy: los puntos de `comparar()` (+30 DNI parecido, −35 DNI distinto, +15 misma fecha…) y el `UMBRAL = 55` están puestos a ojo.
Propuesta: usar esas decisiones para estimar cuánto pesa de verdad cada coincidencia (modelo Fellegi-Sunter) y recalcular los puntos y el umbral cada tanto, mostrando el antes y el después.

**31. Mostrar grupos de fichas, no solo pares** · impacto medio · esfuerzo M
Hoy: la revisión trabaja de a pares.
Propuesta: agrupar los pares que superan el umbral en «posibles grupos de la misma persona» (componentes conectados) y mostrarlos juntos, con una ficha sugerida a conservar y la opción de sacar a alguien del grupo.

**32. Clave fonética para apellidos en español** · impacto alto · esfuerzo S
Hoy: la comparación de nombres usa `difflib.SequenceMatcher` sobre las palabras ordenadas.
Propuesta: una clave fonética propia para español (b=v, c/s/z, ll=y, g=j delante de e/i, h muda, qu=k) como clave de bloqueo adicional en `candidatos()` y como señal en `comparar()` («apellido que suena igual»).

**33. Deshacer una unificación de fichas** · impacto alto · esfuerzo M
Hoy: al unificar, una ficha queda de baja como «Unificada con #…» y su historial pasa a la otra (`detenidos.py`, `aplicar_importacion`).
Propuesta: «Separar fichas» desde el historial de la ficha conservada: reactiva la ficha unificada, devuelve los campos y vínculos que vinieron de ella (los cambios ya se registran campo por campo en `detenidos_cambios`) y marca el par como «distintas» para que no se vue…

**34. RapidFuzz en lugar de difflib** · impacto medio · esfuerzo S
Hoy: `difflib` se usa para comparar nombres en `revision_ia`, `detenidos`, `unidades_menu`, `traslados` e `importar_viajes`.
Propuesta: usar RapidFuzz (C++, MIT, con wheels para Windows y Linux;

**35. Más tolerancias en fechas de nacimiento** · impacto bajo · esfuerzo S
Hoy: `revision_ia._fechas()` reconoce fecha igual, día y mes invertidos y un año de diferencia.
Propuesta: sumar esos casos a la comparación y marcar como «fecha dudosa» las fechas de relleno, para que no sumen ni resten puntos.

**36. Reglas de cada listado escritas como esquema** · impacto medio · esfuerzo M
Hoy: las validaciones de la importación están repartidas en `validar()`, `previa()` e `inconsistencias()` de `detenidos.py`, que ya tiene unas 2000 líneas.
Propuesta: declarar por fuerza un esquema (columnas esperadas, tipo, rangos, valores permitidos como el catálogo de situación procesal, obligatorias) y correrlo con validación completa (`lazy`), que junta todos los errores con fila y columna.

**37. Comparar cada listado con el anterior de la misma fuerza** · impacto alto · esfuerzo M
Hoy: la vista previa muestra altas, actualizaciones y errores del listado nuevo, pero no si el listado en sí es raro.
Propuesta: antes de confirmar, un control de lo esperable contra el listado anterior de esa fuerza: cantidad de personas por unidad (alerta si una unidad baja más del 30%), porcentaje sin DNI, columnas que desaparecieron, fecha del listado anterior a la última cargada.

**38. Historial de alojamiento por persona** · impacto alto · esfuerzo M
Hoy: el alojamiento (unidad, módulo, pabellón) es un campo de la ficha.
Propuesta: armar, a partir de `detenidos_cambios` y `detenidos_listados`, una tabla de tramos (persona, unidad, desde, hasta, listado de origen).

**39. Vincular la nota con la ficha y que lo confirme una persona** · impacto alto · esfuerzo M
Hoy: `detenidos.notas_relacionadas()` busca en cada consulta las notas por DNI o «por todas las palabras del nombre».
Propuesta: en la prerrevisión, detectar a las personas de la nota (DNI y LPU por expresión regular, nombres con un modelo de entidades en español), proponer la ficha con su puntaje (#29, #32) y guardar el vínculo `nota_persona` cuando una persona lo confirma.

**40. Controlar CUIL y formato de documentos** · impacto bajo · esfuerzo S
Hoy: el DNI se valida por largo (6 a 9 números) y el documento extranjero se clasifica (`detenidos.clasificar_documento`).
Propuesta: reconocer CUIL o CUIT (11 dígitos con prefijo 20/23/24/27), validar el dígito verificador (módulo 11), extraer el DNI y avisar si no coincide con el de la ficha.

**41. Ordenar la revisión por lo que más conviene decidir** · impacto medio · esfuerzo S
Hoy: las propuestas de posibles duplicados se ordenan por puntaje.
Propuesta: una pestaña «para decidir primero»: pares de fichas activas, cerca del umbral y donde reglas e IA no coinciden.

**42. Tablero de calidad por fuerza** · impacto medio · esfuerzo S
Hoy: el informe de inconsistencias (`reporte_inconsistencias`) se arma por listado.
Propuesta: un tablero por fuerza y por trimestre: porcentaje de filas con problemas por tipo (sin DNI, documento cruzado, lugar fuera de catálogo, repetidas), tendencia, y un anexo exportable para acompañar las devoluciones institucionales.


### E. Protección de datos y anonimización (Ley 25.326)

**43. Copias anonimizadas para pruebas, capacitación y el examen de la IA** · impacto alto · esfuerzo M
Hoy: los videos de ayuda se grabaron «con datos de prueba» y existe «Borrar notas de prueba», pero no hay una herramienta para obtener material realista sin datos de personas.
Propuesta: un comando que genere copias anonimizadas de notas y fichas: nombres → «[PERSONA_1]» de forma consistente en todo el documento, DNI/LPU/expediente → valores ficticios con el mismo formato, unidades y juzgados se conservan o se generalizan según el uso.

**44. Versión testada de un documento para compartir** · impacto medio · esfuerzo M
Hoy: cuando una nota o un informe se tiene que compartir con terceros, hay que tachar datos a mano fuera del sistema.
Propuesta: «Preparar versión testada»: propone qué tachar (nombres, DNI, LPU, datos de salud) con el mismo motor del #43, la persona acepta o corrige cada tachado y se genera una copia PDF con los datos tapados de verdad, no con un rectángulo encima.

**45. Clasificar la sensibilidad de campos y documentos** · impacto alto · esfuerzo M
Hoy: la base es de datos especialmente protegidos: situación procesal, salud y señales como autolesiones (que ya detecta `agentes.tipo_por_contenido`).
Propuesta: marcar los campos sensibles (situación procesal, observaciones de salud) y los documentos con datos de salud.

**46. Exportaciones y API con datos mínimos y motivo** · impacto medio · esfuerzo S
Hoy: Dirección y Mesa pueden exportar la lista completa a Excel o CSV, y `/api/detenidos` devuelve la ficha completa a quien tenga el `api_token`.
Propuesta: perfiles de exportación (mínima: nombre, DNI, unidad;

**47. Datos mínimos en lo que se manda a la IA y en su registro** · impacto bajo · esfuerzo S
Hoy: `revision_ia._ficha_para_ia` manda la ficha a la IA local, y `ia_registro.salida` guarda hasta 2000 caracteres de lo que devolvió, que puede incluir nombres y DNI.
Propuesta: mandar solo los campos que se comparan y guardar en `ia_registro` la salida con los documentos parcialmente tapados (por ejemplo `30.xxx.x45`).


### F. Firma digital y trazabilidad

**48. Firma PAdES del PDF despachado** · impacto alto · esfuerzo L — *condicionada: acordar con Legales*
Hoy: la «firma» es una imagen insertada en el .docx (`nucleo.insertar_firma`), con PIN y huellas SHA-256 como resguardo.
Propuesta: firmar el PDF final con pyHanko (PAdES), en el servidor o en la PC de quien firma, con el certificado del Director en token (PKCS#11) o, como paso intermedio, con un certificado interno del organismo (firma electrónica).

**49. Sello de tiempo interno (RFC 3161)** · impacto medio · esfuerzo M
Hoy: las fechas de firma y despacho salen del reloj del servidor.
Propuesta: levantar una autoridad de sellado de tiempo interna (uts-server, en la red del organismo) y sellar la huella de cada firmado y despachado, y cada día la huella del registro de auditoría (#50).

**50. Registro de auditoría encadenado** · impacto alto · esfuerzo M
Hoy: los traslados tienen triggers de SQLite que impiden modificar o borrar la auditoría (`database.py`, `traslados_auditoria_*`).
Propuesta: extender los triggers «solo agregar» a esas tablas y sumar una huella encadenada (cada fila incluye la huella de la anterior).

**51. Código QR de verificación en el despachado** · impacto medio · esfuerzo S
Hoy: quien recibe el PDF (o Mesa, cuando consulta una unidad) no tiene forma rápida de comprobar que es el mismo que salió.
Propuesta: estampar en la copia de despacho un QR con número de nota y huella corta, que lleve a una página interna de verificación (compara contra `sha256` guardado).

**52. Validar firmas de los PDF que se reciben** · impacto medio · esfuerzo M
Hoy: las respuestas de organismos que usan GDE llegan como PDF firmados digitalmente, pero «Cargar una respuesta» los guarda sin mirar la firma.
Propuesta: al cargar una respuesta en PDF, validar localmente la firma con pyHanko contra los certificados raíz oficiales cargados a mano en el servidor, y mostrar «firmado por… / íntegro / no se verificó revocación (sin conexión)».

**53. Reconocer números GDE como referencia externa** · impacto medio · esfuerzo S
Hoy: el expediente propio sigue el formato de ppn-mesa-entradas (`EP 1234/2025`) y la extracción de entidades busca ese formato.
Propuesta: reconocer los formatos GDE en el texto, guardarlos como «referencia externa» de la nota y usarlos para proponer vínculos con el #3 (por ejemplo, «responde a NO-2025-…»).

## Viajes, flota y metas


### A. VIAJES, PLANIFICACIÓN Y FLOTA

**54. Tiempos y distancias por calle (OSRM local, opcional)** · impacto alto · esfuerzo M
Hoy: el planificador (`operacion._distancia_km`, `_cerca`, `RADIO_KM_AGRUPAR = 25`) agrupa por distancia en línea recta.
Propuesta: guardar una tabla `unidades_distancias (origen, destino, km, minutos, fuente, calculado_en)` y calcularla con un OSRM instalado en el mismo servidor, a partir de un recorte de OpenStreetMap de Argentina (servicio *table*).

**55. Orden sugerido de las paradas de un desplazamiento** · impacto medio · esfuerzo S
Hoy: `operacion._ordenar_paradas` ordena las paradas por `hora_salida` y, si no hay hora, por id.
Propuesta: botón «Sugerir orden» en `traslados_desplazamiento.html`.

**56. Planificador con ventanas horarias y capacidad (VRPTW)** · impacto alto · esfuerzo L
Hoy: `operacion.planificar` junta pedidos del mismo día por cercanía y plazas, pero no controla si el recorrido entra en el horario de ingreso de cada unidad ni en la jornada del chofer (`MAX_HORAS_DIA` se controla después, c…
Propuesta: un modo «Propuesta optimizada» que arma las salidas con estas restricciones: plazas del vehículo, ventana horaria de cada unidad (propuesta 4), tiempo de permanencia estimado (mediana histórica, como hace `estimar_regreso`) y jornada máxima del chofer.

**57. Horarios de ingreso de cada unidad en formato estructurado** · impacto alto · esfuerzo M
Hoy: `unidades.horarios_visita` es texto libre.
Propuesta: tabla `unidad_ventanas (unidad_id, dia_semana, desde, hasta, tipo [audiencias | visita general | profesionales], vigente_desde, observacion)`.

**58. Requisitos de vehículo y chofer («habilidades»)** · impacto medio · esfuerzo S
Hoy: el chofer sugerido (`operacion.ranking_choferes`) mira si está libre, si tiene licencia y cuántas salidas hizo en la semana.
Propuesta: etiquetas simples (`requisitos` en el viaje, `habilidades` en vehículo y chofer): ruta larga, 7 plazas, licencia D1, habilitado en Complejo X… El sugeridor descarta lo que no cumple y explica por qué.

**59. Descanso mínimo entre jornadas del chofer** · impacto medio · esfuerzo S
Hoy: las anomalías controlan más de 10 horas en el día, más de 2 salidas por día y más de 8 por semana, pero no las horas de descanso entre el regreso de un día y la salida del siguiente.
Propuesta: agregar a `operacion.anomalias` y a `ranking_choferes` la regla «menos de N horas entre regreso real (o estimado) y la próxima salida».

**60. Control del vehículo antes de salir (checklist)** · impacto alto · esfuerzo M
Hoy: la hoja de ruta tiene lugar para km, combustible, novedades y firma, pero no hay un control previo sistemático (luces, cubiertas, matafuego, balizas, documentación).
Propuesta: checklist corto y configurable en la pantalla del chofer («Mis salidas») o impreso en la hoja de ruta: ítem OK / con observación.

**61. Control de consistencia del odómetro** · impacto medio · esfuerzo S
Hoy: `flota.actualizar_km` y el cierre de salida actualizan el km.
Propuesta: al cerrar una salida, avisar (sin bloquear) si `km_regreso < km_salida`, si `km_salida` es menor que el último km del vehículo o si los km recorridos se apartan más de un X % de la distancia estimada (propuesta 1).

**62. Costo por viaje a la unidad y por equipo** · impacto medio · esfuerzo M
Hoy: `operacion.consumo` suma km, litros, km por litro e importe por vehículo.
Propuesta: prorratear el importe del desplazamiento entre sus paradas (por km o en partes iguales) y entre los equipos de cada parada.

**63. Rendimiento de combustible con alerta de desvío** · impacto medio · esfuerzo S
Hoy: se calcula km por litro, pero no se avisa si una carga se aparta del rendimiento habitual del vehículo (error de carga, problema mecánico o uso indebido).
Propuesta: para cada vehículo, la mediana de km/l de las últimas 10 cargas.

**64. Contratos, seguros y proveedores con responsable y aviso configurable** · impacto medio · esfuerzo M
Hoy: `flota.AVISO_DIAS = 30` y `AVISO_KM = 1000` son fijos para todos los controles.
Propuesta: tabla `proveedores` (con baja lógica) y, en cada control, el proveedor, la póliza o el número de orden y un responsable.

**65. Órdenes de trabajo de taller** · impacto medio · esfuerzo M
Hoy: la novedad mecánica tiene estados (cargada → reportada → reparación solicitada → en reparación → reparada).
Propuesta: «Orden de trabajo» vinculada a una o varias novedades, con etapas Nueva / En curso / Hecha / Cancelada, importe y taller.

**66. Disponibilidad de la flota (días fuera de servicio)** · impacto medio · esfuerzo S
Hoy: el panel de flota muestra el estado de hoy, pero no cuántos días por mes estuvo cada vehículo en taller, suspendido o fuera de circulación.
Propuesta: registrar cada cambio de estado del vehículo con su fecha (ya hay motivo en `vehiculos.estado_motivo`) y calcular el % de disponibilidad por mes, por vehículo y para toda la flota, junto con los viajes que quedaron sin vehículo.

**67. Exportar la agenda a calendario (.ics), a pedido** · impacto medio · esfuerzo S
Hoy: no hay exportación a calendario (no encontré `text/calendar` ni `BEGIN:VCALENDAR` en el código).
Propuesta: botón «Descargar mis viajes (.ics)» en «Mi semana» y en «Mis salidas»: un VEVENT por viaje con STATUS (TENTATIVE si está a confirmar, CONFIRMED, CANCELLED) y SEQUENCE que sube con cada reprogramación, para que el calendario de la PC actualice el evento en luga…

**68. Frecuencias más ricas y excepciones en viajes frecuentes** · impacto medio · esfuerzo M
Hoy: `frecuentes.FRECUENCIAS` admite semanal, quincenal y mensual.
Propuesta: guardar la regla como RRULE (FREQ / INTERVAL / BYDAY / BYSETPOS / UNTIL) con fechas excluidas (EXDATE), y expandirla con la librería `recurring-ical-events` o con `dateutil.rrule`.

**69. Calendario único de feriados y días no laborables** · impacto alto · esfuerzo S
Hoy: `agentes.sumar_habiles` y `database.seguimiento_respuestas` reciben un parámetro `feriados`, pero no encontré una tabla de feriados: en la práctica llega vacío.
Propuesta: tabla `feriados (fecha, motivo, tipo [nacional | puente | asueto PPN | feria])` que se carga a mano o se importa desde un .ics descargado.

**70. Vista por recurso: vehículos y choferes en filas, horas en columnas** · impacto alto · esfuerzo M
Hoy: `/traslados/horas` es una agenda por hora y marca en rojo al mismo chofer en dos vehículos.
Propuesta: vista «Por vehículo» y «Por chofer» armada en el servidor (HTML y CSS grid, sin JavaScript de terceros), con barras por salida, reservas, licencias y taller.

**71. Mapa de unidades sin depender de internet** · impacto medio · esfuerzo M
Hoy: `/traslados/mapa` necesita internet para el mapa base de OpenStreetMap (README), y en otra parte se lo reemplazó por un listado con enlace a Google Maps.
Propuesta: servir un único archivo PMTiles de Argentina (o solo del AMBA) desde la carpeta `static/` de la app, con MapLibre o Leaflet incluidos en el propio sistema.

**72. «Llegué / salí» por parada, con un toque** · impacto alto · esfuerzo S
Hoy: se cargan los horarios reales del viaje (`hora_salida_real` y `hora_regreso_real`) y los del desplazamiento, pero no la hora de llegada y de salida de cada parada, que es el dato para medir la demora para ingresar y el t…
Propuesta: en «Mis salidas» (celular del chofer, dentro de la red o por VPN), botones «Llegamos a la unidad», «Ingresamos» y «Salimos», con la hora del servidor.

**73. Doble confirmación de que el viaje se hizo** · impacto alto · esfuerzo S
Hoy: un viaje confirmado con fecha pasada cuenta como realizado para estadísticas y metas (`avance_metas` filtra CONFIRMADO con fecha anterior a hoy).
Propuesta: el viaje pasa a «Realizado» cuando lo confirma quien viajó (al cargar entrevistas) o el chofer (al cerrar la salida).

**74. Tiempo de respuesta de la coordinación (pedido → asignación)** · impacto medio · esfuerzo S
Hoy: se ve qué pedidos están «sin asignar», pero no hace cuánto esperan ni cuál es el tiempo habitual de asignación.
Propuesta: semáforo de antigüedad en «Asignar» (por ejemplo, ámbar a las 24 h hábiles y rojo a las 48 h o a menos de 48 h del viaje) y un indicador mensual con la mediana de horas hasta la asignación, para la Dirección.

**75. Lista de espera con prioridad, no solo por orden de llegada** · impacto medio · esfuerzo S
Hoy: `operacion.avisar_lugar_libre` le avisa a la primera persona de la lista de espera.
Propuesta: cada anotación lleva un motivo tipificado (urgencia: medida de fuerza, huelga de hambre, hábeas corpus, pedido judicial;

**76. Puntaje sugerido cuando faltan vehículos** · impacto medio · esfuerzo M
Hoy: si no hay vehículo, la persona pide «revisión de la Dirección» y la Dirección decide a mano («Dar prioridad» / «No corresponde»).
Propuesta: en la pantalla de revisión, para cada pedido que compite ese día: urgencia declarada, días desde la última visita a la unidad, si el equipo está «atrasado» en su meta y si es un viaje inmediato.

**77. Comparar la propuesta del planificador con lo que se asignó** · impacto bajo · esfuerzo S
Hoy: el planificador propone y la coordinación confirma o cambia, pero no se mide si la propuesta habría ahorrado salidas o km.
Propuesta: al cerrar la semana, un cuadro «propuesto vs.

**78. Informe de recorridos y paradas por vehículo** · impacto medio · esfuerzo S
Hoy: los datos están (desplazamientos, paradas, horas reales, km), pero repartidos entre el tablero del día, la ficha del vehículo y Estadísticas.
Propuesta: un informe por vehículo o chofer y período: cada salida con sus paradas, la hora de cada una (propuesta 19), km, tiempo en ruta, tiempo en unidad y novedades.

**79. Demora para ingresar a la unidad como indicador de obstáculos al monitoreo** · impacto alto · esfuerzo S
Hoy: existen las novedades «ingreso denegado» y «demora para ingresar» (con minutos), sumadas por unidad.
Propuesta: indicador por unidad y mes: % de visitas con obstáculos, mediana de minutos de espera (con la propuesta 19) y denegaciones.

**80. Terminar de cumplir «no se borra nada» en Autos PPN** · impacto alto · esfuerzo S — *ya preparado (bajas con registro, hito 3)*
Hoy: encontré borrados físicos: `operacion.borrar_licencia` (`DELETE FROM chofer_licencias`), la baja de un participante (`traslados.py:798`, `DELETE FROM viaje_participantes`), los precargados «a confirmar» al pausar o termi…
Propuesta: pasar todos a baja lógica (`anulado_en`, `anulado_por`, `motivo`), con filtro «ver anulados» y la opción de recuperar.

**81. Lugares libres en las salidas de los próximos días** · impacto medio · esfuerzo S
Hoy: la lista de espera aparece solo cuando un vehículo está completo.
Propuesta: tarjeta «Salidas con lugar» en el inicio de Autos PPN y en «Mis viajes»: destino, hora y plazas libres, con «Sumarme» (lo confirma la coordinación).


### B. METAS, INDICADORES Y TABLEROS

**82. Una sola meta de visitas por equipo** · impacto alto · esfuerzo S
Hoy: hay dos metas para lo mismo: `metas_viajes` (mínimo de viajes por trimestre, en `tablero_direccion.py`) y `metas_anuales` con el indicador `visitas_equipo` (en `metas.py`).
Propuesta: dejar `metas.py` como única fuente.

**83. Proyección al cierre y lo que falta por mes** · impacto alto · esfuerzo S
Hoy: `metas.estado` compara lo hecho con lo «esperado a la fecha» (la meta repartida linealmente por `_fraccion_anio`).
Propuesta: dos columnas nuevas en el panel: «Al ritmo actual cerrás en N (X % de la meta)» y «Para llegar: N por mes».

**84. Aviso interno cuando una meta pasa a «atrasada»** · impacto alto · esfuerzo S
Hoy: el estado (cumplida / en camino / atrasada) se ve solo si alguien abre el panel.
Propuesta: el mantenimiento de fondo (cada 10 minutos) evalúa los estados una vez por día y, cuando un indicador cambia de «en camino» a «atrasada», avisa en el sistema a la coordinación del equipo y, en un resumen semanal, a la Dirección.

**85. Tarjetas de indicador con tendencia y comparación** · impacto medio · esfuerzo S
Hoy: el panel de metas usa barras de avance (`barra-dir`) por equipo e indicador.
Propuesta: para cada indicador, una tarjeta con el número grande, una mini línea de 12 meses (SVG generado en el servidor), la variación contra el trimestre anterior y contra el mismo trimestre del año anterior.

**86. Revisión trimestral con comentario y plan de acción** · impacto alto · esfuerzo M
Hoy: en `metas.py` se cargan números (quién y cuándo), pero no hay dónde explicar por qué un indicador está atrasado (licencias, cierre de una unidad, cambio de equipo) ni qué se va a hacer.
Propuesta: al cerrar cada trimestre, la coordinación completa un breve «balance»: estado (verde / ámbar / rojo, con sugerencia automática), comentario, obstáculos y acciones.

**87. Objetivos institucionales por encima de los indicadores** · impacto medio · esfuerzo M
Hoy: los indicadores se agrupan por tipo (visitas, monitoreos, informes, reuniones, requerimientos, comunicaciones), pero no se los vincula con los objetivos del plan anual del organismo («fortalecer el monitoreo de cárceles…
Propuesta: capa opcional de «objetivos» con sus «resultados clave», y cada resultado clave vinculado a uno o más indicadores existentes.

**88. Frecuencia mínima de visita por unidad según riesgo** · impacto alto · esfuerzo M
Hoy: el tablero muestra cobertura territorial y «unidades con notas y sin visitas» (`indicadores.py`), y `equipo_unidades` define las unidades habituales de cada equipo.
Propuesta: en `equipo_unidades`, una «frecuencia mínima» (mensual, bimestral…) y un nivel de riesgo (manual, o sugerido por notas recientes, novedades de ingreso y medidas de fuerza).

**89. Indicadores de calidad de la visita, no solo de cantidad** · impacto alto · esfuerzo S
Hoy: se cuentan visitas, audiencias e ingresos a pabellones por separado.
Propuesta: indicadores derivados, sin carga nueva: % de visitas con ingreso a pabellones, audiencias por visita, % de visitas con obstáculos (propuesta 26) y % de visitas con entrevistas informadas.

**90. Seguimiento de lo que se pidió después de cada visita** · impacto alto · esfuerzo L
Hoy: existen la carpeta del caso (`/caso`), las respuestas a notas despachadas con su plazo y los «requerimientos al SPF / FFSS» como indicador de carga manual.
Propuesta: desde el detalle del viaje, «Generó requerimiento / nota» (vínculo con la nota).

**91. Completitud de la carga de metas** · impacto alto · esfuerzo S
Hoy: si una coordinación no carga el mes, el panel muestra 0 y lo marca como atraso.
Propuesta: estado «sin carga» por equipo y período (distinto de 0, que sí queda registrado con quién y cuándo, como ya hace `metas.py`), un semáforo de completitud en el panel de Dirección y un recordatorio a la coordinación los primeros días hábiles del mes, igual que e…

**92. Ficha técnica de cada indicador** · impacto medio · esfuerzo S
Hoy: los criterios están en el código y en el README («desplazamiento = …», «viaje a la unidad = día + unidad + equipo», «se cuentan notas, no informes»), pero no en pantalla.
Propuesta: un «¿Cómo se calcula?» en cada indicador con definición, fórmula, fuente (viajes / carga / planilla), frecuencia, responsable de la carga, desde cuándo vale y cambios de criterio.

**93. Metas ajustadas por días disponibles de cada persona** · impacto medio · esfuerzo M
Hoy: el «esperado a la fecha» se calcula igual para todo el equipo, aunque una persona haya estado de licencia dos meses.
Propuesta: con los datos del cruce, calcular un «esperado ajustado» por persona y equipo (meta × días disponibles / días hábiles).

**94. Comparación entre equipos con valores normalizados** · impacto medio · esfuerzo S
Hoy: el tablero de Dirección compara la carga de cada equipo con el promedio.
Propuesta: cuadro con selector «por integrante / por unidad a cargo / por población alojada (si se carga)» para visitas, audiencias e informes.

**95. Datos abiertos y secreto estadístico también para metas** · impacto medio · esfuerzo S
Hoy: `indicadores.datos_abiertos` aplica `MINIMO_PUBLICABLE = 3` a notas y viajes.
Propuesta: una exportación «para publicar» de metas por equipo y trimestre (sin personas, con el mínimo publicable) para el informe anual.

**96. Lectura del trimestre redactada por la IA local** · impacto medio · esfuerzo M
Hoy: existe el borrador del informe del período en Word (87) con cifras.
Propuesta: botón «Borrador de lectura» en el panel de metas: el servidor arma un resumen numérico estructurado y Ollama solo lo redacta.

**97. Alertas de resultado: «consultas que deberían dar vacío»** · impacto medio · esfuerzo S
Hoy: hay anomalías de traslados, pero no reglas de control de datos de metas y tablero (por ejemplo, audiencias informadas sin visita, una persona con visitas en dos unidades a la misma hora, ingreso a pabellones marcado sin…
Propuesta: un conjunto de controles en Python: cada uno devuelve filas y, si devuelve alguna, aparece en «Administración → Calidad de datos de metas», con un enlace para corregir.

## Interfaz y experiencia


### A. Base técnica y soberanía

**98. htmx siempre local, sin respaldo en CDN** · impacto alto · esfuerzo S
Hoy: las líneas 17 y 18 de `base.html` cargan `https://cdnjs.cloudflare.com/.../htmx.min.js` cuando no existe `static/htmx.min.js`.
Propuesta: copiar `htmx.min.js` 1.9.12 a `static/` y borrar la rama `{% else %}` del CDN.

**99. Prueba automática de «cero recursos remotos»** · impacto alto · esfuerzo S
Hoy: el riesgo anterior puede volver a aparecer en cualquier plantilla nueva.
Propuesta: un test que recorra `templates/` y `static/` buscando `src=` o `href=` con `http(s)://` en `<script>`, `<link>`, `<img>`, `@import` y `url()`.

**100. Mapa de colores semánticos compatible con Poncho** · impacto medio · esfuerzo S
Hoy: `estilos.css` tiene tokens `--color-alerta/atencion/exito/info`, pero conviven con colores fijos.
Propuesta: fijar cuatro significados, como en Poncho: - rojo: grave o urgente;


### B. Navegación e inicio

**101. Menú lateral más corto y agrupado por tarea** · impacto alto · esfuerzo M
Hoy: en `base.html` (líneas 73 a 105), la sección «Notas» puede llegar a 12 ítems para Dirección: Inicio, Notas a la firma, Circuito, Despacho, Mi equipo, Reporte, Expedientes, Datos, Consultar, Actividad, Biblioteca y Ausenc…
Propuesta: tres grupos fijos: - «Mi trabajo»: bandeja, circuito y despacho.

**102. Inicio como bandeja única «qué tengo que hacer hoy»** · impacto alto · esfuerzo M
Hoy: `inicio.html` muestra «Hoy necesita tu atención» y además cuatro tarjetas de KPIs que repiten números («esperan tu acción», «para firmar», «con problemas»).
Propuesta: dejar una sola lista ordenada por verbo, con un botón de acción en cada fila: «Firmar (5)», «Aprobar (3)», «Volver a revisar (1)», «Despachar (2)», «Confirmar viajes (4)».

**103. Nombre del sistema dinámico en la marca del menú** · impacto medio · esfuerzo S
Hoy: en la línea 67 de `base.html`, la marca dice «DGPDH · Notas a la firma» siempre que la persona tenga acceso a Notas, aunque esté en Autos PPN o en Metas.
Propuesta: que la etiqueta dependa de la ruta: «Notas a la firma», «Autos PPN», «Metas» o «Personas detenidas».

**104. Título de pestaña con contexto y contador** · impacto medio · esfuerzo S
Hoy: `<title>` suele ser genérico, por ejemplo «Notas DGPDH» o «Autos PPN — DGPDH».
Propuesta: usar el formato «(5) Pendientes de firma · Notas DGPDH», «Nota 2025-123 · Notas DGPDH» o «Mis salidas · lun 16/11 · Autos PPN».

**105. «Volver» que vuelve a donde estabas** · impacto medio · esfuerzo S
Hoy: en `notificaciones.html`, «Volver al listado» siempre va a `/`, aunque la persona haya llegado desde Inicio o desde Autos.
Propuesta: un macro `volver()` único que use un parámetro `desde=` validado contra rutas internas, con un valor por defecto según el rol.

**106. Banda de fase «Beta» con canal de sugerencias interno** · impacto bajo · esfuerzo S
Hoy: el sistema está en «Beta 01» y lo usan unas 270 personas, pero ninguna pantalla lo dice ni ofrece dónde avisar un problema.
Propuesta: una banda fina debajo del encabezado: «Beta: estamos mejorando el sistema.


### C. Bandejas de firma, aprobación y despacho

**107. Firma en serie con progreso, «saltear» y resumen final** · impacto alto · esfuerzo M
Hoy: `/firma-en-serie` (en `rutas_circuito.py`) redirige nota por nota a `?serie=1`, y existe la `.banda-serie`.
Propuesta: - En la banda: «Firmando 4 de 12 · quedan 8 · 2 URGENTES».

**108. Vista dividida: lista a la izquierda, documento a la derecha** · impacto alto · esfuerzo M
Hoy: en `index.html`, la tabla «Pendientes de tu firma» obliga a entrar a cada nota y volver.
Propuesta: en pantallas de 1280 px o más, al elegir una fila se carga el resumen y la vista previa en un panel derecho con `hx-get="/nota/{id}/fragmento"`.

**109. Estado «bandeja en cero» que diga qué sigue** · impacto medio · esfuerzo S
Hoy: en `index.html` aparece «No hay documentos esperando tu firma.» y nada más.
Propuesta: «Estás al día ✓.

**110. Bandeja ordenada por urgencia real, con cortes visibles** · impacto alto · esfuerzo S
Hoy: el orden actual es prioridad más antigüedad.
Propuesta: separadores de grupo fijos: «Vence hoy», «Vence esta semana», «URGENTES sin plazo» y «Resto».

**111. «Volver a corregir» con motivos frecuentes** · impacto medio · esfuerzo M
Hoy: devolver una nota pide texto libre.
Propuesta: chips de motivos frecuentes, que se pueden marcar varios, más un campo de texto opcional.

**112. Aviso visible de quién firma hoy** · impacto medio · esfuerzo S
Hoy: la Subdirectora tiene las mismas facultades que el Director y la firma depende de quién está logueado.
Propuesta: un banner informativo en la bandeja de Coordinación y en la de Dirección: «Del 18 al 22/11 firma la Subdirectora (el Director está de licencia)».

**113. Mesa de Entradas: cada bloque como lista de tareas** · impacto alto · esfuerzo M
Hoy: en `index.html` (bloques de Mesa), cada bloque muestra un chip «Listo para despachar» o «Faltan firmar N» y tres botones sueltos.
Propuesta: cada tarjeta lleva una lista de tareas con su estado: «Firmas: 4/4 ✓», «Números: falta cargar», «Descarga: hecha», «Despacho: pendiente».

**114. Aprobación por lote para Coordinación** · impacto medio · esfuerzo M
Hoy: la barra `.barra-bloque` sirve para armar bloques, cambiar la prioridad y enviar a Coordinación.
Propuesta: casilla «seleccionar todos los visibles» y una barra contextual con «Aprobar y enviar a corrección (N)».


### D. Formularios

**115. Resumen de errores arriba y error junto a cada campo** · impacto alto · esfuerzo M
Hoy: los errores del servidor llegan como `mostrarAviso` flotante, definido en `base.html`, o como `HTTPException` con `detail`.
Propuesta: un macro `error_resumen(errores)` al principio del formulario, con enlaces a cada campo, que reciba el foco al cargar.

**116. Los avisos de error no se borran solos** · impacto alto · esfuerzo S
Hoy: en `base.html`, `mostrarAviso` elimina todos los avisos a los 9 segundos (`setTimeout(..., 9000)`), también los de error.
Propuesta: el aviso verde de éxito puede desaparecer.

**117. Validación en línea con htmx al salir del campo** · impacto medio · esfuerzo M
Hoy: el DNI o LPU repetido, el número de nota ya usado por Mesa o la unidad inexistente recién se detectan al enviar el formulario.
Propuesta: `hx-post="/validar/dni" hx-trigger="change"` en los campos clave (DNI, LPU, número de nota y expediente).

**118. «Solicitar viaje» en pasos, con revisión antes de enviar** · impacto alto · esfuerzo M
Hoy: el viaje junta circuito, destino o destinos, fecha, horas, participantes, modalidad por participante y motivo.
Propuesta: tres pasos: ¿adónde y cuándo?, ¿quiénes van? y ¿cómo viajan? Al final, una pantalla «Revisá antes de enviar», con «Cambiar» al lado de cada dato.

**119. Fechas en formato argentino y atajos** · impacto medio · esfuerzo S
Hoy: en `index.html`, `traslados.html` y `detenidos.html` las fechas se arman a mano con cortes como `fecha[8:10]/fecha[5:7]`.
Propuesta: un filtro Jinja único, `|fecha_corta`, que muestre por ejemplo «lun 16/11», y `|fecha_larga` para «16/11/2026 10:20».

**120. Autocompletar accesible para unidades, personas y agentes** · impacto alto · esfuerzo M
Hoy: «Unidad» en `traslados.html` y «Centro de detención» en `detenidos.html` son `<select>` con todo el catálogo de unidades penales.
Propuesta: un combobox que filtre mientras se escribe, por sigla, ciudad o provincia, y que priorice las unidades más usadas por el equipo.

**121. Subida de documentos con vista previa de lo que va a pasar** · impacto medio · esfuerzo M
Hoy: en `index.html` (`#form-subida`), el texto explica que los PDF se archivan sin corrección ni firma, pero recién se sabe qué pasó con cada archivo después de subirlo.
Propuesta: al elegir los archivos, mostrar una lista antes de subir: - «Nota_X.docx → corrección y firma» - «Constancia.pdf → archivo directo (adjunto)» Cada archivo lleva su botón para quitarlo, y hay una barra de progreso por archivo.

**122. Protección contra pérdida de cambios y «Guardado hace 1 min»** · impacto alto · esfuerzo M
Hoy: los párrafos editables (`.parrafo-editable`), las observaciones y los formularios largos se pierden si se cierra la pestaña o si vence la sesión por inactividad (el bloque `aviso-inactividad` de `base.html`).
Propuesta: guardar el borrador en el servidor cada 30 segundos o al salir de un párrafo, con un indicador discreto «Guardado 10:42».

**123. No pedir dos veces lo mismo** · impacto medio · esfuerzo S
Hoy: al cargar viajes o actividades de Delegaciones, el asesor repite destino, compañeros y horarios todas las semanas.
Propuesta: en la ficha de un viaje realizado, un botón «Repetir este viaje» que abre el formulario precargado.

**124. Diálogo del PIN más amable** · impacto medio · esfuerzo S
Hoy: `dialogo-pin`, en `base.html`, usa `type=password` sin opción de ver lo escrito.
Propuesta: - un botón «Mostrar» y permitir pegar;


### E. Tablas y filtros

**125. Filtros aplicados como chips removibles** · impacto alto · esfuerzo S
Hoy: en `index.html` hay tres formas de filtrar: el panel plegable, el menú de cada columna (`menu_col`, con un «●» que casi no se ve) y las pestañas de tareas.
Propuesta: una franja fija encima de la tabla: «Filtrando por: Etapa: Firma ✕ · Equipo 3 ✕ · Desde 01/11 ✕ · Quitar todo».

**126. Filtrar sin el botón «Filtrar»** · impacto medio · esfuerzo M
Hoy: `traslados.html` (agenda), `detenidos.html` e `index.html` (panel de filtros) piden tocar «Filtrar» después de cada cambio, y la página se recarga completa.
Propuesta: - `hx-get` con `hx-trigger="change, keyup changed delay:400ms"`;

**127. Ordenamiento que se anuncia: `aria-sort`** · impacto medio · esfuerzo S
Hoy: las columnas ordenables de `index.html` usan `<details>` con enlaces.
Propuesta: `aria-sort="ascending/descending"` en el `<th>` activo, un botón con el nombre de la columna como control de orden y una `caption` con «Ordenado por fecha, más nuevas primero».

**128. Encabezado y primera columna fijos en tablas anchas** · impacto medio · esfuerzo S
Hoy: `detenidos.html` tiene 10 columnas dentro de `.tabla-scroll`.
Propuesta: `position: sticky` en `thead th`, con `top` igual a la altura del encabezado, y en la primera columna.

**129. Densidad y columnas a elección, guardadas en el perfil** · impacto medio · esfuerzo M
Hoy: las tablas de Dirección y de Mesa tienen muchas columnas (Prioridad, Archivo, Tipo, Etapa, Tema, Asesor/equipo, Fecha y Actualizado).
Propuesta: un menú «Columnas» con casillas y una opción de densidad «cómoda» o «compacta».

**130. Menos chips en la celda «Archivo»** · impacto alto · esfuerzo M
Hoy: en las líneas 500 a 506 de `index.html`, la celda puede juntar hasta seis marcas: bloque, alertas de la IA, plazo, posible duplicado, Solo Mesa y respuesta.
Propuesta: una columna «Atención» con un solo indicador del problema más grave (ícono, texto corto y color semántico) más «+2».

**131. Tiempos relativos más fecha exacta** · impacto medio · esfuerzo S
Hoy: «Esperando desde» y «Actualizado» (`|hora`) muestran la hora sin el tiempo transcurrido, que es lo que importa para priorizar.
Propuesta: «hace 3 días» en el texto, con `<time datetime>` y `title` que muestren «12/11/2026 10:20».

**132. Exportar exactamente lo que estoy viendo** · impacto medio · esfuerzo S
Hoy: `detenidos.html` exporta toda la base (`/detenidos/exportar.xlsx`), pero no el resultado de la búsqueda.
Propuesta: un botón «Exportar esta vista (37 filas)» que respete los filtros, el orden y las columnas visibles.

**133. Búsqueda de personas detenidas: la regla dentro del formulario** · impacto medio · esfuerzo S
Hoy: en `detenidos.html`, la regla «con DNI o LPU alcanza un dato;
Propuesta: - Separar en dos bloques: «Búsqueda rápida» (DNI o LPU, un campo grande) y «Por nombre y otros datos».


### F. Búsqueda global y paleta de comandos

**134. Paleta de comandos con Ctrl+K y «/»** · impacto alto · esfuerzo M
Hoy: «/» solo enfoca «Buscar en las notas…», y el buscador del encabezado aparece únicamente con acceso a Notas (`{% if notas_ok %}` en `base.html`).
Propuesta: una paleta, con un `<dialog>` y el patrón combobox, que busque en el servidor (fragmento htmx) en cuatro grupos: Notas, Viajes, Personas detenidas y Unidades.

**135. Resultados de búsqueda agrupados y «sin resultados» útil** · impacto medio · esfuerzo S
Hoy: `buscar.html` busca solo en notas, y los estados vacíos de la aplicación son texto gris (`.estado-vacio`).
Propuesta: agrupar por tipo, con contador por grupo y «ver todos».


### G. Mensajes, confirmaciones y deshacer

**136. Confirmar solo lo irreversible, con botones que digan qué hacen** · impacto alto · esfuerzo S
Hoy: `confirmacion-inline`, en `base.html`, siempre ofrece «Sí, seguir / No».
Propuesta: sin confirmación, pero con «Deshacer» (usando `aviso-deshacer`, que ya existe), para todo lo reversible: filtros, prioridad o marcar como leído.

**137. Lenguaje claro en la interfaz: glosario y sin códigos internos** · impacto alto · esfuerzo S
Hoy: - En la línea 257 de `index.html` se muestran estados crudos (`bn.estado`, como «FIRMADA» o «PARA_REMITIR»).
Propuesta: - Una tabla única `ETIQUETAS_ESTADO` para todo estado visible.

**138. Errores del servidor que explican qué hacer** · impacto alto · esfuerzo S
Hoy: `htmx:responseError` muestra `detail` tal como llega, por ejemplo «La nota todavía no tiene documento firmado» o «No se pudo completar la acción.».
Propuesta: un catálogo de mensajes en tres partes: qué pasó, por qué y qué podés hacer.

**139. Avisos que se abren en la misma pestaña, agrupados y con acción** · impacto medio · esfuerzo S
Hoy: en `notificaciones.html`, cada aviso se abre con `target="_blank"`.
Propuesta: - abrir en la misma pestaña;

**140. Aviso de cierre de sesión que recibe el foco y guarda antes** · impacto medio · esfuerzo S
Hoy: `aviso-inactividad`, en `base.html`, aparece con `hidden=false`, pero el foco no se mueve al botón «Seguir conectado».
Propuesta: al mostrarse, el aviso mueve el foco al botón y lo anuncia.


### H. Accesibilidad y teclado

**141. Que el foco nunca quede tapado por barras fijas** · impacto alto · esfuerzo S
Hoy: en `estilos.css`, `.encabezado` es sticky arriba.
Propuesta: `html { scroll-padding-top: calc(var(--alto-encabezado) + 60px);

**142. Tamaño mínimo de lo que se toca** · impacto alto · esfuerzo S
Hoy: las casillas de selección de las tablas, la «✕» de filtro guardado (`.filtro-guardado__x`), los `chip-select` de prioridad y algunos enlaces chicos dentro de las celdas quedan por debajo de 24 × 24 px.
Propuesta: como mínimo 24 px en todo control.

**143. Atajos de una tecla que se pueden apagar** · impacto alto · esfuerzo S
Hoy: en `base.html` (reforma 36), las teclas `a`, `f`, `c`, `d`, `j` y `k` disparan acciones sin modificador;
Propuesta: un interruptor en «Mi perfil»: «Atajos de una tecla: activados / desactivados», que venga desactivado salvo para Dirección y Mesa.

**144. Ayuda siempre en el mismo lugar** · impacto medio · esfuerzo S
Hoy: «Ayuda» está al final del menú lateral, y en el celular queda escondida detrás del botón de menú.
Propuesta: un botón «?» fijo en el encabezado, junto a Avisos, que abra la sección del manual correspondiente a la ruta actual (`/manual#autos-solicitar`).

**145. Filas clicables sin trampas de teclado** · impacto medio · esfuerzo S
Hoy: `tr[data-href]` (en `interfaz.js`) hace clicable toda la fila, pero dentro de la fila hay `select` de prioridad, casillas y enlaces.
Propuesta: que el enlace accesible sea el nombre del documento, dentro de la celda «Archivo».

**146. Modo oscuro con selector visible y documento siempre «papel»** · impacto medio · esfuerzo S
Hoy: el tema se elige en «Mi perfil» y se guarda en `localStorage`.
Propuesta: - un selector de tres estados en el menú del perfil del encabezado («Como el sistema / Claro / Oscuro»);

**147. No depender solo del color en la agenda** · impacto medio · esfuerzo S
Hoy: en `traslados.html`, «Colorear por equipo» o «por circuito» asigna ocho colores (`--cat-1…8`) al borde izquierdo de cada viaje.
Propuesta: sumar las iniciales del equipo en una pastilla dentro de la tarjeta («E3») y una leyenda con texto.


### I. Celular y tablet para choferes

**148. «Mis salidas» pensada primero para el celular** · impacto alto · esfuerzo M
Hoy: en `traslados_hoy.html`, el chofer ve el encabezado con «Día anterior / Día siguiente», las vistas de Autos y las tarjetas `dia-viaje` con datos en texto chico (hora, destino, participantes).
Propuesta: una tarjeta grande por salida con: - hora en letra grande, destino o destinos en orden y cantidad de pasajeros;

**149. Barra inferior en el celular para los choferes** · impacto medio · esfuerzo S
Hoy: en un teléfono, el menú lateral se abre con la hamburguesa (`#abrir-lateral`), que queda arriba a la izquierda, fuera del alcance del pulgar.
Propuesta: con `@media (max-width: 720px)` y rol CHOFER, mostrar una barra fija abajo con tres íconos y su texto: «Hoy», «Semana» y «Avisos».

**150. Instalable y con lectura sin señal (PWA local)** · impacto medio · esfuerzo L
Hoy: en la ruta (Ezeiza, Marcos Paz) la señal es mala.
Propuesta: un `manifest.webmanifest` y un service worker propios, servidos desde el sistema y sin servicios de terceros, que: - guarden «Mis salidas» de hoy y mañana para leerlas sin conexión;

**151. Agenda semanal legible en pantallas chicas** · impacto medio · esfuerzo M
Hoy: la `.agenda` de `traslados.html` es una grilla de siete días con tarjetas densas (grupos por equipo, chips de salida, plazas libres).
Propuesta: en pantallas angostas, mostrar un solo día por vez con chips de día («L 16 · M 17 · …»), con el día de hoy elegido por defecto y el contador de viajes en cada chip.


### J. Notificaciones

**152. Insignias que cuentan solo lo que pide acción** · impacto medio · esfuerzo S
Hoy: la insignia de Avisos, que aparece dos veces (en el menú lateral y en el encabezado de `base.html`), cuenta todo lo no leído, también lo puramente informativo.
Propuesta: la insignia roja cuenta solo «te toca actuar».

**153. Resumen al entrar, sin correo** · impacto medio · esfuerzo S
Hoy: el organismo decidió no vincular el sistema con correo ni celular por ahora.
Propuesta: en el primer ingreso del día, un banner arriba de Inicio: «Desde ayer: 3 notas nuevas para firmar, 1 devuelta, 2 viajes confirmados».


### K. Ayuda contextual y primeros pasos

**154. Primer ingreso guiado por rol, salteable** · impacto medio · esfuerzo M
Hoy: unas 270 personas, muchas no técnicas, entran por primera vez a un sistema con dos módulos, PIN y circuito de cuatro etapas.
Propuesta: una lista de primeros pasos en Inicio que se puede cerrar.

**155. «¿Qué significa?» en etapas y estados** · impacto medio · esfuerzo S
Hoy: en `index.html`, la etapa se muestra como «2/4 Coordinación», con chips de estado y de antigüedad.
Propuesta: al tocar la etapa, un popover accesible (un `<details>` o el atributo `popover`) que explique: «Etapa 2 de 4: la revisa tu coordinación.

**156. «Qué cambió» después de cada versión** · impacto bajo · esfuerzo S
Hoy: el sistema se actualiza por tandas (Ola 1 a 6, Beta 01) y los cambios solo constan en el `README.md`.
Propuesta: después de una versión nueva, un aviso único por persona con tres líneas filtradas por rol y el enlace «Ver todo».


### L. Rendimiento percibido

**157. Indicadores de carga en botones y esqueletos en fragmentos** · impacto medio · esfuerzo S
Hoy: `procesando.js` cambia el botón a «Procesando…», pero los fragmentos htmx, como `_estado_nota.html` con `hx-trigger="load delay:2s"`, aparecen de golpe y mueven la página.
Propuesta: `hx-indicator` común en botones (spinner dentro del botón y `aria-busy`).

**158. Cola de la IA con tiempo estimado** · impacto medio · esfuerzo S
Hoy: en `index.html` («En corrección automática»), se informa «lugar 3 en la cola» pero no cuánto falta.
Propuesta: «Lugar 3 · unos 6 min (promedio de hoy: 2 min por nota)», con una barra de progreso y la actualización del fragmento cada 30 s.

**159. Cambiar la prioridad sin recargar toda la página** · impacto medio · esfuerzo S
Hoy: `cambiarPrioridad()`, en `base.html`, hace `fetch` y después `window.location.assign(window.location.href)`.
Propuesta: `hx-post` en el `select` con `hx-target="closest tr"` y `hx-swap="outerHTML"`.

**160. Navegación con `hx-boost` y manejo del foco** · impacto medio · esfuerzo M
Hoy: cada clic en el menú recarga la página completa, con todos sus scripts en línea (más de 300 líneas JS en `base.html`).
Propuesta: `hx-boost="true"` en el menú lateral y en las pestañas, con `hx-select="#contenido-principal"`.


### M. Consistencia visual con el portal PPN

**161. Un solo botón primario y «Más acciones» en las cabeceras** · impacto medio · esfuerzo S
Hoy: la cabecera de `detenidos.html` muestra hasta siete botones en fila: Nueva persona, Búsqueda colectiva, Importar, Cargas, Exportar Excel, Exportar CSV y Revisión.
Propuesta: dejar un primario («Nueva persona»), uno o dos secundarios frecuentes, y el resto en un menú «Más acciones ▾».

**162. Íconos con una sola fuente** · impacto bajo · esfuerzo S
Hoy: `base.html` define un macro `icono()` con un diccionario de SVG, mientras `inicio.html` repite los mismos SVG en línea (notas, autos, avisos) y además existe `ico()` en `iconos.py`.
Propuesta: un sprite SVG local (`static/iconos.svg`) con `<use href="#notas">` y un único macro `ico()`.

**163. La guía de estilo como catálogo vivo con estados y pautas** · impacto medio · esfuerzo M
Hoy: existe `/guia-estilo`, pero en `estilos.css` (1859 líneas) conviven reglas viejas y nuevas, con `.boton--chico` definido dos veces (líneas 635 y 1061).
Propuesta: que cada componente de `/guia-estilo` muestre sus estados (normal, hover, foco, deshabilitado y error), sus variantes en claro y oscuro, cuándo usarlo y cuándo no, y su lista de accesibilidad.

**164. Pie institucional y encabezado alineados al portal PPN** · impacto bajo · esfuerzo S
Hoy: no hay pie de página.
Propuesta: un pie fino con «Procuración Penitenciaria de la Nación · DGPDH · versión Beta 01 (14/11/2026) · Soporte: interno 1234 · Accesibilidad».

## Fuentes

El detalle de cada propuesta, con todas sus referencias (URL), está en los documentos del proyecto «propuestas_detalle_notas_ia», «propuestas_detalle_viajes_metas» y «propuestas_detalle_ui_ux». La numeración de esos documentos es por área: Notas 1–53 = 1–53 acá; Viajes 1–44 = 54–97; Interfaz 1–67 = 98–164.