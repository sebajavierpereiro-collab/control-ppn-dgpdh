# Opciones de config.ini del área Notas, IA local y Personas detenidas (propuestas 1–53)

Todas son optativas. Si no están en `config.ini`, el sistema funciona como antes de estos cambios.

## IA local (Ollama) — `[ollama]`

| Clave | Por defecto | Para qué |
|---|---|---|
| `modelo`, `modelo_<proceso>` | (ya existían) | Modelo general y uno por proceso: `correccion`, `clasificacion`, `consistencia`, `redaccion`, `verificacion`, `revision_detenidos`. |
| `max_ctx` | 8192 | Techo de la ventana de contexto automática (propuesta 20). |
| `num_ctx_<proceso>` | — | Ventana fija para ese proceso, por ejemplo `num_ctx_consistencia = 12288` (propuesta 20). |
| `esquemas_json` | true | Manda el esquema JSON en `format` (Ollama 0.5 o más nuevo). Si Ollama no lo acepta, se reintenta solo con «json» (propuesta 19). |
| `keep_alive_noche`, `keep_alive_dia` | — | Cuánto queda el modelo en memoria, por ejemplo `30m` y `5m` (propuesta 21). |
| `ejemplos_correccion` | 0 | 1 a 3 ejemplos de correcciones aprobadas en el pedido de corrección (propuesta 18). |

`[ia] tapar_documentos_registro = true` (por defecto): los números con forma de DNI/CUIL/LPU se guardan tapados en `ia_registro` (propuesta 47).
`[ia_automatica] agrupar_por_modelo = true` (por defecto): de noche, a igual prioridad, sigue con el modelo ya cargado (propuesta 21).

### Recomendación de modelo (propuesta 22)

- Hoy `config.ini` dice `modelo = phi3:mini` (≈3,8B, entrenado sobre todo en inglés). Administración → IA → Modelos lo marca como chico
  para **corrección y redacción**.
- Candidatos locales de 7B o más: `qwen2.5:7b` (el que nombra el README) y Salamandra 7B Instruct (BSC, Apache-2.0, ajustado para
  castellano; versión GGUF). Se bajan a mano con `ollama pull …` y se configuran por proceso:
  `modelo_correccion = qwen2.5:7b`, `modelo_redaccion = qwen2.5:7b`. La clasificación y la revisión de fichas pueden seguir con uno chico.
- Antes de cambiar, correr el examen: `python herramientas/examen_ia.py --modelos qwen2.5:7b,phi3:mini --salida examen.json` (propuesta 23).
  Ampliar los casos con copias anonimizadas (`herramientas/anonimizar.py`, propuesta 43).
- En el servidor de Ollama conviene fijar `OLLAMA_MAX_LOADED_MODELS=1`, `OLLAMA_NUM_PARALLEL=1` y `OLLAMA_NO_CLOUD=1`
  (en el servicio systemd: `Environment=...`).
- Motor de respaldo (propuesta 28): `llama-server` de llama.cpp tiene otra API (`/completion`, OpenAI); `[ollama] url` no lo puede usar tal cual.
  Queda documentado como alternativa, sin integrar.

## Programas locales optativos

| Sección y clave | Programa | Propuesta |
|---|---|---|
| `[libreoffice] unoserver = true` (`unoconvert`, `unoserver_puerto = 2003`) | unoserver en 127.0.0.1 | 7 |
| `[ocr] activo = true` (`comando = ocrmypdf`, `idioma = spa`) | OCRmyPDF + Tesseract | 4 |
| `[languagetool] servidor = http://127.0.0.1:8081` | LanguageTool HTTP server (sin `--public`) | 12 |
| `[despacho] qr_verificacion = true`, `url_verificacion = https://<interno>` | (reportlab/pypdf, ya instalados) | 51 |

Solo se aceptan direcciones de esta máquina; si el programa falta o no responde, se sigue como hoy.

## Corrección y lenguaje claro — `[lenguaje_claro]`

- `activo = true` (por defecto): observaciones de lenguaje claro e índice INFLESZ (propuestas 13 y 14).
- `sin_ia = PRESENTACION_JUDICIAL, OFICIO`: tipos documentales para los que no corre la corrección de la IA (propuesta 17).

## Notas — `[notas]`

- `inactividad_aviso_dias = 7`, `inactividad_archivo_dias = 15` (Modificación 2).

## Personas detenidas — `[detenidos]`

- `exigir_confirmar_alertas = false`: además de la casilla de la pantalla, el servidor rechaza confirmar un listado con alertas sin ella (propuesta 37).
- `exigir_motivo_exportacion = false`, `aviso_exportacion_fichas = 2000`, `api_campos = nombre_completo,dni,centro_detencion` (propuesta 46).
- `ocultar_sensibles = false`: tapa situación procesal, condena y observaciones a quien no mantiene la base (propuesta 45).
