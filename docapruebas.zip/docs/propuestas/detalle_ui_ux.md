# dgpdh_web: 67 propuestas de interfaz y experiencia de usuario

**Fecha:** 14/11/2026.
**Qué se revisó:** `templates/base.html`, `index.html`, `inicio.html`, `traslados.html`, `traslados_hoy.html`, `traslados_chofer.html`, `detenidos.html`, `notificaciones.html`, `login.html`, `nota.html` (pestañas), `static/estilos.css`, `static/interfaz.js` y el `README.md`. Se miró el código en modo de solo lectura y no se tocó nada.

**Criterio general.** Ninguna propuesta depende de servicios externos mientras el sistema funciona: nada de CDN, fuentes remotas, analítica ni mapas de terceros. Todo se sirve desde el propio servidor, con htmx copiado al proyecto y Public Sans local, que ya está en `static/fonts`. Las referencias son guías públicas y se consultan solo para diseñar.

**Cómo leer cada bloque.** Cada propuesta tiene un impacto (alto, medio o bajo) y un esfuerzo:
- **S**: menos de un día.
- **M**: de 1 a 3 días.
- **L**: más de 3 días.

---

## A. Base técnica y soberanía

### 1. htmx siempre local, sin respaldo en CDN
- **Problema:** las líneas 17 y 18 de `base.html` cargan `https://cdnjs.cloudflare.com/.../htmx.min.js` cuando no existe `static/htmx.min.js`. En la copia revisada ese archivo no está. Por eso, hoy cada página pide htmx a internet: si la red del organismo corta la salida, se rompen la subida de documentos, el despacho de bloques y los fragmentos. Además, el navegador le revela a un tercero qué páginas se usan.
- **Propuesta:** copiar `htmx.min.js` 1.9.12 a `static/` y borrar la rama `{% else %}` del CDN. Sumar una prueba que falle si el archivo falta. Agregar la cabecera `Content-Security-Policy: script-src 'self'`.
- **Referencia:** [htmx, ensayo «Vendoring»](https://four.htmx.org/essays/vendoring) y [htmx, instalación](https://four.htmx.org/docs/get-started/installation).
- **Impacto:** alto. **Esfuerzo:** S.

### 2. Prueba automática de «cero recursos remotos»
- **Problema:** el riesgo anterior puede volver a aparecer en cualquier plantilla nueva. Hoy no hay ningún control que lo detecte.
- **Propuesta:** un test que recorra `templates/` y `static/` buscando `src=` o `href=` con `http(s)://` en `<script>`, `<link>`, `<img>`, `@import` y `url()`. Los enlaces de navegación quedan exceptuados. Complementarlo con un CSP estricto (`default-src 'self'`) para que el navegador también lo bloquee.
- **Referencia:** [htmx, «Vendoring»](https://four.htmx.org/essays/vendoring) (se audita mejor lo que vive en el repositorio) y la [Guía de navegación accesible (argentina.gob.ar)](https://argentina.gob.ar/sites/default/files/2024/10/guia_de_recomendaciones_para_navegacion_accesible_en_paginas_web.pdf).
- **Impacto:** alto. **Esfuerzo:** S.

### 3. Mapa de colores semánticos compatible con Poncho
- **Problema:** `estilos.css` tiene tokens `--color-alerta/atencion/exito/info`, pero conviven con colores fijos. Algunos ejemplos son `.alerta-reapertura` (`#E8C78A`, `#7A5518`), `.chip-fuente--*` y `.etiqueta--frecuente`. El mismo «amarillo» significa cosas distintas según la pantalla.
- **Propuesta:** fijar cuatro significados, como en Poncho:
  - **rojo:** grave o urgente;
  - **amarillo:** vence pronto o requiere atención;
  - **azul:** informativo;
  - **verde:** salió bien.

  Reemplazar todos los colores fijos por esos tokens y documentarlos en `/guia-estilo`. El bordó institucional `#AC2423` queda para la marca y la acción primaria, nunca para un error.
- **Referencia:** [argentina.gob.ar, «Recuadros y alertas»](https://www.argentina.gob.ar/node/483816) («los colores de las alertas son semánticos, no decorativos») y [Poncho](https://argob.github.io/poncho/).
- **Impacto:** medio. **Esfuerzo:** S.

---

## B. Navegación e inicio

### 4. Menú lateral más corto y agrupado por tarea
- **Problema:** en `base.html` (líneas 73 a 105), la sección «Notas» puede llegar a 12 ítems para Dirección: Inicio, Notas a la firma, Circuito, Despacho, Mi equipo, Reporte, Expedientes, Datos, Consultar, Actividad, Biblioteca y Ausencias. A eso se suman los paneles y la sección Cuenta. Para quien usa el sistema dos veces por semana, el menú es largo y no deja ver qué es lo diario.
- **Propuesta:** tres grupos fijos:
  - **«Mi trabajo»**: bandeja, circuito y despacho.
  - **«Consultar»**: buscar, expedientes, biblioteca y personas detenidas.
  - **«Gestión»**: reportes, datos, actividad, ausencias y administración.

  Lo que una persona no usó en 60 días pasa a un «Más…» plegable. Cada rol ve primero su verbo principal.
- **Referencia:** [argentina.gob.ar, «Planificar y estructurar»](https://www.argentina.gob.ar/node/482365) (pirámide invertida: lo más importante para la persona, arriba).
- **Impacto:** alto. **Esfuerzo:** M.

### 5. Inicio como bandeja única «qué tengo que hacer hoy»
- **Problema:** `inicio.html` muestra «Hoy necesita tu atención» y además cuatro tarjetas de KPIs que repiten números («esperan tu acción», «para firmar», «con problemas»). La misma información también aparece en el listado. Hay muchas cifras, pero no queda claro por dónde empezar.
- **Propuesta:** dejar una sola lista ordenada por verbo, con un botón de acción en cada fila: «Firmar (5)», «Aprobar (3)», «Volver a revisar (1)», «Despachar (2)», «Confirmar viajes (4)». Los KPIs pasan a una línea de resumen chica y la «Actividad reciente» se pliega.
- **Referencia:** [SAP Fiori, Approval app](https://experience.sap.com/fiori-design-web/v1-30/approval-app) (la bandeja de aprobaciones como punto de entrada).
- **Impacto:** alto. **Esfuerzo:** M.

### 6. Nombre del sistema dinámico en la marca del menú
- **Problema:** en la línea 67 de `base.html`, la marca dice «DGPDH · Notas a la firma» siempre que la persona tenga acceso a Notas, aunque esté en Autos PPN o en Metas. Con dos sistemas separados, desorienta.
- **Propuesta:** que la etiqueta dependa de la ruta: «Notas a la firma», «Autos PPN», «Metas» o «Personas detenidas». Cada panel suma un acento de color en el borde superior del encabezado, tomado de los tokens `--cat-*`.
- **Referencia:** [USWDS, catálogo de componentes (header)](https://designsystem.digital.gov/components/overview/).
- **Impacto:** medio. **Esfuerzo:** S.

### 7. Título de pestaña con contexto y contador
- **Problema:** `<title>` suele ser genérico, por ejemplo «Notas DGPDH» o «Autos PPN — DGPDH». Dirección y Mesa trabajan con varias pestañas abiertas y no distinguen cuál es cuál.
- **Propuesta:** usar el formato «(5) Pendientes de firma · Notas DGPDH», «Nota 2025-123 · Notas DGPDH» o «Mis salidas · lun 16/11 · Autos PPN». El contador sale de `contar_notificaciones` o del conteo de pendientes.
- **Referencia:** [GOV.UK, Question pages](https://design-system.service.gov.uk/patterns/question-pages) (el título de la página repite el encabezado).
- **Impacto:** medio. **Esfuerzo:** S.

### 8. «Volver» que vuelve a donde estabas
- **Problema:** en `notificaciones.html`, «Volver al listado» siempre va a `/`, aunque la persona haya llegado desde Inicio o desde Autos. Otras fichas usan su propia lógica; `traslados_chofer.html`, por ejemplo, decide según `coordina`.
- **Propuesta:** un macro `volver()` único que use un parámetro `desde=` validado contra rutas internas, con un valor por defecto según el rol. En las fichas profundas (nota, viaje, persona), agregar migas: «Notas › Equipo 3 › Nota 123».
- **Referencia:** [USWDS, catálogo de componentes (breadcrumb)](https://designsystem.digital.gov/components/overview/).
- **Impacto:** medio. **Esfuerzo:** S.

### 9. Banda de fase «Beta» con canal de sugerencias interno
- **Problema:** el sistema está en «Beta 01» y lo usan unas 270 personas, pero ninguna pantalla lo dice ni ofrece dónde avisar un problema.
- **Propuesta:** una banda fina debajo del encabezado: «Beta: estamos mejorando el sistema. Contanos qué te trabó». El enlace abre un formulario interno que guarda la URL y el rol. No sale nada a internet.
- **Referencia:** [GOV.UK, Phase banner](https://design-system.service.gov.uk/components/phase-banner).
- **Impacto:** bajo. **Esfuerzo:** S.

---

## C. Bandejas de firma, aprobación y despacho

### 10. Firma en serie con progreso, «saltear» y resumen final
- **Problema:** `/firma-en-serie` (en `rutas_circuito.py`) redirige nota por nota a `?serie=1`, y existe la `.banda-serie`. Sin embargo, el Director no ve cuántas lleva ni cuántas le faltan. Tampoco puede dejar una para después sin salir de la serie.
- **Propuesta:**
  - En la banda: «Firmando 4 de 12 · quedan 8 · 2 URGENTES».
  - Botones «Firmar y seguir» (primario), «Saltear por ahora» y «Volver a corregir».
  - En `firma_terminada.html`: un resumen «Firmaste 11 · salteaste 1 · devolviste 0», con enlace a la salteada y la opción de deshacer la última firma mientras Mesa no la haya despachado.
- **Referencia:** [NN/g, Bulk Actions: 3 Design Guidelines](https://www.nngroup.com/videos/bulk-actions-design-guidelines/) (retroalimentación clara y deshacer).
- **Impacto:** alto. **Esfuerzo:** M.

### 11. Vista dividida: lista a la izquierda, documento a la derecha
- **Problema:** en `index.html`, la tabla «Pendientes de tu firma» obliga a entrar a cada nota y volver. Las pantallas de Dirección son anchas y desaprovechan espacio.
- **Propuesta:** en pantallas de 1280 px o más, al elegir una fila se carga el resumen y la vista previa en un panel derecho con `hx-get="/nota/{id}/fragmento"`. Las teclas J/K, que ya existen, mueven la selección y F firma. En pantallas angostas se mantiene el comportamiento actual.
- **Referencia:** [SAP Fiori, Approval app (maestro y detalle)](https://experience.sap.com/fiori-design-web/v1-32/approval-app) y [htmx, ejemplos](https://htmx.org/examples/).
- **Impacto:** alto. **Esfuerzo:** M.

### 12. Estado «bandeja en cero» que diga qué sigue
- **Problema:** en `index.html` aparece «No hay documentos esperando tu firma.» y nada más. El estado vacío no aprovecha para orientar.
- **Propuesta:** «Estás al día ✓. En corrección automática: 3 (la próxima en unos 4 min). Por vencer esta semana: 2.» Cada dato lleva su enlace. Para el asesor: «Nada pendiente. ¿Subir un documento?».
- **Referencia:** [NN/g, Empty State Interface Design](https://nngroup.com/articles/empty-state-interface-design).
- **Impacto:** medio. **Esfuerzo:** S.

### 13. Bandeja ordenada por urgencia real, con cortes visibles
- **Problema:** el orden actual es prioridad más antigüedad. Los plazos aparecen como chip dentro de la celda «Archivo» (`semaforo(nota)`), mezclados con otros cinco chips.
- **Propuesta:** separadores de grupo fijos: «Vence hoy», «Vence esta semana», «URGENTES sin plazo» y «Resto». Se reutiliza el mecanismo de `fila-grupo` que ya existe en `index.html`.
- **Referencia:** [NN/g, Data Tables](https://nngroup.com/articles/data-tables).
- **Impacto:** alto. **Esfuerzo:** S.

### 14. «Volver a corregir» con motivos frecuentes
- **Problema:** devolver una nota pide texto libre. Las mismas observaciones se escriben una y otra vez, por ejemplo «falta el LPU», «fecha mal», «destinatario» o «firma de la Subdirectora». El asesor recibe textos con formatos muy distintos.
- **Propuesta:** chips de motivos frecuentes, que se pueden marcar varios, más un campo de texto opcional. El asesor ve la devolución como una lista de verificación que tilda a medida que corrige. Los motivos alimentan el «aprendizaje», que ya existe.
- **Referencia:** [GOV.UK, Error message](https://design-system.service.gov.uk/components/error-message) (mensajes específicos y accionables).
- **Impacto:** medio. **Esfuerzo:** M.

### 15. Aviso visible de quién firma hoy
- **Problema:** la Subdirectora tiene las mismas facultades que el Director y la firma depende de quién está logueado. Ninguna pantalla aclara a quién le va a llegar una nota cuando una de las dos personas está de licencia, aunque `ausencias` existe.
- **Propuesta:** un banner informativo en la bandeja de Coordinación y en la de Dirección: «Del 18 al 22/11 firma la Subdirectora (el Director está de licencia)».
- **Referencia:** [GOV.UK, Notification banner](https://design-system.service.gov.uk/components/notification-banner).
- **Impacto:** medio. **Esfuerzo:** S.

### 16. Mesa de Entradas: cada bloque como lista de tareas
- **Problema:** en `index.html` (bloques de Mesa), cada bloque muestra un chip «Listo para despachar» o «Faltan firmar N» y tres botones sueltos. Los pasos reales son: firmados, números cargados, descargado y despachado. No se ve en qué paso está cada bloque.
- **Propuesta:** cada tarjeta lleva una lista de tareas con su estado: «Firmas: 4/4 ✓», «Números: falta cargar», «Descarga: hecha», «Despacho: pendiente». El botón primario es siempre el próximo paso. Lo que todavía no se puede hacer se muestra deshabilitado con su motivo.
- **Referencia:** [GOV.UK, Task list](https://design-system.service.gov.uk/components/task-list).
- **Impacto:** alto. **Esfuerzo:** M.

### 17. Aprobación por lote para Coordinación
- **Problema:** la barra `.barra-bloque` sirve para armar bloques, cambiar la prioridad y enviar a Coordinación. Coordinación, en cambio, aprueba de a una.
- **Propuesta:** casilla «seleccionar todos los visibles» y una barra contextual con «Aprobar y enviar a corrección (N)». Se confirma una sola vez, con la lista de nombres, y después se puede deshacer con el mecanismo de `aviso-deshacer`. La firma sigue siendo de a una: la responsabilidad del Director no cambia.
- **Referencia:** [NN/g, Bulk Actions](https://www.nngroup.com/videos/bulk-actions-design-guidelines/).
- **Impacto:** medio. **Esfuerzo:** M.

---

## D. Formularios

### 18. Resumen de errores arriba y error junto a cada campo
- **Problema:** los errores del servidor llegan como `mostrarAviso` flotante, definido en `base.html`, o como `HTTPException` con `detail`. No queda marcado qué campo falló. Para lectores de pantalla y para personas poco técnicas, eso significa tener que adivinar.
- **Propuesta:** un macro `error_resumen(errores)` al principio del formulario, con enlaces a cada campo, que reciba el foco al cargar. En cada campo, un mensaje en rojo con `aria-describedby`. Ejemplos de texto: «Ingresá el DNI sin puntos», «Elegí la unidad de destino».
- **Referencia:** [GOV.UK, Error summary](https://design-system.service.gov.uk/components/error-summary) y [GOV.UK, patrón de validación](https://design-system.service.gov.uk/patterns/validation).
- **Impacto:** alto. **Esfuerzo:** M.

### 19. Los avisos de error no se borran solos
- **Problema:** en `base.html`, `mostrarAviso` elimina todos los avisos a los 9 segundos (`setTimeout(..., 9000)`), también los de error. Quien lee despacio o se distrae pierde el motivo del fallo.
- **Propuesta:** el aviso verde de éxito puede desaparecer. Los de error y de atención quedan fijos hasta que se cierran con su botón «Cerrar». Los avisos de una acción importante, como «Nota firmada», se muestran como banner en la página siguiente.
- **Referencia:** [GOV.UK, Notification banner](https://design-system.service.gov.uk/components/notification-banner) y [WCAG 2.2, novedades](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/). El tiempo suficiente es el criterio 2.2.1.
- **Impacto:** alto. **Esfuerzo:** S.

### 20. Validación en línea con htmx al salir del campo
- **Problema:** el DNI o LPU repetido, el número de nota ya usado por Mesa o la unidad inexistente recién se detectan al enviar el formulario.
- **Propuesta:** `hx-post="/validar/dni" hx-trigger="change"` en los campos clave (DNI, LPU, número de nota y expediente). Muestra «Ya existe: Juan Pérez, CPF I» con enlace a la ficha. Sin JS, el formulario funciona igual.
- **Referencia:** [htmx, ejemplos (inline validation)](https://v1.htmx.org/examples/).
- **Impacto:** medio. **Esfuerzo:** M.

### 21. «Solicitar viaje» en pasos, con revisión antes de enviar
- **Problema:** el viaje junta circuito, destino o destinos, fecha, horas, participantes, modalidad por participante y motivo. En una sola pantalla larga, quien lo usa poco se pierde. Unas 200 personas usan Autos PPN.
- **Propuesta:** tres pasos: ¿adónde y cuándo?, ¿quiénes van? y ¿cómo viajan? Al final, una pantalla «Revisá antes de enviar», con «Cambiar» al lado de cada dato. Se mantiene «Viaje frecuente» como atajo para cargarlo en un paso.
- **Referencia:** [GOV.UK, Check answers](https://design-system.service.gov.uk/patterns/check-answers) y [Question pages](https://design-system.service.gov.uk/patterns/question-pages).
- **Impacto:** alto. **Esfuerzo:** M.

### 22. Fechas en formato argentino y atajos
- **Problema:** en `index.html`, `traslados.html` y `detenidos.html` las fechas se arman a mano con cortes como `fecha[8:10]/fecha[5:7]`. El formato cambia de pantalla en pantalla (con año y sin año, con día de la semana y sin él). Además, `input type=date` depende del idioma del navegador.
- **Propuesta:** un filtro Jinja único, `|fecha_corta`, que muestre por ejemplo «lun 16/11», y `|fecha_larga` para «16/11/2026 10:20». En los formularios, junto al campo, chips «Hoy», «Mañana» y «Próximo lunes».
- **Referencia:** [GOV.UK, Dates](https://design-system.service.gov.uk/patterns/dates) y [Date input](https://design-system.service.gov.uk/components/date-input).
- **Impacto:** medio. **Esfuerzo:** S.

### 23. Autocompletar accesible para unidades, personas y agentes
- **Problema:** «Unidad» en `traslados.html` y «Centro de detención» en `detenidos.html` son `<select>` con todo el catálogo de unidades penales. Encontrar «CPF I Ezeiza» en una lista larga es lento, sobre todo en el celular.
- **Propuesta:** un combobox que filtre mientras se escribe, por sigla, ciudad o provincia, y que priorice las unidades más usadas por el equipo. Debe ser una mejora progresiva sobre el `<select>`: sin JS sigue andando. Se puede copiar `accessible-autocomplete` al proyecto o escribir uno chico siguiendo el patrón de ARIA.
- **Referencia:** [alphagov/accessible-autocomplete](https://github.com/alphagov/accessible-autocomplete/blob/main/CHANGELOG.md) y [WAI-ARIA APG, Combobox](https://w3.org/WAI/ARIA/apg/patterns/combobox).
- **Impacto:** alto. **Esfuerzo:** M.

### 24. Subida de documentos con vista previa de lo que va a pasar
- **Problema:** en `index.html` (`#form-subida`), el texto explica que los PDF se archivan sin corrección ni firma, pero recién se sabe qué pasó con cada archivo después de subirlo. El bloque `campo-agrupar` aparece solo con dos o más archivos.
- **Propuesta:** al elegir los archivos, mostrar una lista antes de subir:
  - «Nota_X.docx → corrección y firma»
  - «Constancia.pdf → archivo directo (adjunto)»

  Cada archivo lleva su botón para quitarlo, y hay una barra de progreso por archivo. El aviso de duplicados, que ya existe, se integra en esa misma lista.
- **Referencia:** [NN/g, Progress Indicators](https://www.nngroup.com/videos/progress-indicators/).
- **Impacto:** medio. **Esfuerzo:** M.

### 25. Protección contra pérdida de cambios y «Guardado hace 1 min»
- **Problema:** los párrafos editables (`.parrafo-editable`), las observaciones y los formularios largos se pierden si se cierra la pestaña o si vence la sesión por inactividad (el bloque `aviso-inactividad` de `base.html`).
- **Propuesta:** guardar el borrador en el servidor cada 30 segundos o al salir de un párrafo, con un indicador discreto «Guardado 10:42». Usar `beforeunload` solo si hay cambios sin guardar. Antes del cierre por inactividad, guardar lo pendiente.
- **Referencia:** [NN/g, Indicators, Validations, and Notifications](https://nngroup.com/articles/indicators-validations-notifications).
- **Impacto:** alto. **Esfuerzo:** M.

### 26. No pedir dos veces lo mismo
- **Problema:** al cargar viajes o actividades de Delegaciones, el asesor repite destino, compañeros y horarios todas las semanas. Los «viajes frecuentes» resuelven una parte, pero solo si alguien los armó antes.
- **Propuesta:** en la ficha de un viaje realizado, un botón «Repetir este viaje» que abre el formulario precargado. En el formulario, «Últimos usados» como chips para destinos y personas.
- **Referencia:** [WCAG 2.2, 3.3.7 Redundant Entry](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/).
- **Impacto:** medio. **Esfuerzo:** S.

### 27. Diálogo del PIN más amable
- **Problema:** `dialogo-pin`, en `base.html`, usa `type=password` sin opción de ver lo escrito. El mensaje de error dice «PIN incorrecto.» y no indica cuántos intentos quedan ni qué hacer si se olvidó el PIN.
- **Propuesta:**
  - un botón «Mostrar» y permitir pegar;
  - el texto «Te quedan 2 intentos»;
  - un enlace «¿Te olvidaste el PIN? Pedí que lo reinicien en Administración»;
  - foco atrapado dentro del diálogo y retorno del foco al botón original al cerrar.
- **Referencia:** [WCAG 2.2, 3.3.8 Accessible Authentication](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/) y [WAI-ARIA APG, Dialog (Modal)](https://www.w3.org/WAI/ARIA/apg/patterns/dialogmodal/).
- **Impacto:** medio. **Esfuerzo:** S.

---

## E. Tablas y filtros

### 28. Filtros aplicados como chips removibles
- **Problema:** en `index.html` hay tres formas de filtrar: el panel plegable, el menú de cada columna (`menu_col`, con un «●» que casi no se ve) y las pestañas de tareas. Hay dos enlaces «Quitar filtros» casi seguidos, en las líneas 438 a 445. Además, con el panel cerrado no se ve qué filtro está activo.
- **Propuesta:** una franja fija encima de la tabla: «Filtrando por: Etapa: Firma ✕ · Equipo 3 ✕ · Desde 01/11 ✕ · Quitar todo». La franja sale de los mismos parámetros `f_*`. Se borra el segundo enlace duplicado.
- **Referencia:** [Baymard, How to design applied filters](https://baymard.com/blog/how-to-design-applied-filters) y [NN/g, Filters vs. Facets](https://www.nngroup.com/articles/filters-vs-facets/).
- **Impacto:** alto. **Esfuerzo:** S.

### 29. Filtrar sin el botón «Filtrar»
- **Problema:** `traslados.html` (agenda), `detenidos.html` e `index.html` (panel de filtros) piden tocar «Filtrar» después de cada cambio, y la página se recarga completa.
- **Propuesta:**
  - `hx-get` con `hx-trigger="change, keyup changed delay:400ms"`;
  - `hx-target` apuntando a la tabla y `hx-push-url="true"`, para que la URL siga siendo compartible y el botón Atrás funcione;
  - `<noscript>` con el botón actual.
- **Referencia:** [htmx, ejemplos (active search)](https://htmx.org/examples/).
- **Impacto:** medio. **Esfuerzo:** M.

### 30. Ordenamiento que se anuncia: `aria-sort`
- **Problema:** las columnas ordenables de `index.html` usan `<details>` con enlaces. El lector de pantalla no sabe por qué columna está ordenada la tabla, y no hay ningún `aria-sort` en el código.
- **Propuesta:** `aria-sort="ascending/descending"` en el `<th>` activo, un botón con el nombre de la columna como control de orden y una `caption` con «Ordenado por fecha, más nuevas primero».
- **Referencia:** [WAI-ARIA APG, Sortable Table](https://www.w3.org/WAI/ARIA/apg/example-index/table/sortable-table.html) y [MDN, aria-sort](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-sort).
- **Impacto:** medio. **Esfuerzo:** S.

### 31. Encabezado y primera columna fijos en tablas anchas
- **Problema:** `detenidos.html` tiene 10 columnas dentro de `.tabla-scroll`. Al desplazarse se pierden los títulos y el nombre de la persona.
- **Propuesta:** `position: sticky` en `thead th`, con `top` igual a la altura del encabezado, y en la primera columna. Sombra suave al desplazar. Revisar que no tape el foco (ver la propuesta 44).
- **Referencia:** [NN/g, Data Tables](https://nngroup.com/articles/data-tables) y [USWDS, Table: accessibility tests](https://designsystem.digital.gov/components/table/accessibility-tests).
- **Impacto:** medio. **Esfuerzo:** S.

### 32. Densidad y columnas a elección, guardadas en el perfil
- **Problema:** las tablas de Dirección y de Mesa tienen muchas columnas (Prioridad, Archivo, Tipo, Etapa, Tema, Asesor/equipo, Fecha y Actualizado). Cada perfil necesita otras. Hoy las preferencias van a `localStorage` (por ejemplo `agenda-colorear` o `notas-grupos-cerrados`) y se pierden al cambiar de PC.
- **Propuesta:** un menú «Columnas» con casillas y una opción de densidad «cómoda» o «compacta». Se guarda en la tabla de usuario, igual que los filtros guardados.
- **Referencia:** [NN/g, Data Tables](https://nngroup.com/articles/data-tables).
- **Impacto:** medio. **Esfuerzo:** M.

### 33. Menos chips en la celda «Archivo»
- **Problema:** en las líneas 500 a 506 de `index.html`, la celda puede juntar hasta seis marcas: bloque, alertas de la IA, plazo, posible duplicado, Solo Mesa y respuesta. Cada una tiene su color, lo que se vuelve ruido visual y compite con el nombre del documento.
- **Propuesta:** una columna «Atención» con un solo indicador del problema más grave (ícono, texto corto y color semántico) más «+2». El detalle se ve al pasar el cursor o en la ficha. El nombre del documento queda limpio.
- **Referencia:** [NN/g, Indicators, Validations, and Notifications](https://nngroup.com/articles/indicators-validations-notifications) y [argentina.gob.ar, Alertas](https://www.argentina.gob.ar/node/483816).
- **Impacto:** alto. **Esfuerzo:** M.

### 34. Tiempos relativos más fecha exacta
- **Problema:** «Esperando desde» y «Actualizado» (`|hora`) muestran la hora sin el tiempo transcurrido, que es lo que importa para priorizar.
- **Propuesta:** «hace 3 días» en el texto, con `<time datetime>` y `title` que muestren «12/11/2026 10:20». A partir de cierto umbral se aplica el color de antigüedad que ya existe (`antiguedad--nivel`).
- **Referencia:** [GOV.UK, Dates](https://design-system.service.gov.uk/patterns/dates).
- **Impacto:** medio. **Esfuerzo:** S.

### 35. Exportar exactamente lo que estoy viendo
- **Problema:** `detenidos.html` exporta toda la base (`/detenidos/exportar.xlsx`), pero no el resultado de la búsqueda. En Notas no hay exportación del listado filtrado.
- **Propuesta:** un botón «Exportar esta vista (37 filas)» que respete los filtros, el orden y las columnas visibles. La exportación de toda la base queda para administración, dentro de «Más acciones».
- **Referencia:** [NN/g, Data Tables](https://nngroup.com/articles/data-tables).
- **Impacto:** medio. **Esfuerzo:** S.

### 36. Búsqueda de personas detenidas: la regla dentro del formulario
- **Problema:** en `detenidos.html`, la regla «con DNI o LPU alcanza un dato; si no, al menos dos» aparece en un párrafo debajo de nueve campos. Si no se cumple, recién se entera después de buscar.
- **Propuesta:**
  - Separar en dos bloques: «Búsqueda rápida» (DNI o LPU, un campo grande) y «Por nombre y otros datos».
  - Mostrar un contador en vivo: «Completaste 1 de 2 datos».
  - Ignorar acentos y mayúsculas.
- **Referencia:** [GOV.UK, Question pages](https://design-system.service.gov.uk/patterns/question-pages) (pistas junto al campo) y [ANDIS, Lenguaje claro](https://argentina.gob.ar/sites/default/files/2023/12/6_lenguaje_claro.pdf).
- **Impacto:** medio. **Esfuerzo:** S.

---

## F. Búsqueda global y paleta de comandos

### 37. Paleta de comandos con Ctrl+K y «/»
- **Problema:** «/» solo enfoca «Buscar en las notas…», y el buscador del encabezado aparece únicamente con acceso a Notas (`{% if notas_ok %}` en `base.html`). Las personas que solo usan Autos PPN, unas 200, no tienen búsqueda global ni acceso rápido a acciones.
- **Propuesta:** una paleta, con un `<dialog>` y el patrón combobox, que busque en el servidor (fragmento htmx) en cuatro grupos: Notas, Viajes, Personas detenidas y Unidades. Además ofrece acciones según el permiso: «Solicitar viaje», «Firmar en serie», «Subir documentos» o «Ir a Despacho del día». No se envía nada a terceros.
- **Referencia:** [SaaS UI, Search & command palette patterns](https://www.saasui.design/blog/saas-search-command-palette-ux-patterns) y [WAI-ARIA APG, Combobox](https://w3.org/WAI/ARIA/apg/patterns/combobox).
- **Impacto:** alto. **Esfuerzo:** M.

### 38. Resultados de búsqueda agrupados y «sin resultados» útil
- **Problema:** `buscar.html` busca solo en notas, y los estados vacíos de la aplicación son texto gris (`.estado-vacio`).
- **Propuesta:** agrupar por tipo, con contador por grupo y «ver todos». Si no hay resultados: «No encontramos “Gonzales”. ¿Quisiste decir “González”? · Buscar también en el histórico · Buscar en expedientes».
- **Referencia:** [NN/g, Empty State Interface Design](https://nngroup.com/articles/empty-state-interface-design).
- **Impacto:** medio. **Esfuerzo:** S.

---

## G. Mensajes, confirmaciones y deshacer

### 39. Confirmar solo lo irreversible, con botones que digan qué hacen
- **Problema:** `confirmacion-inline`, en `base.html`, siempre ofrece «Sí, seguir / No». Se usa tanto para quitar un filtro guardado (`index.html`) como para despachar un bloque completo. Cuando todo pide confirmación, la gente confirma sin leer.
- **Propuesta:** sin confirmación, pero con «Deshacer» (usando `aviso-deshacer`, que ya existe), para todo lo reversible: filtros, prioridad o marcar como leído. Con confirmación, solo lo irreversible. En esos casos el botón nombra la acción, por ejemplo «Sí, despachar el bloque “Unidad 9”», y «Cancelar» queda separado y en estilo secundario.
- **Referencia:** [NN/g, Confirmation Dialogs](https://www.nngroup.com/articles/confirmation-dialog/), [NN/g, Proximity of Consequential Options](https://www.nngroup.com/articles/proximity-consequential-options/) y [argentina.gob.ar, Botones](https://www.argentina.gob.ar/contenidosdigitales/markdown/boton) (el texto empieza con un verbo y el rojo queda para lo irreversible).
- **Impacto:** alto. **Esfuerzo:** S.

### 40. Lenguaje claro en la interfaz: glosario y sin códigos internos
- **Problema:**
  - En la línea 257 de `index.html` se muestran estados crudos (`bn.estado`, como «FIRMADA» o «PARA_REMITIR»).
  - En `traslados.html` aparecen abreviaturas como «s/h», «Expte.» y «LPU».
  - Hay mayúsculas sostenidas, como «URGENTE».
  - Algunas frases son largas; un ejemplo es la ayuda de subida de documentos.
- **Propuesta:**
  - Una tabla única `ETIQUETAS_ESTADO` para todo estado visible.
  - `<abbr title>` para las siglas, más un glosario en Ayuda.
  - «sin horario» en lugar de «s/h».
  - Frases de menos de 30 palabras, en voz activa y dirigidas a la persona («Subí el Word; el PDF se archiva solo»).
  - Una revisión de textos con la ficha de ANDIS como lista de control.
- **Referencia:** [ANDIS, ficha «Lenguaje claro» (argentina.gob.ar)](https://argentina.gob.ar/sites/default/files/2023/12/6_lenguaje_claro.pdf), [GOV.UK, Writing for user interfaces](https://gov.uk/service-manual/design/writing-for-user-interfaces) y la [Guía de lenguaje claro (GCBA)](https://lenguajeclaro.jusbaires.gob.ar/app/uploads/2022/11/GUIA_DE_LENGUAJE_CLARO-Gobierno-CABA.pdf).
- **Impacto:** alto. **Esfuerzo:** S.

### 41. Errores del servidor que explican qué hacer
- **Problema:** `htmx:responseError` muestra `detail` tal como llega, por ejemplo «La nota todavía no tiene documento firmado» o «No se pudo completar la acción.». Cuando hay un conflicto porque otra persona ya actuó, no se ofrece salida.
- **Propuesta:** un catálogo de mensajes en tres partes: qué pasó, por qué y qué podés hacer. Por ejemplo: «Esta nota ya la firmó la Subdirectora a las 10:42. [Ver la nota] [Volver a la bandeja]». En los 409 se agrega el botón «Actualizar». En los 500, un código corto para soporte (`Ref. 7F3A`).
- **Referencia:** [GOV.UK, Error message](https://design-system.service.gov.uk/components/error-message).
- **Impacto:** alto. **Esfuerzo:** S.

### 42. Avisos que se abren en la misma pestaña, agrupados y con acción
- **Problema:** en `notificaciones.html`, cada aviso se abre con `target="_blank"`. Se acumulan pestañas y el lector de pantalla no lo anticipa. Los avisos son una lista plana sin agrupar.
- **Propuesta:**
  - abrir en la misma pestaña;
  - agrupar por «Hoy», «Ayer» y «Esta semana»;
  - separar «Te toca actuar» de «Para que sepas»;
  - incluir la acción directa en el aviso («Firmar», «Confirmar viaje»).
- **Referencia:** [SAP Fiori, Notification Center](https://www.sap.com/design-system/fiori-design-web/v1-145/ui-elements/notification-center/usage) y [NN/g, Indicators, Validations, and Notifications](https://nngroup.com/articles/indicators-validations-notifications).
- **Impacto:** medio. **Esfuerzo:** S.

### 43. Aviso de cierre de sesión que recibe el foco y guarda antes
- **Problema:** `aviso-inactividad`, en `base.html`, aparece con `hidden=false`, pero el foco no se mueve al botón «Seguir conectado». Al vencer, la página redirige a `/login` sin guardar lo que se estaba escribiendo.
- **Propuesta:** al mostrarse, el aviso mueve el foco al botón y lo anuncia. Antes de redirigir, envía los borradores pendientes (propuesta 25). Después del login, vuelve a la misma pantalla con «Recuperamos tu borrador».
- **Referencia:** [DWP Design System, Manage a session timeout](https://f-new-site.design-system.dwp.gov.uk/patterns/manage-a-session-timeout/examples/timedout-nojs/nunjucks).
- **Impacto:** medio. **Esfuerzo:** S.

---

## H. Accesibilidad y teclado

### 44. Que el foco nunca quede tapado por barras fijas
- **Problema:** en `estilos.css`, `.encabezado` es sticky arriba. `.barra-firma` y `.banda-serie` son sticky a 76 px, y `.barra-accion` y `.barra-lote-usuarios` son sticky abajo. Al recorrer con Tab, el elemento enfocado puede quedar debajo de alguna de esas barras.
- **Propuesta:** `html { scroll-padding-top: calc(var(--alto-encabezado) + 60px); scroll-padding-bottom: 80px; }` en las páginas con barras. Probarlo con teclado en la nota, la firma en serie y la administración de usuarios.
- **Referencia:** [WCAG 2.2, 2.4.11 Focus Not Obscured (AA)](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/).
- **Impacto:** alto. **Esfuerzo:** S.

### 45. Tamaño mínimo de lo que se toca
- **Problema:** las casillas de selección de las tablas, la «✕» de filtro guardado (`.filtro-guardado__x`), los `chip-select` de prioridad y algunos enlaces chicos dentro de las celdas quedan por debajo de 24 × 24 px. En tablet, para los choferes, se necesitan unos 44 px.
- **Propuesta:** como mínimo 24 px en todo control. Con `@media (pointer: coarse)`, 44 px de alto en botones, casillas y filas tocables. Como contraparte, más separación entre acciones cercanas que tengan consecuencias distintas.
- **Referencia:** [WCAG 2.2, 2.5.8 Target Size (AA)](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/) y [NN/g, Touch Target Size](https://www.nngroup.com/articles/touch-target-size/).
- **Impacto:** alto. **Esfuerzo:** S.

### 46. Atajos de una tecla que se pueden apagar
- **Problema:** en `base.html` (reforma 36), las teclas `a`, `f`, `c`, `d`, `j` y `k` disparan acciones sin modificador; una de ellas es «Firmar». Una persona que usa reconocimiento de voz, o que teclea por error fuera de un campo, puede firmar o devolver sin querer.
- **Propuesta:** un interruptor en «Mi perfil»: «Atajos de una tecla: activados / desactivados», que venga desactivado salvo para Dirección y Mesa. En el caso de `f`, el atajo lleva al botón de firma y lo enfoca, pero no lo ejecuta: se confirma con Enter.
- **Referencia:** [W3C, Understanding 2.1.4 Character Key Shortcuts](https://www.w3.org/WAI/WCAG21/Understanding/character-key-shortcuts).
- **Impacto:** alto. **Esfuerzo:** S.

### 47. Ayuda siempre en el mismo lugar
- **Problema:** «Ayuda» está al final del menú lateral, y en el celular queda escondida detrás del botón de menú. Las ayudas de cada pantalla («?» plegables) cambian de lugar según la página.
- **Propuesta:** un botón «?» fijo en el encabezado, junto a Avisos, que abra la sección del manual correspondiente a la ruta actual (`/manual#autos-solicitar`). Las ayudas plegables siempre van debajo del `h1`.
- **Referencia:** [WCAG 2.2, 3.2.6 Consistent Help](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/) y [NN/g, Help and Documentation](https://www.nngroup.com/articles/help-and-documentation/).
- **Impacto:** medio. **Esfuerzo:** S.

### 48. Filas clicables sin trampas de teclado
- **Problema:** `tr[data-href]` (en `interfaz.js`) hace clicable toda la fila, pero dentro de la fila hay `select` de prioridad, casillas y enlaces. Al teclado, la fila no es un objetivo, y los clics sobre los controles internos pueden competir con el de la fila.
- **Propuesta:** que el enlace accesible sea el nombre del documento, dentro de la celda «Archivo». El resto de la fila se vuelve clicable solo con mouse (usando `::after` en el enlace), y los controles internos detienen la propagación del clic. La columna «Abrir», que hoy es redundante, se elimina.
- **Referencia:** [Carbon, Data table: accessibility](https://carbondesignsystem.com/components/data-table/accessibility/) y [USWDS, Table: accessibility tests](https://designsystem.digital.gov/components/table/accessibility-tests).
- **Impacto:** medio. **Esfuerzo:** S.

### 49. Modo oscuro con selector visible y documento siempre «papel»
- **Problema:** el tema se elige en «Mi perfil» y se guarda en `localStorage`. Además, hay bloques que fijan colores claros dentro del modo oscuro, como `.alerta-reapertura` (`#7A5518` sobre un fondo de atención). En oscuro, la vista previa del documento no se parece al Word que se firma.
- **Propuesta:**
  - un selector de tres estados en el menú del perfil del encabezado («Como el sistema / Claro / Oscuro»);
  - guardar la preferencia en el servidor;
  - la vista previa del documento (`.caja-vista-previa`) siempre en fondo blanco con texto negro, como una hoja;
  - una pasada de contraste sobre chips y etiquetas en oscuro.
- **Referencia:** [NN/g, Dark Mode: How Users Think About It and Issues to Avoid](https://nngroup.com/articles/dark-mode-users-issues).
- **Impacto:** medio. **Esfuerzo:** S.

### 50. No depender solo del color en la agenda
- **Problema:** en `traslados.html`, «Colorear por equipo» o «por circuito» asigna ocho colores (`--cat-1…8`) al borde izquierdo de cada viaje. Con más de ocho equipos, los colores se repiten. Las personas con daltonismo, y la impresión en blanco y negro, no los distinguen.
- **Propuesta:** sumar las iniciales del equipo en una pastilla dentro de la tarjeta («E3») y una leyenda con texto. En `forced-colors`, que ya tiene reglas, el estado se lee por el texto (`viaje__estado`) y no por el borde.
- **Referencia:** [argentina.gob.ar, Alertas](https://www.argentina.gob.ar/node/483816) (el color es significado, no adorno) y [Ley 26.653 y pautas de accesibilidad, seminario ONTI](https://argentina.gob.ar/sites/default/files/seminario_accesibilidad_tic_onti.pdf).
- **Impacto:** medio. **Esfuerzo:** S.

---

## I. Celular y tablet para choferes

### 51. «Mis salidas» pensada primero para el celular
- **Problema:** en `traslados_hoy.html`, el chofer ve el encabezado con «Día anterior / Día siguiente», las vistas de Autos y las tarjetas `dia-viaje` con datos en texto chico (hora, destino, participantes). No tiene botones para registrar la salida ni la vuelta: los horarios reales los cargan otras personas.
- **Propuesta:** una tarjeta grande por salida con:
  - hora en letra grande, destino o destinos en orden y cantidad de pasajeros;
  - dirección de la unidad en texto;
  - teléfono con `tel:` para llamar con un toque;
  - dos botones de 48 px: «Salí» y «Volví», que guardan la hora real.

  La navegación entre días queda en una sola fila de chips: «Hoy», «Mañana» y «Semana».
- **Referencia:** [NN/g, Touch Target Size](https://www.nngroup.com/articles/touch-target-size/).
- **Impacto:** alto. **Esfuerzo:** M.

### 52. Barra inferior en el celular para los choferes
- **Problema:** en un teléfono, el menú lateral se abre con la hamburguesa (`#abrir-lateral`), que queda arriba a la izquierda, fuera del alcance del pulgar. El chofer usa solo tres pantallas.
- **Propuesta:** con `@media (max-width: 720px)` y rol CHOFER, mostrar una barra fija abajo con tres íconos y su texto: «Hoy», «Semana» y «Avisos». El menú completo queda en «Más».
- **Referencia:** [NN/g, Touch Target Size](https://www.nngroup.com/articles/touch-target-size/).
- **Impacto:** medio. **Esfuerzo:** S.

### 53. Instalable y con lectura sin señal (PWA local)
- **Problema:** en la ruta (Ezeiza, Marcos Paz) la señal es mala. Si la página no carga, el chofer no ve a quién busca ni adónde va.
- **Propuesta:** un `manifest.webmanifest` y un service worker propios, servidos desde el sistema y sin servicios de terceros, que:
  - guarden «Mis salidas» de hoy y mañana para leerlas sin conexión;
  - encolen «Salí» y «Volví» y los envíen cuando vuelva la señal, con el aviso «Pendiente de enviar».

  Requiere HTTPS interno, que ya está previsto en `https_interno.py`.
- **Referencia:** [MDN, Making PWAs installable](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Installable_PWAs) y [MDN, Progressive web apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps).
- **Impacto:** medio. **Esfuerzo:** L.

### 54. Agenda semanal legible en pantallas chicas
- **Problema:** la `.agenda` de `traslados.html` es una grilla de siete días con tarjetas densas (grupos por equipo, chips de salida, plazas libres). En un teléfono o una tablet chica se vuelve una columna interminable.
- **Propuesta:** en pantallas angostas, mostrar un solo día por vez con chips de día («L 16 · M 17 · …»), con el día de hoy elegido por defecto y el contador de viajes en cada chip. Los detalles de equipos y pasajeros se pliegan.
- **Referencia:** [NN/g, Data Tables](https://nngroup.com/articles/data-tables) (adaptar la densidad al dispositivo).
- **Impacto:** medio. **Esfuerzo:** M.

---

## J. Notificaciones

### 55. Insignias que cuentan solo lo que pide acción
- **Problema:** la insignia de Avisos, que aparece dos veces (en el menú lateral y en el encabezado de `base.html`), cuenta todo lo no leído, también lo puramente informativo. Con el tiempo, la gente deja de mirarla.
- **Propuesta:** la insignia roja cuenta solo «te toca actuar». Lo informativo se ve en la lista sin insignia. Cada sección del menú lleva su propio contador de acciones pendientes («Notas a la firma 5»). Se elimina la insignia duplicada del menú en escritorio.
- **Referencia:** [NN/g, Indicators, Validations, and Notifications](https://nngroup.com/articles/indicators-validations-notifications).
- **Impacto:** medio. **Esfuerzo:** S.

### 56. Resumen al entrar, sin correo
- **Problema:** el organismo decidió no vincular el sistema con correo ni celular por ahora. Entonces, la primera pantalla del día es el único momento para ponerse al tanto.
- **Propuesta:** en el primer ingreso del día, un banner arriba de Inicio: «Desde ayer: 3 notas nuevas para firmar, 1 devuelta, 2 viajes confirmados». Se cierra con «Entendido» y no vuelve hasta el día siguiente.
- **Referencia:** [GOV.UK, Notification banner](https://design-system.service.gov.uk/components/notification-banner).
- **Impacto:** medio. **Esfuerzo:** S.

---

## K. Ayuda contextual y primeros pasos

### 57. Primer ingreso guiado por rol, salteable
- **Problema:** unas 270 personas, muchas no técnicas, entran por primera vez a un sistema con dos módulos, PIN y circuito de cuatro etapas. Hoy aterrizan en Inicio o en Autos sin orientación.
- **Propuesta:** una lista de primeros pasos en Inicio que se puede cerrar. Para un asesor: «Subí tu primer documento · Mirá el video de 1 minuto · Elegí tu foto». Para Dirección: «Creá tu PIN · Probá Firmar en serie». Cada ítem se tilda solo al completarse. Nada de recorridos con globos que tapan la pantalla.
- **Referencia:** [NN/g, Onboarding Tutorials](https://www.nngroup.com/articles/onboarding-tutorials/).
- **Impacto:** medio. **Esfuerzo:** M.

### 58. «¿Qué significa?» en etapas y estados
- **Problema:** en `index.html`, la etapa se muestra como «2/4 Coordinación», con chips de estado y de antigüedad. Quien recién llega no sabe qué falta ni quién tiene la nota.
- **Propuesta:** al tocar la etapa, un popover accesible (un `<details>` o el atributo `popover`) que explique: «Etapa 2 de 4: la revisa tu coordinación. Después pasa a corrección y a firma. Hace 3 días que está acá.» Incluye un enlace a la sección del manual.
- **Referencia:** [NN/g, Help and Documentation](https://www.nngroup.com/articles/help-and-documentation/) y [USWDS, Process list](https://designsystem.digital.gov/components/process-list).
- **Impacto:** medio. **Esfuerzo:** S.

### 59. «Qué cambió» después de cada versión
- **Problema:** el sistema se actualiza por tandas (Ola 1 a 6, Beta 01) y los cambios solo constan en el `README.md`. Las personas descubren las novedades por sorpresa.
- **Propuesta:** después de una versión nueva, un aviso único por persona con tres líneas filtradas por rol y el enlace «Ver todo». Los textos salen de un archivo `novedades.md` versionado.
- **Referencia:** [GOV.UK, Notification banner](https://design-system.service.gov.uk/components/notification-banner).
- **Impacto:** bajo. **Esfuerzo:** S.

---

## L. Rendimiento percibido

### 60. Indicadores de carga en botones y esqueletos en fragmentos
- **Problema:** `procesando.js` cambia el botón a «Procesando…», pero los fragmentos htmx, como `_estado_nota.html` con `hx-trigger="load delay:2s"`, aparecen de golpe y mueven la página.
- **Propuesta:** `hx-indicator` común en botones (spinner dentro del botón y `aria-busy`). Para fragmentos de más de 1 s, un esqueleto con la forma final, con alto reservado para que el contenido no salte. Respetar `prefers-reduced-motion`, que ya existe.
- **Referencia:** [NN/g, Skeleton Screens 101](https://nngroup.com/articles/skeleton-screens/) y [NN/g, Skeleton Screens vs. Progress Bars vs. Spinners](https://www.nngroup.com/videos/skeleton-screens-vs-progress-bars-vs-spinners/).
- **Impacto:** medio. **Esfuerzo:** S.

### 61. Cola de la IA con tiempo estimado
- **Problema:** en `index.html` («En corrección automática»), se informa «lugar 3 en la cola» pero no cuánto falta. Dirección termina pasando notas «sin corrección» por no saber si conviene esperar.
- **Propuesta:** «Lugar 3 · unos 6 min (promedio de hoy: 2 min por nota)», con una barra de progreso y la actualización del fragmento cada 30 s. Si la IA está en pausa porque hay gente usando el sistema, se dice explícitamente: «En pausa mientras hay uso; sigue a los 90 s sin uso».
- **Referencia:** [NN/g, Response Time](https://www.nngroup.com/topic/response-time/) y [NN/g, Progress Indicators](https://www.nngroup.com/videos/progress-indicators/).
- **Impacto:** medio. **Esfuerzo:** S.

### 62. Cambiar la prioridad sin recargar toda la página
- **Problema:** `cambiarPrioridad()`, en `base.html`, hace `fetch` y después `window.location.assign(window.location.href)`. Se recarga todo el listado, se pierde el desplazamiento y se cierran los grupos.
- **Propuesta:** `hx-post` en el `select` con `hx-target="closest tr"` y `hx-swap="outerHTML"`. El servidor devuelve solo la fila actualizada y el aviso «Prioridad cambiada · Deshacer».
- **Referencia:** [htmx, ejemplos (edit row, click to edit)](https://htmx.org/examples/).
- **Impacto:** medio. **Esfuerzo:** S.

### 63. Navegación con `hx-boost` y manejo del foco
- **Problema:** cada clic en el menú recarga la página completa, con todos sus scripts en línea (más de 300 líneas JS en `base.html`). En la PC del organismo y en Windows eso se nota.
- **Propuesta:** `hx-boost="true"` en el menú lateral y en las pestañas, con `hx-select="#contenido-principal"`. Después de cada cambio, mover el foco al `h1` y actualizar `<title>`. Los scripts de `base.html` pasan a `static/*.js`, para que el navegador los guarde en caché.
- **Referencia:** [htmx, documentación](https://v2-0v2-0.htmx.org/docs/) y [htmx, ejemplos](https://htmx.org/examples/).
- **Impacto:** medio. **Esfuerzo:** M.

---

## M. Consistencia visual con el portal PPN

### 64. Un solo botón primario y «Más acciones» en las cabeceras
- **Problema:** la cabecera de `detenidos.html` muestra hasta siete botones en fila: Nueva persona, Búsqueda colectiva, Importar, Cargas, Exportar Excel, Exportar CSV y Revisión. Además, el botón «Revisión» se vuelve primario cuando hay alertas, y quedan dos primarios. Eso contradice la regla del `README.md` («un solo botón primario por pantalla»).
- **Propuesta:** dejar un primario («Nueva persona»), uno o dos secundarios frecuentes, y el resto en un menú «Más acciones ▾». Las alertas de revisión van como aviso arriba de la tabla, no como un segundo botón primario.
- **Referencia:** [argentina.gob.ar, Botones](https://www.argentina.gob.ar/contenidosdigitales/markdown/boton) y [NN/g, Proximity of Consequential Options](https://www.nngroup.com/articles/proximity-consequential-options/).
- **Impacto:** medio. **Esfuerzo:** S.

### 65. Íconos con una sola fuente
- **Problema:** `base.html` define un macro `icono()` con un diccionario de SVG, mientras `inicio.html` repite los mismos SVG en línea (notas, autos, avisos) y además existe `ico()` en `iconos.py`. Esto genera trazos y tamaños desparejos y mantenimiento triple.
- **Propuesta:** un sprite SVG local (`static/iconos.svg`) con `<use href="#notas">` y un único macro `ico()`. La regla: todo ícono decorativo lleva `aria-hidden` y todo ícono solo, sin texto, lleva `aria-label`.
- **Referencia:** [argentina.gob.ar, Recuadros y alertas](https://www.argentina.gob.ar/node/483816) (íconos de una librería única, la de Poncho).
- **Impacto:** bajo. **Esfuerzo:** S.

### 66. La guía de estilo como catálogo vivo con estados y pautas
- **Problema:** existe `/guia-estilo`, pero en `estilos.css` (1859 líneas) conviven reglas viejas y nuevas, con `.boton--chico` definido dos veces (líneas 635 y 1061). Cada pantalla nueva tiende a inventar su clase (`.mesa-asignar`, `.filtros-direccion`, `.barra-lote-usuarios`).
- **Propuesta:** que cada componente de `/guia-estilo` muestre sus estados (normal, hover, foco, deshabilitado y error), sus variantes en claro y oscuro, cuándo usarlo y cuándo no, y su lista de accesibilidad. Pasar en limpio las reglas duplicadas. Sumar una prueba que avise si se agrega una clase nueva sin documentarla.
- **Referencia:** [DESY, sistema de diseño del Gobierno de Aragón](https://desy.aragon.es/desy-html), [USWDS, componentes](https://designsystem.digital.gov/components/overview/) y [Poncho](https://argob.github.io/poncho/).
- **Impacto:** medio. **Esfuerzo:** M.

### 67. Pie institucional y encabezado alineados al portal PPN
- **Problema:** no hay pie de página. Falta versión, contacto de soporte interno, declaración de accesibilidad y fecha de la última actualización. El portal y Mesa de Entradas (plantilla «Minimal») sí tienen una franja institucional.
- **Propuesta:** un pie fino con «Procuración Penitenciaria de la Nación · DGPDH · versión Beta 01 (14/11/2026) · Soporte: interno 1234 · Accesibilidad». La página de declaración de accesibilidad, interna, enumera lo que cumple y lo que no.
- **Referencia:** [Manual de identidad gráfica gob.mx](https://www.gob.mx/guias/grafica/v4/assets/documents/assets/documents/manual-de-uso.pdf), [Kit digital de Gobierno de Chile (Hacienda)](https://www.hacienda.cl/subsecretaria/noticias/subsecretaria-berner-encabezo-lanzamiento-de-kit-para-estandarizar-diseno-de) y [GOV.UK, Accessibility statement del Design System](https://design-system.service.gov.uk/accessibility-statement).
- **Impacto:** bajo. **Esfuerzo:** S.

---

## Orden sugerido para empezar

1. **Rápidas de alto impacto (S):**
   - 1 y 2: soberanía del frontend.
   - 19: errores que no desaparecen.
   - 28: chips de filtros.
   - 39: confirmaciones.
   - 40: lenguaje claro.
   - 41: errores accionables.
   - 44, 45 y 46: WCAG 2.2.
   - 13: bandeja por urgencia.
2. **Bandejas (M):** 5, 10, 11, 16 y 17.
3. **Formularios (M):** 18, 21, 23 y 25.
4. **Choferes:** 51 y 52 (M y S); después 53 (L).
5. **Búsqueda global:** 37.

## Fuentes consultadas (todas vistas durante esta investigación)

- **Poncho:** [documentación](https://argob.github.io/poncho/) (Bootstrap 3, colores semánticos `#242C4F`, `#c62828`, `#E7BA61` y `#2e7d33`), [Recuadros y alertas](https://www.argentina.gob.ar/node/483816), [Botones](https://www.argentina.gob.ar/contenidosdigitales/markdown/boton), [Estándares de contenidos](https://www.argentina.gob.ar/contenidosdigitales/estandares) y [Planificar y estructurar](https://www.argentina.gob.ar/node/482365).
- **Argentina, accesibilidad y lenguaje claro:**
  - [ANDIS, Lenguaje claro](https://argentina.gob.ar/sites/default/files/2023/12/6_lenguaje_claro.pdf)
  - [Guía de navegación accesible](https://argentina.gob.ar/sites/default/files/2024/10/guia_de_recomendaciones_para_navegacion_accesible_en_paginas_web.pdf)
  - [Seminario de accesibilidad TIC, ONTI](https://argentina.gob.ar/sites/default/files/seminario_accesibilidad_tic_onti.pdf)
  - [Guía de lenguaje claro GCBA](https://lenguajeclaro.jusbaires.gob.ar/app/uploads/2022/11/GUIA_DE_LENGUAJE_CLARO-Gobierno-CABA.pdf)
- **GOV.UK:** [Error summary](https://design-system.service.gov.uk/components/error-summary), [Error message](https://design-system.service.gov.uk/components/error-message), [Validation](https://design-system.service.gov.uk/patterns/validation), [Check answers](https://design-system.service.gov.uk/patterns/check-answers), [Question pages](https://design-system.service.gov.uk/patterns/question-pages), [Dates](https://design-system.service.gov.uk/patterns/dates), [Date input](https://design-system.service.gov.uk/components/date-input), [Task list](https://design-system.service.gov.uk/components/task-list), [Notification banner](https://design-system.service.gov.uk/components/notification-banner), [Phase banner](https://design-system.service.gov.uk/components/phase-banner), [Writing for user interfaces](https://gov.uk/service-manual/design/writing-for-user-interfaces) y [accessible-autocomplete](https://github.com/alphagov/accessible-autocomplete/blob/main/CHANGELOG.md).
- **USWDS:** [Table: accessibility tests](https://designsystem.digital.gov/components/table/accessibility-tests), [Process list](https://designsystem.digital.gov/components/process-list) y [Componentes](https://designsystem.digital.gov/components/overview/).
- **W3C:** [Novedades de WCAG 2.2](https://w3.org/WAI/standards-guidelines/wcag/new-in-22/), [2.1.4 Character Key Shortcuts](https://www.w3.org/WAI/WCAG21/Understanding/character-key-shortcuts), [APG Sortable Table](https://www.w3.org/WAI/ARIA/apg/example-index/table/sortable-table.html), [APG Combobox](https://w3.org/WAI/ARIA/apg/patterns/combobox) y [APG Dialog](https://www.w3.org/WAI/ARIA/apg/patterns/dialogmodal/).
- **Nielsen Norman Group:**
  - [Data Tables](https://nngroup.com/articles/data-tables)
  - [Filters vs. Facets](https://www.nngroup.com/articles/filters-vs-facets/)
  - [Bulk Actions](https://www.nngroup.com/videos/bulk-actions-design-guidelines/)
  - [Empty States](https://nngroup.com/articles/empty-state-interface-design)
  - [Skeleton Screens](https://nngroup.com/articles/skeleton-screens/)
  - [Progress Indicators](https://www.nngroup.com/videos/progress-indicators/)
  - [Response Time](https://www.nngroup.com/topic/response-time/)
  - [Confirmation Dialogs](https://www.nngroup.com/articles/confirmation-dialog/)
  - [Proximity of Consequential Options](https://www.nngroup.com/articles/proximity-consequential-options/)
  - [Dark Mode](https://nngroup.com/articles/dark-mode-users-issues)
  - [Indicators, Validations, Notifications](https://nngroup.com/articles/indicators-validations-notifications)
  - [Onboarding Tutorials](https://www.nngroup.com/articles/onboarding-tutorials/)
  - [Help and Documentation](https://www.nngroup.com/articles/help-and-documentation/)
  - [Touch Target Size](https://www.nngroup.com/articles/touch-target-size/)
- **Otros sistemas:** [Baymard, Applied filters](https://baymard.com/blog/how-to-design-applied-filters), [Carbon, Data table accessibility](https://carbondesignsystem.com/components/data-table/accessibility/), [SAP Fiori, Approval app](https://experience.sap.com/fiori-design-web/v1-30/approval-app), [SAP Fiori, Notification center](https://www.sap.com/design-system/fiori-design-web/v1-145/ui-elements/notification-center/usage), [SaaS UI, Command palette](https://www.saasui.design/blog/saas-search-command-palette-ux-patterns), [DWP, Session timeout](https://f-new-site.design-system.dwp.gov.uk/patterns/manage-a-session-timeout/examples/timedout-nojs/nunjucks), [DESY Aragón](https://desy.aragon.es/desy-html), [gob.mx, manual gráfico](https://www.gob.mx/guias/grafica/v4/assets/documents/assets/documents/manual-de-uso.pdf) y [Kit digital de Chile](https://www.hacienda.cl/subsecretaria/noticias/subsecretaria-berner-encabezo-lanzamiento-de-kit-para-estandarizar-diseno-de).
- **htmx y MDN:** [htmx, ejemplos](https://htmx.org/examples/), [htmx v1, ejemplos](https://v1.htmx.org/examples/), [htmx, Vendoring](https://four.htmx.org/essays/vendoring), [htmx, Instalación](https://four.htmx.org/docs/get-started/installation), [htmx v2, documentación](https://v2-0v2-0.htmx.org/docs/), [MDN, PWA instalables](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Installable_PWAs) y [MDN, aria-sort](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-sort).

**Notas sobre las fuentes:**
- La URL de documentación de Poncho y sus colores se tomaron de una ficha de [open-design.ai](https://open-design.ai/design-system-assets/locales/es/DESIGN-poncho.md), porque el acceso directo a GitHub estaba bloqueado en esta sesión.
- No se encontró un sistema de diseño nacional vigente de España. Se usó DESY, del Gobierno de Aragón, como referencia española abierta.
