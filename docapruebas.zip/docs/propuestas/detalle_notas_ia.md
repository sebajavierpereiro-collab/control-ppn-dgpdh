# dgpdh_web — Propuestas de mejora: Notas, IA local y Personas detenidas

Relevamiento hecho el 14/11/2026 sobre el código de `/home/claude/pc` (solo lectura) y fuentes abiertas consultadas en la web.

**Cómo leer cada bloque**

- **Problema en este sistema**: qué falla o falta hoy, y si ya hay algo parecido en el código (con el archivo).
- **Propuesta**: qué hacer, en concreto.
- **Referencia**: proyecto o documento abierto que sirve de modelo o se puede incorporar (URL vista en esta búsqueda).
- **Impacto**: alto / medio / bajo. **Esfuerzo**: S (días), M (1–3 semanas), L (más de un mes).
- **Reglas fijas**: IA solo local · nada sale al exterior automáticamente · la IA propone y decide una persona · no se borra nada físicamente.

Hay cuatro hallazgos del código que conviene mirar primero, porque son baratos de arreglar y hoy dan resultados flojos sin que se note: **#13** (fórmula de legibilidad en inglés), **#20** (sin `num_ctx`, Ollama recorta los pedidos largos), **#22** (`config.ini` usa `phi3:mini`) y **#33** (no se puede deshacer una unificación de fichas).

---

## A. Módulo de notas: circuito y gestión documental

### 1. Metadatos propios por tipo documental
- **Problema en este sistema:** `tipos_documentales.py` ya clasifica en 13 tipos (Oficio, Pedido de informe, Nota a persona detenida…), pero todas las notas tienen los mismos campos fijos. Datos como «organismo requerido», «persona detenida», «plazo pedido» o «juzgado» se vuelven a leer del texto cada vez (`agentes.entidades`, `nota_entidades`) y no se pueden corregir a mano en un solo lugar.
- **Propuesta:** definir, por tipo documental, una lista corta de campos (texto, fecha, número, vínculo a persona detenida, vínculo a unidad, vínculo a otra nota). Los asistentes proponen el valor leído del texto y quien lleva la nota lo confirma. Los filtros, la carpeta del caso y los indicadores leen esos campos.
- **Referencia:** campos personalizados de Paperless-ngx, con tipos Text, Date, Integer y Document Link — https://docs.paperless-ngx.com/usage ; tipos de metadatos por tipo de documento de Mayan EDMS — https://docs.mayan-edms.com/parts/features.html
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple (los asistentes proponen y una persona confirma).

### 2. Reglas «si pasa esto, proponé aquello», editables por la Dirección
- **Problema en este sistema:** las reglas de clasificación y prerrevisión están en el código (`agentes.py`, `analisis.prioridad_por_palabras`) o en `datos/temas.json`. Para sumar una regla («si el texto menciona *huelga de hambre*, proponer URGENTE y el equipo de Salud») hay que tocar código o un JSON a mano.
- **Propuesta:** pantalla de reglas con disparador (al subir, al enviar a Coordinación, al firmar), condición (texto contiene, tipo documental, unidad, equipo) y acción **propuesta** (prioridad, equipo, etiqueta, plazo, aviso). Cada regla muestra cuántas veces se aceptó o descartó, con el mismo tablero de agentes que ya existe.
- **Referencia:** workflows de Paperless-ngx (disparadores Document Added/Updated, filtros por contenido y acciones de asignación) — https://docs.paperless-ngx.com/usage
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple, siempre que la acción sea una propuesta y no un cambio automático.

### 3. Vínculos con tipo entre documentos
- **Problema en este sistema:** hoy hay bloques, versiones, respuestas cargadas, reiteraciones sugeridas y la carpeta del caso (`/caso`), pero cada relación vive en una tabla distinta. No se puede decir «esta nota reitera a la N° 123» ni «este oficio responde a nuestra nota 456» de forma uniforme.
- **Propuesta:** una tabla `vinculos_documentos(origen, destino, tipo, quien, fecha)` con tipos fijos: responde a, reitera a, amplía, anexo de, reemplaza a. La carpeta del caso y el plazo de respuesta la leen. El sistema propone el vínculo cuando el texto cita un número de nota o expediente.
- **Referencia:** campo «Document Link» de Paperless-ngx — https://docs.paperless-ngx.com/usage ; agrupamiento por metadatos de Mayan EDMS — https://docs.mayan-edms.com/parts/features.html
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 4. OCR local para PDF escaneados
- **Problema en este sistema:** los PDF archivados se indexan con `pypdf` solo si traen texto (README, «Archivo directo de PDF»). Las respuestas de unidades y juzgados suelen llegar escaneadas: no se pueden buscar, no alimentan Antecedentes y la referencia de la IA (`referencia_ia._extraer_texto`) las ignora.
- **Propuesta:** pasar los PDF sin texto por OCRmyPDF con Tesseract en español, en la cola nocturna. Se guarda una **copia** con capa de texto (PDF/A) y el original queda intacto con su huella. El texto va a `notas_fts` y a la referencia de la IA.
- **Referencia:** OCRmyPDF — https://pypi.org/project/ocrmypdf/12.1.0
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple (corre en el servidor y no reemplaza el original).

### 5. Plan de retención sin borrado físico
- **Problema en este sistema:** el README dice que la retención es una «decisión pendiente de la institución». Mientras tanto todo se conserva igual: un borrador descartado y una nota firmada tienen el mismo tratamiento.
- **Propuesta:** cargar una tabla de series documentales (tipo, plazo de guarda, destino final: conservación permanente o «en condiciones de baja»). El sistema solo **marca** lo vencido y arma un listado para que Archivo o Legales lo autoricen. Aun autorizado, el documento pasa a un estado «retirado», sin borrarse. Sirve como insumo para decidir la política.
- **Referencia:** gestión de registros de Alfresco Governance Services — https://docs.alfresco.com/governance-services/community
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (no borra; solo marca y registra).

### 6. Paquete de archivo por expediente o por año
- **Problema en este sistema:** ya hay PDF/A por nota (`[archivo] pdfa_en_despacho`) y respaldos, pero no hay una entrega ordenada a Archivo con un inventario verificable.
- **Propuesta:** «Exportar paquete de archivo»: una carpeta o un .zip por expediente o por año con los PDF/A firmados, un manifiesto con la huella SHA-256 de cada archivo (las de `integridad.py`), el historial de estados en CSV y los metadatos. El paquete se puede volver a verificar en el futuro.
- **Referencia:** Archivematica, preservación digital con cadena de custodia — https://infrafinder.investinopen.org/solutions/archivematica
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (se genera solo a pedido de una persona y queda en la red interna).

### 7. Conversión de Word con LibreOffice siempre abierto (para Ubuntu)
- **Problema en este sistema:** en Linux no hay Word. Cada conversión de .doc o de PDF del despacho abre un `soffice --headless` nuevo (`nucleo._convertir_doc_a_docx_con_libreoffice`, `despacho._pdf_con_soffice`), que tarda varios segundos en arrancar. En un despacho del día con muchas notas, eso suma.
- **Propuesta:** dejar un servicio unoserver corriendo (systemd, solo en 127.0.0.1) y convertir con `unoconvert`. Si el servicio no está, se vuelve al método actual.
- **Referencia:** unoserver — https://pypi.org/project/unoserver
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 8. Plantillas con condiciones y tablas
- **Problema en este sistema:** las plantillas con campos (`«Campo»` o `[[Campo]]`, ola 3, #61) solo reemplazan texto. No pueden decir «Sr./Sra.» según el destinatario, repetir una fila por cada persona detenida mencionada ni omitir un párrafo si no hay plazo.
- **Propuesta:** sumar plantillas docxtpl (Jinja dentro del Word), con `{% if %}` y tablas que se repiten. Las plantillas viejas siguen funcionando. Es la base natural del «Generador» que menciona `tipos_documentales.py`.
- **Referencia:** python-docx-template (docxtpl) — https://docxtpl.readthedocs.io/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 9. Asistente de redacción en pasos (entrevista guiada)
- **Problema en este sistema:** «Completar y usar» pide los campos de corrido. Para notas repetitivas (pedido de colchón, de atención médica, de traslado) el asesor igual tiene que saber qué datos hacen falta y qué fórmula corresponde.
- **Propuesta:** un formulario en pasos por tipo de pedido (¿a quién va?, ¿qué persona detenida?, se elige de la base, ¿qué se pide?, ¿hay plazo?), que arma el borrador con la plantilla del #8 y valida contra la base de personas y el catálogo de unidades. La IA, si está, solo propone una redacción del párrafo de fundamentos.
- **Referencia:** Docassemble (entrevistas guiadas que arman documentos) — https://docassemble.org/docs.html
- **Impacto:** alto · **Esfuerzo:** L
- **Reglas fijas:** cumple (Docassemble se usa como modelo de diseño; no hace falta instalarlo).

### 10. Correcciones exportadas como control de cambios de Word
- **Problema en este sistema:** el control de cambios se ve en la web (`control_cambios.py`, verde y rojo), pero el .docx procesado que descarga el asesor trae el texto ya cambiado. En Word no se ve qué tocó la corrección.
- **Propuesta:** botón «Descargar con control de cambios»: genera una **copia** con marcas reales de Word (`w:ins`/`w:del`) con autor «Corrección automática» o el nombre de quien decidió. El asesor puede aceptar o rechazar en Word.
- **Referencia:** docx-revisions, soporte de revisiones para python-docx (MIT, todavía en versión 0.x) — https://pypi.org/project/docx-revisions
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 11. Búsqueda en español con raíces de palabras (al pasar a PostgreSQL)
- **Problema en este sistema:** `notas_fts` usa FTS5 con `unicode61 remove_diacritics 2` (`database.py`). Ignora las tildes, pero no relaciona las formas de una palabra: buscar «traslado» no encuentra «trasladaron» ni «traslados».
- **Propuesta:** en la migración a PostgreSQL (ya planeada, #98) usar `tsvector` con la configuración `spanish` y el diccionario `unaccent`. Hasta entonces, sumar en SQLite una columna normalizada con raíces calculadas en Python.
- **Referencia:** PostgreSQL, unaccent — https://www.postgresql.org/docs/15/unaccent.html
- **Impacto:** medio · **Esfuerzo:** S (dentro de la migración)
- **Reglas fijas:** cumple.

---

## B. Corrección y redacción en español

### 12. LanguageTool como servicio local fijo
- **Problema en este sistema:** `nucleo.inicializar_languagetool()` levanta LanguageTool dentro del proceso con `language_tool_python`. En Ubuntu depende de copiar la carpeta a `LTP_PATH`. Si falta, intenta bajarla de internet (lo avisa `linux/verificar_servidor.py`) y el Modo Seguro la bloquea. Además, cada reinicio de la app vuelve a arrancar Java.
- **Propuesta:** correr el servidor HTTP de LanguageTool como servicio propio (systemd, versión fija, solo `127.0.0.1:8081`, sin `--public`) y que la app lo consulte por HTTP. Se reinician por separado, arranca más rápido y la versión queda controlada.
- **Referencia:** LanguageTool HTTP server — https://dev.languagetool.org/http-server ; language-tool-python (permite usar un servidor ya levantado) — https://pypi.org/project/language-tool-python
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (servidor local; el Modo Seguro ya deja pasar localhost).

### 13. Índice de legibilidad con fórmula para español
- **Problema en este sistema:** `nucleo.calcular_legibilidad()` usa la fórmula de Flesch **para inglés** (206,835 − 1,015 × palabras por oración − 84,6 × sílabas por palabra). El español tiene más sílabas por palabra, así que la nota sale peor de lo que es y el número no se puede comparar con ninguna escala publicada.
- **Propuesta:** reemplazarla por Fernández-Huerta o Szigriszt-Pazos (escala INFLESZ), que están adaptadas al español, y mostrar la interpretación en palabras («algo difícil», «normal»). Se puede usar textstat (MIT) o calcular la fórmula directamente.
- **Referencia:** textstat, con `fernandez_huerta` y `szigriszt_pazos` — https://pypi.org/project/textstat ; legibilidad (INFLESZ y otras; GPL-3, sirve para contrastar resultados) — https://pypi.org/project/legibilidad/0.3/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 14. Control de lenguaje claro según la guía del Estado
- **Problema en este sistema:** `evaluar_claridad()` solo marca oraciones de más de 35 palabras y el promedio. La ficha de lenguaje claro de la ANDIS recomienda no pasar de 30 palabras por oración, voz activa, sujeto expreso, párrafos de hasta 6 líneas, una idea por oración y evitar la doble negación. Importa sobre todo en la «Nota a persona detenida», que lee alguien privado de la libertad.
- **Propuesta:** un control «Lenguaje claro» por reglas (largo de oración y de párrafo, pasivas con «se + participio» y «fue + participio», dobles negaciones, tecnicismos de un glosario con su alternativa común). Cada aviso explica el porqué y nunca reescribe solo. Para «Nota a persona detenida» se aplica con umbrales más exigentes.
- **Referencia:** ANDIS, «Lenguaje claro» (ficha 06) — https://argentina.gob.ar/sites/default/files/2023/12/6_lenguaje_claro.pdf ; Guía de lenguaje claro del Gobierno de la Ciudad — https://lenguajeclaro.jusbaires.gob.ar/app/uploads/2022/11/GUIA_DE_LENGUAJE_CLARO-Gobierno-CABA.pdf
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 15. Diccionario Hunspell es_AR en vez de pyspellchecker
- **Problema en este sistema:** `evaluar_ortografia()` usa `pyspellchecker`, que trabaja con una lista de frecuencias de español general sin flexiones ni variante argentina. Lo compensan los «términos propios» de `referencia_ia`, pero los falsos positivos siguen (voseo, regionalismos).
- **Propuesta:** usar el diccionario es_AR del proyecto RLA-ES (el mismo de LibreOffice) con un diccionario personal institucional que se arma solo con los términos de `referencia_ia.terminos_institucionales()` y el glosario.
- **Referencia:** RLA-ES, diccionarios de español por país — https://github.com/sbosio/rla-es
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 16. Usar los rechazos de párrafo para apagar reglas que molestan
- **Problema en este sistema:** `aprendizaje.py` solo mira las modificaciones del Director. Su propio docstring aclara que los rechazos de párrafo no se usan, porque el motivo puede ser cualquiera. Entonces una regla de LanguageTool que el Director rechaza 30 veces se sigue proponiendo.
- **Propuesta:** al rechazar un cambio, ofrecer un motivo opcional de un clic (cambió el sentido, nombre propio, fórmula institucional, no era un error). Llevar la cuenta por regla de LanguageTool (`ruleId`), por reemplazo del diccionario y por la IA. Cuando una regla supera N rechazos, proponer a la Dirección desactivarla (`disabledRules`). No se apaga sola.
- **Referencia:** language-tool-python, reglas desactivables — https://pypi.org/project/language-tool-python
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 17. Perfil de corrección por tipo documental
- **Problema en este sistema:** la corrección (`generar_propuesta_parrafo`) es la misma para un oficio judicial que para una nota a una persona detenida. La IA recibe siempre la orden de «conservar el estilo administrativo-jurídico».
- **Propuesta:** un perfil por tipo documental: qué reglas se aplican, umbrales de claridad (#14), si se proponen reformulaciones y qué fórmulas están protegidas. Se elige con el tipo que ya confirma quien lleva la nota.
- **Referencia:** ANDIS, «Lenguaje claro» — https://argentina.gob.ar/sites/default/files/2023/12/6_lenguaje_claro.pdf
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 18. Ejemplos elegidos por parecido para la IA (few-shot)
- **Problema en este sistema:** la etapa 7 del plan (few-shot con ejemplos reales) sigue pendiente. Hoy `ejemplo_de_estilo()` pasa solo el comienzo del firmado más parecido, buscado por palabras.
- **Propuesta:** guardar pares «original → texto final aprobado por el Director» y, para cada párrafo nuevo, darle a la IA los 2 o 3 pares más parecidos (buscados como en el #24). Los ejemplos negativos de consistencia ya se arman así (`_bloque_negativos`).
- **Referencia:** Ollama, embeddings locales — https://docs.ollama.com/api/embed
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (todo local).

---

## C. IA local (Ollama)

### 19. Respuestas con esquema JSON validado
- **Problema en este sistema:** `consultar_ollama(..., formato_json=True)` manda `"format": "json"`. Eso garantiza un JSON, pero no su forma. Después cada módulo corrige a mano lo que llega: `revision_ia.opinion_ia` traduce «misma persona», «mismo» o «dudoso», y `_parsear_json` busca llaves con expresiones regulares. Lo que no encaja se descarta y la IA trabajó para nada.
- **Propuesta:** pasar en `format` el **esquema** (con `enum` para veredicto o prioridad, rangos para confianza) generado con Pydantic, y validar la respuesta con el mismo modelo. Así baja la cantidad de descartes y el código de cada asistente queda más corto.
- **Referencia:** Ollama, salidas estructuradas — https://docs.ollama.com/capabilities/structured-outputs
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 20. Ventana de contexto explícita (num_ctx) y control del tamaño del pedido
- **Problema en este sistema:** `consultar_ollama` no fija `num_ctx`, así que Ollama usa su valor por defecto de 4096 tokens. El control cruzado manda dos documentos de hasta 4000 caracteres cada uno, más instrucciones y ejemplos negativos. Las mejoras desde el informe mandan la nota, el informe y un ejemplo de 1200 caracteres. Si el pedido no entra, Ollama lo recorta y el modelo responde sin parte de las instrucciones, sin que quede registrado.
- **Propuesta:** calcular el tamaño aproximado en tokens antes de llamar, fijar `num_ctx` por proceso en `config.ini` (por ejemplo 8192 para consistencia y redacción) y registrar en `ia_registro` cuando el pedido supera el 90% del contexto. Si no entra, partir el documento o avisar.
- **Referencia:** Ollama FAQ, longitud de contexto y `num_ctx` — https://docs.ollama.com/faq.md
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 21. Menos cambios de modelo en memoria
- **Problema en este sistema:** hay un modelo por proceso (`modelo_correccion`, `modelo_clasificacion`, `modelo_consistencia`, `modelo_redaccion`, `revision_detenidos`). Si la cola los alterna, Ollama carga y descarga varios GB por trabajo. Ya existe la pausa por uso y la IA adaptativa a la carga de la PC.
- **Propuesta:** ordenar la cola nocturna por modelo (todos los trabajos de un modelo seguidos), usar `keep_alive` largo dentro de la ventana nocturna y 0 en horario de oficina, y fijar en el servidor `OLLAMA_MAX_LOADED_MODELS=1` y `OLLAMA_NUM_PARALLEL=1`.
- **Referencia:** Ollama FAQ (`keep_alive`, `OLLAMA_MAX_LOADED_MODELS`, `OLLAMA_NUM_PARALLEL`) — https://docs.ollama.com/faq.md
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 22. Elegir el modelo por cómo anda en español (hoy config.ini usa phi3:mini)
- **Problema en este sistema:** el `config.ini` de la PC tiene `modelo = phi3:mini`, mientras el README y `nucleo.OLLAMA_MODEL` hablan de `qwen2.5:7b` y recomiendan 8B o más para redacción. phi3:mini es un modelo chico, entrenado sobre todo en inglés. Sin un modelo por proceso cargado, todo cae ahí.
- **Propuesta:** decidir con el examen del #23 entre candidatos que se ejecutan en Ollama, por ejemplo qwen2.5:7b y Salamandra 7B Instruct (del Barcelona Supercomputing Center, Apache-2.0, ajustado sobre todo para español), con versiones GGUF. Mostrar una advertencia en Administración → IA si un proceso de redacción usa un modelo de menos de 7B.
- **Referencia:** Salamandra 7B Instruct — https://huggingface.co/BSC-LT/salamandra-7b-instruct/blob/d1e62fb8acb4967766585bd762f8f10e2db2f44e/README.md ; versiones GGUF — https://huggingface.co/cstr/salamandra-7b-instruct-GGUF
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple (los pesos se bajan una vez a mano y se ejecutan en el servidor).

### 23. Examen propio de los modelos antes de cambiarlos
- **Problema en este sistema:** el tablero por modelo (Administración → IA → Calidad) mide la aceptación **después** de usarlo con notas reales, y los tests usan respuestas simuladas. No hay forma de saber antes si un modelo nuevo corrige mejor o inventa más.
- **Propuesta:** un conjunto fijo y anonimizado (ver #43): unos 100 párrafos con su corrección esperada, 30 pares de documentos con contradicciones conocidas, 50 pares de fichas ya decididas y 20 intentos de instrucciones escondidas. Un comando corre el examen contra cada modelo y da un puntaje por tarea. Se corre antes de cambiar el modelo o los prompts.
- **Referencia:** promptfoo con proveedor Ollama, que corre local y puede usar Ollama también como evaluador. Hay que apagar la telemetría con `PROMPTFOO_DISABLE_TELEMETRY=1` y no usar sus funciones en la nube — https://www.promptfoo.dev/docs/providers/ollama y https://www.promptfoo.dev/docs/faq/ . Alternativa: un script Python propio con los mismos casos.
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple solo con telemetría apagada y datos anonimizados; si no, usar el script propio.

### 24. Búsqueda por significado con embeddings locales
- **Problema en este sistema:** `referencia_ia.parecidos()` usa TF-IDF con similitud coseno, escrito a mano, y en memoria. Encuentra documentos con las mismas palabras, pero no los que dicen lo mismo con otras («colchón» y «elementos de descanso», «aislamiento» y «sanción de celda»). `agentes.casi_iguales` y Antecedentes tienen el mismo límite.
- **Propuesta:** calcular embeddings con un modelo multilingüe servido por Ollama (`/api/embed`) y guardarlos en sqlite-vec mientras siga SQLite, o en pgvector después de migrar. Combinar el puntaje con el TF-IDF actual (búsqueda híbrida) y seguir mostrando solo **propuestas** de parecidos.
- **Referencia:** Ollama `/api/embed` — https://docs.ollama.com/api/embed ; sqlite-vec (MIT/Apache, Windows y Linux) — https://github.com/asg017/sqlite-vec ; pgvector — https://github.com/ankane/pgvector
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 25. Antecedentes con citas verificadas (RAG local)
- **Problema en este sistema:** «Consultar» (#14 de la ola 5) pasa la pregunta a filtros y cuenta. No responde preguntas como «¿qué le pedimos antes a la Unidad 6 sobre agua caliente?».
- **Propuesta:** un modo «Buscar antecedentes»: recupera los fragmentos más parecidos (#24) de lo firmado que la persona puede ver y la IA redacta 3 o 4 líneas, cada una con su cita **literal**. Se reutiliza la verificación de citas que ya existe en `analisis.validar_hallazgos_ia`: si la cita no está en el documento, la línea se descarta.
- **Referencia:** Ollama embeddings — https://docs.ollama.com/api/embed ; sqlite-vec — https://github.com/asg017/sqlite-vec
- **Impacto:** medio · **Esfuerzo:** L
- **Reglas fijas:** cumple (respeta los permisos de visibilidad de cada persona).

### 26. Validar contra el texto también los resúmenes y proveídos
- **Problema en este sistema:** las mejoras desde el informe y los hallazgos de consistencia se validan contra el texto (citas literales, números). En cambio `agentes.resumen_ia()` acepta cualquier 2 o 3 líneas que vuelvan, y `proveido_ia` también se apoya en el modelo. Un número de expediente o un apellido inventado en el resumen de «Pendientes de tu firma» puede inducir a error.
- **Propuesta:** aplicar a resumen y proveído el mismo filtro contra invenciones: cada número, fecha, DNI, LPU y nombre propio de la salida tiene que estar en el texto fuente. Si no está, se descarta y se usa la versión por reglas.
- **Referencia:** patrón ya existente en el propio sistema (`analisis.validar_sugerencia`). Para detectar nombres propios, spaCy es_core_news_lg — https://huggingface.co/spacy/es_core_news_lg
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 27. Registrar la versión exacta del modelo y del prompt
- **Problema en este sistema:** `ia_registro` guarda el nombre del modelo (`qwen2.5:7b`), la huella del pedido y la salida recortada. Si alguien hace `ollama pull` del mismo nombre, el modelo cambia sin que quede constancia. Tampoco se sabe qué versión del prompt se usó.
- **Propuesta:** guardar en cada llamada el *digest* del modelo (lo informa Ollama al listar modelos), un identificador de versión del prompt (huella del template) y los parámetros (`temperature`, `num_ctx`). Avisar en Administración → IA cuando cambia el digest de un modelo en uso.
- **Referencia:** Ollama, documentación de la API — https://docs.ollama.com/faq.md
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 28. llama.cpp como motor de respaldo en el servidor
- **Problema en este sistema:** toda la IA depende de Ollama. Si una actualización de Ollama se rompe en Ubuntu, la IA queda apagada (el sistema sigue sin IA, eso ya está bien resuelto).
- **Propuesta:** dejar documentado y probado `llama-server` (llama.cpp) con los mismos GGUF, solo en localhost, como alternativa configurable en `[ollama] url`. Permite además gramáticas GBNF para respuestas cerradas.
- **Referencia:** llama.cpp, gramáticas GBNF — https://raw.github.com/ggerganov/llama.cpp/master/./grammars/README.md
- **Impacto:** bajo · **Esfuerzo:** M
- **Reglas fijas:** cumple.

---

## D. Base de personas detenidas: calidad y vinculación

### 29. Pesar los nombres según qué tan comunes son
- **Problema en este sistema:** `revision_ia.comparar()` suma +55 por «mismo nombre» sin importar si es «Juan Carlos González» (muy repetido en una población penitenciaria) o un nombre raro. Eso infla los falsos duplicados de nombres comunes y subestima los nombres raros con otro dato que no coincide.
- **Propuesta:** contar la frecuencia de cada apellido y nombre en la base y ajustar los puntos: menos puntos para coincidencias muy comunes y más para las raras. Se puede calcular dentro de `comparar()`, sin dependencias nuevas.
- **Referencia:** Splink, ajuste por frecuencia de término — https://moj-analytical-services.github.io/splink
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 30. Calibrar el puntaje con las decisiones ya tomadas
- **Problema en este sistema:** los puntos de `comparar()` (+30 DNI parecido, −35 DNI distinto, +15 misma fecha…) y el `UMBRAL = 55` están puestos a ojo. Mientras tanto, la base ya acumula decisiones de personas en `detenidos_revision` y `detenidos_ia_propuestas`.
- **Propuesta:** usar esas decisiones para estimar cuánto pesa de verdad cada coincidencia (modelo Fellegi-Sunter) y recalcular los puntos y el umbral cada tanto, mostrando el antes y el después. Splink corre local con DuckDB. Para algo más liviano, recordlinkage tiene un clasificador ECM sin datos etiquetados.
- **Referencia:** Splink — https://moj-analytical-services.github.io/splink ; Python Record Linkage Toolkit — https://recordlinkage.readthedocs.io/en/stable/
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple (solo cambia qué pares se proponen; unificar sigue siendo decisión de una persona).

### 31. Mostrar grupos de fichas, no solo pares
- **Problema en este sistema:** la revisión trabaja de a pares. Si A se parece a B y B a C, aparecen como dos propuestas separadas, y se puede unificar A con B y después decidir otra cosa para B con C.
- **Propuesta:** agrupar los pares que superan el umbral en «posibles grupos de la misma persona» (componentes conectados) y mostrarlos juntos, con una ficha sugerida a conservar y la opción de sacar a alguien del grupo.
- **Referencia:** Splink, agrupamiento que da un identificador estimado de persona — https://moj-analytical-services.github.io/splink
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 32. Clave fonética para apellidos en español
- **Problema en este sistema:** la comparación de nombres usa `difflib.SequenceMatcher` sobre las palabras ordenadas. Los errores típicos de quien carga listados (Vázquez/Básquez, Jiménez/Giménez, Yanina/Llanina, Hernández/Ernández, Sosa/Zoza) bajan el parecido y a veces el par ni entra como candidato en `_claves_nombre`.
- **Propuesta:** una clave fonética propia para español (b=v, c/s/z, ll=y, g=j delante de e/i, h muda, qu=k) como clave de bloqueo adicional en `candidatos()` y como señal en `comparar()` («apellido que suena igual»). Para la distancia, Jaro-Winkler.
- **Referencia:** jellyfish (Jaro-Winkler y algoritmos fonéticos, pensados para inglés, sirven de base) — https://pypi.org/project/jellyfish/0.8.8/
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 33. Deshacer una unificación de fichas
- **Problema en este sistema:** al unificar, una ficha queda de baja como «Unificada con #…» y su historial pasa a la otra (`detenidos.py`, `aplicar_importacion`). No encontré en `detenidos.py`, `rutas_detenidos.py` ni `revision_ia.py` una acción para revertirlo. Un error de unificación entre dos personas distintas solo se arregla a mano.
- **Propuesta:** «Separar fichas» desde el historial de la ficha conservada: reactiva la ficha unificada, devuelve los campos y vínculos que vinieron de ella (los cambios ya se registran campo por campo en `detenidos_cambios`) y marca el par como «distintas» para que no se vuelva a proponer.
- **Referencia:** Splink, agrupamiento con identificador de persona estimado y revisable — https://moj-analytical-services.github.io/splink
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple (no borra: reactiva y registra).

### 34. RapidFuzz en lugar de difflib
- **Problema en este sistema:** `difflib` se usa para comparar nombres en `revision_ia`, `detenidos`, `unidades_menu`, `traslados` e `importar_viajes`. Es Python puro y lento para comparar miles de fichas contra miles. Por eso la revisión necesita topes (`MAX_POR_TOKEN`, `limite_ia`).
- **Propuesta:** usar RapidFuzz (C++, MIT, con wheels para Windows y Linux; pide Python 3.11+, igual que el sistema). `token_set_ratio` da 100 cuando un nombre contiene al otro (falta el segundo nombre) y `process.cdist` compara en lote.
- **Referencia:** RapidFuzz — https://github.com/rapidfuzz/RapidFuzz
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 35. Más tolerancias en fechas de nacimiento
- **Problema en este sistema:** `revision_ia._fechas()` reconoce fecha igual, día y mes invertidos y un año de diferencia. No contempla fechas de relleno (01/01/1900, 01/01 del año), dígitos del año invertidos (1987/1978) ni años de dos cifras mal interpretados (05 → 2005 en vez de 1905).
- **Propuesta:** sumar esos casos a la comparación y marcar como «fecha dudosa» las fechas de relleno, para que no sumen ni resten puntos. Cada caso nuevo se agrega a los motivos que ya se muestran.
- **Referencia:** Python Record Linkage Toolkit, comparación de fechas con día y mes invertidos — https://recordlinkage.readthedocs.io/en/stable/
- **Impacto:** bajo · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 36. Reglas de cada listado escritas como esquema
- **Problema en este sistema:** las validaciones de la importación están repartidas en `validar()`, `previa()` e `inconsistencias()` de `detenidos.py`, que ya tiene unas 2000 líneas. Para saber qué se controla de cada columna hay que leer el código, y cada fuerza manda columnas distintas.
- **Propuesta:** declarar por fuerza un esquema (columnas esperadas, tipo, rangos, valores permitidos como el catálogo de situación procesal, obligatorias) y correrlo con validación completa (`lazy`), que junta todos los errores con fila y columna. El informe de devolución a la fuerza (`reporte_inconsistencias`) se arma desde ese resultado.
- **Referencia:** Pandera, esquemas con `lazy=True` e informe de casos que fallan — https://pandera.readthedocs.io/
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 37. Comparar cada listado con el anterior de la misma fuerza
- **Problema en este sistema:** la vista previa muestra altas, actualizaciones y errores del listado nuevo, pero no si el listado en sí es raro. Un listado al que le falta una unidad entera puede generar decenas de «egresos» si se elige esa opción al importar.
- **Propuesta:** antes de confirmar, un control de lo esperable contra el listado anterior de esa fuerza: cantidad de personas por unidad (alerta si una unidad baja más del 30%), porcentaje sin DNI, columnas que desaparecieron, fecha del listado anterior a la última cargada. Las alertas piden una confirmación aparte.
- **Referencia:** Great Expectations (suites de expectativas y checkpoints) — https://docsearch.algolia.com/mcp/docs/repo/great-expectations/great_expectations ; ydata-profiling (perfil automático de calidad) — https://ydata.ai/resources/research-paper-ydata-profiling
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 38. Historial de alojamiento por persona
- **Problema en este sistema:** el alojamiento (unidad, módulo, pabellón) es un campo de la ficha. Sus cambios quedan en `detenidos_cambios`, pero no hay una vista de «dónde estuvo y desde cuándo», y la verificación de las notas no puede preguntar «¿esta persona estaba en esta unidad en la fecha de la nota?».
- **Propuesta:** armar, a partir de `detenidos_cambios` y `detenidos_listados`, una tabla de tramos (persona, unidad, desde, hasta, listado de origen). Mostrarla como línea de tiempo en la ficha, detectar traslados entre listados y avisar en la prerrevisión cuando la nota menciona una unidad distinta a la del último listado.
- **Referencia:** registro de transparencia de MoJ Data First, vinculación de registros de justicia en el tiempo con Splink — https://www.gov.uk/algorithmic-transparency-records/moj-data-first-splink
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 39. Vincular la nota con la ficha y que lo confirme una persona
- **Problema en este sistema:** `detenidos.notas_relacionadas()` busca en cada consulta las notas por DNI o «por todas las palabras del nombre». Eso falla con nombres comunes o escritos de otra forma. `agentes.verificar_lpu()` cruza contra las planillas de expedientes, no contra la base de personas.
- **Propuesta:** en la prerrevisión, detectar a las personas de la nota (DNI y LPU por expresión regular, nombres con un modelo de entidades en español), proponer la ficha con su puntaje (#29, #32) y guardar el vínculo `nota_persona` cuando una persona lo confirma. La ficha y la carpeta del caso leen ese vínculo.
- **Referencia:** spaCy es_core_news_lg, entidades en español — https://huggingface.co/spacy/es_core_news_lg
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 40. Controlar CUIL y formato de documentos
- **Problema en este sistema:** el DNI se valida por largo (6 a 9 números) y el documento extranjero se clasifica (`detenidos.clasificar_documento`). Si un listado trae CUIL, no se controla su dígito verificador ni se compara con el DNI de la ficha.
- **Propuesta:** reconocer CUIL o CUIT (11 dígitos con prefijo 20/23/24/27), validar el dígito verificador (módulo 11), extraer el DNI y avisar si no coincide con el de la ficha. Solo avisa.
- **Referencia:** algoritmo del dígito verificador de CUIT/CUIL — https://gist.github.com/neiker/874c197cd0cbb06efb328f3cbc6753b3
- **Impacto:** bajo · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 41. Ordenar la revisión por lo que más conviene decidir
- **Problema en este sistema:** las propuestas de posibles duplicados se ordenan por puntaje. Las de puntaje muy alto casi siempre son ciertas y las de muy bajo casi siempre falsas. Las dudosas, que es donde una decisión humana más enseña, quedan en el medio.
- **Propuesta:** una pestaña «para decidir primero»: pares de fichas activas, cerca del umbral y donde reglas e IA no coinciden. Esas decisiones alimentan la calibración del #30 (aprendizaje activo).
- **Referencia:** dedupe, aprendizaje activo que pide etiquetar los pares más inciertos — https://docsearch.algolia.com/mcp/docs/repo/dedupeio/dedupe
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 42. Tablero de calidad por fuerza
- **Problema en este sistema:** el informe de inconsistencias (`reporte_inconsistencias`) se arma por listado. No hay una vista que diga si la calidad de lo que manda cada fuerza mejora o empeora con el tiempo.
- **Propuesta:** un tablero por fuerza y por trimestre: porcentaje de filas con problemas por tipo (sin DNI, documento cruzado, lugar fuera de catálogo, repetidas), tendencia, y un anexo exportable para acompañar las devoluciones institucionales.
- **Referencia:** Great Expectations, documentación de resultados de validación — https://docsearch.algolia.com/mcp/docs/repo/great-expectations/great_expectations
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

---

## E. Protección de datos y anonimización (Ley 25.326)

### 43. Copias anonimizadas para pruebas, capacitación y el examen de la IA
- **Problema en este sistema:** los videos de ayuda se grabaron «con datos de prueba» y existe «Borrar notas de prueba», pero no hay una herramienta para obtener material realista **sin** datos de personas. El examen de modelos (#23) y la capacitación lo necesitan.
- **Propuesta:** un comando que genere copias anonimizadas de notas y fichas: nombres → «[PERSONA_1]» de forma consistente en todo el documento, DNI/LPU/expediente → valores ficticios con el mismo formato, unidades y juzgados se conservan o se generalizan según el uso. Reconocedores propios por expresión regular para DNI, LPU, `EP 1234/2025` y una lista de términos del catálogo de unidades. Una persona revisa una muestra antes de usarlas.
- **Referencia:** Presidio (Microsoft, el sitio pasó a data-privacy-stack), con reconocedores propios y listas — https://microsoft.github.io/presidio/analyzer/adding_recognizers ; modelo spaCy de anonimización en español del Plan TL (MIT) — https://huggingface.co/PlanTL-GOB-ES/es_anonimization_core_lg/tree/main/ner ; Ley 25.326, art. 2 («disociación de datos») — https://www.argentina.gob.ar/normativa/nacional/64790/texto
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple (todo local; las copias no reemplazan ni borran originales).

### 44. Versión testada de un documento para compartir
- **Problema en este sistema:** cuando una nota o un informe se tiene que compartir con terceros, hay que tachar datos a mano fuera del sistema. «Datos publicables» (#88) resuelve solo los agregados.
- **Propuesta:** «Preparar versión testada»: propone qué tachar (nombres, DNI, LPU, datos de salud) con el mismo motor del #43, la persona acepta o corrige cada tachado y se genera una **copia** PDF con los datos tapados de verdad, no con un rectángulo encima. Queda registrado quién la generó.
- **Referencia:** Presidio, anonimización de valores conocidos — https://microsoft.github.io/presidio/samples/python/Anonymizing%20known%20values
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (se genera a pedido; el envío sigue siendo manual).

### 45. Clasificar la sensibilidad de campos y documentos
- **Problema en este sistema:** la base es de datos especialmente protegidos: situación procesal, salud y señales como autolesiones (que ya detecta `agentes.tipo_por_contenido`). Pero el acceso es por rol para toda la ficha: «Personas detenidas» lo ven todos los que ven Notas, salvo los choferes.
- **Propuesta:** marcar los campos sensibles (situación procesal, observaciones de salud) y los documentos con datos de salud. Mostrarlos tapados por defecto («ver» con motivo, queda en `seguridad_eventos`) para quienes no trabajan el caso, y excluirlos de exportaciones salvo que se pidan.
- **Referencia:** Ley 25.326, art. 7 (datos sensibles; inc. 4, antecedentes penales) y art. 9 (seguridad) — https://www.argentina.gob.ar/normativa/nacional/64790/texto
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 46. Exportaciones y API con datos mínimos y motivo
- **Problema en este sistema:** Dirección y Mesa pueden exportar la lista completa a Excel o CSV, y `/api/detenidos` devuelve la ficha completa a quien tenga el `api_token`. Ya se registra cada exportación.
- **Propuesta:** perfiles de exportación (mínima: nombre, DNI, unidad; completa: todo) con motivo obligatorio para la completa. Marca en el archivo con usuario, fecha e identificador de exportación. Tokens de API con alcance por campos. Avisar a la Dirección cuando alguien exporta más de N fichas en un día.
- **Referencia:** Ley 25.326, art. 9 (seguridad y confidencialidad) — https://www.argentina.gob.ar/normativa/nacional/64790/texto
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 47. Datos mínimos en lo que se manda a la IA y en su registro
- **Problema en este sistema:** `revision_ia._ficha_para_ia` manda la ficha a la IA local, y `ia_registro.salida` guarda hasta 2000 caracteres de lo que devolvió, que puede incluir nombres y DNI. Es local, pero es otra copia de datos sensibles sin plazo de conservación.
- **Propuesta:** mandar solo los campos que se comparan y guardar en `ia_registro` la salida con los documentos parcialmente tapados (por ejemplo `30.xxx.x45`). Fijar cuánto tiempo se conserva la salida completa antes de quedar solo la huella. Es un caso de retención para el #5: se marca, no se borra sin autorización.
- **Referencia:** Ley 25.326, art. 9 — https://www.argentina.gob.ar/normativa/nacional/64790/texto
- **Impacto:** bajo · **Esfuerzo:** S
- **Reglas fijas:** cumple (si se acorta la salida guardada, debe autorizarlo la institución en el marco del #5).

---

## F. Firma digital y trazabilidad

### 48. Firma PAdES del PDF despachado
- **Problema en este sistema:** la «firma» es una imagen insertada en el .docx (`nucleo.insertar_firma`), con PIN y huellas SHA-256 como resguardo. Para la Ley 25.506 eso no es firma digital: el PDF despachado no prueba por sí mismo quién lo firmó ni que no se alteró.
- **Propuesta:** firmar el PDF final con pyHanko (PAdES), en el servidor o en la PC de quien firma, con el certificado del Director en token (PKCS#11) o, como paso intermedio, con un certificado interno del organismo (firma electrónica). La imagen puede seguir como apariencia visible. Hay que acordarlo con Legales y con quien administre ppn-mesa-entradas.
- **Referencia:** pyHanko (MIT; firma PAdES, soporte PKCS#11) — https://pypi.org/project/pyHanko/0.36.0/ ; Ley 25.506 de firma digital — https://mpba.gov.ar/files/documents/Ley%2025.506.pdf
- **Impacto:** alto · **Esfuerzo:** L
- **Reglas fijas:** cumple con token o certificado local. Una firma remota con un certificador externo queda descartada (ver Descartes).

### 49. Sello de tiempo interno (RFC 3161)
- **Problema en este sistema:** las fechas de firma y despacho salen del reloj del servidor. Si alguien cambia la hora del equipo, nada lo detecta.
- **Propuesta:** levantar una autoridad de sellado de tiempo interna (uts-server, en la red del organismo) y sellar la huella de cada firmado y despachado, y cada día la huella del registro de auditoría (#50). pyHanko puede incrustar el sello en el PDF.
- **Referencia:** uts-server, servidor RFC 3161 — https://uts-server.readthedocs.io/
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (servidor interno).

### 50. Registro de auditoría encadenado
- **Problema en este sistema:** los traslados tienen triggers de SQLite que impiden modificar o borrar la auditoría (`database.py`, `traslados_auditoria_*`). En cambio `historial_estados` de notas, `detenidos_cambios`, `seguridad_eventos` e `ia_registro` no tienen esa protección.
- **Propuesta:** extender los triggers «solo agregar» a esas tablas y sumar una huella encadenada (cada fila incluye la huella de la anterior). «Verificar integridad» recorre la cadena. Una vez por día se guarda la última huella en el respaldo y, si existe el #49, se sella.
- **Referencia:** Mayan EDMS, todo evento queda registrado para auditoría — https://docs.mayan-edms.com/parts/features.html ; uts-server para sellar la huella diaria — https://uts-server.readthedocs.io/
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 51. Código QR de verificación en el despachado
- **Problema en este sistema:** quien recibe el PDF (o Mesa, cuando consulta una unidad) no tiene forma rápida de comprobar que es el mismo que salió.
- **Propuesta:** estampar en la copia de despacho un QR con número de nota y huella corta, que lleve a una página **interna** de verificación (compara contra `sha256` guardado). Desde afuera de la red se verifica pidiéndolo a Mesa.
- **Referencia:** pyHanko, sellos con QR (extra `qr`) — https://pypi.org/project/pyHanko/0.36.0/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (la verificación es interna; no se publica nada).

### 52. Validar firmas de los PDF que se reciben
- **Problema en este sistema:** las respuestas de organismos que usan GDE llegan como PDF firmados digitalmente, pero «Cargar una respuesta» los guarda sin mirar la firma.
- **Propuesta:** al cargar una respuesta en PDF, validar localmente la firma con pyHanko contra los certificados raíz oficiales cargados a mano en el servidor, y mostrar «firmado por… / íntegro / no se verificó revocación (sin conexión)». Solo informa.
- **Referencia:** pyHanko, validación de firmas — https://pyhanko.readthedocs.io/en/latest/api-docs/pyhanko.sign.validation.html
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple, sin consultar revocación en línea (eso sería salida al exterior; si algún día se quiere, solo con `soberania.salida_confirmada`).

### 53. Reconocer números GDE como referencia externa
- **Problema en este sistema:** el expediente propio sigue el formato de ppn-mesa-entradas (`EP 1234/2025`) y la extracción de entidades busca ese formato. Los oficios y respuestas del Estado nacional citan números GDE (del tipo `EX-2025-12345678-APN-…` o `NO-…`), que hoy no se reconocen ni vinculan.
- **Propuesta:** reconocer los formatos GDE en el texto, guardarlos como «referencia externa» de la nota y usarlos para proponer vínculos con el #3 (por ejemplo, «responde a NO-2025-…»).
- **Referencia:** Decreto 561/2016, implementación de GDE — https://www.boletinoficial.gob.ar/detalleAviso/primera/143286/20160407
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

---

## Descartadas o condicionadas (no cumplen las reglas fijas tal como están)

- **Firma digital remota con la plataforma nacional (Firmar.gob.ar).** Requiere mandar la huella o el documento a un servicio externo. Solo podría hacerse a pedido expreso de quien firma y pasando por `soberania.salida_confirmada`, nunca automático. Hasta que la Dirección lo decida, queda descartada. Ref.: https://www.argentina.gob.ar/jefatura/innovacion-ciencia-y-tecnologia/innovacion/firma-digital/pfdr
- **Modelos «cloud» de Ollama o LanguageTool Premium/API pública.** Mandan el texto afuera: incumplen «IA solo local». En el servidor conviene fijar `OLLAMA_NO_CLOUD=1`. Ref.: https://docs.ollama.com/faq.md
- **Instalar Paperless-ngx, Mayan EDMS o Alfresco como reemplazo del módulo de notas.** Ninguno tiene el circuito asesor → coordinación → firma → Mesa, y sumarían una segunda base de documentos con datos de personas detenidas. Se toman como referencia de diseño (#1–#6), no para integrar.
- **OpenProject para el seguimiento de notas.** Es gestión de proyectos y tareas, no de expedientes. Duplicaría el circuito y los permisos. Ref.: https://www.openproject.org/index.html
- **Label Studio para etiquetar pares de fichas.** Funciona en servidor propio, pero suma otra aplicación con datos sensibles para algo que el #41 resuelve dentro del sistema. Ref.: https://blog.elest.io/label-studio-free-open-source-data-labeling-platform-for-ai-models/
- **Verificar revocación de certificados en línea (OCSP/CRL) automáticamente.** Es una salida al exterior en cada validación. Ver #52.

---

## Resumen por prioridad (impacto alto, esfuerzo S): para empezar

| # | Propuesta | Módulo |
|---|---|---|
| 13 | Legibilidad con fórmula para español | Notas |
| 16 | Usar los rechazos de párrafo para apagar reglas | Notas / IA |
| 19 | Esquema JSON validado en las respuestas de la IA | IA |
| 20 | `num_ctx` explícito y control del tamaño del pedido | IA |
| 22 | Reemplazar `phi3:mini` por un modelo evaluado en español | IA |
| 26 | Validar resúmenes y proveídos contra el texto | IA |
| 29 | Pesar nombres según qué tan comunes son | Personas |
| 32 | Clave fonética para apellidos en español | Personas |
| 4 | OCR local para PDF escaneados | Notas |

Siguiente tanda (alto, M): #1, #14, #23, #30, #33, #37, #38, #39, #43, #45, #50.
