# Propuestas para Autos PPN (viajes y flota) y Metas / tableros — dgpdh_web

Investigación del 14/11/2026. Leí `README.md` y revisé por arriba `traslados.py`, `operacion.py`, `flota.py`, `frecuentes.py`,
`presentismo.py`, `metas.py`, `metas_importar.py`, `tablero_direccion.py`, `indicadores.py`, `rutas_traslados.py`, `database.py`
(esquema) y las plantillas `traslados*.html`, `viaje_*.html` y `metas*.html`. No modifiqué nada en `/home/claude/pc`.

**Reglas fijas que se controlan en cada propuesta:** (1) sin mapas interactivos externos obligatorios; (2) nada se transmite al
exterior de forma automática; (3) no se borra nada (baja lógica e historial); (4) la IA, si aparece, es local (Ollama);
(5) FastAPI + Jinja2 + SQLite, sin infraestructura nueva obligatoria.

**Cómo leer las referencias:** son proyectos de los que se toma la *idea* o el *modelo de datos*, no código. Algunos tienen
licencias que piden cuidado (Fleetbase es AGPL-3.0; la vista *timeline* de FullCalendar es Premium); se avisa en cada caso.
De «LibreFleet» no encontré ningún proyecto abierto identificable: no lo cito.

Lo que **ya existe** y no repito como propuesta nueva: desplazamientos con paradas, hoja de ruta imprimible, cierre con km,
litros e importe, novedades del viaje, licencias de choferes, reservas, lista de espera, planificador semanal por cercanía
(haversine, 25 km), chofer sugerido, anomalías, hora de regreso estimada, agenda por hora y por mes, frecuentes con
precarga «a confirmar», panel de flota con semáforo, novedades mecánicas con estados, presentismo y cruce con Personal,
tablero de Dirección con cobertura y metas de viajes, metas anuales con carga mensual o trimestral, importación de planillas,
datos abiertos con mínimo publicable de 3 e informe del período.

---

## A. VIAJES, PLANIFICACIÓN Y FLOTA

### 1. Tiempos y distancias por calle (OSRM local, opcional)
- **Problema / qué hay hoy:** el planificador (`operacion._distancia_km`, `_cerca`, `RADIO_KM_AGRUPAR = 25`) agrupa por distancia en
  línea recta. En el AMBA, 25 km en línea recta entre Ezeiza y Marcos Paz no reflejan el tiempo real por ruta, y la hora de
  regreso estimada no tiene en cuenta el trayecto entre paradas.
- **Propuesta:** guardar una tabla `unidades_distancias (origen, destino, km, minutos, fuente, calculado_en)` y calcularla con un
  OSRM instalado **en el mismo servidor**, a partir de un recorte de OpenStreetMap de Argentina (servicio *table*). Si OSRM no
  está, se sigue usando la haversine con un factor de corrección (por ejemplo ×1,3). La tabla se recalcula a mano desde
  Administración, no en cada pedido.
- **Referencia:** OSRM, servicio Table (matriz de distancias y duraciones, self-hosted y sin tope de elementos) —
  https://blog.afi.io/blog/osrm-table-api-free-and-open-source-distance-matrix-api/ · API: https://project-osrm.org/docs/v5.5.1/api/
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple. Es local y optativo; sin OSRM todo sigue funcionando. No usar el servidor público de OSRM, porque
  mandaría coordenadas de unidades al exterior.

### 2. Orden sugerido de las paradas de un desplazamiento
- **Problema / qué hay hoy:** `operacion._ordenar_paradas` ordena las paradas por `hora_salida` y, si no hay hora, por id. Si una salida
  recorre tres unidades, el orden puede obligar a ir y volver.
- **Propuesta:** botón «Sugerir orden» en `traslados_desplazamiento.html`. Calcula el recorrido más corto (vecino más cercano +
  2-opt en Python puro, o OR-Tools si está instalado) con la matriz de la propuesta 1 o con la haversine. Muestra el orden
  actual y el sugerido con km y minutos; la coordinación confirma y queda registrado en el historial.
- **Referencia:** Google OR-Tools, ruteo de vehículos — https://developers.google.com/optimization/routing/vrp
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (cálculo local; el sistema solo propone).

### 3. Planificador con ventanas horarias y capacidad (VRPTW)
- **Problema / qué hay hoy:** `operacion.planificar` junta pedidos del mismo día por cercanía y plazas, pero no controla si el
  recorrido entra en el horario de ingreso de cada unidad ni en la jornada del chofer (`MAX_HORAS_DIA` se controla después, como
  anomalía).
- **Propuesta:** un modo «Propuesta optimizada» que arma las salidas con estas restricciones: plazas del vehículo, ventana horaria de
  cada unidad (propuesta 4), tiempo de permanencia estimado (mediana histórica, como hace `estimar_regreso`) y jornada máxima del
  chofer. Usa OR-Tools (dimensión «Time» con *slack* para la espera) o VROOM con su enlace Python. Igual que hoy, cada salida se
  confirma con un botón.
- **Referencia:** OR-Tools VRPTW — https://developers.google.com/optimization/routing/vrptw · VROOM (ventanas, capacidad,
  *skills*, pausas y prioridades; BSD-2) — https://github.com/vroom-project/vroom · pyvroom — https://pypi.python.org/project/pyvroom/
- **Impacto:** alto · **Esfuerzo:** L
- **Reglas fijas:** cumple (librerías locales; si no están instaladas, queda el planificador actual).

### 4. Horarios de ingreso de cada unidad en formato estructurado
- **Problema / qué hay hoy:** `unidades.horarios_visita` es texto libre. Sirve para la hoja de ruta, pero el sistema no puede avisar
  «la unidad no recibe audiencias después de las 15» ni usarlo en el planificador.
- **Propuesta:** tabla `unidad_ventanas (unidad_id, dia_semana, desde, hasta, tipo [audiencias | visita general | profesionales],
  vigente_desde, observacion)`. El texto actual se conserva como «nota». Al pedir un viaje se avisa si la hora cae fuera de la
  ventana (no bloquea) y el dato alimenta las propuestas 3 y 26.
- **Referencia:** modelo de ventanas horarias por punto de VROOM (`time_windows`) — https://github.com/vroom-project/vroom
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple (los cambios se versionan con `vigente_desde`; no se pisan).

### 5. Requisitos de vehículo y chofer («habilidades»)
- **Problema / qué hay hoy:** el chofer sugerido (`operacion.ranking_choferes`) mira si está libre, si tiene licencia y cuántas salidas
  hizo en la semana. No sabe si el viaje necesita un vehículo apto para ruta larga, una categoría de licencia determinada o un
  chofer habilitado para ingresar a cierta unidad.
- **Propuesta:** etiquetas simples (`requisitos` en el viaje, `habilidades` en vehículo y chofer): ruta larga, 7 plazas, licencia
  D1, habilitado en Complejo X… El sugeridor descarta lo que no cumple y explica por qué.
- **Referencia:** *skills* de VROOM (vehículos y trabajos con habilidades) — https://github.com/vroom-project/vroom
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 6. Descanso mínimo entre jornadas del chofer
- **Problema / qué hay hoy:** las anomalías controlan más de 10 horas en el día, más de 2 salidas por día y más de 8 por semana, pero no
  las horas de descanso entre el regreso de un día y la salida del siguiente.
- **Propuesta:** agregar a `operacion.anomalias` y a `ranking_choferes` la regla «menos de N horas entre regreso real (o estimado) y la
  próxima salida». N se configura en `config.ini`; se muestra el motivo.
- **Referencia:** pausas de conductor (*breaks*) en VROOM — https://github.com/vroom-project/vroom
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 7. Control del vehículo antes de salir (checklist)
- **Problema / qué hay hoy:** la hoja de ruta tiene lugar para km, combustible, novedades y firma, pero no hay un control previo
  sistemático (luces, cubiertas, matafuego, balizas, documentación). Las novedades mecánicas se cargan solo cuando alguien las
  ve.
- **Propuesta:** checklist corto y configurable en la pantalla del chofer («Mis salidas») o impreso en la hoja de ruta: ítem
  OK / con observación. Un ítem marcado «no apto» crea solo una novedad mecánica (`vehiculo_registros` tipo NOVEDAD) y avisa a la
  coordinación. Queda por desplazamiento.
- **Referencia:** Fleetms (mantenimiento de flota abierto: inspecciones, problemas, órdenes de trabajo) —
  https://relatedrepos.com/gh/jmnda-dev/fleetms · ítems típicos de control previo (comercial, solo como lista de ideas) —
  https://www.fleetio.com/blog/pre-trip-inspection-checklist
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 8. Control de consistencia del odómetro
- **Problema / qué hay hoy:** `flota.actualizar_km` y el cierre de salida actualizan el km. No encontré un control de km que
  retroceda o de un salto que no corresponda con la distancia esperada del recorrido.
- **Propuesta:** al cerrar una salida, avisar (sin bloquear) si `km_regreso < km_salida`, si `km_salida` es menor que el último km del
  vehículo o si los km recorridos se apartan más de un X % de la distancia estimada (propuesta 1). El aviso queda en anomalías.
- **Referencia:** Odoo Fleet, registro de odómetro y servicios por vehículo —
  https://www.odoo.com/documentation/17.0/applications/hr/fleet/service.html
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 9. Costo por viaje a la unidad y por equipo
- **Problema / qué hay hoy:** `operacion.consumo` suma km, litros, km por litro e importe **por vehículo**. Falta saber cuánto cuesta
  sostener la presencia en cada unidad o el trabajo de cada equipo.
- **Propuesta:** prorratear el importe del desplazamiento entre sus paradas (por km o en partes iguales) y entre los equipos de cada
  parada. Cuadro «costo por unidad / por equipo / por trimestre» en Estadísticas y en el tablero de Dirección, exportable a Excel.
- **Referencia:** Odoo Fleet, costos por tipo de servicio con vista pivote y exportación a XLSX —
  https://www.odoo.com/documentation/17.0/applications/hr/fleet/service.html
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 10. Rendimiento de combustible con alerta de desvío
- **Problema / qué hay hoy:** se calcula km por litro, pero no se avisa si una carga se aparta del rendimiento habitual del vehículo
  (error de carga, problema mecánico o uso indebido).
- **Propuesta:** para cada vehículo, la mediana de km/l de las últimas 10 cargas. Si una carga se aparta más de un 25 %, se crea un
  aviso para revisar. Se muestra en la ficha del vehículo.
- **Referencia:** alertas de combustible y mantenimiento de Traccar — https://www.traccar.org/local-en/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 11. Contratos, seguros y proveedores con responsable y aviso configurable
- **Problema / qué hay hoy:** `flota.AVISO_DIAS = 30` y `AVISO_KM = 1000` son fijos para todos los controles. No hay registro de
  proveedor (aseguradora, taller, estación) ni una persona responsable de cada vencimiento.
- **Propuesta:** tabla `proveedores` (con baja lógica) y, en cada control, el proveedor, la póliza o el número de orden y un
  responsable. Días de aviso por tipo (VTV 45, seguro 30, matafuego 15). El aviso le llega a la persona responsable dentro del
  sistema.
- **Referencia:** Odoo Fleet, alerta de fin de contrato N días antes, al responsable —
  https://www.odoo.com/documentation/17.0/applications/hr/fleet.html
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (el aviso es interno; nada sale por correo mientras no se vincule).

### 12. Órdenes de trabajo de taller
- **Problema / qué hay hoy:** la novedad mecánica tiene estados (cargada → reportada → reparación solicitada → en reparación →
  reparada). Falta la orden en sí: taller, presupuesto, fecha prometida, costo final y repuestos.
- **Propuesta:** «Orden de trabajo» vinculada a una o varias novedades, con etapas Nueva / En curso / Hecha / Cancelada, importe y
  taller. Al pasar a «En curso», el vehículo queda en TALLER automáticamente y vuelve a DISPONIBLE al cerrarla, pidiendo confirmación.
- **Referencia:** Odoo Fleet, servicios con etapas New / Running / Done / Cancelled y proveedor —
  https://www.odoo.com/documentation/17.0/applications/hr/fleet/service.html · Fleetms —
  https://relatedrepos.com/gh/jmnda-dev/fleetms
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (una orden cancelada se conserva).

### 13. Disponibilidad de la flota (días fuera de servicio)
- **Problema / qué hay hoy:** el panel de flota muestra el estado de hoy, pero no cuántos días por mes estuvo cada vehículo en taller,
  suspendido o fuera de circulación.
- **Propuesta:** registrar cada cambio de estado del vehículo con su fecha (ya hay motivo en `vehiculos.estado_motivo`) y calcular
  el % de disponibilidad por mes, por vehículo y para toda la flota, junto con los viajes que quedaron sin vehículo. Sirve para
  fundamentar pedidos de presupuesto.
- **Referencia:** reportes de resumen por vehículo y por flota de OpenGTS — https://opengts.sourceforge.net/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 14. Exportar la agenda a calendario (.ics), a pedido
- **Problema / qué hay hoy:** no hay exportación a calendario (no encontré `text/calendar` ni `BEGIN:VCALENDAR` en el código). Choferes y
  asesores miran «Mi semana» solo dentro del sistema.
- **Propuesta:** botón «Descargar mis viajes (.ics)» en «Mi semana» y en «Mis salidas»: un VEVENT por viaje con STATUS
  (TENTATIVE si está a confirmar, CONFIRMED, CANCELLED) y SEQUENCE que sube con cada reprogramación, para que el calendario de
  la PC actualice el evento en lugar de duplicarlo. Opcional: una dirección de suscripción con token personal, que solo funcione
  dentro de la red interna.
- **Referencia:** RFC 5545 iCalendar (VEVENT §3.6.1, STATUS §3.8.1.11, SEQUENCE §3.8.7.4) — https://rfc-editor.org/rfc/rfc5545
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple si es descarga manual o suscripción interna. No poner nombres de personas detenidas en el evento: solo
  unidad, horario y compañeros de viaje.

### 15. Frecuencias más ricas y excepciones en viajes frecuentes
- **Problema / qué hay hoy:** `frecuentes.FRECUENCIAS` admite semanal, quincenal y mensual. No se puede decir «primer y tercer martes
  del mes» ni «todos los lunes menos durante la feria judicial»; el «no viaja» se marca semana por semana.
- **Propuesta:** guardar la regla como RRULE (FREQ / INTERVAL / BYDAY / BYSETPOS / UNTIL) con fechas excluidas (EXDATE), y expandirla
  con la librería `recurring-ical-events` o con `dateutil.rrule`. La interfaz sigue siendo de opciones simples; la regla queda
  por detrás.
- **Referencia:** RFC 5545 RRULE §3.8.5.3 y EXDATE §3.8.5.1 — https://rfc-editor.org/rfc/rfc5545 · python-recurring-ical-events —
  https://github.com/tobixen/python-recurring-ical-events
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (librería local).

### 16. Calendario único de feriados y días no laborables
- **Problema / qué hay hoy:** `agentes.sumar_habiles` y `database.seguimiento_respuestas` reciben un parámetro `feriados`, pero no
  encontré una tabla de feriados: en la práctica llega vacío. Los frecuentes se precargan en feriados, el «jueves anterior» no se
  corre si el jueves es feriado y el «esperado a la fecha» de las metas cuenta días no laborables.
- **Propuesta:** tabla `feriados (fecha, motivo, tipo [nacional | puente | asueto PPN | feria])` que se carga a mano o se importa
  desde un .ics descargado. La usan los frecuentes (no precargar), el recordatorio del jueves (correrlo al día hábil anterior),
  los plazos de notas y las metas (propuesta 30).
- **Referencia:** EXDATE de RFC 5545 como modelo de excepciones — https://rfc-editor.org/rfc/rfc5545
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple (nada se descarga solo).

### 17. Vista por recurso: vehículos y choferes en filas, horas en columnas
- **Problema / qué hay hoy:** `/traslados/horas` es una agenda por hora y marca en rojo al mismo chofer en dos vehículos. Para asignar,
  sirve más ver cada vehículo y cada chofer como una fila del día, con los huecos libres a la vista.
- **Propuesta:** vista «Por vehículo» y «Por chofer» armada en el servidor (HTML y CSS grid, sin JavaScript de terceros), con
  barras por salida, reservas, licencias y taller. Tocar un hueco abre «Asignar» con ese recurso precargado.
- **Referencia:** concepto de *resource timeline* de FullCalendar — https://fullcalendar.io/docs/timeline-view (es una función
  **Premium**: se toma la idea y se arma en Jinja2, sin la librería).
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 18. Mapa de unidades sin depender de internet
- **Problema / qué hay hoy:** `/traslados/mapa` necesita internet para el mapa base de OpenStreetMap (README), y en otra parte se lo
  reemplazó por un listado con enlace a Google Maps. Las dos opciones dependen de afuera y hacen pedidos a terceros.
- **Propuesta:** servir un único archivo PMTiles de Argentina (o solo del AMBA) desde la carpeta `static/` de la app, con MapLibre o
  Leaflet incluidos en el propio sistema. Si el archivo no está, se sigue mostrando el listado actual.
- **Referencia:** Protomaps / PMTiles (mapa base en un solo archivo, sin servidor de teselas) — https://protomaps.com/faq ·
  alternativa más pesada: servidor de teselas OSM en Docker — https://www.Github.com/Overv/openstreetmap-tile-server
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple mejor que lo actual: el mapa es opcional y local, y no hay pedidos a terceros.

### 19. «Llegué / salí» por parada, con un toque
- **Problema / qué hay hoy:** se cargan los horarios reales del viaje (`hora_salida_real` y `hora_regreso_real`) y los del
  desplazamiento, pero no la hora de llegada y de salida de **cada parada**, que es el dato para medir la demora para ingresar y el
  tiempo efectivo dentro de la unidad.
- **Propuesta:** en «Mis salidas» (celular del chofer, dentro de la red o por VPN), botones «Llegamos a la unidad», «Ingresamos» y
  «Salimos», con la hora del servidor. Sin GPS: es un registro manual y voluntario.
- **Referencia:** geozonas de OpenGTS (registran llegada y salida de cada zona) — https://opengts.sourceforge.net/ · detección de
  paradas de Traccar (duración y distancia mínimas) — https://www.traccar.org/trips-stops/
- **Impacto:** alto (alimenta la propuesta 26) · **Esfuerzo:** S
- **Reglas fijas:** cumple. No se rastrea a nadie ni se transmite ubicación.

### 20. Doble confirmación de que el viaje se hizo
- **Problema / qué hay hoy:** un viaje confirmado con fecha pasada cuenta como realizado para estadísticas y metas
  (`avance_metas` filtra CONFIRMADO con fecha anterior a hoy). Si nadie carga la cancelación, se infla la meta.
- **Propuesta:** el viaje pasa a «Realizado» cuando lo confirma quien viajó (al cargar entrevistas) o el chofer (al cerrar la salida).
  Los confirmados sin ninguna de las dos marcas después de N días aparecen como «sin constancia» en el tablero, separados del
  resto.
- **Referencia:** constancia de realización con foto, firma o escaneo en la app de chofer de Fleetbase —
  https://github.com/fleetbase/fleetbase (AGPL-3.0: solo la idea).
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 21. Tiempo de respuesta de la coordinación (pedido → asignación)
- **Problema / qué hay hoy:** se ve qué pedidos están «sin asignar», pero no hace cuánto esperan ni cuál es el tiempo habitual de
  asignación.
- **Propuesta:** semáforo de antigüedad en «Asignar» (por ejemplo, ámbar a las 24 h hábiles y rojo a las 48 h o a menos de 48 h del
  viaje) y un indicador mensual con la mediana de horas hasta la asignación, para la Dirección. Reutiliza la lógica de semáforo
  de días en la etapa que ya tienen las notas.
- **Referencia:** estados de alerta OK / TRIGGERED / UNKNOWN de Redash —
  https://redash.io/help/user-guide/alerts/setting-up-an-alert/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 22. Lista de espera con prioridad, no solo por orden de llegada
- **Problema / qué hay hoy:** `operacion.avisar_lugar_libre` le avisa a la **primera** persona de la lista de espera.
- **Propuesta:** cada anotación lleva un motivo tipificado (urgencia: medida de fuerza, huelga de hambre, hábeas corpus, pedido
  judicial; o rutina). El orden sugerido es primero urgencia y después antigüedad; la coordinación puede cambiarlo y queda
  registrado.
- **Referencia:** prioridades de trabajos en VROOM — https://github.com/vroom-project/vroom
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 23. Puntaje sugerido cuando faltan vehículos
- **Problema / qué hay hoy:** si no hay vehículo, la persona pide «revisión de la Dirección» y la Dirección decide a mano («Dar
  prioridad» / «No corresponde»). No hay datos a la vista para comparar los pedidos que compiten.
- **Propuesta:** en la pantalla de revisión, para cada pedido que compite ese día: urgencia declarada, días desde la última visita a la
  unidad, si el equipo está «atrasado» en su meta y si es un viaje inmediato. Es solo información; la decisión sigue siendo de
  la Dirección.
- **Referencia:** APT, *Monitoring Places of Detention: A Practical Guide* (planificación de visitas según prioridades) —
  https://hrea.org/resources/monitoring-places-of-detention-a-practical-guide/
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 24. Comparar la propuesta del planificador con lo que se asignó
- **Problema / qué hay hoy:** el planificador propone y la coordinación confirma o cambia, pero no se mide si la propuesta habría
  ahorrado salidas o km.
- **Propuesta:** al cerrar la semana, un cuadro «propuesto vs. asignado»: salidas, km estimados, horas de chofer y pedidos sin
  cubrir. Sirve para ajustar los parámetros (radio, plazas) con datos.
- **Referencia:** benchmark de soluciones CVRPTW (comparar contra una solución de referencia) —
  https://www.hexaly.com/benchmarks/hexaly-gurobi-or-tools-capacitated-vehicle-routing-problem-with-time-windows-cvrptw
- **Impacto:** bajo · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 25. Informe de recorridos y paradas por vehículo
- **Problema / qué hay hoy:** los datos están (desplazamientos, paradas, horas reales, km), pero repartidos entre el tablero del día,
  la ficha del vehículo y Estadísticas.
- **Propuesta:** un informe por vehículo o chofer y período: cada salida con sus paradas, la hora de cada una (propuesta 19), km,
  tiempo en ruta, tiempo en unidad y novedades. Totales al pie y salida a Excel.
- **Referencia:** informes de recorridos, paradas y resumen de Traccar — https://www.traccar.org/trips-stops/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 26. Demora para ingresar a la unidad como indicador de obstáculos al monitoreo
- **Problema / qué hay hoy:** existen las novedades «ingreso denegado» y «demora para ingresar» (con minutos), sumadas por unidad.
  No se las muestra como serie en el tiempo ni se comparan con el horario de ingreso acordado.
- **Propuesta:** indicador por unidad y mes: % de visitas con obstáculos, mediana de minutos de espera (con la propuesta 19) y
  denegaciones. Se ve en «Datos → Por unidad» y en el tablero de Dirección, y se exporta para fundamentar notas y presentaciones.
- **Referencia:** APT, acceso irrestricto y sin demoras como condición del monitoreo preventivo —
  https://hrea.org/resources/monitoring-places-of-detention-a-practical-guide/ · APT NPM toolkit —
  https://www.apt.ch/index.php/en/knowledge-hub/npm-toolkit/activities/visit-reports
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 27. Terminar de cumplir «no se borra nada» en Autos PPN
- **Problema / qué hay hoy:** encontré borrados físicos: `operacion.borrar_licencia` (`DELETE FROM chofer_licencias`), la baja de un
  participante (`traslados.py:798`, `DELETE FROM viaje_participantes`), los precargados «a confirmar» al pausar o terminar un
  frecuente (`frecuentes.py:179-194`), los desplazamientos vacíos (`operacion.py:82`) y los alias de equipo
  (`traslados.py:1596`).
- **Propuesta:** pasar todos a baja lógica (`anulado_en`, `anulado_por`, `motivo`), con filtro «ver anulados» y la opción de
  recuperar. En los precargados que nadie confirmó puede bastar un estado `DESCARTADO`.
- **Referencia:** la misma regla que el sistema ya aplica a vehículos («Vehículos eliminados», con recuperar) y a notas
  («Descartados»).
- **Impacto:** alto (es una regla fija) · **Esfuerzo:** S
- **Reglas fijas:** corrige incumplimientos actuales.

### 28. Lugares libres en las salidas de los próximos días
- **Problema / qué hay hoy:** la lista de espera aparece solo cuando un vehículo está completo. Si una salida tiene plazas libres hacia
  Ezeiza, nadie se entera, aunque otro equipo vaya por sus propios medios.
- **Propuesta:** tarjeta «Salidas con lugar» en el inicio de Autos PPN y en «Mis viajes»: destino, hora y plazas libres, con
  «Sumarme» (lo confirma la coordinación). Bajan los viajes por medios propios y aumenta la cobertura.
- **Referencia:** asignación de pedidos en lote con planificación previa (*Orchestrator* de Fleetbase) —
  https://github.com/fleetbase/fleetbase
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

---

## B. METAS, INDICADORES Y TABLEROS

### 29. Una sola meta de visitas por equipo
- **Problema / qué hay hoy:** hay **dos** metas para lo mismo: `metas_viajes` (mínimo de viajes por trimestre, en
  `tablero_direccion.py`) y `metas_anuales` con el indicador `visitas_equipo` (en `metas.py`). Pueden contradecirse: un equipo puede
  estar «cumplido» en un tablero y «atrasado» en el otro.
- **Propuesta:** dejar `metas.py` como única fuente. El tablero de Dirección lee de ahí la meta y su reparto trimestral; los valores
  de `metas_viajes` se migran (si difieren, se muestran para elegir) y la tabla queda de solo lectura, sin borrarla.
- **Referencia:** práctica de «una sola fuente de verdad» por indicador en Metabase (preguntas reutilizadas en varios tableros) —
  https://www.metabase.com/learn/metabase-basics/getting-started/next-steps
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 30. Proyección al cierre y lo que falta por mes
- **Problema / qué hay hoy:** `metas.estado` compara lo hecho con lo «esperado a la fecha» (la meta repartida linealmente por
  `_fraccion_anio`). No dice cómo cerraría el año al ritmo actual ni cuánto hay que hacer por mes para llegar.
- **Propuesta:** dos columnas nuevas en el panel: «Al ritmo actual cerrás en N (X % de la meta)» y «Para llegar: N por mes». El
  esperado se calcula con días hábiles (propuesta 16) y, si se quiere, con la estacionalidad de años anteriores (enero y la
  feria).
- **Referencia:** Big Number con línea de tendencia y comparación entre períodos de Superset / Preset —
  https://docs.preset.io/docs/big-number-chart
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 31. Aviso interno cuando una meta pasa a «atrasada»
- **Problema / qué hay hoy:** el estado (cumplida / en camino / atrasada) se ve solo si alguien abre el panel.
- **Propuesta:** el mantenimiento de fondo (cada 10 minutos) evalúa los estados una vez por día y, cuando un indicador **cambia** de
  «en camino» a «atrasada», avisa en el sistema a la coordinación del equipo y, en un resumen semanal, a la Dirección. Avisa solo al
  cambiar, para no saturar, y se vuelve a activar cuando el indicador se recupera.
- **Referencia:** Metabase, alertas de línea de meta (al cruzarla, la primera vez o todas) —
  https://www.metabase.com/docs/latest/questions/alerts · Redash, frecuencia de notificación «Just once» —
  https://redash.io/help/user-guide/alerts/setting-up-an-alert/
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple (avisos internos).

### 32. Tarjetas de indicador con tendencia y comparación
- **Problema / qué hay hoy:** el panel de metas usa barras de avance (`barra-dir`) por equipo e indicador. No muestra la evolución mes
  a mes ni la comparación con el mismo período del año anterior (hay datos importados de planillas viejas).
- **Propuesta:** para cada indicador, una tarjeta con el número grande, una mini línea de 12 meses (SVG generado en el servidor),
  la variación contra el trimestre anterior y contra el mismo trimestre del año anterior.
- **Referencia:** Superset / Preset, Big Number with Trendline — https://docs.preset.io/docs/big-number-chart
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (sin librerías externas).

### 33. Revisión trimestral con comentario y plan de acción
- **Problema / qué hay hoy:** en `metas.py` se cargan números (quién y cuándo), pero no hay dónde explicar por qué un indicador está
  atrasado (licencias, cierre de una unidad, cambio de equipo) ni qué se va a hacer.
- **Propuesta:** al cerrar cada trimestre, la coordinación completa un breve «balance»: estado (verde / ámbar / rojo, con sugerencia
  automática), comentario, obstáculos y acciones. La Dirección lo lee junto al número y puede responder. Queda versionado.
- **Referencia:** Operately (OKR abierto, Apache-2.0, con *check-ins* periódicos de metas) — https://github.com/operately/operately
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 34. Objetivos institucionales por encima de los indicadores
- **Problema / qué hay hoy:** los indicadores se agrupan por tipo (visitas, monitoreos, informes, reuniones, requerimientos,
  comunicaciones), pero no se los vincula con los objetivos del plan anual del organismo («fortalecer el monitoreo de cárceles de
  mujeres», etc.).
- **Propuesta:** capa opcional de «objetivos» con sus «resultados clave», y cada resultado clave vinculado a uno o más indicadores
  existentes. Un tablero por objetivo suma el avance de sus indicadores.
- **Referencia:** OpenProject, OKR (objetivos y resultados clave vinculados al trabajo) — https://www.openproject.org/okr-software/ ·
  plan estratégico del MNPT de Costa Rica como ejemplo de un mecanismo de prevención con objetivos e indicadores —
  https://dhr.go.cr/images/planes-y-cumplimiento/2-2-1-1-plan-estrategico/Plan_Estrategico_MNPT_2024_2028.pdf
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 35. Frecuencia mínima de visita por unidad según riesgo
- **Problema / qué hay hoy:** el tablero muestra cobertura territorial y «unidades con notas y sin visitas» (`indicadores.py`), y
  `equipo_unidades` define las unidades habituales de cada equipo. No existe una frecuencia esperada por unidad.
- **Propuesta:** en `equipo_unidades`, una «frecuencia mínima» (mensual, bimestral…) y un nivel de riesgo (manual, o sugerido por notas
  recientes, novedades de ingreso y medidas de fuerza). Indicador: «% de unidades a cargo visitadas dentro de su frecuencia» y
  listado de «unidades vencidas» ordenado por días de atraso.
- **Referencia:** APT, guía práctica (periodicidad y selección de lugares a visitar) —
  https://hrea.org/resources/monitoring-places-of-detention-a-practical-guide/ · lista de control de MNP de la APT en español —
  https://www.apt.ch/sites/default/files/publications/NPM.checkshort_esp%20%281%29.pdf
- **Impacto:** alto · **Esfuerzo:** M
- **Reglas fijas:** cumple.

### 36. Indicadores de calidad de la visita, no solo de cantidad
- **Problema / qué hay hoy:** se cuentan visitas, audiencias e ingresos a pabellones por separado. No se ve la proporción: cuántas
  visitas incluyeron recorrida de pabellones o cuántas audiencias promedio hubo por visita.
- **Propuesta:** indicadores derivados, sin carga nueva: % de visitas con ingreso a pabellones, audiencias por visita, % de visitas con
  obstáculos (propuesta 26) y % de visitas con entrevistas informadas. Se presentan junto a las metas de cantidad.
- **Referencia:** APT, guía práctica (la visita incluye inspección de sectores y entrevistas en privado) —
  https://hrea.org/resources/monitoring-places-of-detention-a-practical-guide/ · salvaguardas de la APT —
  https://www.apt.ch/torture-prevention/what-torture-prevention/detention-safeguards
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 37. Seguimiento de lo que se pidió después de cada visita
- **Problema / qué hay hoy:** existen la carpeta del caso (`/caso`), las respuestas a notas despachadas con su plazo y los
  «requerimientos al SPF / FFSS» como indicador de carga manual. No hay una vista que una visita → requerimiento o nota → respuesta
  → cumplido o pendiente.
- **Propuesta:** desde el detalle del viaje, «Generó requerimiento / nota» (vínculo con la nota). Indicadores: requerimientos por
  unidad, % respondidos en plazo, % cumplidos y antigüedad de los pendientes. En la próxima visita a esa unidad, la hoja de ruta
  lista los pendientes para controlarlos en el lugar.
- **Referencia:** APT, NPM toolkit, informes de visita (el informe es línea de base para medir la implementación de las
  recomendaciones; los de seguimiento destacan lo no atendido) —
  https://www.apt.ch/index.php/en/knowledge-hub/npm-toolkit/activities/visit-reports
- **Impacto:** alto · **Esfuerzo:** L
- **Reglas fijas:** cumple. Ojo: la hoja de ruta impresa no debería llevar datos sensibles de personas detenidas; alcanza con el
  número de nota y el tema.

### 38. Completitud de la carga de metas
- **Problema / qué hay hoy:** si una coordinación no carga el mes, el panel muestra 0 y lo marca como atraso. No se distingue «no se
  hizo» de «no se cargó».
- **Propuesta:** estado «sin carga» por equipo y período (distinto de 0, que sí queda registrado con quién y cuándo, como ya hace
  `metas.py`), un semáforo de completitud en el panel de Dirección y un recordatorio a la coordinación los primeros días hábiles del
  mes, igual que el recordatorio del jueves.
- **Referencia:** estado UNKNOWN de Redash (sin datos ≠ OK ≠ disparado) —
  https://redash.io/help/user-guide/alerts/setting-up-an-alert/
- **Impacto:** alto · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 39. Ficha técnica de cada indicador
- **Problema / qué hay hoy:** los criterios están en el código y en el README («desplazamiento = …», «viaje a la unidad = día + unidad +
  equipo», «se cuentan notas, no informes»), pero no en pantalla.
- **Propuesta:** un «¿Cómo se calcula?» en cada indicador con definición, fórmula, fuente (viajes / carga / planilla), frecuencia,
  responsable de la carga, desde cuándo vale y cambios de criterio. Se genera a partir de `metas.INDICADORES`, ampliado con esos
  campos.
- **Referencia:** balanced scorecard para gobierno (definición y dueño de cada indicador; comercial, solo como práctica) —
  https://www.clearpointstrategy.com/balanced-scorecard-for-government/
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 40. Metas ajustadas por días disponibles de cada persona
- **Problema / qué hay hoy:** el «esperado a la fecha» se calcula igual para todo el equipo, aunque una persona haya estado de licencia
  dos meses. El cruce de presentismo ya lee la planilla de Personal (P/A/L/C).
- **Propuesta:** con los datos del cruce, calcular un «esperado ajustado» por persona y equipo (meta × días disponibles / días
  hábiles). Se muestra al lado del esperado lineal y no lo reemplaza: la meta fijada por la Dirección no cambia.
- **Referencia:** capacidad y recursos por vehículo de OR-Tools como analogía de capacidad por persona —
  https://developers.google.com/optimization/routing/cvrptw_resources
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (no corrige ni pisa datos; solo calcula).

### 41. Comparación entre equipos con valores normalizados
- **Problema / qué hay hoy:** el tablero de Dirección compara la carga de cada equipo con el promedio. Los equipos tienen tamaños y
  cantidades de unidades muy distintos.
- **Propuesta:** cuadro con selector «por integrante / por unidad a cargo / por población alojada (si se carga)» para visitas,
  audiencias e informes. Las celdas con menos de 3 casos se marcan como poco representativas.
- **Referencia:** Metabase, filtros y comparación en tableros —
  https://www.metabase.com/learn/metabase-basics/getting-started/next-steps
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

### 42. Datos abiertos y secreto estadístico también para metas
- **Problema / qué hay hoy:** `indicadores.datos_abiertos` aplica `MINIMO_PUBLICABLE = 3` a notas y viajes. Las metas y el tablero de
  Dirección se exportan a Excel sin esa regla, y por persona.
- **Propuesta:** una exportación «para publicar» de metas por equipo y trimestre (sin personas, con el mínimo publicable) para el
  informe anual. La exportación interna sigue como está.
- **Referencia:** informe anual de la PPN como destino de estas cifras —
  https://www.theioi.org/downloads/efpol/Argentina_PPN_Annual%20Report_2024_ES.pdf
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple (descarga manual; nada se publica solo).

### 43. Lectura del trimestre redactada por la IA local
- **Problema / qué hay hoy:** existe el borrador del informe del período en Word (87) con cifras. Falta un texto que interprete
  («Visitas: 82 % de lo esperado; atraso concentrado en CPF II por denegaciones de ingreso en agosto»).
- **Propuesta:** botón «Borrador de lectura» en el panel de metas: el servidor arma un resumen numérico estructurado y Ollama solo lo
  redacta. Las cifras se insertan desde los datos, no las genera el modelo, y el texto se marca como borrador para revisar.
- **Referencia:** Metabase, funciones avanzadas de análisis (se toma la idea de una explicación automática del tablero) —
  https://www.metabase.com/learn/metabase-basics/getting-started/next-steps
- **Impacto:** medio · **Esfuerzo:** M
- **Reglas fijas:** cumple (Ollama local; se respeta la pausa por uso de la IA que ya existe).

### 44. Alertas de resultado: «consultas que deberían dar vacío»
- **Problema / qué hay hoy:** hay anomalías de traslados, pero no reglas de control de datos de metas y tablero (por ejemplo,
  audiencias informadas sin visita, una persona con visitas en dos unidades a la misma hora, ingreso a pabellones marcado sin
  viaje realizado).
- **Propuesta:** un conjunto de controles en Python: cada uno devuelve filas y, si devuelve alguna, aparece en «Administración →
  Calidad de datos de metas», con un enlace para corregir. No corrige nada solo.
- **Referencia:** Metabase, *results alerts* (avisan cuando una consulta que suele no traer filas trae alguna) —
  https://www.metabase.com/docs/latest/questions/alerts
- **Impacto:** medio · **Esfuerzo:** S
- **Reglas fijas:** cumple.

---

## Resumen por prioridad

| Prioridad | Propuestas |
|---|---|
| Alto impacto y esfuerzo S (empezar por acá) | 16 feriados · 19 llegué/salí · 20 doble confirmación · 26 demora de ingreso · 27 no borrar · 29 unificar metas · 30 proyección · 31 aviso de atraso · 36 calidad de visita · 38 completitud |
| Alto impacto, esfuerzo M o L | 1 OSRM local · 3 VRPTW · 4 ventanas por unidad · 7 checklist · 17 vista por recurso · 33 revisión trimestral · 35 frecuencia por riesgo · 37 seguimiento de requerimientos |
| Medio o bajo impacto | 2, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 18, 21, 22, 23, 24, 25, 28, 32, 34, 39, 40, 41, 42, 43, 44 |

**Dependencias:** 3 depende de 4 (y conviene tener 1). 26 y 25 mejoran mucho con 19. 30 y 40 usan 16. 31 y 38 se apoyan en
el mantenimiento de fondo que ya existe. 29 conviene hacerla antes que cualquier otra mejora del tablero de metas.
