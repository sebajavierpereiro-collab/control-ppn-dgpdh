# Guía para implementar las propuestas de mejora (164)

Numeración y detalle: `docs/propuestas/propuestas_mejora.md` (índice) y los tres `detalle_*.md`.
- Notas, IA y detenidos: propuestas 1–53 = detalle_notas_ia #1–53.
- Viajes, flota y metas: 54–97 = detalle_viajes_metas #1–44.
- Interfaz: 98–164 = detalle_ui_ux #1–67.

## Reglas que no se negocian
1. **IA solo local** (Ollama). Nada se transmite al exterior automáticamente: sin CDN, sin fuentes, mapas ni analítica remotos, sin APIs públicas. `pruebas/test_sin_recursos_remotos.py` lo controla.
2. **La IA propone; decide una persona.** Ninguna IA cambia datos sola.
3. **Nada se borra físicamente.** Usá baja lógica, anulación con motivo o `db.borrar_con_registro` (deja la fila en la auditoría).
4. **Auditoría:** todo cambio de datos que haga una persona va a `dgpdh.seguridad.auditoria.registrar(con, ...)`, en la misma transacción.
5. **Permisos:** respetá los existentes (`auth`, `_puede_ver_nota`, `_puede_gestionar_nota`, `traslados.puede_coordinar`, `detenidos.puede_ver`, etc.). Nunca muestres datos que la persona hoy no ve.
6. **Sin dependencias nuevas obligatorias.** Si una propuesta necesita software externo (OSRM, OCRmyPDF, unoserver, Presidio, pyHanko, otro modelo de Ollama, LanguageTool como servicio), hacé la integración **optativa**: se activa por `config.ini` y, si falta, el sistema funciona igual que hoy. Avisalo en el informe final. No agregues paquetes a `requirements.txt` salvo que ya estén instalados en el entorno de pruebas y sean livianos.
7. **El sistema está en producción** (≈70 personas en Notas, ≈200 en Autos PPN). Ningún cambio puede romper un flujo actual. Ante la duda, la mejora va como opción y no reemplaza lo de hoy.
8. Textos de pantalla en **español rioplatense claro** (vos, sin jerga técnica), igual que el resto del sistema.

## Dónde poner el código (para que las tres áreas no choquen)
- **Código nuevo** en módulos nuevos: preferentemente `dgpdh/` (dominio puro, servicios con `sqlite3.Connection`, tipado estricto, `mypy` sin errores), o un `rutas_<tema>.py` nuevo que se registre como los demás (`registrar(app, ctx)` al final de `main.py`).
- **Archivos compartidos** (`main.py`, `database.py`, `templates/base.html`, `nucleo.py`, `traslados.py`): cambios mínimos y localizados. No reformatees ni muevas bloques.
- **CSS:** cada área tiene su propio archivo. No toques `static/estilos.css` salvo para corregir algo puntual.
  - Notas e IA: `static/estilos_notas.css`.
  - Viajes y metas: `static/estilos_viajes.css`.
  - Interfaz: `static/estilos_ui.css`.

  Para el `<link>` en `base.html`, una sola línea después de la de `estilos.css`.
- **JS:** archivos propios en `static/` (`notas_*.js`, `viajes_*.js`, `ui_*.js`). Nada de JS de terceros, salvo que lo copies al repositorio con su licencia y su huella.
- **Migraciones** (`dgpdh/persistencia/versiones/`), con número por rango:
  - Notas: 0010–0019.
  - Viajes: 0020–0029.
  - Interfaz: 0030–0039.
  - Notas (ampliación): 0040–0049.
  - Viajes (ampliación): 0050–0059.

  Solo agregan (ADD COLUMN, CREATE TABLE/INDEX IF NOT EXISTS) y comprueban si la tabla o columna existe antes de tocarla.

## Pruebas y verificación (obligatorio antes de cada commit)
- Cada mejora trae su prueba: el caso normal, los casos borde y los permisos. Las pruebas nuevas van en `pruebas/test_<tema>.py` (pytest), o como script en `tests/` siguiendo el arnés de `tests/test_obstaculizaciones_web.py`.
- `python3 herramientas/verificar.py` tiene que terminar en «todo en orden»: ruff sin avisos nuevos, mypy estricto sobre `dgpdh/` y todas las pruebas. Antes de correrlo, borrá `datos/*.db*`.
- Si una prueba vieja falla, no la «arregles» para que pase: entendé por qué falla. Solo se ajusta si el cambio de comportamiento es intencional y está documentado.
- Commits chicos, uno por propuesta o grupo chico: `git commit -m "Propuesta N: ..."`.

## Informe final (en el mensaje de cierre)
Una tabla con el número de cada propuesta del área y su estado:
- **HECHA:** qué archivos y qué prueba.
- **PARCIAL:** qué falta.
- **OPTATIVA:** el código está, pero se activa en `config.ini` cuando se instale X.
- **NO HECHA:** por qué. Por ejemplo, necesita una decisión del usuario, contradice una regla o es demasiado grande.

Al final, las decisiones que hacen falta del usuario.
