# Mapa de dependencias (generado por herramientas/mapa_dependencias.py)

63 módulos, 32,237 líneas. «SQL» = llamadas a `.execute(` en el módulo (fuera de database.py indica acceso directo a la base que debería pasar a un repositorio).

## IA y procesamiento

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| nucleo | 1,705 | 0 | despacho, referencia_ia, trazabilidad_ia | 11 |
| analisis | 743 | 0 | nucleo, referencia_ia | 4 |
| automatico | 740 | 0 | agentes, analisis, avisos_correo, carga, database, nucleo, operacion, programados, referencia_ia, respaldo, revision_ia, salud, traslados, trazabilidad_ia | 5 |
| agentes | 718 | 1 | analisis, auth, automatico, database, despacho, expedientes, mesa_entradas, nucleo, plazos | 6 |
| referencia_ia | 709 | 27 | analisis, database, nucleo, tipos_documentales | 6 |
| revision_ia | 421 | 19 | automatico, database, detenidos, nucleo | 4 |
| consultas | 402 | 3 | agentes, database, indicadores, nucleo, traslados, trazabilidad_ia | 1 |
| trazabilidad_ia | 105 | 6 | database | 5 |
| aprendizaje | 82 | 0 | — | 1 |

## dominio / servicios

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| detenidos | 2,082 | 108 | auth, database, expedientes, presentismo, revision_ia | 6 |
| traslados | 1,599 | 92 | database, flota, frecuentes, geo_ar, operacion, tablero_direccion | 16 |
| operacion | 984 | 56 | auth, database, flota, frecuentes, importar_viajes, traslados | 4 |
| circuito | 549 | 0 | database, despacho, nucleo | 2 |
| indicadores | 489 | 13 | auth, database, reportes, traslados | 3 |
| metas | 489 | 8 | auth, database, metas_importar, traslados | 4 |
| presentismo | 457 | 4 | database, traslados | 4 |
| unidades_menu | 441 | 29 | database | 2 |
| tablero_direccion | 424 | 7 | database, flota, traslados | 2 |
| metas_importar | 404 | 19 | auth, database, metas | 2 |
| frecuentes | 361 | 17 | database, traslados | 3 |
| flota | 351 | 21 | database, traslados | 4 |
| despacho | 330 | 0 | — | 6 |
| importar_viajes | 286 | 5 | database, traslados | 2 |
| manual | 253 | 0 | auth | 1 |
| salud | 230 | 6 | auth, automatico, avisos_correo, database, https_interno, nucleo, respaldo | 2 |
| programados | 199 | 4 | auth, database, indicadores, presentismo | 3 |
| unidades_csv | 138 | 0 | database | 1 |
| importar_usuarios | 136 | 0 | auth, database | 1 |
| reportes | 134 | 4 | database | 3 |
| archivo_cargas | 91 | 7 | database | 5 |
| menu_paneles | 84 | 0 | auth, database, detenidos, metas, traslados | 1 |
| tipos_documentales | 72 | 0 | — | 3 |
| diagnostico_login | 69 | 1 | auth, database | 0 |
| plazos | 66 | 0 | — | 3 |
| flujo | 62 | 0 | — | 2 |
| carga | 58 | 0 | database | 2 |
| fechas | 45 | 0 | — | 4 |
| geo_ar | 44 | 0 | — | 1 |
| avatares | 41 | 0 | database | 1 |
| iconos | 30 | 0 | — | 5 |

## integración / infraestructura

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| sso | 241 | 0 | database | 1 |
| expedientes | 225 | 0 | — | 3 |
| https_interno | 184 | 0 | — | 2 |
| mesa_entradas | 158 | 0 | — | 2 |
| avisos_correo | 112 | 0 | database, fechas | 3 |
| almacen_ppn | 72 | 0 | — | 1 |

## persistencia

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| database | 3,702 | 419 | agentes, archivo_cargas, auth, detenidos, fechas, metas, plazos, referencia_ia, revision_ia, soberania, tipos_documentales, trazabilidad_ia, unidades_menu | 43 |
| respaldo | 262 | 4 | database, soberania | 3 |
| migrar_postgresql | 209 | 13 | database | 1 |
| integridad | 62 | 0 | — | 1 |

## seguridad y auditoría

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| soberania | 310 | 4 | database | 3 |
| pin | 151 | 5 | auth, database | 2 |
| auth | 131 | 0 | — | 20 |
| control_cambios | 89 | 0 | — | 1 |
| actividad | 72 | 4 | database, fechas | 1 |

## web (rutas)

| Módulo | Líneas | SQL | Importa | Lo importan |
|---|---:|---:|---|---|
| main | 5,690 | 3 | actividad, agentes, almacen_ppn, analisis, aprendizaje, archivo_cargas, auth, automatico, avisos_correo, carga, circuito, control_cambios, database, despacho, detenidos, expedientes, fechas, flujo, https_interno, iconos, importar_usuarios, integridad, menu_paneles, mesa_entradas, migrar_postgresql, nucleo, operacion, pin, plazos, programados, referencia_ia, reportes, respaldo, rutas_circuito, rutas_datos, rutas_detenidos, rutas_metas, rutas_operacion, rutas_referencia, rutas_traslados, salud, soberania, sso, tipos_documentales, traslados, trazabilidad_ia | 1 |
| rutas_traslados | 1,383 | 1 | archivo_cargas, auth, avatares, database, detenidos, flota, frecuentes, iconos, importar_viajes, presentismo, tablero_direccion, traslados, unidades_csv, unidades_menu | 1 |
| rutas_detenidos | 733 | 2 | archivo_cargas, database, despacho, detenidos, revision_ia | 1 |
| rutas_operacion | 518 | 4 | database, iconos, operacion, traslados | 1 |
| rutas_circuito | 501 | 1 | agentes, auth, automatico, circuito, database, despacho, flujo, iconos, main, nucleo, reportes, traslados | 1 |
| rutas_metas | 332 | 0 | archivo_cargas, auth, database, metas, metas_importar | 1 |
| rutas_datos | 330 | 1 | agentes, auth, consultas, database, iconos, indicadores, manual, nucleo, pin, presentismo, programados, traslados | 1 |
| rutas_referencia | 147 | 0 | auth, referencia_ia | 1 |

## Importaciones circulares directas

- agentes ↔ automatico
- agentes ↔ database
- analisis ↔ referencia_ia
- archivo_cargas ↔ database
- automatico ↔ revision_ia
- automatico ↔ salud
- database ↔ detenidos
- database ↔ metas
- database ↔ referencia_ia
- database ↔ revision_ia
- database ↔ soberania
- database ↔ trazabilidad_ia
- database ↔ unidades_menu
- detenidos ↔ revision_ia
- flota ↔ traslados
- frecuentes ↔ traslados
- main ↔ rutas_circuito
- metas ↔ metas_importar
- nucleo ↔ referencia_ia
- operacion ↔ traslados
- tablero_direccion ↔ traslados
