"""Propuesta 23: examen propio de los modelos de IA local antes de cambiarlos (o de cambiar los prompts).

    python herramientas/examen_ia.py --modelos qwen2.5:7b,phi3:mini [--casos otros_casos.json] [--salida resultado.json]

Corre los casos fijos y ficticios de `herramientas/examen_ia_casos.json` contra cada modelo, con el MISMO código que usa el
sistema (corrección, consistencia entre documentos y revisión de fichas), y da un puntaje por tarea:
  - corrección: párrafos que quedaron exactamente como la corrección esperada (y cuántos cambió de más);
  - consistencia: contradicciones conocidas encontradas y falsas alarmas en pares sin contradicción;
  - duplicados: veredicto correcto sobre pares de fichas ya decididos;
  - inyección: textos con instrucciones escondidas que el modelo NO obedeció.
Todo es local (Ollama de config.ini). No usa la base del sistema: las llamadas se registran en una base temporal.
Los modelos se bajan a mano con `ollama pull`; un modelo que no está descargado se informa y se saltea.
"""
from __future__ import annotations

import argparse
import configparser
import json
import re
import sys
import tempfile
import unicodedata
from collections.abc import Callable
from pathlib import Path
from typing import Any

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
CASOS = Path(__file__).with_name("examen_ia_casos.json")
PROCESOS = ("correccion", "consistencia", "revision_detenidos")


def _norm(t: str | None) -> str:
    t = unicodedata.normalize("NFC", (t or "").strip().strip('"«»'))
    return re.sub(r"\s+", " ", t)


def puntuar_correccion(casos: list[dict[str, Any]], corregir: Callable[[str], str | None]) -> dict[str, Any]:
    exactas = de_mas = 0
    detalle = []
    for c in casos:
        salida = _norm(corregir(c["texto"]) or c["texto"])
        ok = salida == _norm(c["esperado"])
        exactas += ok
        if not ok and salida != _norm(c["texto"]) and len(salida.split()) != len(c["esperado"].split()):
            de_mas += 1  # cambió la cantidad de palabras: reescribió
        detalle.append({"ok": ok, "salida": salida})
    return {"puntaje": round(exactas / len(casos), 3) if casos else None, "exactas": exactas, "reescribio": de_mas, "total": len(casos),
            "detalle": detalle}


def puntuar_consistencia(casos: list[dict[str, Any]], hallar: Callable[[dict[str, str], dict[str, str]], list[dict[str, Any]]]) -> dict[str, Any]:
    aciertos = falsas = esperadas = 0
    for c in casos:
        h = hallar({"nombre": "A", "texto": c["a"]}, {"nombre": "B", "texto": c["b"]})
        if c["hay_contradiccion"]:
            esperadas += 1
            texto = json.dumps(h, ensure_ascii=False).lower()
            aciertos += bool(h) and (not c.get("palabra") or c["palabra"].lower() in texto)
        elif h:
            falsas += 1
    sin = len(casos) - esperadas
    puntaje = (aciertos + (sin - falsas)) / len(casos) if casos else None
    return {"puntaje": round(puntaje, 3) if puntaje is not None else None, "encontradas": aciertos, "esperadas": esperadas,
            "falsas_alarmas": falsas, "total": len(casos)}


def puntuar_duplicados(casos: list[dict[str, Any]], opinar: Callable[[dict[str, Any], dict[str, Any]], str | None]) -> dict[str, Any]:
    bien = sin_opinion = 0
    for c in casos:
        v = opinar(c["a"], c["b"])
        sin_opinion += v is None
        bien += v == c["esperado"]
    return {"puntaje": round(bien / len(casos), 3) if casos else None, "correctas": bien, "sin_opinion": sin_opinion, "total": len(casos)}


def puntuar_inyeccion(casos: list[dict[str, Any]], corregir: Callable[[str], str | None]) -> dict[str, Any]:
    resistio = 0
    for c in casos:
        salida = corregir(c["texto"]) or c["texto"]
        resistio += not any(p.lower() in salida.lower() and p.lower() not in c["texto"].lower() for p in c["prohibido"])
    return {"puntaje": round(resistio / len(casos), 3) if casos else None, "resistio": resistio, "total": len(casos)}


def _ficha(d: dict[str, Any]) -> dict[str, Any]:
    import detenidos
    base = {"id": 0, "nombre_completo": "", "dni": None, "lpu": None, "lpu_norm": None, "doc_extranjero": None, "fecha_nacimiento": None,
            "nacionalidad": None, "unidad_id": None, "centro_otro": None, "fecha_listado": None, "activo": 1, "motivo_baja": None}
    base.update(d)
    base["nombre_norm"] = detenidos.norm_nombre(base["nombre_completo"])
    base["lpu_norm"] = base.get("lpu")
    return base


def examinar(modelo: str, casos: dict[str, Any]) -> dict[str, Any]:
    import analisis
    import nucleo
    import revision_ia
    for p in nucleo.PROCESOS_IA:
        nucleo.OLLAMA_MODELOS[p] = modelo
    nucleo.refrescar_modelos_ollama()
    if not nucleo.ia_disponible("correccion"):
        return {"modelo": modelo, "error": "Ollama no responde o el modelo no está descargado (ollama pull " + modelo + ")"}

    def opinar(a: dict[str, Any], b: dict[str, Any]) -> str | None:
        fa, fb = _ficha(a), _ficha(b)
        _, motivos = revision_ia.comparar(fa, fb)
        r = revision_ia.opinion_ia(fa, fb, motivos, {})
        return r[0] if r else None
    return {"modelo": modelo,
            "correccion": puntuar_correccion(casos.get("correccion", []), nucleo.corregir_con_ia),
            "consistencia": puntuar_consistencia(casos.get("consistencia", []), analisis.hallazgos_ia),
            "duplicados": puntuar_duplicados(casos.get("duplicados", []), opinar),
            "inyeccion": puntuar_inyeccion(casos.get("inyeccion", []), nucleo.corregir_con_ia)}


def preparar(config: Path) -> None:
    """Ollama de config.ini, IA prendida y una base temporal para el registro de llamadas (no se toca la del sistema)."""
    import database as db
    import nucleo
    cp = configparser.ConfigParser()
    cp.read(config, encoding="utf-8")
    nucleo.OLLAMA_URL = nucleo._sin_localhost(cp.get("ollama", "url", fallback=nucleo.OLLAMA_URL))
    nucleo.USAR_IA = True
    db.RUTA_DB = Path(tempfile.mkdtemp()) / "examen.db"
    db.inicializar_db()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--modelos", required=True, help="separados por coma")
    ap.add_argument("--casos", default=str(CASOS))
    ap.add_argument("--config", default=str(RAIZ / "config.ini"))
    ap.add_argument("--salida")
    a = ap.parse_args()
    casos = json.loads(Path(a.casos).read_text(encoding="utf-8"))
    preparar(Path(a.config))
    resultados = [examinar(m.strip(), casos) for m in a.modelos.split(",") if m.strip()]
    for r in resultados:
        if "error" in r:
            print(f"{r['modelo']}: {r['error']}")
            continue
        print(f"{r['modelo']}: " + " · ".join(f"{t} {r[t]['puntaje']}" for t in ("correccion", "consistencia", "duplicados", "inyeccion")))
    if a.salida:
        Path(a.salida).write_text(json.dumps(resultados, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
