"""Verificación completa antes de entregar una versión (hito 0 del plan de arquitectura).

    python herramientas/verificar.py              # lint + tipos + pruebas
    python herramientas/verificar.py --rapido     # solo lint y tipos
    python herramientas/verificar.py --linea-base # guarda los avisos actuales de ruff como aceptados

1. ruff: el código histórico tiene avisos; falla solo si aparecen avisos NUEVOS respecto de la línea de base
   (herramientas/ruff_linea_base.json, por archivo y regla). Bajar avisos siempre está permitido.
2. mypy estricto sobre el paquete nuevo dgpdh/.
3. pytest (pruebas/): corre todos los scripts de tests/ y las pruebas nuevas.
Si ruff o mypy no están instalados, se avisa y se sigue (la PC de producción no los necesita).
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
LINEA_BASE = RAIZ / "herramientas" / "ruff_linea_base.json"


def _avisos_ruff() -> Counter[str] | None:
    if not shutil.which("ruff"):
        print("· ruff no está instalado: se omite el lint (pip install ruff)")
        return None
    r = subprocess.run(["ruff", "check", ".", "--output-format", "json", "--exit-zero"], cwd=RAIZ, capture_output=True, text=True,
                       encoding="utf-8")
    datos = json.loads(r.stdout or "[]")
    return Counter(f"{Path(a['filename']).resolve().relative_to(RAIZ).as_posix()}::{a['code'] or 'sintaxis'}" for a in datos)


def lint(guardar: bool) -> bool:
    actuales = _avisos_ruff()
    if actuales is None:
        return True
    if guardar:
        LINEA_BASE.write_text(json.dumps(dict(sorted(actuales.items())), indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"✓ línea de base de ruff guardada: {sum(actuales.values())} aviso(s) aceptados")
        return True
    base = Counter(json.loads(LINEA_BASE.read_text(encoding="utf-8"))) if LINEA_BASE.exists() else Counter()
    nuevos = {k: n - base.get(k, 0) for k, n in actuales.items() if n > base.get(k, 0)}
    if nuevos:
        print("✗ ruff: avisos nuevos respecto de la línea de base:")
        for k, n in sorted(nuevos.items()):
            print(f"   {k}  (+{n})")
        subprocess.run(["ruff", "check", *sorted({k.split('::')[0] for k in nuevos}), "--output-format", "concise"], cwd=RAIZ)
        return False
    bajaron = sum(base.values()) - sum(actuales.values())
    print(f"✓ ruff: sin avisos nuevos ({sum(actuales.values())} históricos" + (f", {bajaron} menos que la línea de base" if bajaron > 0 else "") + ")")
    return True


def tipos() -> bool:
    if not shutil.which("mypy"):
        print("· mypy no está instalado: se omite el chequeo de tipos (pip install mypy)")
        return True
    r = subprocess.run(["mypy"], cwd=RAIZ, capture_output=True, text=True, encoding="utf-8")
    ok = r.returncode == 0
    print(("✓ mypy (dgpdh/, estricto): " if ok else "✗ mypy:\n") + (r.stdout.strip().splitlines()[-1] if ok and r.stdout.strip() else r.stdout))
    return ok


def pruebas() -> bool:
    r = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=RAIZ)
    print("✓ pruebas" if r.returncode == 0 else "✗ pruebas con fallas")
    return r.returncode == 0


def main() -> int:
    args = set(sys.argv[1:])
    ok = lint("--linea-base" in args)
    ok = tipos() and ok
    if "--rapido" not in args and "--linea-base" not in args:
        ok = pruebas() and ok
    print("\nRESULTADO: " + ("todo en orden" if ok else "HAY PROBLEMAS"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
