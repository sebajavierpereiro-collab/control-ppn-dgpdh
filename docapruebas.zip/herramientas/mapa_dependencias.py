"""Genera docs/mapa_dependencias.md: qué módulo importa a cuál, cuáles tocan la base directamente y el tamaño de cada uno.

    python herramientas/mapa_dependencias.py

Sirve para planificar el paso de los módulos históricos al paquete dgpdh/ (ver ARCHITECTURE.md).
"""
from __future__ import annotations

import ast
from collections import defaultdict
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
SALIDA = RAIZ / "docs" / "mapa_dependencias.md"


def capa(nombre: str) -> str:
    if nombre in ("main",) or nombre.startswith("rutas_"):
        return "web (rutas)"
    if nombre in ("database", "migrar_postgresql", "respaldo", "integridad"):
        return "persistencia"
    if nombre in ("sso", "almacen_ppn", "mesa_entradas", "expedientes", "avisos_correo", "https_interno"):
        return "integración / infraestructura"
    if nombre in ("nucleo", "analisis", "revision_ia", "referencia_ia", "trazabilidad_ia", "aprendizaje", "agentes", "automatico", "consultas"):
        return "IA y procesamiento"
    if nombre in ("auth", "pin", "soberania", "control_cambios", "actividad"):
        return "seguridad y auditoría"
    return "dominio / servicios"


def main() -> None:
    modulos = {p.stem: p for p in RAIZ.glob("*.py")}
    importa: dict[str, set[str]] = defaultdict(set)
    sql: dict[str, int] = {}
    lineas: dict[str, int] = {}
    for nombre, ruta in sorted(modulos.items()):
        texto = ruta.read_text(encoding="utf-8")
        lineas[nombre] = texto.count("\n") + 1
        sql[nombre] = texto.count(".execute(")
        for nodo in ast.walk(ast.parse(texto)):
            if isinstance(nodo, ast.Import):
                importa[nombre] |= {a.name.split(".")[0] for a in nodo.names if a.name.split(".")[0] in modulos}
            elif isinstance(nodo, ast.ImportFrom) and nodo.module and nodo.module.split(".")[0] in modulos:
                importa[nombre].add(nodo.module.split(".")[0])
        importa[nombre].discard(nombre)
    lo_importan: dict[str, set[str]] = defaultdict(set)
    for a, bs in importa.items():
        for b in bs:
            lo_importan[b].add(a)
    por_capa: dict[str, list[str]] = defaultdict(list)
    for n in modulos:
        por_capa[capa(n)].append(n)
    out = ["# Mapa de dependencias (generado por herramientas/mapa_dependencias.py)", "",
           f"{len(modulos)} módulos, {sum(lineas.values()):,} líneas. «SQL» = llamadas a `.execute(` en el módulo "
           "(fuera de database.py indica acceso directo a la base que debería pasar a un repositorio).", ""]
    for c in sorted(por_capa):
        out += [f"## {c}", "", "| Módulo | Líneas | SQL | Importa | Lo importan |", "|---|---:|---:|---|---|"]
        for n in sorted(por_capa[c], key=lambda x: -lineas[x]):
            out.append(f"| {n} | {lineas[n]:,} | {sql[n]} | {', '.join(sorted(importa[n])) or '—'} | {len(lo_importan[n])} |")
        out.append("")
    ciclos = sorted({tuple(sorted((a, b))) for a, bs in importa.items() for b in bs if a in importa.get(b, set())})
    out += ["## Importaciones circulares directas", ""] + ([f"- {a} ↔ {b}" for a, b in ciclos] or ["Ninguna."]) + [""]
    SALIDA.parent.mkdir(exist_ok=True)
    SALIDA.write_text("\n".join(out), encoding="utf-8")
    print(f"✓ {SALIDA.relative_to(RAIZ)}: {len(modulos)} módulos, {len(ciclos)} ciclo(s) directos")


if __name__ == "__main__":
    main()
