"""Propuesta 43: copias anonimizadas de notas y fichas (para pruebas, capacitación y el examen de la IA).

    python herramientas/anonimizar.py --salida /ruta/copia_anonimizada [--notas 200] [--fichas 500] [--generalizar-lugares]

- Lee la base en modo solo lectura (no cambia nada) y escribe en la carpeta de salida:
  notas/<n>.txt, fichas.csv, resumen.json y MUESTRA_PARA_REVISAR.txt.
- Los nombres de la base de personas detenidas se usan para encontrarlos en los textos; además se reconocen
  «APELLIDO, Nombre» y «Sr./interno Nombre Apellido». DNI, CUIL, LPU, expedientes y números GDE pasan a valores ficticios.
- ANTES DE USAR LA COPIA, una persona revisa la muestra (lo marcado como «revisar» puede ser un dato que se escapó).
- La carpeta de salida no puede estar dentro de datos/ ni ser la carpeta del sistema: la copia es aparte.
"""
from __future__ import annotations

import argparse
import csv
import json
import sqlite3
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from dgpdh.dominio.anonimizar import Anonimizador  # noqa: E402

CAMPOS_FICHA = ("id", "nombre_completo", "dni", "lpu", "fecha_nacimiento", "nacionalidad", "unidad_id", "centro_otro", "modulo", "pabellon",
                "situacion_procesal", "juzgado", "tribunal", "activo", "motivo_baja", "observaciones")


def _leer(base: Path, sql: str, params: tuple[object, ...] = ()) -> list[dict[str, object]]:
    con = sqlite3.connect(f"file:{base}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        return [dict(f) for f in con.execute(sql, params)]
    except sqlite3.OperationalError:
        return []
    finally:
        con.close()


def generar(base: Path, salida: Path, notas: int = 200, fichas: int = 500, generalizar_lugares: bool = False,
            semilla: str = "dgpdh") -> dict[str, object]:
    salida = salida.resolve()
    if salida == RAIZ or RAIZ / "datos" in (salida, *salida.parents) or base.parent.resolve() in (salida, *salida.parents):
        raise SystemExit("La carpeta de salida tiene que estar fuera del sistema y de la carpeta de datos.")
    nombres = [str(f["nombre_completo"]) for f in _leer(base, "SELECT nombre_completo FROM detenidos")]
    lugares = [str(f["nombre"]) for f in _leer(base, "SELECT nombre FROM unidades")]
    an = Anonimizador(semilla=semilla, nombres_conocidos=nombres, lugares=lugares, generalizar_lugares=generalizar_lugares)
    (salida / "notas").mkdir(parents=True, exist_ok=True)
    muestra: list[str] = []
    textos = _leer(base, "SELECT nota_id, contenido FROM notas_texto ORDER BY nota_id DESC LIMIT ?", (notas,))
    for i, f in enumerate(textos, 1):
        copia = an.texto(str(f["contenido"]))
        (salida / "notas" / f"{i:04d}.txt").write_text(copia, encoding="utf-8")
        dudas = an.sospechosos(copia)
        if i <= 10 or dudas:
            muestra.append(f"--- notas/{i:04d}.txt" + (f"  · REVISAR: {', '.join(dudas[:8])}" if dudas else "")
                           + "\n" + copia[:800] + "\n")
    filas = _leer(base, f"SELECT {', '.join(CAMPOS_FICHA)} FROM detenidos ORDER BY id LIMIT ?", (fichas,))
    with (salida / "fichas.csv").open("w", encoding="utf-8", newline="") as a:
        w = csv.DictWriter(a, fieldnames=list(CAMPOS_FICHA))
        w.writeheader()
        for i, f in enumerate(filas, 1):
            copia = an.ficha(f)
            copia["id"] = i
            w.writerow({k: copia.get(k) for k in CAMPOS_FICHA})
    resumen = {"notas": len(textos), "fichas": len(filas), "reemplazos": an.resumen(), "semilla": semilla,
               "generalizar_lugares": generalizar_lugares}
    (salida / "resumen.json").write_text(json.dumps(resumen, ensure_ascii=False, indent=1), encoding="utf-8")
    (salida / "MUESTRA_PARA_REVISAR.txt").write_text(
        "Copia anonimizada (Ley 25.326, art. 2). Antes de usarla, una persona revisa esta muestra y lo marcado como REVISAR.\n"
        "Si algo se escapó, no se usa la copia: se agrega el caso a dgpdh/dominio/anonimizar.py y se vuelve a generar.\n\n"
        + "\n".join(muestra), encoding="utf-8")
    return resumen


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default=str(RAIZ / "datos" / "dgpdh.db"))
    ap.add_argument("--salida", required=True)
    ap.add_argument("--notas", type=int, default=200)
    ap.add_argument("--fichas", type=int, default=500)
    ap.add_argument("--generalizar-lugares", action="store_true")
    ap.add_argument("--semilla", default="dgpdh")
    a = ap.parse_args()
    r = generar(Path(a.base), Path(a.salida), a.notas, a.fichas, a.generalizar_lugares, a.semilla)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    print(f"Listo en {a.salida}. Revisá MUESTRA_PARA_REVISAR.txt antes de usar la copia.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
