#!/usr/bin/env python3
"""Reparación puntual de la nota 676 (PDF archivado por error del circuito anterior).

Uso:
  python3 scripts/reparar_nota_676.py --simular
  python3 scripts/reparar_nota_676.py --aplicar
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
import database as db
import agentes

NOTA_ID = 676


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--simular", action="store_true")
    group.add_argument("--aplicar", action="store_true")
    args = parser.parse_args()

    nota = db.obtener_nota(NOTA_ID)
    if nota is None:
        print(f"ERROR: nota {NOTA_ID} no existe.")
        sys.exit(1)

    ruta = Path(nota.get("ruta_original") or "")
    texto = ""
    if ruta.is_file():
        try:
            from pypdf import PdfReader
            texto = "\n".join((p.extract_text() or "") for p in PdfReader(str(ruta)).pages[:200]).strip()
        except Exception as e:
            print(f"  Advertencia: no se pudo extraer texto del PDF: {e}")

    print(f"Nota {NOTA_ID}: {nota['nombre_original']}")
    print(f"  Estado actual : {nota['estado']}")
    print(f"  Tipo actual   : {nota.get('tipo') or '(sin tipo)'}")
    print(f"  Archivo       : {ruta} ({'existe' if ruta.is_file() else 'NO EXISTE'})")
    print(f"  Texto extraído: {len(texto)} chars" if texto else "  Texto extraído: sin texto (escaneado)")

    plan = [
        f"1. recuperar_nota (DESCARTADA → ARCHIVADA)",
        f"2. actualizar_tipo → ADJUNTO",
        f"3. actualizar_estado → A_CONFIRMAR  [comentario: 'Corrección: PDF archivado al subir por error del circuito']",
    ]
    if texto:
        plan.append("4. indexar_texto + registrar_entidades")
    print("\nAcciones a aplicar:")
    for p in plan:
        print(f"  {p}")

    if args.simular:
        print("\n(SIMULACIÓN — sin cambios)")
        return

    if nota["estado"] != "DESCARTADA":
        print(f"\nERROR: se esperaba estado DESCARTADA, es {nota['estado']}. Verificá manualmente.")
        sys.exit(1)

    db.recuperar_nota(NOTA_ID, "script reparar_nota_676")
    print("  → recuperada a ARCHIVADA")

    db.actualizar_tipo(NOTA_ID, "ADJUNTO")
    print("  → tipo = ADJUNTO")

    db.actualizar_estado(NOTA_ID, "A_CONFIRMAR",
                         comentario="Corrección: PDF archivado al subir por error del circuito",
                         desde=("ARCHIVADA",))
    print("  → estado = A_CONFIRMAR")

    if texto:
        db.indexar_texto(NOTA_ID, texto)
        agentes.registrar_entidades(NOTA_ID, texto)
        print("  → texto indexado y entidades registradas")

    nota = db.obtener_nota(NOTA_ID)
    print(f"\nEstado final: {nota['estado']} | tipo: {nota.get('tipo')}")
    print("Reparación completada.")


if __name__ == "__main__":
    main()
