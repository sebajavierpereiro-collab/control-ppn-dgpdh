#!/usr/bin/env python3
"""Reparación de las 103 notas PDF en estado ERROR+tipo=ADJUNTO+bloque_id=NULL+nro_expte=NULL.

Uso:
  python3 scripts/reparar_adjuntos_con_error.py --simular
  python3 scripts/reparar_adjuntos_con_error.py --aplicar   # solo con la orden "APLICÁ REPARACIÓN"

--simular: muestra qué se haría sin tocar nada (candidatos de expediente por nota).
--aplicar: ejecuta la reparación. Exige backup previo (ver abajo).

BACKUP OBLIGATORIO antes de --aplicar:
  cp /opt/dgpdh/dgpdh_web/datos/dgpdh.db \\
     /opt/dgpdh/dgpdh_web/datos/dgpdh.db.bak.$(date +%Y%m%d_%H%M%S)
"""
import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import database as db
import agentes
import analisis as _analisis
import despacho as _despacho

QUERY = """
    SELECT id, ruta_original, nombre_original, error, bloque_id
    FROM notas
    WHERE estado = 'ERROR'
      AND tipo = 'ADJUNTO'
      AND bloque_id IS NULL
      AND nro_expte IS NULL
      AND lower(ruta_original) LIKE '%.pdf'
    ORDER BY id
"""


def _extraer_texto_pdf(ruta):
    from pypdf import PdfReader
    try:
        reader = PdfReader(ruta)
        texto = "\n".join((p.extract_text() or "") for p in reader.pages[:200])
        return texto.strip()
    except Exception as e:
        return ""


def _candidatos(texto, nombre_archivo, det_por_lpu, det_por_dni):
    """Devuelve lista de candidatos [{id, nombre, confianza, motivo}]."""
    candidatos = []
    vistos = set()

    # LPU exacto en detenidos = ALTA
    lpus = agentes.lpus_del_texto(texto)
    for lpu_n, _, _ in lpus:
        if lpu_n in det_por_lpu:
            for d in det_por_lpu[lpu_n]:
                if d["id"] not in vistos:
                    vistos.add(d["id"])
                    candidatos.append({
                        "detenido_id": d["id"],
                        "nombre": d["nombre_completo"],
                        "nro_expte_ppn": d.get("nro_expediente_ppn") or "",
                        "confianza": "ALTA",
                        "motivo": f"LPU {lpu_n} exacto en DB",
                    })

    # DNI exacto en detenidos = ALTA
    ent = _analisis.extraer_entidades(texto)
    for d_ent in ent["dni"]:
        dni_n = d_ent["norm"]
        if dni_n in det_por_dni:
            for d in det_por_dni[dni_n]:
                if d["id"] not in vistos:
                    vistos.add(d["id"])
                    candidatos.append({
                        "detenido_id": d["id"],
                        "nombre": d["nombre_completo"],
                        "nro_expte_ppn": d.get("nro_expediente_ppn") or "",
                        "confianza": "ALTA",
                        "motivo": f"DNI {dni_n} exacto en DB",
                    })

    # Expediente/GDE detectado en texto
    expte = _despacho.proponer_expediente(texto, nombre_archivo)
    if expte:
        candidatos.append({
            "detenido_id": None,
            "nombre": "",
            "nro_expte_ppn": expte,
            "confianza": "MEDIA",
            "motivo": f"Expediente extraído del texto: {expte}",
        })

    return candidatos[:5]


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--simular", action="store_true", help="Mostrar qué se haría sin modificar nada")
    group.add_argument("--aplicar", action="store_true", help="Ejecutar la reparación (requiere backup previo)")
    args = parser.parse_args()

    if args.aplicar:
        backup = Path("/opt/dgpdh/dgpdh_web/datos/dgpdh.db.bak.reparacion")
        if not any(Path("/opt/dgpdh/dgpdh_web/datos/").glob("dgpdh.db.bak.*")):
            print("ERROR: No se encontró ningún backup en datos/dgpdh.db.bak.*")
            print("Creá un backup antes de aplicar:")
            print("  cp /opt/dgpdh/dgpdh_web/datos/dgpdh.db \\")
            print("     /opt/dgpdh/dgpdh_web/datos/dgpdh.db.bak.$(date +%Y%m%d_%H%M%S)")
            sys.exit(1)

    with db._conexion() as con:
        filas = [dict(f) for f in con.execute(QUERY).fetchall()]
        det_rows = con.execute(
            "SELECT id, nombre_completo, dni, lpu_norm, nro_expediente_ppn FROM detenidos WHERE activo=1"
        ).fetchall()

    det_por_dni = {}
    det_por_lpu = {}
    for d in det_rows:
        d = dict(d)
        if d["dni"]:
            dni_n = re.sub(r"\D", "", d["dni"])
            det_por_dni.setdefault(dni_n, []).append(d)
        if d["lpu_norm"]:
            det_por_lpu.setdefault(d["lpu_norm"], []).append(d)

    print(f"{'=' * 70}")
    print(f"MODO: {'SIMULACIÓN (sin cambios)' if args.simular else '*** APLICANDO CAMBIOS ***'}")
    print(f"Notas a reparar: {len(filas)}")
    print(f"{'=' * 70}\n")

    reparadas = 0
    sin_texto = 0
    errores = 0

    for f in filas:
        nota_id = f["id"]
        ruta = f["ruta_original"]
        nombre = f["nombre_original"]
        p = Path(ruta)

        if not p.exists():
            print(f"[{nota_id}] ERROR: archivo no existe: {ruta}")
            errores += 1
            continue

        texto = _extraer_texto_pdf(ruta)
        tiene_texto = bool(texto)

        if not tiene_texto:
            sin_texto += 1
            print(f"[{nota_id}] SIN TEXTO (escaneado): {nombre}")
        else:
            print(f"[{nota_id}] Con texto ({len(texto)} chars): {nombre}")

        candidatos = _candidatos(texto, nombre, det_por_lpu, det_por_dni) if tiene_texto else []
        if candidatos:
            for c in candidatos:
                print(f"       {c['confianza']}: {c['nombre'] or '(sin nombre)'} — {c['motivo']}"
                      + (f" | Expte PPN: {c['nro_expte_ppn']}" if c.get("nro_expte_ppn") else ""))
        else:
            print(f"       (sin candidatos)")

        if args.aplicar:
            try:
                # ERROR → A_CONFIRMAR (historial preserva el error original)
                db.actualizar_estado(nota_id, "A_CONFIRMAR",
                                     comentario="Reparación: PDF con error en circuito anterior → pendiente de confirmación de Dirección",
                                     desde=("ERROR",))
                # Indexar texto y registrar entidades si hay texto
                if tiene_texto:
                    db.indexar_texto(nota_id, texto)
                    agentes.registrar_entidades(nota_id, texto)
                reparadas += 1
            except Exception as e:
                print(f"       ERROR al aplicar: {e}")
                errores += 1

    print(f"\n{'=' * 70}")
    if args.simular:
        print(f"SIMULACIÓN completada.")
        print(f"  Con texto: {len(filas) - sin_texto}")
        print(f"  Sin texto (escaneados): {sin_texto}")
        print(f"  Sin archivo: {errores}")
        print(f"\nPara ejecutar: python3 scripts/reparar_adjuntos_con_error.py --aplicar")
    else:
        print(f"Reparación completada.")
        print(f"  Reparadas → A_CONFIRMAR: {reparadas}")
        print(f"  Sin texto (escaneados): {sin_texto}")
        print(f"  Errores: {errores}")


if __name__ == "__main__":
    main()
