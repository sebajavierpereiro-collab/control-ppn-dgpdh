// ui_combobox.js — propuesta 120 (U23): autocompletar accesible (patrón combobox de WAI-ARIA) sobre los <select> largos
// (unidades, centros de detención, personas). Es una mejora progresiva: el <select> sigue en la página y es el que se envía;
// sin JavaScript se usa como siempre. Se aplica a select[data-combobox] y a cualquier select de 30 opciones o más.
// Busca por cualquier parte del texto, sin importar acentos ni mayúsculas, y pone primero las opciones que más usaste.
(function () {
    "use strict";
    var MINIMO = 30, MAX_VISIBLES = 60, n = 0;
    function normal(t) { return String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
    function usos() { try { return JSON.parse(localStorage.getItem("ui-combobox-usos") || "{}") || {}; } catch (e) { return {}; } }
    function anotarUso(clave, valor) {
        try { var u = usos(); var k = clave + ":" + valor; u[k] = (u[k] || 0) + 1; localStorage.setItem("ui-combobox-usos", JSON.stringify(u)); } catch (e) {}
    }

    function mejorar(sel) {
        if (sel.dataset.uiCombobox || sel.multiple || sel.closest("dialog, .menu-col")) return;
        // Si la pantalla ya trae su propio buscador para ese formulario (la solicitud de viaje), no se suma otro.
        if (sel.form && sel.form.querySelector('[role="combobox"]:not(.combobox__campo)')) return;
        n++;
        var id = "cb-" + n, clave = sel.name || sel.id || "x";
        var opciones = Array.prototype.map.call(sel.options, function (o, i) {
            return { i: i, valor: o.value, texto: o.textContent.trim(), n: normal(o.textContent), grupo: o.parentNode.tagName === "OPTGROUP" ? o.parentNode.label : "" };
        });
        var vacia = opciones.filter(function (o) { return o.valor === ""; })[0];
        var caja = document.createElement("div"); caja.className = "combobox";
        var input = document.createElement("input");
        input.type = "text"; input.id = id; input.className = "combobox__campo"; input.autocomplete = "off";
        input.setAttribute("role", "combobox"); input.setAttribute("aria-autocomplete", "list"); input.setAttribute("aria-expanded", "false");
        input.setAttribute("aria-controls", id + "-lista");
        input.placeholder = sel.dataset.comboboxAyuda || "Escribí para buscar (sigla, ciudad o provincia)…";
        var lista = document.createElement("ul"); lista.id = id + "-lista"; lista.className = "combobox__lista"; lista.setAttribute("role", "listbox"); lista.hidden = true;
        var estado = document.createElement("span"); estado.className = "sr-only"; estado.setAttribute("aria-live", "polite");
        // la etiqueta del select pasa al campo de texto
        var etiqueta = sel.id ? document.querySelector('label[for="' + sel.id + '"]') : null;
        if (etiqueta) etiqueta.htmlFor = id; else if (sel.closest("label")) { /* la etiqueta envuelve: alcanza con estar adentro */ }
        else if (sel.getAttribute("aria-label")) input.setAttribute("aria-label", sel.getAttribute("aria-label"));
        if (sel.getAttribute("aria-describedby")) input.setAttribute("aria-describedby", sel.getAttribute("aria-describedby"));
        if (sel.required) input.setAttribute("aria-required", "true");
        sel.dataset.uiCombobox = id;
        sel.classList.add("combobox__select"); sel.tabIndex = -1; sel.setAttribute("aria-hidden", "true");
        sel.parentNode.insertBefore(caja, sel);
        caja.appendChild(input); caja.appendChild(lista); caja.appendChild(estado); caja.appendChild(sel);

        var visibles = [], activa = -1;
        function textoElegido() { var o = sel.options[sel.selectedIndex]; return o && o.value !== "" ? o.textContent.trim() : ""; }
        function sincronizar() { input.value = textoElegido(); }
        function cerrar() { lista.hidden = true; input.setAttribute("aria-expanded", "false"); input.removeAttribute("aria-activedescendant"); activa = -1; }
        function pintar(filtro) {
            var f = normal(filtro).trim(), u = usos();
            var cand = opciones.filter(function (o) { return o.valor !== "" && (!f || f.split(/\s+/).every(function (p) { return o.n.indexOf(p) >= 0; })); });
            cand.sort(function (a, b) {
                var ua = u[clave + ":" + a.valor] || 0, ub = u[clave + ":" + b.valor] || 0;
                var pa = f && a.n.indexOf(f) === 0 ? 1 : 0, pb = f && b.n.indexOf(f) === 0 ? 1 : 0;
                return (ub - ua) || (pb - pa) || (a.i - b.i);
            });
            visibles = cand.slice(0, MAX_VISIBLES);
            lista.innerHTML = "";
            visibles.forEach(function (o, j) {
                var li = document.createElement("li");
                li.id = id + "-op-" + j; li.setAttribute("role", "option"); li.className = "combobox__opcion";
                li.setAttribute("aria-selected", String(o.valor === sel.value));
                li.textContent = o.texto;
                if (u[clave + ":" + o.valor] && !f) { var m = document.createElement("span"); m.className = "combobox__marca"; m.textContent = "usada"; li.appendChild(m); }
                li.addEventListener("mousedown", function (e) { e.preventDefault(); elegir(o); });
                lista.appendChild(li);
            });
            if (!visibles.length) { var li = document.createElement("li"); li.className = "combobox__vacio"; li.textContent = "No hay coincidencias. Probá con otra palabra."; lista.appendChild(li); }
            lista.hidden = false; input.setAttribute("aria-expanded", "true");
            estado.textContent = cand.length ? cand.length + (cand.length === 1 ? " opción" : " opciones") + (cand.length > MAX_VISIBLES ? "; se muestran las primeras " + MAX_VISIBLES : "") : "Sin coincidencias";
            marcar(-1);
        }
        function marcar(j) {
            activa = j;
            Array.prototype.forEach.call(lista.children, function (li, k) { li.classList.toggle("combobox__opcion--activa", k === j); });
            if (j >= 0 && lista.children[j]) { input.setAttribute("aria-activedescendant", lista.children[j].id); lista.children[j].scrollIntoView({ block: "nearest" }); }
            else input.removeAttribute("aria-activedescendant");
        }
        function elegir(o) {
            sel.selectedIndex = o.i;
            sel.dispatchEvent(new Event("change", { bubbles: true }));
            anotarUso(clave, o.valor);
            sincronizar(); cerrar();
        }
        input.addEventListener("input", function () { pintar(input.value); });
        input.addEventListener("focus", function () { if (!input.value) pintar(""); });
        input.addEventListener("click", function () { if (lista.hidden) pintar(input.value === textoElegido() ? "" : input.value); });
        input.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") { e.preventDefault(); if (lista.hidden) pintar(""); marcar(Math.min(activa + 1, visibles.length - 1)); }
            else if (e.key === "ArrowUp") { e.preventDefault(); marcar(Math.max(activa - 1, 0)); }
            else if (e.key === "Enter" && !lista.hidden) { if (activa >= 0 && visibles[activa]) { e.preventDefault(); elegir(visibles[activa]); } else if (visibles.length === 1) { e.preventDefault(); elegir(visibles[0]); } }
            else if (e.key === "Escape") { if (!lista.hidden) { e.preventDefault(); cerrar(); sincronizar(); } }
        });
        input.addEventListener("blur", function () {
            setTimeout(function () {
                cerrar();
                if (!input.value.trim() && vacia) { if (sel.value !== "") { sel.selectedIndex = vacia.i; sel.dispatchEvent(new Event("change", { bubbles: true })); } }
                else sincronizar();
            }, 120);
        });
        sel.addEventListener("change", function () { if (document.activeElement !== input) sincronizar(); });
        if (sel.form) sel.form.addEventListener("reset", function () { setTimeout(sincronizar, 0); });
        sincronizar();
    }

    function iniciar(raiz) {
        (raiz || document).querySelectorAll("select").forEach(function (s) {
            if (s.hasAttribute("data-sin-combobox")) return;
            if (s.hasAttribute("data-combobox") || s.options.length >= MINIMO) mejorar(s);
        });
    }
    window.uiCombobox = iniciar;
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { iniciar(); }); else iniciar();
    document.addEventListener("htmx:afterSwap", function (e) { iniciar(e.target); });
})();
