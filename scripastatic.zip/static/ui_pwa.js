// ui_pwa.js — propuesta 150 (U53): registra el service worker propio (/sw.js), manda las marcas que quedaron sin enviar cuando
// vuelve la señal, avisa «Pendiente de enviar» y borra lo guardado al salir del sistema.
(function () {
    "use strict";
    if (!("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () {});
    function enviar() { if (navigator.serviceWorker.controller && navigator.onLine) navigator.serviceWorker.controller.postMessage("enviar-pendientes"); }
    window.addEventListener("online", enviar);
    navigator.serviceWorker.addEventListener("message", function (e) {
        if (!e.data || e.data.tipo !== "pendientes") return;
        var b = document.getElementById("pendientes-envio");
        if (!e.data.cantidad) { if (b) b.remove(); return; }
        if (!b) { b = document.createElement("p"); b.id = "pendientes-envio"; b.className = "aviso-borrador"; b.setAttribute("role", "status");
            var c = document.querySelector(".contenido"); if (c) c.insertBefore(b, c.firstChild); }
        b.textContent = "Pendiente de enviar: " + e.data.cantidad + " marca(s) de salida o vuelta. Se mandan solas cuando vuelva la señal.";
    });
    document.addEventListener("DOMContentLoaded", function () {
        enviar();
        // la hora en que se tocó «Salí» o «Volví» viaja con la marca (por si se envía más tarde)
        document.querySelectorAll('form[action^="/ui/viaje/"]').forEach(function (f) {
            f.addEventListener("submit", function () {
                var d = new Date(), hora = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2);
                var fecha = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
                [["hora", hora], ["fecha", fecha]].forEach(function (x) {
                    var i = f.querySelector('input[name="' + x[0] + '"]'); if (!i) { i = document.createElement("input"); i.type = "hidden"; i.name = x[0]; f.appendChild(i); }
                    i.value = x[1];
                });
            });
        });
        document.querySelectorAll('a[href="/logout"]').forEach(function (a) {
            a.addEventListener("click", function () { if (navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage("borrar-todo"); });
        });
    });
})();
