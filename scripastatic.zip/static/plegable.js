// plegable.js — segmentos que se pueden retraer/expandir. El título queda
// siempre visible. Uso: <section data-plegable="clave" [data-plegado-inicial="si"]>.
// El estado se recuerda por persona en este navegador (si el navegador no
// permite guardarlo, funciona igual, solo que no se acuerda).
(function () {
    function leer(clave) {
        try { return window.localStorage.getItem("plegado:" + clave); } catch (e) { return null; }
    }
    function guardar(clave, valor) {
        try { window.localStorage.setItem("plegado:" + clave, valor); } catch (e) { /* sin almacenamiento */ }
    }

    function preparar(seccion) {
        var clave = seccion.getAttribute("data-plegable");
        var cabecera = seccion.querySelector(":scope > .panel-lista__encabezado, :scope > .tarjeta-bloque__encabezado") ||
                       seccion.querySelector(":scope > h1, :scope > h2, :scope > h3");
        if (!cabecera) return;
        cabecera.classList.add("plegable__cabecera");

        // Todo lo que no es la cabecera va dentro del cuerpo plegable.
        var cuerpo = document.createElement("div");
        cuerpo.className = "plegable__cuerpo";
        cuerpo.id = "plegable-" + clave;
        Array.prototype.slice.call(seccion.children).forEach(function (hijo) {
            if (hijo !== cabecera) cuerpo.appendChild(hijo);
        });
        seccion.appendChild(cuerpo);

        var boton = document.createElement("button");
        boton.type = "button";
        boton.className = "plegable__flecha";
        boton.setAttribute("aria-controls", cuerpo.id);
        cabecera.insertBefore(boton, cabecera.firstChild);

        function aplicar(plegado) {
            seccion.classList.toggle("plegable--plegado", plegado);
            cuerpo.hidden = plegado;
            boton.setAttribute("aria-expanded", plegado ? "false" : "true");
            boton.setAttribute("aria-label", (plegado ? "Expandir " : "Retraer ") + "el segmento");
            if (!boton.firstChild) boton.innerHTML = '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
        }

        var guardado = leer(clave);
        var plegado = guardado === null ? seccion.getAttribute("data-plegado-inicial") === "si" : guardado === "1";
        // data-abrir="si": se muestra abierto aunque se haya retraído antes (p. ej. la bandeja cuando hay tareas).
        if (seccion.getAttribute("data-abrir") === "si") plegado = false;
        aplicar(plegado);

        cabecera.addEventListener("click", function (e) {
            // Los enlaces, botones y campos dentro del título siguen funcionando normal.
            if (e.target.closest("a, input, select, textarea, label") ||
                (e.target.closest("button") && e.target.closest("button") !== boton)) return;
            plegado = !plegado;
            aplicar(plegado);
            guardar(clave, plegado ? "1" : "0");
        });
    }

    function iniciar() {
        document.querySelectorAll("[data-plegable]").forEach(preparar);
        // <details data-recordar="x">: también recuerdan si estaban abiertos.
        document.querySelectorAll("details[data-recordar]").forEach(function (d) {
            var v = leer("details:" + d.getAttribute("data-recordar"));
            if (v === "1" && !d.open) d.open = true;
            if (v === "0" && d.open && !d.hasAttribute("data-forzar")) d.open = false;
            d.addEventListener("toggle", function () { guardar("details:" + d.getAttribute("data-recordar"), d.open ? "1" : "0"); });
        });
    }

    // Un solo menú de columna abierto a la vez; se cierra al tocar afuera.
    document.addEventListener("click", function (e) {
        document.querySelectorAll("details.menu-col[open]").forEach(function (d) {
            if (!d.contains(e.target)) d.removeAttribute("open");
        });
    });

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar);
    else iniciar();
})();
