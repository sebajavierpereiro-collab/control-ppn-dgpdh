// ui_paleta.js — propuesta 134 (U37): paleta de comandos con Ctrl+K (o «/» si los atajos de una tecla están activos y la
// pantalla no tiene buscador). Busca en el servidor (notas, viajes, personas detenidas, unidades) y ofrece acciones según el
// permiso. Patrón combobox de WAI-ARIA dentro de un <dialog>. No se envía nada a terceros.
(function () {
    "use strict";
    var dlg, campo, lista, timer, pedido = 0, activa = -1;
    function opciones() { return Array.prototype.slice.call(lista.querySelectorAll(".paleta__opcion")); }
    function marcar(i) {
        var ops = opciones();
        activa = ops.length ? (i + ops.length) % ops.length : -1;
        ops.forEach(function (o, j) { o.setAttribute("aria-selected", j === activa ? "true" : "false"); o.classList.toggle("paleta__opcion--activa", j === activa); });
        if (activa >= 0) { campo.setAttribute("aria-activedescendant", ops[activa].id); ops[activa].scrollIntoView({ block: "nearest" }); }
        else campo.removeAttribute("aria-activedescendant");
    }
    function buscar() {
        var n = ++pedido;
        lista.setAttribute("aria-busy", "true");
        fetch("/ui/paleta?q=" + encodeURIComponent(campo.value), { credentials: "same-origin", headers: { "HX-Request": "true" } })
            .then(function (r) { return r.ok ? r.text() : ""; })
            .then(function (h) { if (n !== pedido) return; lista.innerHTML = h; lista.removeAttribute("aria-busy"); marcar(campo.value ? 0 : -1); })
            .catch(function () { lista.removeAttribute("aria-busy"); lista.innerHTML = '<p class="paleta__vacio">No hay conexión con el servidor.</p>'; });
    }
    function crear() {
        dlg = document.createElement("dialog");
        dlg.className = "paleta"; dlg.setAttribute("aria-labelledby", "paleta-titulo");
        dlg.innerHTML = '<h2 id="paleta-titulo" class="sr-only">Buscar o ir a</h2>' +
            '<div class="paleta__cabeza"><input id="paleta-campo" class="paleta__campo" type="text" role="combobox" aria-expanded="true" aria-controls="paleta-lista" aria-autocomplete="list" autocomplete="off" placeholder="Buscá notas, viajes, personas, unidades o acciones…" aria-label="Buscar o ir a">' +
            '<button type="button" class="boton boton--chico paleta__cerrar">Cerrar <kbd>Esc</kbd></button></div>' +
            '<div id="paleta-lista" class="paleta__lista" role="listbox" aria-label="Resultados"></div>' +
            '<p class="paleta__pie texto-ayuda"><kbd>↑</kbd> <kbd>↓</kbd> para moverte · <kbd>Enter</kbd> para abrir · <kbd>Ctrl</kbd>+<kbd>K</kbd> abre esta búsqueda desde cualquier pantalla</p>';
        document.body.appendChild(dlg);
        campo = dlg.querySelector("#paleta-campo"); lista = dlg.querySelector("#paleta-lista");
        campo.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(buscar, 220); });
        campo.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") { e.preventDefault(); marcar(activa + 1); }
            else if (e.key === "ArrowUp") { e.preventDefault(); marcar(activa - 1); }
            else if (e.key === "Enter") { var o = opciones()[activa]; if (o) { e.preventDefault(); location.assign(o.href); } }
        });
        dlg.querySelector(".paleta__cerrar").addEventListener("click", function () { dlg.close(); });
        dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
        dlg.addEventListener("close", function () { if (dlg._volver && dlg._volver.focus) dlg._volver.focus(); });
    }
    function abrir() {
        if (!dlg) crear();
        if (dlg.open) return;
        dlg._volver = document.activeElement;
        campo.value = "";
        dlg.showModal();
        campo.focus();
        buscar();
    }
    window.uiAbrirPaleta = abrir;
    document.addEventListener("keydown", function (e) {
        if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === "k" || e.key === "K")) { e.preventDefault(); abrir(); return; }
        var t = (e.target.tagName || "").toLowerCase();
        if (e.key === "/" && !e.ctrlKey && !e.metaKey && !/^(input|textarea|select)$/.test(t) && !e.target.isContentEditable &&
            !document.getElementById("campo-buscar") && document.documentElement.getAttribute("data-atajos") !== "no") { e.preventDefault(); abrir(); }
    });
    document.addEventListener("click", function (e) { var b = e.target.closest && e.target.closest("[data-ui-paleta]"); if (b) { e.preventDefault(); abrir(); } });
})();
