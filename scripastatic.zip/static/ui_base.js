// ui_base.js — comportamientos generales del área de interfaz (propuestas 98–164). Todo es mejora progresiva: sin JavaScript
// las páginas funcionan igual. Nada se pide a internet.
(function () {
    "use strict";

    function txt(s) { return String(s == null ? "" : s); }
    function el(tag, clase, texto) { var e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; }

    // ---- Propuesta 136 (U39): el botón de confirmación dice qué hace («Sí, despachar el bloque…»).
    window.uiTextoConfirmar = function (ancla) {
        var t = "";
        if (ancla && /^(BUTTON|INPUT)$/.test(ancla.tagName || "")) t = (ancla.value && ancla.tagName === "INPUT") ? ancla.value : (ancla.textContent || "");
        t = t.replace(/\s+/g, " ").replace(/\(\d+\)\s*$/, "").trim();
        if (!t || t.length > 60) return "Sí, seguir";
        return "Sí, " + t.charAt(0).toLowerCase() + t.slice(1);
    };

    // ---- Propuesta 138 (U41): errores del servidor que explican qué pasó y qué hacer.
    var QUE_HACER = {
        400: "Revisá lo que cargaste y probá de nuevo.",
        401: "Volvé a ingresar con tu usuario y contraseña.",
        403: "Si creés que deberías poder, pedilo en Administración.",
        404: "Puede que otra persona lo haya movido. Volvé a la bandeja.",
        409: "Actualizá la pantalla para ver cómo quedó.",
        413: "Probá con un archivo más chico o dividilo.",
        422: "Revisá los campos marcados y probá de nuevo.",
        429: "Esperá unos minutos y probá de nuevo.",
        500: "Probá de nuevo en un momento. Si se repite, avisá a soporte con el código de referencia.",
        503: "Esperá un minuto y probá de nuevo."
    };
    var QUE_PASO = {
        401: "Tu sesión se cerró.", 403: "No tenés permiso para hacer esto.", 404: "Lo que buscás ya no está disponible.",
        409: "Otra persona ya actuó sobre esto.", 413: "El archivo es demasiado grande.", 500: "Algo falló en el servidor.",
        503: "El sistema está ocupado o en mantenimiento."
    };
    window.uiAvisoError = function (xhr) {
        var codigo = (xhr && xhr.status) || 0, detalle = "";
        try { detalle = JSON.parse(xhr.responseText).detail || ""; } catch (e) { detalle = ""; }
        if (typeof detalle !== "string") detalle = "";
        var paso = detalle || QUE_PASO[codigo] || (codigo >= 500 ? QUE_PASO[500] : "No se pudo completar la acción.");
        var hacer = QUE_HACER[codigo] || (codigo >= 500 ? QUE_HACER[500] : QUE_HACER[400]);
        var actualizar = codigo === 409 || /\b(ya (la|lo|las|los) |otra persona|cambió|ya fue)/i.test(paso);
        uiAviso(paso, codigo >= 500 || codigo === 403 ? "error" : "atencion", hacer, actualizar);
    };

    // Aviso con dos líneas (qué pasó / qué podés hacer) y botones; los de error y atención no se van solos (propuesta 116).
    function uiAviso(paso, tipo, hacer, actualizar) {
        var caja = document.getElementById("avisos");
        if (!caja) { if (window.mostrarAviso) window.mostrarAviso(paso); return; }
        var trazos = { atencion: '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17v.5"/>',
                       error: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16v.5"/>' };
        var d = el("div", "aviso-flotante aviso-flotante--" + tipo + " aviso-ui");
        d.setAttribute("role", "alert");
        d.innerHTML = '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (trazos[tipo] || trazos.error) + "</svg>";
        var cuerpo = el("div", "aviso-ui__cuerpo");
        cuerpo.appendChild(el("strong", "aviso-ui__paso", paso));
        if (hacer) cuerpo.appendChild(el("span", "aviso-ui__hacer", hacer));
        if (actualizar) {
            var b = el("button", "boton boton--chico", "Actualizar");
            b.type = "button"; b.addEventListener("click", function (e) { e.stopPropagation(); location.reload(); });
            cuerpo.appendChild(b);
        }
        d.appendChild(cuerpo);
        var x = el("button", "aviso-flotante__cerrar", "×"); x.type = "button"; x.setAttribute("aria-label", "Cerrar aviso");
        x.addEventListener("click", function () { d.remove(); });
        d.appendChild(x);
        caja.appendChild(d);
    }
    window.uiAviso = uiAviso;

    // ---- Propuesta 146 (U49): tema en tres estados, visible en el encabezado y guardado en el servidor (te sigue en otra PC).
    var TEMA_A_ATRIBUTO = { sistema: "", claro: "light", oscuro: "dark" };
    var NOMBRE_TEMA = { sistema: "como el sistema", claro: "claro", oscuro: "oscuro" };
    function temaActual() {
        var t = document.documentElement.getAttribute("data-theme");
        return t === "light" ? "claro" : (t === "dark" ? "oscuro" : "sistema");
    }
    function enviar(datos) {
        var fd = new FormData();
        Object.keys(datos).forEach(function (k) { fd.append(k, datos[k]); });
        return fetch("/ui/preferencias", { method: "POST", body: fd, credentials: "same-origin", headers: { "Accept": "application/json" } })
            .catch(function () { return null; });
    }
    window.uiEnviarPreferencia = enviar;
    function aplicarTema(v, guardar) {
        var a = TEMA_A_ATRIBUTO[v];
        if (a === undefined) return;
        if (a) document.documentElement.setAttribute("data-theme", a); else document.documentElement.removeAttribute("data-theme");
        try { if (a) localStorage.setItem("apariencia-tema", a); else localStorage.removeItem("apariencia-tema"); } catch (e) {}
        document.querySelectorAll("[data-ui-tema]").forEach(pintarBotonTema);
        if (guardar) enviar({ tema: v });
    }
    function pintarBotonTema(b) {
        var t = temaActual();
        b.setAttribute("data-estado", t);
        b.setAttribute("aria-label", "Tema: " + NOMBRE_TEMA[t] + ". Tocá para cambiarlo.");
        b.title = "Tema: " + NOMBRE_TEMA[t];
        var s = b.querySelector(".boton-tema__texto"); if (s) s.textContent = NOMBRE_TEMA[t].charAt(0).toUpperCase() + NOMBRE_TEMA[t].slice(1);
    }
    function prepararTema() {
        document.querySelectorAll("[data-ui-tema]").forEach(function (b) {
            pintarBotonTema(b);
            b.addEventListener("click", function () {
                var orden = ["sistema", "claro", "oscuro"], t = temaActual();
                aplicarTema(orden[(orden.indexOf(t) + 1) % 3], true);
            });
        });
        // Los botones de «Mi perfil → Apariencia» también guardan el tema en el servidor.
        document.querySelectorAll('.apariencia input[name="tema"]').forEach(function (r) {
            r.addEventListener("change", function () { enviar({ tema: r.value === "light" ? "claro" : (r.value === "dark" ? "oscuro" : "sistema") }); });
        });
    }

    function iniciar() {
        prepararTema();
        document.dispatchEvent(new CustomEvent("ui:listo"));
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 149 (U52): «Más» de la barra inferior del chofer abre el menú completo.
document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-ui-abrir-menu]");
    if (!b) return;
    var m = document.getElementById("abrir-lateral");
    if (m) m.click();
});

// ---- Propuesta 157 (U60): lo que se está cargando avisa con aria-busy (y el botón muestra el indicador, ver estilos_ui.css).
document.addEventListener("htmx:beforeRequest", function (e) { var t = e.detail && e.detail.target; if (t && t.setAttribute) t.setAttribute("aria-busy", "true"); });
document.addEventListener("htmx:afterRequest", function (e) { var t = e.detail && e.detail.target; if (t && t.removeAttribute) t.removeAttribute("aria-busy"); });

// ---- Propuestas 153 y 156: «Entendido» cierra la banda sin recargar (sin JavaScript, el formulario hace lo mismo).
document.addEventListener("submit", function (e) {
    var f = e.target;
    if (!f.matches || !f.matches("[data-ui-cerrar-banda]")) return;
    e.preventDefault();
    fetch(f.action, { method: "POST", body: new FormData(f), credentials: "same-origin", headers: { "Accept": "application/json" } }).catch(function () {});
    var b = f.closest(".banda-aviso"); if (b) b.remove();
});

// ---- Propuesta 124 (U27): diálogo del PIN más amable: «Mostrar» lo escrito, qué hacer si te olvidaste el PIN y el foco vuelve
// al botón que lo abrió al cerrar (el foco ya queda atrapado dentro del <dialog> modal). El servidor dice cuántos intentos quedan.
function uiPrepararPin() {
    var dlg = document.getElementById("dialogo-pin");
    if (!dlg || dlg.dataset.ui) return;
    dlg.dataset.ui = "1";
    var ultimo = null;
    document.addEventListener("focusin", function (e) { if (!dlg.contains(e.target)) ultimo = e.target; });
    dlg.addEventListener("close", function () { if (ultimo && document.contains(ultimo) && ultimo.focus) ultimo.focus(); });
    dlg.querySelectorAll('input[type="password"]').forEach(function (inp) {
        var b = document.createElement("button");
        b.type = "button"; b.className = "boton boton--chico pin-mostrar"; b.textContent = "Mostrar"; b.setAttribute("aria-pressed", "false");
        b.setAttribute("aria-label", "Mostrar lo que escribiste");
        b.addEventListener("click", function () {
            var ver = inp.type === "password"; inp.type = ver ? "text" : "password";
            b.textContent = ver ? "Ocultar" : "Mostrar"; b.setAttribute("aria-pressed", ver ? "true" : "false"); inp.focus();
        });
        inp.insertAdjacentElement("afterend", b);
    });
    var acciones = dlg.querySelector(".acciones");
    if (acciones && !dlg.querySelector('input[name="repetir"]')) {  // solo al confirmar un PIN que ya existe
        var p = document.createElement("p"); p.className = "texto-ayuda pin-olvido";
        p.textContent = "¿Te olvidaste el PIN? Pedí en Administración que lo reinicien y creá uno nuevo.";
        acciones.insertAdjacentElement("beforebegin", p);
    }
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", uiPrepararPin); else uiPrepararPin();

// ---- Propuesta 147 (U50): en la agenda coloreada por equipo o circuito, el color no es la única pista: cada viaje lleva una
// pastilla con las iniciales («SA» = Equipo Salud) y la leyenda las repite junto al nombre.
(function () {
    function iniciales(t) {
        var p = String(t || "—").replace(/^equipo\s+/i, "").split(/[\s\-·]+/).filter(function (x) { return x && /[A-Za-zÁÉÍÓÚÑáéíóúñ0-9]/.test(x); });
        if (!p.length) return "—";
        if (p.length === 1) return p[0].slice(0, 2).toUpperCase();
        return p.slice(0, 3).map(function (x) { return /^\d/.test(x) ? x : x.charAt(0).toUpperCase(); }).join("");
    }
    function pastillas() {
        var sel = document.getElementById("colorear-por");
        if (!sel) return;
        var modo = sel.value;
        document.querySelectorAll(".agenda .viaje").forEach(function (a) {
            var p = a.querySelector(".viaje__pastilla");
            if (modo === "estado") { if (p) p.remove(); return; }
            if (!p) { p = document.createElement("span"); p.className = "viaje__pastilla"; a.insertBefore(p, a.firstChild); }
            var v = a.dataset[modo] || "—";
            p.textContent = iniciales(v); p.title = v; p.setAttribute("aria-label", v);
        });
        var ley = document.getElementById("leyenda-dinamica");
        if (ley && modo !== "estado") ley.querySelectorAll("li").forEach(function (li) {
            if (li.querySelector(".viaje__pastilla")) return;
            var s = document.createElement("span"); s.className = "viaje__pastilla"; s.setAttribute("aria-hidden", "true");
            s.textContent = iniciales(li.textContent.trim()); li.insertBefore(s, li.firstChild.nextSibling);
        });
    }
    function iniciar() {
        var sel = document.getElementById("colorear-por");
        if (!sel) return;
        sel.addEventListener("change", function () { setTimeout(pastillas, 0); });
        setTimeout(pastillas, 0);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 154 (U57): al tocar un paso que no se detecta solo (el video, la foto, probar la firma en serie), queda tildado.
document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest("[data-ui-marca-paso]");
    if (!a || !window.uiEnviarPreferencia) return;
    var fd = { visto: a.dataset.uiMarcaPaso, valor: "si" };
    if (navigator.sendBeacon) { var f = new FormData(); f.append("visto", fd.visto); f.append("valor", fd.valor); navigator.sendBeacon("/ui/preferencias", f); }
    else window.uiEnviarPreferencia(fd);
});
