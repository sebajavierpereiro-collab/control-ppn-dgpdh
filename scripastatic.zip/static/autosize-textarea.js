// autosize-textarea.js — cada <textarea class="parrafo-editable"> muestra su
// párrafo COMPLETO, sin scroll interno. La causa del problema anterior era el
// contenedor (altura máxima + flex que achicaba los cuadros); acá además se
// recalcula cuando el cuadro pasa a ser visible, al cambiar el ancho de la
// ventana y al escribir.
(function () {
    function ajustar(area) {
        if (!area.offsetParent && area.offsetWidth === 0) return;  // oculto: se ajusta al mostrarse
        area.style.height = "auto";
        area.style.height = (area.scrollHeight + 2) + "px";
    }

    function todos() {
        return document.querySelectorAll("textarea.parrafo-editable");
    }

    function ajustarTodos() {
        todos().forEach(ajustar);
    }

    function inicializar() {
        todos().forEach(function (area) {
            area.addEventListener("input", function () { ajustar(area); });
            if ("ResizeObserver" in window) {
                // Si cambia el ancho (ventana, panel lateral, <details> que se abre) se recalcula.
                var ancho = area.offsetWidth;
                new ResizeObserver(function () {
                    if (area.offsetWidth !== ancho) { ancho = area.offsetWidth; ajustar(area); }
                    else if (area.style.height === "" || area.style.height === "0px") { ajustar(area); }
                }).observe(area);
            }
        });
        ajustarTodos();
        window.addEventListener("resize", ajustarTodos);
        window.addEventListener("load", ajustarTodos);
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(ajustarTodos);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", inicializar);
    } else {
        inicializar();
    }

    document.addEventListener("toggle", function (e) {
        if (e.target && e.target.tagName === "DETAILS") {
            e.target.querySelectorAll("textarea.parrafo-editable").forEach(ajustar);
        }
    }, true);
})();
