// ui_sw.js — propuesta 150 (U53): «Mis salidas» del chofer se puede leer sin señal y «Salí» / «Volví» se guardan en el teléfono
// hasta que vuelve la conexión. Se sirve desde el propio servidor (/sw.js) y solo se activa con [interfaz] pwa = si.
// No habla con nadie más que con el servidor del organismo. Al salir del sistema se borra todo lo guardado.
"use strict";
var CACHE = "mis-salidas-v1";
var BASE = "dgpdh-pendientes", TIENDA = "marcas";
var RUTA_HOY = /^\/traslados\/hoy(\?|$)/;
var RUTA_MARCA = /^\/ui\/viaje\/\d+\/(sali|volvi)$/;

self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) {
    e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); })
        .then(function () { return self.clients.claim(); }));
});

function abrir() {
    return new Promise(function (ok, mal) {
        var r = indexedDB.open(BASE, 1);
        r.onupgradeneeded = function () { r.result.createObjectStore(TIENDA, { keyPath: "id", autoIncrement: true }); };
        r.onsuccess = function () { ok(r.result); }; r.onerror = function () { mal(r.error); };
    });
}
function guardarMarca(m) {
    return abrir().then(function (db) { return new Promise(function (ok, mal) {
        var t = db.transaction(TIENDA, "readwrite"); t.objectStore(TIENDA).add(m); t.oncomplete = ok; t.onerror = function () { mal(t.error); };
    }); });
}
function marcas() {
    return abrir().then(function (db) { return new Promise(function (ok) {
        var r = db.transaction(TIENDA).objectStore(TIENDA).getAll(); r.onsuccess = function () { ok(r.result || []); }; r.onerror = function () { ok([]); };
    }); });
}
function borrarMarca(id) {
    return abrir().then(function (db) { return new Promise(function (ok) { var t = db.transaction(TIENDA, "readwrite"); t.objectStore(TIENDA).delete(id); t.oncomplete = ok; t.onerror = ok; }); });
}
function enviarPendientes() {
    return marcas().then(function (lista) {
        return lista.reduce(function (p, m) {
            return p.then(function () {
                var fd = new FormData(); fd.append("hora", m.hora); fd.append("fecha", m.fecha);
                return fetch(m.url, { method: "POST", body: fd, credentials: "same-origin", redirect: "manual" })
                    .then(function (r) { if (r.ok || r.type === "opaqueredirect" || (r.status >= 400 && r.status < 500)) return borrarMarca(m.id); })
                    .catch(function () {});
            });
        }, Promise.resolve()).then(function () { return marcas(); });
    }).then(function (quedan) {
        return self.clients.matchAll().then(function (cs) { cs.forEach(function (c) { c.postMessage({ tipo: "pendientes", cantidad: quedan.length }); }); });
    });
}
function paginaSinSenal(texto) {
    return new Response('<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">' +
        '<title>Sin señal · Mis salidas</title><link rel="stylesheet" href="/static/estilos.css"><link rel="stylesheet" href="/static/estilos_ui.css"></head>' +
        '<body><main class="contenido" style="padding:16px"><h1>Sin señal</h1><p>' + texto + '</p><p><a class="boton boton--primario" href="/traslados/hoy">Volver a Mis salidas</a></p></main></body></html>',
        { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

self.addEventListener("message", function (e) {
    if (e.data === "enviar-pendientes") e.waitUntil(enviarPendientes());
    if (e.data === "borrar-todo") e.waitUntil(caches.delete(CACHE).then(function () { return abrir(); }).then(function (db) {
        var t = db.transaction(TIENDA, "readwrite"); t.objectStore(TIENDA).clear();
    }).catch(function () {}));
});

self.addEventListener("fetch", function (e) {
    var req = e.request, url = new URL(req.url);
    if (url.origin !== self.location.origin) return;
    if (url.pathname === "/logout") {  // al salir no queda nada guardado en el teléfono
        e.waitUntil(caches.delete(CACHE));
        return;
    }
    if (req.method === "GET" && req.mode === "navigate" && RUTA_HOY.test(url.pathname + url.search)) {
        e.respondWith(fetch(req).then(function (r) {
            if (r.ok && !r.redirected) { var copia = r.clone(); caches.open(CACHE).then(function (c) { c.put(req, copia); }); }
            return r;
        }).catch(function () {
            return caches.match(req).then(function (r) {
                return r || paginaSinSenal("Todavía no hay una copia guardada de este día. Abrí «Mis salidas» con señal al menos una vez.");
            });
        }));
        return;
    }
    if (req.method === "POST" && RUTA_MARCA.test(url.pathname)) {
        var copia = req.clone();
        e.respondWith(fetch(req).catch(function () {
            return copia.formData().then(function (fd) {
                var hora = fd.get("hora") || new Date().toTimeString().slice(0, 5);
                var fecha = fd.get("fecha") || new Date().toISOString().slice(0, 10);
                return guardarMarca({ url: url.pathname, hora: hora, fecha: fecha }).then(function () {
                    var que = /sali$/.test(url.pathname) ? "«Salí»" : "«Volví»";
                    return paginaSinSenal("Guardamos " + que + " de las " + hora + " en el teléfono. <strong>Pendiente de enviar:</strong> se manda solo cuando vuelva la señal.");
                });
            });
        }));
    }
});
