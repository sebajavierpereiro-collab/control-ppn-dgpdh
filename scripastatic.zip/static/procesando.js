/* Evita el doble envío: mientras una acción se procesa, el botón queda bloqueado con «Procesando…» y, si tarda,
   aparece arriba el aviso «Procesando la solicitud…». Vale para formularios comunes y para los botones con htmx. */
(function () {
    "use strict";
    var DEMORA_AVISO = 350;      // ms: las acciones rápidas no muestran el aviso
    var SEGURIDAD = 30000;       // ms: si la página no cambia (p. ej., una descarga), se libera el botón
    var temporizador = null, activos = 0;

    function indicador() {
        var d = document.getElementById("procesando-global");
        if (!d) {
            d = document.createElement("div");
            d.id = "procesando-global"; d.className = "procesando-global"; d.setAttribute("role", "status"); d.setAttribute("aria-live", "polite");
            d.innerHTML = '<span class="procesando-giro" aria-hidden="true"></span><span>Procesando la solicitud… no hace falta volver a tocar el botón.</span>';
            d.hidden = true;
            document.body.appendChild(d);
        }
        return d;
    }
    function empezar() {
        activos++;
        clearTimeout(temporizador);
        temporizador = setTimeout(function () { if (activos > 0) indicador().hidden = false; }, DEMORA_AVISO);
    }
    function terminar() {
        activos = Math.max(0, activos - 1);
        if (activos === 0) { clearTimeout(temporizador); var d = document.getElementById("procesando-global"); if (d) d.hidden = true; }
    }
    function bloquear(boton) {
        if (!boton || boton.dataset.procesando === "1") return;
        boton.dataset.procesando = "1";
        boton.dataset.textoOriginal = boton.innerHTML;
        boton.classList.add("boton--procesando");
        boton.setAttribute("aria-busy", "true");
        boton.innerHTML = '<span class="procesando-giro" aria-hidden="true"></span> Procesando…';
        // Se desactiva recién después de armar el envío, para que el valor del botón (p. ej. «decision») viaje igual.
        setTimeout(function () { boton.disabled = true; }, 0);
    }
    function liberar(boton) {
        if (!boton || boton.dataset.procesando !== "1") return;
        boton.disabled = false;
        boton.classList.remove("boton--procesando");
        boton.removeAttribute("aria-busy");
        if (boton.dataset.textoOriginal !== undefined) boton.innerHTML = boton.dataset.textoOriginal;
        delete boton.dataset.procesando; delete boton.dataset.textoOriginal;
    }
    function liberarForm(form) {
        if (!form) return;
        delete form.dataset.enviando;
        form.removeAttribute("aria-busy");
        form.querySelectorAll("[data-procesando='1']").forEach(liberar);
    }

    // Formularios comunes (POST). Corre al final: si otra parte de la página frenó el envío (confirmación,
    // aviso de duplicado, PIN, htmx), no hace nada.
    window.addEventListener("submit", function (e) {
        var form = e.target;
        if (!form || form.tagName !== "FORM") return;
        if (form.dataset.enviando === "1") { e.preventDefault(); return; }   // segundo toque: se ignora
        if (e.defaultPrevented) return;
        if ((form.getAttribute("method") || "get").toLowerCase() !== "post") return;
        form.dataset.enviando = "1";
        form.setAttribute("aria-busy", "true");
        bloquear(e.submitter || form.querySelector("[type=submit]"));
        empezar();
        // Los formularios que bajan un archivo (data-descarga) no cambian de página: se liberan a los pocos segundos.
        setTimeout(function () { liberarForm(form); terminar(); }, form.hasAttribute("data-descarga") ? 4000 : SEGURIDAD);
    });

    // Botones y formularios con htmx (acciones que no recargan toda la página).
    document.addEventListener("htmx:beforeRequest", function (e) {
        var cfg = e.detail.requestConfig || {};
        if ((cfg.verb || "get").toLowerCase() === "get") return;   // consultas automáticas: sin aviso
        var elt = e.detail.elt;
        if (elt.dataset.enviando === "1") { e.preventDefault(); return; }
        elt.dataset.enviando = "1";
        var boton = elt.tagName === "BUTTON" ? elt : (elt.querySelector && elt.querySelector("[type=submit]"));
        if (boton) bloquear(boton);
        e.detail.__boton = boton;
        empezar();
    });
    document.addEventListener("htmx:afterRequest", function (e) {
        var cfg = e.detail.requestConfig || {};
        if ((cfg.verb || "get").toLowerCase() === "get") return;
        var elt = e.detail.elt;
        if (!elt || elt.dataset.enviando !== "1") return;
        delete elt.dataset.enviando;
        var boton = elt.tagName === "BUTTON" ? elt : (elt.querySelector && elt.querySelector("[data-procesando='1']"));
        liberar(boton);
        terminar();
    });

    // Volver con «Atrás»: el navegador puede mostrar la página como estaba (con el botón bloqueado).
    window.addEventListener("pageshow", function (e) {
        // Si la página vino de la memoria del navegador, puede mostrar un estado viejo (p. ej., «Firmar» en una nota
        // ya firmada): se vuelve a pedir al servidor para ver el estado real.
        if (e.persisted && /^\/nota\/\d+/.test(location.pathname)) { location.reload(); return; }
        document.querySelectorAll("form[data-enviando='1']").forEach(liberarForm);
        document.querySelectorAll("[data-procesando='1']").forEach(liberar);
        activos = 0; terminar();
    });
})();
