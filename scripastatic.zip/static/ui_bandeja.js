// ui_bandeja.js — bandejas de firma, aprobación y despacho (propuestas 107–114). Mejora progresiva: sin JavaScript, el nombre
// de cada documento es un enlace común a la nota.
(function () {
    "use strict";
    var ANCHO_DIVIDIDO = "(min-width: 1280px)";

    function atajosActivos() { return document.documentElement.getAttribute("data-atajos") !== "no"; }
    function enCampo(e) { var t = (e.target.tagName || "").toLowerCase(); return t === "input" || t === "textarea" || t === "select" || e.target.isContentEditable; }

    // ---- Propuesta 108 (U11): vista dividida. En pantallas de 1280 px o más, elegir una fila carga el resumen y la vista previa a la derecha.
    function prepararVistaDividida(caja) {
        var detalle = caja.querySelector(".vista-dividida__detalle");
        var enlaces = Array.prototype.slice.call(caja.querySelectorAll("a.fila-enlace[data-vista]"));
        if (!detalle || !enlaces.length) return;
        var mq = window.matchMedia ? window.matchMedia(ANCHO_DIVIDIDO) : null;
        function ancho() { return !mq || mq.matches; }
        var actual = -1;
        function elegir(i, enfocarPanel) {
            if (i < 0 || i >= enlaces.length) return;
            actual = i;
            enlaces.forEach(function (a, j) {
                var tr = a.closest("tr");
                if (tr) tr.classList.toggle("fila--elegida", j === i);
                if (j === i) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
            });
            var a = enlaces[i];
            caja.classList.add("vista-dividida--abierta");
            detalle.hidden = false;
            detalle.setAttribute("aria-busy", "true");
            var listo = function () {
                detalle.removeAttribute("aria-busy");
                if (enfocarPanel) { var h = detalle.querySelector(".vista-nota__titulo"); if (h) h.focus(); }
            };
            if (window.htmx) {
                var p = window.htmx.ajax("GET", a.dataset.vista, { target: detalle, swap: "innerHTML" });
                if (p && p.then) p.then(listo, listo); else setTimeout(listo, 400);
            } else {
                fetch(a.dataset.vista, { credentials: "same-origin" }).then(function (r) { return r.text(); })
                    .then(function (h) { detalle.innerHTML = h; listo(); }, listo);
            }
            a.scrollIntoView({ block: "nearest" });
        }
        enlaces.forEach(function (a, i) {
            a.addEventListener("click", function (e) {
                if (!ancho() || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
                e.preventDefault();
                elegir(i, false);
            });
        });
        // J / K mueven la selección (si los atajos de una tecla están activos); Enter en el enlace abre la nota completa.
        document.addEventListener("keydown", function (e) {
            if (!ancho() || !atajosActivos() || enCampo(e) || e.ctrlKey || e.metaKey || e.altKey) return;
            var k = (e.key || "").toLowerCase();
            if (k === "j" || k === "k") {
                if (document.querySelector('[data-atajo="j"], [data-atajo="k"]')) return;
                e.preventDefault();
                elegir(actual < 0 ? 0 : actual + (k === "j" ? 1 : -1), false);
                enlaces[actual] && enlaces[actual].focus();
            }
        });
        if (mq && mq.addEventListener) mq.addEventListener("change", function () {
            if (!ancho()) { caja.classList.remove("vista-dividida--abierta"); detalle.hidden = true; }
        });
    }

    function iniciar() {
        document.querySelectorAll("[data-vista-dividida]").forEach(prepararVistaDividida);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 114 (U17): «seleccionar todos los visibles» y «Aprobar y enviar a corrección (N)» en la barra de selección.
(function () {
    "use strict";
    function iniciar() {
        var barra = document.getElementById("form-bloques");
        if (!barra) return;
        var todos = document.querySelector("[data-ui-todos]");
        var aprobar = document.getElementById("barra-aprobar");
        function cajas() { return Array.prototype.filter.call(document.querySelectorAll('input[name="nota_ids"][form="form-bloques"]'), function (c) { return c.offsetParent !== null; }); }
        function actualizar() {
            var marcadas = cajas().filter(function (c) { return c.checked; });
            if (todos) { var n = cajas().length; todos.checked = n > 0 && marcadas.length === n; todos.indeterminate = marcadas.length > 0 && marcadas.length < n; }
            if (aprobar) {
                var subidas = marcadas.filter(function (c) { return c.dataset.estado === "SUBIDA"; });
                aprobar.hidden = subidas.length === 0;
                var s = aprobar.querySelector("[data-ui-cantidad-aprobar]"); if (s) s.textContent = subidas.length;
                var nombres = subidas.map(function (c) { return c.dataset.nombre || c.value; });
                aprobar.dataset.confirmar = "Vas a aprobar y mandar a corrección " + subidas.length + " documento(s): " + nombres.slice(0, 8).join(", ") + (nombres.length > 8 ? "…" : "") +
                    (marcadas.length > subidas.length ? ". Los marcados que no esperan aprobación no se tocan." : ".");
                aprobar.dataset.confirmarBoton = "Sí, aprobar " + subidas.length;
            }
        }
        if (todos && cajas().length > 1) {
            todos.hidden = false;
            todos.addEventListener("change", function () {
                cajas().forEach(function (c) { if (c.checked !== todos.checked) { c.checked = todos.checked; c.dispatchEvent(new Event("change", { bubbles: true })); } });
                actualizar();
            });
        }
        document.addEventListener("change", function (e) { if (e.target && e.target.name === "nota_ids") actualizar(); });
        actualizar();
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 159 (U62): cambiar la prioridad sin recargar la página (no se pierde el desplazamiento ni los grupos abiertos),
// con el aviso «Prioridad cambiada · Deshacer». Reemplaza a la función de base.html, que recargaba todo el listado.
(function () {
    "use strict";
    function pintar(select, valor) {
        select.className = select.className.replace(/chip-select--\w+/, "chip-select--" + valor.toLowerCase());
        var tr = select.closest("tr");
        if (tr) tr.className = tr.className.replace(/fila-prioridad-\w+/, "fila-prioridad-" + valor.toLowerCase());
        select.dataset.previa = valor;
    }
    window.cambiarPrioridad = function (select) {
        var previa = select.dataset.previa || Array.prototype.filter.call(select.options, function (o) { return o.defaultSelected; }).map(function (o) { return o.value; })[0];
        var datos = new FormData(); datos.append("prioridad", select.value);
        select.disabled = true; select.setAttribute("aria-busy", "true");
        fetch("/nota/" + select.dataset.nota + "/prioridad", { method: "POST", body: datos, credentials: "same-origin", redirect: "manual" })
            .then(function (r) {
                if (r.type !== "opaqueredirect" && !r.ok) { return r.json().then(function (j) { throw new Error(j.detail || "No se pudo cambiar la prioridad."); }); }
                pintar(select, select.value);
                return fetch("/ui/aviso-pendiente", { credentials: "same-origin", headers: { "Accept": "application/json" } }).then(function (x) { return x.ok ? x.json() : {}; });
            })
            .then(function (j) {
                select.disabled = false; select.removeAttribute("aria-busy");
                var texto = (j && j.flash) || "Prioridad cambiada.";
                if (j && j.deshacer && window.uiAvisoDeshacer) window.uiAvisoDeshacer(texto, previa, select);
                else if (window.mostrarAviso) window.mostrarAviso(texto, true);
            })
            .catch(function (err) {
                select.disabled = false; select.removeAttribute("aria-busy");
                if (previa) select.value = previa;
                if (window.mostrarAviso) window.mostrarAviso(err.message || "No se pudo cambiar la prioridad.");
            });
    };
    window.uiAvisoDeshacer = function (texto, previa, select) {
        var caja = document.getElementById("avisos"); if (!caja) return;
        var d = document.createElement("div"); d.className = "aviso-flotante aviso-flotante--ok aviso-ui"; d.setAttribute("role", "status");
        var t = document.createElement("span"); t.textContent = texto; d.appendChild(t);
        var b = document.createElement("button"); b.type = "button"; b.className = "boton boton--chico"; b.textContent = "Deshacer";
        b.addEventListener("click", function (e) { e.stopPropagation(); d.remove(); select.value = previa; window.cambiarPrioridad(select); });
        d.appendChild(b);
        var x = document.createElement("button"); x.type = "button"; x.className = "aviso-flotante__cerrar"; x.setAttribute("aria-label", "Cerrar aviso"); x.textContent = "×";
        x.addEventListener("click", function () { d.remove(); }); d.appendChild(x);
        caja.appendChild(d);
        setTimeout(function () { d.remove(); }, 20000);
    };
})();

// ---- Propuesta 121 (U24): antes de subir, qué va a pasar con cada archivo (Word → corrección y firma; PDF → archivo directo),
// con un botón para quitar cada uno, y una barra de progreso mientras se sube.
(function () {
    "use strict";
    function destino(nombre, varios) {
        if (/\.pdf$/i.test(nombre)) return varios ? "archivo directo (va como adjunto si los agrupás)" : "archivo directo, sin corrección ni firma";
        if (/\.docx?$/i.test(nombre)) return "corrección y firma";
        return "no se puede subir (solo Word o PDF)";
    }
    function iniciar() {
        var form = document.getElementById("form-subida");
        var inp = form && form.querySelector('input[type="file"][name="archivos"]');
        if (!inp) return;
        var lista = document.createElement("ul"); lista.className = "previa-subida"; lista.setAttribute("aria-live", "polite"); lista.hidden = true;
        var barra = document.createElement("progress"); barra.className = "progreso-subida"; barra.max = 100; barra.value = 0; barra.hidden = true;
        barra.setAttribute("aria-label", "Progreso de la subida");
        form.appendChild(lista); form.appendChild(barra);
        function pintar() {
            var archivos = Array.prototype.slice.call(inp.files || []);
            lista.innerHTML = ""; lista.hidden = !archivos.length;
            archivos.forEach(function (f, i) {
                var li = document.createElement("li"), malo = !/\.(docx?|pdf)$/i.test(f.name);
                li.className = "previa-subida__item" + (malo ? " previa-subida__item--malo" : "");
                var t = document.createElement("span"); t.textContent = f.name + " → " + destino(f.name, archivos.length > 1);
                var x = document.createElement("button"); x.type = "button"; x.className = "boton boton--chico"; x.textContent = "Quitar";
                x.setAttribute("aria-label", "Quitar " + f.name);
                x.addEventListener("click", function () {
                    if (typeof DataTransfer === "undefined") return;
                    var dt = new DataTransfer();
                    archivos.forEach(function (g, j) { if (j !== i) dt.items.add(g); });
                    inp.files = dt.files; inp.dispatchEvent(new Event("change", { bubbles: true }));
                });
                li.appendChild(t); li.appendChild(x); lista.appendChild(li);
            });
        }
        inp.addEventListener("change", pintar);
        form.addEventListener("htmx:xhr:progress", function (e) {
            if (!e.detail || !e.detail.lengthComputable) return;
            barra.hidden = false; barra.value = Math.round(100 * e.detail.loaded / e.detail.total);
        });
        form.addEventListener("htmx:afterRequest", function () { barra.hidden = true; barra.value = 0; });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 132 (U35): «Exportar esta vista»: un CSV con exactamente lo que se ve en el listado de Notas (filtros, orden y
// columnas visibles de la página actual). Se arma en el navegador con lo que ya está en pantalla: no pide nada nuevo al servidor.
(function () {
    "use strict";
    function celda(td) {
        var c = (td.querySelector("summary") || td).cloneNode(true);
        c.querySelectorAll("br").forEach(function (br) { br.replaceWith(document.createTextNode(" · ")); });
        c.querySelectorAll("select").forEach(function (s) { var o = s.options[s.selectedIndex]; s.replaceWith(document.createTextNode(o ? o.textContent : "")); });
        c.querySelectorAll("input, button, .sr-only, .etapa-ayuda__caja, svg").forEach(function (x) { x.remove(); });
        return (c.textContent || "").replace(/\s+/g, " ").trim();
    }
    function csv(tabla) {
        var filas = [];
        var cab = Array.prototype.map.call(tabla.querySelectorAll("thead th"), function (th) { return celda(th).replace(/[▾●]/g, "").trim(); });
        var usar = cab.map(function (t) { return !!t; });
        filas.push(cab.filter(function (t, i) { return usar[i]; }));
        tabla.querySelectorAll("tbody tr").forEach(function (tr) {
            if (tr.hidden || tr.classList.contains("fila-grupo")) return;
            var tds = Array.prototype.slice.call(tr.children);
            filas.push(tds.map(celda).filter(function (t, i) { return usar[i]; }));
        });
        return "\ufeff" + filas.map(function (f) { return f.map(function (v) { return /[";\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(";"); }).join("\r\n");
    }
    function iniciar() {
        var seccion = document.querySelector('[data-plegable="documentos"]');
        var tabla = seccion && seccion.querySelector("table.tabla-notas");
        if (!tabla) return;
        var n = tabla.querySelectorAll("tbody tr:not(.fila-grupo)").length;
        if (!n) return;
        var b = document.createElement("button"); b.type = "button"; b.className = "boton boton--chico exportar-vista";
        b.textContent = "Exportar esta vista (" + n + " fila" + (n === 1 ? "" : "s") + ")";
        b.title = "Descarga un CSV con lo que ves: los mismos filtros, el mismo orden y las mismas columnas";
        b.addEventListener("click", function () {
            var url = URL.createObjectURL(new Blob([csv(tabla)], { type: "text/csv;charset=utf-8" }));
            var a = document.createElement("a"); a.href = url; a.download = "notas_vista_" + new Date().toISOString().slice(0, 10) + ".csv";
            document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
        });
        tabla.closest(".tabla-scroll").insertAdjacentElement("beforebegin", b);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 130 (U33): menos chips junto al nombre del documento. Queda a la vista solo la marca más grave (plazo vencido,
// alertas de la IA, posible duplicado…) y el resto se pliega en «+N», que se abre con un toque. Sin JavaScript se ven todas.
(function () {
    "use strict";
    var GRAVEDAD = [".chip-plazo--vencida", ".chip-plazo--rojo", ".chip-hallazgo", 'a.etiqueta--aviso', ".chip-plazo--ambar",
                    '.etiqueta[title^="Respuesta"]', ".etiqueta--solo-mesa", ".chip-protocolo", ".chip-bloque"];
    function iniciar() {
        var seccion = document.querySelector('[data-plegable="documentos"]');
        if (!seccion) return;
        var tabla = seccion.querySelector("table.tabla-notas");
        if (!tabla) return;
        var col = Array.prototype.findIndex.call(tabla.querySelectorAll("thead th"), function (th) { return /^\s*Archivo/.test(th.textContent); });
        if (col < 0) return;
        tabla.querySelectorAll("tbody tr:not(.fila-grupo)").forEach(function (tr, i) {
            var td = tr.children[col];
            if (!td) return;
            var marcas = Array.prototype.filter.call(td.children, function (c) { return /chip-|etiqueta/.test(c.className) && c.tagName !== "BR"; });
            if (marcas.length < 2) return;
            var orden = function (el) { for (var k = 0; k < GRAVEDAD.length; k++) if (el.matches(GRAVEDAD[k])) return k; return GRAVEDAD.length; };
            marcas.sort(function (a, b) { return orden(a) - orden(b); });
            var resto = marcas.slice(1);
            var caja = document.createElement("span"); caja.className = "atencion-resto"; caja.id = "atencion-" + i; caja.hidden = true;
            resto.forEach(function (m) { caja.appendChild(document.createTextNode(" ")); caja.appendChild(m); });
            var b = document.createElement("button"); b.type = "button"; b.className = "atencion-mas"; b.textContent = "+" + resto.length;
            b.setAttribute("aria-expanded", "false"); b.setAttribute("aria-controls", caja.id);
            b.setAttribute("aria-label", "Ver " + resto.length + " marca" + (resto.length === 1 ? "" : "s") + " más: " + resto.map(function (m) { return m.textContent.trim(); }).join(", "));
            b.title = resto.map(function (m) { return m.textContent.trim(); }).join(" · ");
            b.addEventListener("click", function (e) { e.stopPropagation(); var abrir = caja.hidden; caja.hidden = !abrir; b.setAttribute("aria-expanded", abrir ? "true" : "false"); });
            marcas[0].insertAdjacentElement("afterend", b);
            b.insertAdjacentElement("afterend", caja);
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
