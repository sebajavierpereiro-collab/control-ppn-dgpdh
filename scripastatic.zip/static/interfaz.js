// interfaz.js — comportamientos comunes de la interfaz (evaluación de interfaz, octubre 2026).
// Todo es mejora progresiva: sin JavaScript la página funciona igual.
(function () {
    "use strict";
    var SVG = function (trazo) {
        return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + trazo + "</svg>";
    };
    var ICO = {
        ayuda: SVG('<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2.5-3 4M12 17v.5"/>'),
        subir: SVG('<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>')
    };
    function leer(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }

    // ---- Propuesta 18: las ayudas largas quedan detrás de un «?» junto al título (se pueden ver siempre desde Mi perfil).
    function prepararAyudas() {
        if (leer("apariencia-ayudas") === "siempre") { document.body.classList.add("ayudas-visibles"); }
        var n = 0;
        document.querySelectorAll(".contenido p.texto-ayuda, .contenido div.texto-ayuda").forEach(function (p) {
            if (p.classList.contains("ayuda--siempre") || p.closest(".ayuda--siempre, .aviso, .mensaje-error, .confirmacion-inline, form .acciones, td, li, dd, .lateral")) return;
            if (p.querySelector("a, button, input, select, textarea, strong.texto-alerta")) return;
            if ((p.textContent || "").trim().length < 70) return;
            // el título más cercano antes del párrafo, en el mismo contenedor
            var t = p.previousElementSibling, saltos = 0;
            while (t && saltos < 3 && !/^H[1-4]$/.test(t.tagName) && !t.classList.contains("cabecera-accion") && !t.classList.contains("panel-lista__encabezado")) { t = t.previousElementSibling; saltos++; }
            if (!t) return;
            var titulo = /^H[1-4]$/.test(t.tagName) ? t : t.querySelector("h1, h2, h3");
            if (!titulo) return;
            var b = titulo.querySelector(".ayuda-boton");
            if (!b) {
                b = document.createElement("button");
                b.type = "button"; b.className = "ayuda-boton"; b.innerHTML = ICO.ayuda;
                b.setAttribute("aria-label", "Ver la ayuda de esta sección"); b.setAttribute("aria-expanded", "false");
                b.title = "Ver la ayuda";
                b._ayudas = [];
                b.addEventListener("click", function (e) {
                    e.stopPropagation();
                    var abrir = b.getAttribute("aria-expanded") !== "true";
                    b.setAttribute("aria-expanded", abrir ? "true" : "false");
                    b._ayudas.forEach(function (x) { x.classList.toggle("ayuda--abierta", abrir); });
                });
                titulo.appendChild(b);
            }
            n++;
            p.id = p.id || ("ayuda-" + n);
            p.classList.add("ayuda-plegada");
            b._ayudas.push(p);
            b.setAttribute("aria-controls", b._ayudas.map(function (x) { return x.id; }).join(" "));
        });
    }

    // ---- Propuesta 33: filas de tabla clicables (tr[data-href]); los botones y enlaces de la fila siguen funcionando.
    function prepararFilas() {
        document.addEventListener("click", function (e) {
            var tr = e.target.closest && e.target.closest("tr[data-href]");
            if (!tr || e.target.closest("a, button, input, select, textarea, label, summary, details")) return;
            if (window.getSelection && String(window.getSelection())) return;  // estaba seleccionando texto
            if (e.ctrlKey || e.metaKey) { window.open(tr.dataset.href, "_blank"); } else { window.location.assign(tr.dataset.href); }
        });
    }

    // ---- Propuesta 15: selector de archivos en castellano, con arrastrar y soltar.
    function prepararArchivos() {
        document.querySelectorAll('input[type="file"]:not([data-sin-selector])').forEach(function (inp) {
            if (inp.closest(".selector-archivos")) return;
            var caja = document.createElement("label");
            caja.className = "selector-archivos";
            var multiple = inp.multiple;
            caja.innerHTML = '<span class="boton boton--chico">' + ICO.subir + (multiple ? "Elegir archivos" : "Elegir archivo") + "</span>" +
                '<span class="selector-archivos__texto">' + (multiple ? "o arrastralos acá" : "o arrastralo acá") + "</span>" +
                '<span class="selector-archivos__lista" aria-live="polite"></span>';
            inp.parentNode.insertBefore(caja, inp);
            caja.appendChild(inp);
            var lista = caja.querySelector(".selector-archivos__lista"), texto = caja.querySelector(".selector-archivos__texto");
            function pintar() {
                var n = inp.files ? inp.files.length : 0;
                texto.hidden = n > 0;
                lista.textContent = n === 0 ? "" : (n === 1 ? inp.files[0].name : n + " archivos: " + Array.prototype.map.call(inp.files, function (f) { return f.name; }).slice(0, 3).join(", ") + (n > 3 ? "…" : ""));
            }
            inp.addEventListener("change", pintar);
            ["dragenter", "dragover"].forEach(function (ev) { caja.addEventListener(ev, function (e) { e.preventDefault(); caja.classList.add("selector-archivos--sobre"); }); });
            ["dragleave", "drop"].forEach(function (ev) { caja.addEventListener(ev, function () { caja.classList.remove("selector-archivos--sobre"); }); });
            caja.addEventListener("drop", function (e) {
                e.preventDefault();
                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
                    try { inp.files = e.dataTransfer.files; } catch (x) { return; }
                    inp.dispatchEvent(new Event("change", { bubbles: true }));
                }
            });
        });
    }

    // ---- Propuesta 15: horas en formato 24 h en todos los navegadores (HH:MM).
    function prepararHoras() {
        document.querySelectorAll('input[type="time"]').forEach(function (inp) {
            var v = inp.value;
            inp.type = "text";
            inp.value = v;
            inp.inputMode = "numeric"; inp.maxLength = 5; inp.autocomplete = "off";
            inp.placeholder = inp.placeholder || "HH:MM";
            inp.pattern = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
            inp.title = "Hora en formato de 24 horas, por ejemplo 09:30 o 15:00";
            inp.classList.add("campo-hora");
            inp.addEventListener("input", function () {
                var d = inp.value.replace(/[^0-9]/g, "").slice(0, 4);
                if (d.length >= 3) inp.value = d.slice(0, d.length - 2) + ":" + d.slice(-2);
                else inp.value = d;
            });
            inp.addEventListener("blur", function () {
                var m = /^(\d{1,2}):?(\d{2})$/.exec(inp.value.trim());
                if (m && +m[1] < 24 && +m[2] < 60) { inp.value = ("0" + m[1]).slice(-2) + ":" + m[2]; inp.dispatchEvent(new Event("change", { bubbles: true })); }
            });
        });
    }

    function iniciar() {
        prepararHoras();
        prepararArchivos();
        prepararFilas();
        prepararAyudas();
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
