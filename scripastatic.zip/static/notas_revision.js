/* Modificación 1: «Revisar correcciones» a dos columnas. El inspector (derecha) se pliega y recuerda el estado;
   al tocar un aviso, el documento va al párrafo afectado y lo resalta un momento. Sin dependencias externas. */
(function () {
    "use strict";
    var raiz = document.getElementById("notas-revision"), boton = document.getElementById("inspector-plegar");
    if (!raiz) return;
    function plegar(si) {
        raiz.classList.toggle("notas-revision--plegado", si);
        if (boton) { boton.setAttribute("aria-expanded", si ? "false" : "true"); boton.textContent = si ? "Mostrar" : "Plegar"; }
        try { localStorage.setItem("revision-inspector-plegado", si ? "1" : "0"); } catch (e) { /* sin almacenamiento */ }
    }
    var guardado = null;
    try { guardado = localStorage.getItem("revision-inspector-plegado"); } catch (e) { /* sin almacenamiento */ }
    plegar(guardado === "1");
    if (boton) boton.addEventListener("click", function () { plegar(!raiz.classList.contains("notas-revision--plegado")); });

    function normal(t) {
        return (t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[«»"“”…]/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
    }
    var filas = Array.prototype.slice.call(document.querySelectorAll("#documento-comparado > *"));
    function textoFila(f) {
        var a = f.querySelector("textarea[data-original]");
        return normal((a ? a.dataset.original + " " + a.value : "") + " " + f.textContent);
    }
    function buscar(fragmentos) {
        var trozos = fragmentos.map(function (x) {
            var n = normal(x);  // se buscan los 40 caracteres del medio: el fragmento suele venir recortado en los bordes
            return n.length > 50 ? n.slice(Math.floor(n.length / 2) - 20, Math.floor(n.length / 2) + 20) : n;
        }).filter(function (x) { return x.length >= 6; });
        for (var i = 0; i < filas.length; i++) {
            var t = textoFila(filas[i]);
            for (var j = 0; j < trozos.length; j++) if (t.indexOf(trozos[j]) >= 0) return filas[i];
        }
        return null;
    }
    function ir(tarjeta) {
        var frs = (tarjeta.dataset.fragmentos || "").split("␞");
        var fila = buscar(frs);
        if (!fila) { tarjeta.classList.add("notas-sin-ubicar"); return; }
        if (fila.tagName === "DETAILS") fila.open = true;
        fila.scrollIntoView({ behavior: "smooth", block: "center" });
        fila.classList.remove("notas-resaltado"); void fila.offsetWidth; fila.classList.add("notas-resaltado");
        setTimeout(function () { fila.classList.remove("notas-resaltado"); }, 2500);
    }
    document.querySelectorAll(".notas-revision__inspector .hallazgo[data-fragmentos]").forEach(function (t) {
        if (!t.dataset.fragmentos) return;
        t.classList.add("notas-hallazgo-navegable");
        t.setAttribute("tabindex", "0");
        t.setAttribute("title", "Ir al párrafo en el documento");
        t.addEventListener("click", function (e) { if (!e.target.closest("button, a, form, details, input, textarea, select")) ir(t); });
        t.addEventListener("keydown", function (e) { if ((e.key === "Enter" || e.key === " ") && e.target === t) { e.preventDefault(); ir(t); } });
    });
})();
