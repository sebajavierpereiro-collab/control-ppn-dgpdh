// ui_agenda.js — propuesta 151 (U54): en pantallas angostas, la agenda semanal muestra un día por vez, con chips de día
// («L 16 · M 17 · …», hoy elegido por defecto y la cantidad de viajes en cada chip). En pantallas anchas no cambia nada.
(function () {
    "use strict";
    var ANGOSTA = "(max-width: 720px)";
    function iniciar() {
        var agenda = document.querySelector(".agenda");
        if (!agenda || !window.matchMedia) return;
        var dias = Array.prototype.slice.call(agenda.querySelectorAll(":scope > .agenda__dia"));
        if (dias.length < 2) return;
        var nav = document.createElement("div"); nav.className = "agenda-chips"; nav.setAttribute("role", "tablist"); nav.setAttribute("aria-label", "Día de la semana");
        var elegido = Math.max(0, dias.findIndex(function (d) { return d.classList.contains("agenda__dia--hoy"); }));
        var botones = dias.map(function (d, i) {
            var h = d.querySelector("h3"), t = (h ? h.textContent : "").trim().split(/\s+/);
            var n = d.querySelectorAll(".viaje").length;
            d.id = d.id || "agenda-dia-" + i; d.setAttribute("role", "tabpanel");
            var b = document.createElement("button"); b.type = "button"; b.className = "agenda-chip"; b.setAttribute("role", "tab");
            b.setAttribute("aria-controls", d.id); b.id = d.id + "-chip";
            b.innerHTML = "<span></span><small></small>";
            b.firstChild.textContent = (t[0] || "").charAt(0) + " " + ((t[1] || "").split("/")[0] || "");
            b.lastChild.textContent = n + (n === 1 ? " viaje" : " viajes");
            b.setAttribute("aria-label", (h ? h.textContent.trim() : "") + ", " + b.lastChild.textContent);
            d.setAttribute("aria-labelledby", b.id);
            b.addEventListener("click", function () { elegir(i, true); });
            nav.appendChild(b);
            return b;
        });
        agenda.parentNode.insertBefore(nav, agenda);
        var mq = window.matchMedia(ANGOSTA);
        function elegir(i, foco) {
            elegido = i;
            var angosta = mq.matches;
            nav.hidden = !angosta;
            dias.forEach(function (d, j) { d.hidden = angosta && j !== i; });
            botones.forEach(function (b, j) { b.setAttribute("aria-selected", j === i ? "true" : "false"); b.tabIndex = j === i ? 0 : -1; });
            if (angosta) nav.scrollLeft = Math.max(0, botones[i].offsetLeft - nav.offsetLeft - 8);
            if (foco) botones[i].focus();
        }
        nav.addEventListener("keydown", function (e) {
            if (e.key === "ArrowRight") { e.preventDefault(); elegir((elegido + 1) % dias.length, true); }
            if (e.key === "ArrowLeft") { e.preventDefault(); elegir((elegido - 1 + dias.length) % dias.length, true); }
        });
        if (mq.addEventListener) mq.addEventListener("change", function () { elegir(elegido, false); });
        elegir(elegido, false);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
