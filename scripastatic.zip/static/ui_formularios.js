// ui_formularios.js — formularios (propuestas 115, 119, 122): resumen de errores con enlaces, mensajes junto a cada campo,
// atajos de fecha y borradores guardados en el servidor. Mejora progresiva: sin JavaScript el navegador valida como siempre.
(function () {
    "use strict";

    function etiquetaDe(campo) {
        if (campo.labels && campo.labels.length) return campo.labels[0].textContent.replace(/\s*\(.*?\)\s*/g, " ").replace(/\s+/g, " ").trim();
        return campo.getAttribute("aria-label") || campo.placeholder || campo.name || "este dato";
    }
    function mensajeDe(campo) {
        if (campo.dataset.error) return campo.dataset.error;
        var v = campo.validity, nombre = "«" + etiquetaDe(campo).replace(/[«»:*]/g, "").trim() + "»";
        if (v.valueMissing) return campo.type === "checkbox" || campo.type === "radio" ? "Elegí una opción en " + nombre + "." : "Completá " + nombre + ".";
        if (v.patternMismatch) return "Revisá el formato de " + nombre + (campo.title ? ": " + campo.title : ".");
        if (v.typeMismatch) return "Revisá " + nombre + ": el formato no es válido.";
        if (v.tooShort) return nombre + " tiene que tener al menos " + campo.minLength + " caracteres.";
        if (v.rangeUnderflow || v.rangeOverflow) return "Revisá " + nombre + ": el valor está fuera de lo permitido.";
        return campo.validationMessage || ("Revisá " + nombre + ".");
    }
    function idDe(campo, i) { if (!campo.id) campo.id = "campo-ui-" + (campo.name || "x").replace(/\W/g, "") + "-" + i; return campo.id; }

    // ---- Propuesta 115 (U18): al intentar enviar con errores, un resumen arriba (con enlaces) y el error junto a cada campo.
    function limpiar(form) {
        form.querySelectorAll(".error-campo[data-ui]").forEach(function (p) { p.remove(); });
        form.querySelectorAll("[aria-invalid='true'][data-ui-invalido]").forEach(function (c) {
            c.removeAttribute("aria-invalid"); c.removeAttribute("data-ui-invalido");
            var d = (c.getAttribute("aria-describedby") || "").split(" ").filter(function (x) { return x && x !== c.id + "-error"; }).join(" ");
            if (d) c.setAttribute("aria-describedby", d); else c.removeAttribute("aria-describedby");
        });
        var r = form.querySelector(".resumen-errores[data-ui]"); if (r) r.remove();
    }
    function mostrarErrores(form) {
        limpiar(form);
        var malos = Array.prototype.filter.call(form.elements, function (c) { return c.willValidate && !c.validity.valid; });
        if (!malos.length) return;
        var vistos = {}, items = [];
        malos.forEach(function (c, i) {
            if (c.type === "radio" && vistos[c.name]) return;
            vistos[c.name] = true;
            var id = c.dataset.uiCombobox || idDe(c, i), m = mensajeDe(c);  // en un combobox (propuesta 120) el foco va al campo de texto
            items.push([id, m]);
            var p = document.createElement("p"); p.className = "error-campo"; p.id = id + "-error"; p.dataset.ui = "1"; p.textContent = m;
            var ancla = c.closest(".combobox") || c.closest("label") || c;
            if (c.type === "radio" || c.type === "checkbox") ancla = c.closest("fieldset") || ancla;
            ancla.insertAdjacentElement("afterend", p);
            c.setAttribute("aria-invalid", "true"); c.dataset.uiInvalido = "1";
            c.setAttribute("aria-describedby", ((c.getAttribute("aria-describedby") || "") + " " + id + "-error").trim());
        });
        var caja = document.createElement("div");
        caja.className = "resumen-errores"; caja.dataset.ui = "1"; caja.setAttribute("role", "alert"); caja.tabIndex = -1;
        caja.innerHTML = '<h2 class="resumen-errores__titulo">Hay que corregir esto antes de seguir</h2><ul class="resumen-errores__lista"></ul>';
        var ul = caja.querySelector("ul");
        items.forEach(function (x) {
            var li = document.createElement("li"), a = document.createElement("a");
            a.href = "#" + x[0]; a.textContent = x[1];
            a.addEventListener("click", function (e) { e.preventDefault(); var c = document.getElementById(x[0]); if (c) { c.focus(); c.scrollIntoView({ block: "center" }); } });
            li.appendChild(a); ul.appendChild(li);
        });
        form.insertBefore(caja, form.firstChild);
        caja.focus();
    }
    function prepararValidacion() {
        var pendiente = null;
        document.addEventListener("invalid", function (e) {
            var form = e.target.form;
            if (!form || form.hasAttribute("data-sin-resumen") || form.closest("dialog")) return;
            e.preventDefault();  // sin el globo del navegador: el resumen dice todo junto
            if (pendiente === form) return;
            pendiente = form;
            setTimeout(function () { pendiente = null; mostrarErrores(form); }, 0);
        }, true);
        document.addEventListener("input", function (e) {
            var c = e.target;
            if (c.dataset && c.dataset.uiInvalido && c.validity && c.validity.valid) {
                var p = document.getElementById(c.id + "-error"); if (p && p.dataset.ui) p.remove();
                c.removeAttribute("aria-invalid"); delete c.dataset.uiInvalido;
            }
        });
        // Los errores que devuelve el servidor arriba del formulario reciben el foco al cargar.
        var r = document.querySelector("[data-ui-resumen-errores], .contenido > .mensaje-error[role='alert'], .contenido > .aviso-error[role='alert']");
        if (r) { if (!r.hasAttribute("tabindex")) r.tabIndex = -1; r.focus({ preventScroll: false }); }
    }

    // ---- Propuesta 119 (U22): atajos «Hoy», «Mañana» y «Próximo lunes» junto a los campos de fecha.
    function iso(d) { return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2); }
    function prepararFechas() {
        document.querySelectorAll('input[type="date"]').forEach(function (inp) {
            if (inp.dataset.uiFechas || inp.hasAttribute("data-sin-atajos") || inp.closest(".form-filtros, .menu-col, .agrupar-notas, dialog") || inp.readOnly || inp.disabled) return;
            inp.dataset.uiFechas = "1";
            var hoy = new Date(), man = new Date(hoy.getTime() + 864e5), lun = new Date(hoy.getTime() + ((8 - hoy.getDay()) % 7 || 7) * 864e5);
            var caja = document.createElement("span"); caja.className = "atajos-fecha"; caja.setAttribute("role", "group");
            caja.setAttribute("aria-label", "Atajos para " + etiquetaDe(inp));
            [["Hoy", hoy], ["Mañana", man], ["Próximo lunes", lun]].forEach(function (x) {
                var v = iso(x[1]);
                if ((inp.min && v < inp.min) || (inp.max && v > inp.max)) return;
                var b = document.createElement("button"); b.type = "button"; b.className = "atajos-fecha__chip"; b.textContent = x[0];
                b.addEventListener("click", function () { inp.value = v; inp.dispatchEvent(new Event("input", { bubbles: true })); inp.dispatchEvent(new Event("change", { bubbles: true })); });
                caja.appendChild(b);
            });
            if (caja.children.length) (inp.closest("label") || inp).insertAdjacentElement("afterend", caja);
        });
    }

    // ---- Propuesta 122 (U25): borradores guardados en el servidor cada 30 s y al salir de un campo largo, con «Guardado 10:42»,
    // aviso al cerrar la pestaña solo si hay cambios sin guardar, y recuperación al volver (también después del cierre por inactividad).
    var borradores = [];
    function camposDe(form) {
        return Array.prototype.filter.call(form.elements, function (c) {
            return c.name && !c.disabled && !/^(password|file|hidden|submit|button|reset)$/.test(c.type) && !c.closest("[data-sin-borrador]");
        });
    }
    function leerForm(form) {
        var d = {};
        camposDe(form).forEach(function (c) {
            if (c.type === "checkbox" || c.type === "radio") { if (c.checked) (d[c.name] = d[c.name] || []).push(c.value); }
            else if (c.multiple) d[c.name] = Array.prototype.filter.call(c.options, function (o) { return o.selected; }).map(function (o) { return o.value; });
            else d[c.name] = [c.value];
        });
        return d;
    }
    function escribirForm(form, d) {
        camposDe(form).forEach(function (c) {
            var v = d[c.name]; if (!v) { if (c.type === "checkbox" || c.type === "radio") c.checked = false; return; }
            if (c.type === "checkbox" || c.type === "radio") c.checked = v.indexOf(c.value) >= 0;
            else if (c.multiple) Array.prototype.forEach.call(c.options, function (o) { o.selected = v.indexOf(o.value) >= 0; });
            else c.value = v[0];
            c.dispatchEvent(new Event("change", { bubbles: true }));
        });
    }
    function candidato(form) {
        if (form.hasAttribute("data-borrador")) return true;
        if ((form.method || "").toLowerCase() !== "post" || form.hasAttribute("data-sin-borrador") || form.closest("dialog, .lateral, .barra-bloque")) return false;
        if (form.querySelector('input[type="password"], input[type="file"]')) return false;
        var textos = camposDe(form).filter(function (c) { return c.tagName === "TEXTAREA" || (c.tagName === "INPUT" && /^(text|search|date|number|email|tel)$/.test(c.type)); });
        return !!form.querySelector("textarea") || textos.length >= 4;
    }
    function enviar(url, datos, baliza) {
        var fd = new FormData(); Object.keys(datos).forEach(function (k) { fd.append(k, datos[k]); });
        if (baliza && navigator.sendBeacon) { navigator.sendBeacon(url, fd); return Promise.resolve(null); }
        return fetch(url, { method: "POST", body: fd, credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
    }
    function prepararBorrador(form, i) {
        var clave = (location.pathname + "#" + (form.id || form.getAttribute("action") || i)).slice(0, 200);
        var b = { form: form, clave: clave, inicial: JSON.stringify(leerForm(form)), guardado: null, sucio: false, enviando: false };
        b.guardado = b.inicial;
        var marca = document.createElement("span"); marca.className = "marca-guardado"; marca.setAttribute("aria-live", "polite");
        var acciones = form.querySelector(".acciones") || form;
        acciones.appendChild(marca);
        b.guardar = function (baliza) {
            var actual = JSON.stringify(leerForm(form));
            if (actual === b.guardado || actual === b.inicial) { b.sucio = actual !== b.inicial && actual !== b.guardado; return; }
            b.guardado = actual; b.sucio = false;
            enviar("/ui/borrador", { clave: clave, datos: actual }, baliza).then(function (r) {
                if (r && r.hora) marca.textContent = "Borrador guardado " + r.hora;
            });
        };
        form.addEventListener("input", function () { b.sucio = true; });
        form.addEventListener("change", function () { b.sucio = true; });
        form.addEventListener("focusout", function (e) { if (e.target.tagName === "TEXTAREA") b.guardar(false); });
        form.addEventListener("submit", function () { b.sucio = false; b.guardado = JSON.stringify(leerForm(form)); enviar("/ui/borrador/descartar", { clave: clave }, true); });
        borradores.push(b);
        fetch("/ui/borrador?clave=" + encodeURIComponent(clave), { credentials: "same-origin" })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (j) {
                if (!j || !j.borrador || JSON.stringify(j.borrador.datos) === b.inicial) return;
                var aviso = document.createElement("div"); aviso.className = "aviso-borrador"; aviso.setAttribute("role", "status");
                aviso.innerHTML = "<span>Tenés un borrador sin enviar de este formulario.</span>";
                var rec = document.createElement("button"); rec.type = "button"; rec.className = "boton boton--chico"; rec.textContent = "Recuperar el borrador";
                var des = document.createElement("button"); des.type = "button"; des.className = "boton boton--chico"; des.textContent = "Descartarlo";
                rec.addEventListener("click", function () { escribirForm(form, j.borrador.datos); aviso.innerHTML = "<span>Recuperamos tu borrador. Revisalo antes de enviar.</span>"; b.guardado = JSON.stringify(leerForm(form)); });
                des.addEventListener("click", function () { aviso.remove(); enviar("/ui/borrador/descartar", { clave: clave }, false); });
                aviso.appendChild(rec); aviso.appendChild(des);
                form.insertBefore(aviso, form.firstChild);
            }).catch(function () {});
    }
    function prepararBorradores() {
        Array.prototype.forEach.call(document.querySelectorAll(".contenido form"), function (f, i) { if (candidato(f)) prepararBorrador(f, i); });
        if (!borradores.length) return;
        setInterval(function () { borradores.forEach(function (b) { if (b.sucio) b.guardar(false); }); }, 30000);
        window.addEventListener("beforeunload", function (e) {
            var pendiente = borradores.some(function (b) { return b.sucio && JSON.stringify(leerForm(b.form)) !== b.guardado; });
            if (!pendiente) return;
            borradores.forEach(function (b) { b.guardar(true); });
            if (!navigator.sendBeacon) { e.preventDefault(); e.returnValue = ""; }  // si no se pudo mandar, se avisa antes de cerrar
        });
    }
    window.uiGuardarBorradores = function () { borradores.forEach(function (b) { b.guardar(true); }); };

    function iniciar() { prepararValidacion(); prepararFechas(); prepararBorradores(); }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 126 (U29): los filtros se aplican solos al cambiar una lista, una fecha o una casilla (el texto, al salir del
// campo o con Enter). La URL sigue siendo compartible y «Atrás» funciona; el botón «Filtrar» queda para quien no usa JavaScript.
(function () {
    "use strict";
    function iniciar() {
        document.querySelectorAll("form.form-filtros, form[data-autofiltrar]").forEach(function (f) {
            if ((f.method || "get").toLowerCase() !== "get" || f.dataset.uiAuto) return;
            f.dataset.uiAuto = "1";
            var t = null;
            f.addEventListener("change", function (e) {
                var c = e.target;
                if (!c.name || c.closest(".combobox") && c.tagName === "INPUT") return;  // el combobox avisa con el change de su select
                clearTimeout(t);
                t = setTimeout(function () { if (f.requestSubmit) f.requestSubmit(); else f.submit(); }, 250);
            });
            var aviso = document.createElement("span"); aviso.className = "texto-ayuda filtros-auto";
            aviso.textContent = "Se aplica solo al cambiar un filtro.";
            var b = f.querySelector('button[type="submit"], button:not([type])');
            if (b) b.insertAdjacentElement("afterend", aviso);
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 133 (U36): en la búsqueda de personas detenidas, la regla («con DNI o LPU alcanza; si no, dos datos») está dentro
// del formulario y un contador en vivo dice cuánto falta, antes de buscar.
(function () {
    "use strict";
    function iniciar() {
        var f = document.querySelector("form.form-buscar-detenidos");
        if (!f) return;
        var estado = document.createElement("p"); estado.className = "contador-datos"; estado.setAttribute("aria-live", "polite"); estado.id = "contador-datos";
        var boton = f.querySelector('button[type="submit"]');
        f.insertBefore(estado, boton);
        if (boton) boton.setAttribute("aria-describedby", "contador-datos");
        var CLAVE = ["dni", "lpu"], OTROS = ["apellido", "nombre", "expediente", "codigo", "unidad_id", "edad"];
        function val(n) { var c = f.elements[n]; return c ? String(c.value || "").trim() : ""; }
        function pintar() {
            var clave = CLAVE.some(function (n) { return val(n).replace(/\D/g, "").length >= 3; });
            var n = OTROS.filter(function (k) { return val(k); }).length;
            var listo = clave || n >= 2;
            estado.classList.toggle("contador-datos--listo", listo);
            estado.textContent = clave ? "Con el DNI o el LPU alcanza: ya podés buscar." :
                (listo ? "Completaste " + n + " datos: ya podés buscar." : "Completaste " + n + " de 2 datos (o escribí el DNI o el LPU, que alcanza solo).");
        }
        f.addEventListener("input", pintar); f.addEventListener("change", pintar); pintar();
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();

// ---- Propuesta 111 (U14): al devolver una nota, chips con los motivos frecuentes (se pueden marcar varios) que se suman al
// texto como una lista «• …»; el texto libre sigue disponible.
(function () {
    "use strict";
    var cache = null;
    function motivos() {
        if (!cache) cache = fetch("/ui/motivos-frecuentes", { credentials: "same-origin" }).then(function (r) { return r.ok ? r.json() : { motivos: [] }; })
            .catch(function () { return { motivos: [] }; });
        return cache;
    }
    function preparar(ta) {
        if (ta.dataset.uiMotivos) return;
        ta.dataset.uiMotivos = "1";
        motivos().then(function (j) {
            if (!j.motivos || !j.motivos.length) return;
            var caja = document.createElement("div"); caja.className = "chips-motivos"; caja.setAttribute("role", "group"); caja.setAttribute("aria-label", "Motivos frecuentes");
            j.motivos.forEach(function (m) {
                var b = document.createElement("button"); b.type = "button"; b.className = "chip-motivo"; b.textContent = m; b.setAttribute("aria-pressed", "false");
                b.addEventListener("click", function () {
                    var linea = "• " + m, lineas = ta.value.split("\n").filter(function (x) { return x.trim(); });
                    var i = lineas.indexOf(linea);
                    if (i >= 0) { lineas.splice(i, 1); b.setAttribute("aria-pressed", "false"); } else { lineas.push(linea); b.setAttribute("aria-pressed", "true"); }
                    ta.value = lineas.join("\n"); ta.dispatchEvent(new Event("input", { bubbles: true }));
                });
                caja.appendChild(b);
            });
            ta.insertAdjacentElement("beforebegin", caja);
        });
    }
    function buscar(raiz) {
        (raiz || document).querySelectorAll('form[hx-post*="/rechazar-coordinacion"] textarea[name="motivo"], form[action*="/rechazar-direccion"] textarea[name="motivo"]').forEach(preparar);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { buscar(); }); else buscar();
    document.addEventListener("htmx:afterSwap", function (e) { buscar(e.target); });
})();

// ---- Propuesta 117 (U20): en la ficha de una persona detenida, el DNI y el LPU se controlan al salir del campo.
(function () {
    "use strict";
    function iniciar() {
        document.querySelectorAll('form[action^="/detenidos"] input[name="dni"], form[action^="/detenidos"] input[name="lpu"]').forEach(function (inp) {
            var form = inp.form, m = /\/detenidos\/(\d+)/.exec(form.getAttribute("action") || "");
            if (!/\/(nueva|\d+\/editar)$/.test(form.getAttribute("action") || "")) return;
            var caja = document.createElement("span"); caja.className = "validacion-en-linea"; caja.setAttribute("aria-live", "polite");
            caja.id = "valida-" + inp.name;
            (inp.closest("label") || inp).insertAdjacentElement("afterend", caja);
            inp.setAttribute("aria-describedby", ((inp.getAttribute("aria-describedby") || "") + " " + caja.id).trim());
            inp.addEventListener("change", function () {
                fetch("/ui/validar/" + inp.name + "?valor=" + encodeURIComponent(inp.value) + "&excluir=" + (m ? m[1] : ""), { credentials: "same-origin" })
                    .then(function (r) { return r.ok ? r.text() : ""; }).then(function (h) { caja.innerHTML = h; }).catch(function () {});
            });
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
