/* Mesa de asignación: al marcar pedidos de un día suma personas y franja horaria, propone chofer y vehículo libres
   (la persona decide) y avisa capacidad, solapamientos, licencias y vencimientos antes de enviar. */
(function () {
    "use strict";
    function mins(h) { var p = String(h || "").split(":"); return (+p[0] || 0) * 60 + (+p[1] || 0); }
    function hhmm(m) { return String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0"); }
    function choca(op, desde, hasta) {
        var lista = []; try { lista = JSON.parse(op.dataset.ocupado || "[]"); } catch (e) {}
        return lista.filter(function (f) { return mins(f.desde) < hasta && desde < mins(f.hasta); });
    }
    function iniciar(form) {
        var selCh = form.querySelector("[data-chofer]"), selVe = form.querySelector("[data-vehiculo]");
        var resumen = form.querySelector("[data-resumen]"), avisos = form.querySelector("[data-avisos]");
        var forzar = form.querySelector("[data-forzar]"), boton = form.querySelector("[data-asignar]");
        var maxPlazas = +form.dataset.maxPlazas || 0;
        var elegidoAMano = {ch: false, ve: false};
        selCh.addEventListener("change", function () { elegidoAMano.ch = !!selCh.value; actualizar(); });
        selVe.addEventListener("change", function () { elegidoAMano.ve = true; actualizar(); });
        form.querySelectorAll("[data-marcar-lugar]").forEach(function (b) {
            b.addEventListener("click", function () {
                var cajas = b.closest("fieldset").querySelectorAll("input[name=viaje_id]");
                var todas = Array.prototype.every.call(cajas, function (c) { return c.checked; });
                cajas.forEach(function (c) { c.checked = !todas; });
                actualizar();
            });
        });
        form.addEventListener("change", function (e) { if (e.target.name === "viaje_id") actualizar(); });

        function actualizar() {
            var marcados = Array.prototype.filter.call(form.querySelectorAll("input[name=viaje_id]"), function (c) { return c.checked; });
            form.querySelectorAll(".mesa-pedido").forEach(function (p) { p.classList.toggle("mesa-pedido--marcado", p.querySelector("input").checked); });
            var personas = 0, desde = 24 * 60, hasta = 0;
            marcados.forEach(function (c) {
                var p = c.closest(".mesa-pedido");
                personas += +p.dataset.personas || 0;
                desde = Math.min(desde, mins(p.dataset.salida)); hasta = Math.max(hasta, mins(p.dataset.regreso));
            });
            var lista = [];
            // marcar cada opción: ocupada en la franja, bloqueada o sin capacidad
            Array.prototype.forEach.call(selCh.options, function (o) {
                if (!o.value) return;
                var ch = marcados.length ? choca(o, desde, hasta) : [];
                o.dataset.choque = ch.length ? "Ya tiene el viaje #" + ch[0].viaje + " (" + ch[0].desde + "–" + ch[0].hasta + ", " + ch[0].destino + ")" : "";
                o.textContent = o.dataset.nombre + " · " + o.dataset.detalle + (o.dataset.bloqueo ? " — " + o.dataset.bloqueo : (o.dataset.choque ? " — ocupado en ese horario" : (marcados.length ? " — libre" : "")));
            });
            Array.prototype.forEach.call(selVe.options, function (o) {
                if (!o.value) return;
                var ch = marcados.length ? choca(o, desde, hasta) : [];
                var cap = +o.dataset.cap;
                o.dataset.choque = ch.length ? "Ya está en el viaje #" + ch[0].viaje + " (" + ch[0].desde + "–" + ch[0].hasta + ")" : "";
                o.dataset.chico = personas > cap ? "1" : "";
                o.textContent = o.dataset.nombre + " · " + o.dataset.detalle + (personas > cap ? " — no alcanza" : (o.dataset.bloqueo ? " — " + o.dataset.bloqueo : (o.dataset.choque ? " — ocupado en ese horario" : (marcados.length ? " — libre" : ""))));
                o.disabled = personas > cap;
            });
            if (!marcados.length) {
                resumen.textContent = "Marcá los pedidos que van juntos.";
                avisos.innerHTML = ""; forzar.hidden = true; boton.disabled = true; boton.textContent = "Asignar";
                return;
            }
            resumen.innerHTML = "<strong>" + marcados.length + " pedido" + (marcados.length > 1 ? "s" : "") + " · " + personas +
                " persona" + (personas !== 1 ? "s" : "") + "</strong> · de " + hhmm(desde) + " a " + hhmm(hasta);
            // propuesta: chofer libre (el primero ya viene ordenado por menos salidas) y el vehículo más chico que alcanza
            if (!elegidoAMano.ch) {
                var libre = Array.prototype.find.call(selCh.options, function (o) { return o.value && !o.dataset.bloqueo && !o.dataset.choque; });
                selCh.value = libre ? libre.value : "";
            }
            if (!elegidoAMano.ve || (selVe.selectedOptions[0] && selVe.selectedOptions[0].disabled)) {
                var fijo = selCh.selectedOptions[0] && selCh.selectedOptions[0].dataset.fijo;
                var opciones = Array.prototype.filter.call(selVe.options, function (o) { return o.value && !o.disabled && !o.dataset.bloqueo && !o.dataset.choque; });
                var v = opciones.find(function (o) { return o.value === fijo; }) || opciones[0];
                selVe.value = v ? v.value : "";
                if (elegidoAMano.ve) elegidoAMano.ve = false;
            }
            var och = selCh.selectedOptions[0], ove = selVe.selectedOptions[0];
            if (och && och.value) {
                if (och.dataset.bloqueo) lista.push({nivel: "alto", t: och.dataset.nombre + ": " + och.dataset.bloqueo + "."});
                if (och.dataset.choque) lista.push({nivel: "aviso", t: och.dataset.nombre + ": " + och.dataset.choque + "."});
            }
            if (ove && ove.value) {
                if (ove.dataset.bloqueo) lista.push({nivel: "alto", t: ove.dataset.nombre + ": " + ove.dataset.bloqueo + "."});
                if (ove.dataset.choque) lista.push({nivel: "aviso", t: ove.dataset.nombre + ": " + ove.dataset.choque + "."});
            } else {
                lista.push({nivel: "info", t: "Sin vehículo: el pedido queda con chofer y el vehículo se elige después."});
            }
            if (maxPlazas && personas > maxPlazas) lista.unshift({nivel: "alto", t: "Son " + personas + " personas y el vehículo más grande tiene " + maxPlazas + " plazas: marcá menos pedidos."});
            if (!och || !och.value) lista.unshift({nivel: "aviso", t: "No hay chofer libre en ese horario: elegí uno y aceptá el aviso, o marcá otros pedidos."});
            avisos.innerHTML = "";
            lista.forEach(function (a) {
                var p = document.createElement("p"); p.className = "mesa-aviso mesa-aviso--" + a.nivel; p.textContent = a.t; avisos.appendChild(p);
            });
            var hayAviso = lista.some(function (a) { return a.nivel === "alto" || a.nivel === "aviso"; }) && och && och.value;
            forzar.hidden = !hayAviso;
            if (!hayAviso) forzar.querySelector("input").checked = false;
            boton.disabled = !(och && och.value) || (maxPlazas && personas > maxPlazas);
            boton.textContent = "Asignar " + (marcados.length > 1 ? "los " + marcados.length + " pedidos" : "el pedido") + (och && och.value ? " a " + och.dataset.nombre : "");
        }
        form.addEventListener("submit", function (e) {
            if (!forzar.hidden && !forzar.querySelector("input").checked) {
                e.preventDefault();
                forzar.classList.add("mesa-asignar__forzar--pide");
                forzar.querySelector("input").focus();
            }
        });
        actualizar();
    }
    function arrancar() { document.querySelectorAll("[data-mesa-dia]").forEach(iniciar); }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", arrancar); else arrancar();
})();
