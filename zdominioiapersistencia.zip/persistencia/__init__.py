"""Persistencia: conexión, migraciones numeradas (ADR-0003) y repositorios."""
