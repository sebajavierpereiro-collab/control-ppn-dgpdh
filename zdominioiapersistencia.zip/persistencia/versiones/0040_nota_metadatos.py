"""Propuesta 1: campos propios por tipo documental (organismo requerido, persona detenida, plazo, juzgado…), un valor por
nota y campo, propuesto por el sistema y confirmado por una persona."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS nota_metadatos (
        nota_id INTEGER NOT NULL, campo TEXT NOT NULL, valor TEXT, origen TEXT NOT NULL,   -- CONFIRMADO | MANUAL
        quien TEXT, fecha TEXT NOT NULL, PRIMARY KEY (nota_id, campo))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_nota_metadatos_campo ON nota_metadatos(campo, valor)")
