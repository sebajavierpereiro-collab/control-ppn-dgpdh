"""Propuesta 64 (viajes 11): proveedores (aseguradora, taller, estación…) con baja lógica; en cada control de un vehículo, el
proveedor, la póliza u orden y una persona responsable; días de aviso por tipo de control y registro de los avisos internos
ya enviados (para no repetirlos). Solo agrega tablas y columnas."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS proveedores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        tipo TEXT NOT NULL DEFAULT 'OTRO',
        cuit TEXT, telefono TEXT, correo TEXT, observaciones TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        creado_por TEXT, creado_en TEXT NOT NULL,
        baja_por TEXT, baja_en TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS controles_dias_aviso (
        tipo TEXT PRIMARY KEY,
        dias INTEGER NOT NULL,
        actualizado_por TEXT, actualizado_en TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS controles_avisos_enviados (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        control_id INTEGER NOT NULL,
        usuario_id INTEGER NOT NULL,
        nivel TEXT NOT NULL,
        enviado_en TEXT NOT NULL,
        UNIQUE (control_id, usuario_id, nivel))""")
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'vehiculo_controles'").fetchone():
        existentes = {f[1] for f in con.execute("PRAGMA table_info(vehiculo_controles)")}
        for col in ("proveedor_id INTEGER", "referencia TEXT", "responsable_id INTEGER"):
            if col.split()[0] not in existentes:
                con.execute(f"ALTER TABLE vehiculo_controles ADD COLUMN {col}")
