"""Propuesta 69 (viajes 16): calendario único de feriados y días no laborables. Nada se borra: baja lógica con motivo."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS feriados (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT NOT NULL UNIQUE,
        motivo TEXT NOT NULL,
        tipo TEXT NOT NULL DEFAULT 'NACIONAL',          -- NACIONAL | PUENTE | ASUETO | FERIA
        activo INTEGER NOT NULL DEFAULT 1,
        origen TEXT,                                     -- manual | ics
        cargado_por TEXT NOT NULL, cargado_en TEXT NOT NULL,
        actualizado_por TEXT, actualizado_en TEXT,
        baja_por TEXT, baja_en TEXT, motivo_baja TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_feriados_activos ON feriados(activo, fecha)")
