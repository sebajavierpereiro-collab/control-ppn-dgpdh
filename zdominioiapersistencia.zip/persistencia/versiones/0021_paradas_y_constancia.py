"""Propuestas 72 y 73 (viajes 19 y 20): hora de llegada, ingreso y salida de cada parada (registro manual, sin GPS) y
constancia de que el viaje se hizo (quién viajó o el chofer). Solo agrega columnas a `viajes`."""
import sqlite3
from datetime import date

COLUMNAS = ("llegada_unidad TEXT", "ingreso_unidad TEXT", "salida_unidad TEXT", "tiempos_por TEXT", "tiempos_en TEXT",
            "constancia_origen TEXT", "constancia_por TEXT", "constancia_en TEXT")


def aplicar(con: sqlite3.Connection) -> None:
    hay = con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'viajes'").fetchone()
    if hay:  # la tabla la crea database.inicializar_db() antes de las migraciones
        existentes = {f[1] for f in con.execute("PRAGMA table_info(viajes)")}
        for col in COLUMNAS:
            if col.split()[0] not in existentes:
                con.execute(f"ALTER TABLE viajes ADD COLUMN {col}")
        con.execute("CREATE INDEX IF NOT EXISTS ix_viajes_constancia ON viajes(estado, fecha, constancia_en)")
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'ajustes'").fetchone():
        # los viajes anteriores a esta versión no tienen constancia: no se los marca como «sin constancia»
        con.execute("INSERT OR IGNORE INTO ajustes (clave, valor) VALUES ('viajes_constancia_desde', ?)", (date.today().isoformat(),))
