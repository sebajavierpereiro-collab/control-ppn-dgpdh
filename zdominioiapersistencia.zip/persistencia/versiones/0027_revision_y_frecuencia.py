"""Propuestas 86 y 88 (viajes 33 y 35): balance trimestral de metas con respuesta de la Dirección (versionado: cada
cambio es una versión nueva) y frecuencia mínima de visita y nivel de riesgo de cada unidad a cargo de un equipo.
La frecuencia va en tabla aparte porque `equipo_unidades` se rearma cada vez que se editan las unidades del equipo."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS metas_revisiones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, trimestre INTEGER NOT NULL, version INTEGER NOT NULL,
        color TEXT NOT NULL, color_sugerido TEXT, comentario TEXT NOT NULL, obstaculos TEXT, acciones TEXT,
        autor TEXT NOT NULL, autor_id INTEGER, creado_en TEXT NOT NULL,
        UNIQUE (equipo_id, anio, trimestre, version))""")
    con.execute("""CREATE TABLE IF NOT EXISTS metas_revisiones_respuestas (
        id INTEGER PRIMARY KEY AUTOINCREMENT, equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, trimestre INTEGER NOT NULL,
        texto TEXT NOT NULL, autor TEXT NOT NULL, autor_id INTEGER, creado_en TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS unidad_frecuencias (
        equipo_id INTEGER NOT NULL, unidad_id INTEGER NOT NULL,
        frecuencia_dias INTEGER, riesgo TEXT,                 -- riesgo: BAJO | MEDIO | ALTO (manual)
        actualizado_por TEXT, actualizado_en TEXT,
        PRIMARY KEY (equipo_id, unidad_id))""")
