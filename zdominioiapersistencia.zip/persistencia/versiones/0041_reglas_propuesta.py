"""Propuesta 2: reglas «si pasa esto, proponé aquello», editables por la Dirección. Lo que proponen va a sugerencias_ia
(agente REGLA), así se acepta o se descarta como cualquier otra sugerencia y se mide en el tablero de agentes."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS reglas_propuesta (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL,
        disparador TEXT NOT NULL,                  -- SUBIDA | ENVIO | FIRMA
        condicion TEXT NOT NULL, condicion_valor TEXT NOT NULL,   -- texto_contiene | tipo_documental | unidad | equipo
        accion TEXT NOT NULL, accion_valor TEXT NOT NULL,         -- prioridad | aviso_equipo | plazo_dias | etiqueta
        activa INTEGER NOT NULL DEFAULT 1, creada_por TEXT, creada_en TEXT NOT NULL, actualizada_por TEXT, actualizada_en TEXT)""")
