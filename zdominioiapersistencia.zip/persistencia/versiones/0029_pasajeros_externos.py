"""Pedido del usuario (Modificación 4): pasajeros externos registrados (estudiantes de prácticas, personal externo, invitados)
con un catálogo editable de categorías. Nada se borra: baja lógica. No son personas detenidas ni se cruzan con esa base, y
nunca cuentan para las metas de ningún equipo."""
import sqlite3
from datetime import datetime, timezone

CATEGORIAS = ("Estudiante práctico Trabajo Social UBA", "Estudiante práctico Derecho", "Personal externo", "Invitado")


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS pasajero_categorias (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL UNIQUE COLLATE NOCASE, orden INTEGER NOT NULL DEFAULT 0,
        activo INTEGER NOT NULL DEFAULT 1, creado_por TEXT NOT NULL, creado_en TEXT NOT NULL, baja_por TEXT, baja_en TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS pasajeros_externos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL, apellido TEXT NOT NULL, documento TEXT NOT NULL UNIQUE,
        categoria_id INTEGER NOT NULL REFERENCES pasajero_categorias(id), institucion TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        creado_por TEXT NOT NULL, creado_en TEXT NOT NULL, actualizado_por TEXT, actualizado_en TEXT,
        baja_por TEXT, baja_en TEXT, motivo_baja TEXT)""")
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'viaje_participantes'").fetchone():
        if "pasajero_externo_id" not in {f[1] for f in con.execute("PRAGMA table_info(viaje_participantes)")}:
            con.execute("ALTER TABLE viaje_participantes ADD COLUMN pasajero_externo_id INTEGER")
    if not con.execute("SELECT 1 FROM pasajero_categorias LIMIT 1").fetchone():
        ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
        con.executemany("INSERT INTO pasajero_categorias (nombre, orden, creado_por, creado_en) VALUES (?, ?, 'Sistema', ?)",
                        [(n, i, ahora) for i, n in enumerate(CATEGORIAS, 1)])
