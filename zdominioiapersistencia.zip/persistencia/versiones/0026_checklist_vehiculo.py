"""Propuesta 60 (viajes 7): control del vehículo antes de salir. Ítems configurables (baja lógica) y resultado por salida.
Un ítem «no apto» genera una novedad mecánica (la crea la capa de arriba con el circuito de novedades que ya existe)."""
import sqlite3
from datetime import datetime, timezone

ITEMS = ("Luces y balizas", "Cubiertas y rueda de auxilio", "Matafuego", "Documentación (cédula, seguro y VTV)",
         "Niveles de aceite y agua", "Frenos", "Cinturones de seguridad")


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS checklist_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT, texto TEXT NOT NULL, orden INTEGER NOT NULL DEFAULT 0, activo INTEGER NOT NULL DEFAULT 1,
        cargado_por TEXT NOT NULL, cargado_en TEXT NOT NULL, baja_por TEXT, baja_en TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS checklist_controles (
        id INTEGER PRIMARY KEY AUTOINCREMENT, desplazamiento_id INTEGER NOT NULL, vehiculo_id INTEGER,
        item_id INTEGER NOT NULL, item_texto TEXT NOT NULL,
        resultado TEXT NOT NULL,                 -- OK | OBSERVACION | NO_APTO
        observacion TEXT, novedad_id INTEGER,
        registrado_por TEXT NOT NULL, registrado_en TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_checklist_desp ON checklist_controles(desplazamiento_id)")
    if not con.execute("SELECT 1 FROM checklist_items LIMIT 1").fetchone():
        ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
        con.executemany("INSERT INTO checklist_items (texto, orden, cargado_por, cargado_en) VALUES (?, ?, 'Sistema', ?)",
                        [(t, i, ahora) for i, t in enumerate(ITEMS, 1)])
