"""Línea de base: el esquema histórico lo crea database.inicializar_db() (tablas y ALTER TABLE al arrancar).
Esta migración solo marca el punto de partida; de acá en adelante cada cambio de esquema es una migración nueva."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("SELECT 1")
