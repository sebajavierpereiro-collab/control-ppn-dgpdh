"""Propuesta 33: cada unificación de fichas de personas detenidas guarda cómo estaban las dos fichas antes y cómo quedó la
conservada, para poder separarlas después sin perder nada («Separar fichas»)."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS detenidos_unificaciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mantener_id INTEGER NOT NULL, absorbida_id INTEGER NOT NULL,
        antes_mantener TEXT, antes_absorbida TEXT, despues_mantener TEXT,
        origen TEXT NOT NULL DEFAULT 'SISTEMA',          -- SISTEMA (guardada al unificar) | RECONSTRUIDA (desde detenidos_cambios)
        usuario TEXT, fecha TEXT NOT NULL,
        separada_en TEXT, separada_por TEXT, motivo_separacion TEXT, resultado_separacion TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_det_unif_mantener ON detenidos_unificaciones(mantener_id)")
    con.execute("CREATE INDEX IF NOT EXISTS ix_det_unif_absorbida ON detenidos_unificaciones(absorbida_id)")
