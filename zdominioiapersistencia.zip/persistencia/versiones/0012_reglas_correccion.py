"""Propuesta 16: cuenta de aceptaciones y rechazos por regla de corrección (regla de LanguageTool, reemplazo del diccionario o
modelo de IA), con el motivo opcional del rechazo, y el estado de cada regla (la Dirección decide desactivarla)."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS correccion_reglas_uso (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nota_id INTEGER, ubicacion TEXT, regla TEXT NOT NULL,
        decision TEXT NOT NULL,              -- aceptar | modificar | rechazar
        motivo TEXT,                         -- sentido | nombre_propio | formula | no_era_error | NULL
        usuario TEXT, fecha TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_reglas_uso_regla ON correccion_reglas_uso(regla, decision)")
    con.execute("""CREATE TABLE IF NOT EXISTS correccion_reglas_estado (
        regla TEXT PRIMARY KEY, estado TEXT NOT NULL,       -- DESACTIVADA | ACTIVA (reactivada)
        motivo TEXT, decidido_por TEXT, decidido_en TEXT NOT NULL)""")
