"""Propuesta 82 (viajes 29): una sola meta de visitas por equipo.

Hasta ahora había dos: `metas_viajes` (mínimo por trimestre, tablero de Dirección) y `metas_anuales` con el indicador
`visitas_equipo` (panel de Metas). Regla conservadora (a confirmar por la Dirección): manda la meta anual de Metas.
  * Si el equipo no tenía meta anual de visitas, se copia la del tablero (suma de los trimestres) y su reparto.
  * Si las dos coinciden, se conserva el reparto trimestral del tablero.
  * Si difieren, se deja la anual y la diferencia queda en `metas_unificacion` para que la Dirección elija.
`metas_viajes` no se borra ni se modifica: queda de solo lectura, como respaldo.
"""
import sqlite3
from datetime import datetime, timezone

QUIEN = "Unificación de metas (migración 0023)"


def _hay(con: sqlite3.Connection, tabla: str) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone() is not None


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS metas_trimestres (
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, indicador TEXT NOT NULL, trimestre INTEGER NOT NULL,
        meta INTEGER NOT NULL DEFAULT 0, actualizado_por TEXT, actualizado_en TEXT,
        PRIMARY KEY (equipo_id, anio, indicador, trimestre))""")
    con.execute("""CREATE TABLE IF NOT EXISTS metas_unificacion (
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL,
        meta_anual INTEGER NOT NULL, meta_tablero INTEGER NOT NULL, trimestres_tablero TEXT NOT NULL,
        detectado_en TEXT NOT NULL,
        resuelto TEXT, resuelto_por TEXT, resuelto_en TEXT,      -- ANUAL | TABLERO | NUEVA (la Dirección fijó otra)
        PRIMARY KEY (equipo_id, anio))""")
    if not (_hay(con, "metas_viajes") and _hay(con, "metas_anuales")):
        return
    ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
    viejas: dict[tuple[int, int], dict[int, int]] = {}
    for eid, anio, t, minimo in con.execute("SELECT equipo_id, anio, trimestre, minimo FROM metas_viajes"):
        viejas.setdefault((int(eid), int(anio)), {})[int(t)] = int(minimo or 0)
    for (eid, anio), tri in sorted(viejas.items()):
        total = sum(tri.values())
        if not total:
            continue
        actual = con.execute("SELECT meta FROM metas_anuales WHERE equipo_id = ? AND anio = ? AND indicador = 'visitas_equipo'",
                             (eid, anio)).fetchone()
        reparto = [tri.get(t, 0) for t in (1, 2, 3, 4)]
        if actual is None:
            con.execute("""INSERT INTO metas_anuales (equipo_id, anio, indicador, meta, actualizado_por, actualizado_en)
                           VALUES (?, ?, 'visitas_equipo', ?, ?, ?)""", (eid, anio, total, QUIEN, ahora))
        elif int(actual[0]) != total:
            con.execute("""INSERT OR IGNORE INTO metas_unificacion (equipo_id, anio, meta_anual, meta_tablero, trimestres_tablero, detectado_en)
                           VALUES (?, ?, ?, ?, ?, ?)""", (eid, anio, int(actual[0]), total, ",".join(map(str, reparto)), ahora))
            continue
        for t, meta in enumerate(reparto, 1):
            con.execute("""INSERT OR IGNORE INTO metas_trimestres (equipo_id, anio, indicador, trimestre, meta, actualizado_por, actualizado_en)
                           VALUES (?, ?, 'visitas_equipo', ?, ?, ?, ?)""", (eid, anio, t, meta, QUIEN, ahora))
