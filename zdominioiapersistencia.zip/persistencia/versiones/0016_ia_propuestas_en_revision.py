"""Modificación 7: una propuesta de la IA sobre fichas de detenidos puede quedar «En revisión» (sin cerrarse) mientras se
recaba información: quién la dejó así, cuándo y por qué."""
import sqlite3

COLUMNAS = ("en_revision_por TEXT", "en_revision_en TEXT", "en_revision_nota TEXT")


def aplicar(con: sqlite3.Connection) -> None:
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'detenidos_ia_propuestas'").fetchone():
        return
    existentes = {f[1] for f in con.execute("PRAGMA table_info(detenidos_ia_propuestas)")}
    for col in COLUMNAS:
        if col.split()[0] not in existentes:
            con.execute(f"ALTER TABLE detenidos_ia_propuestas ADD COLUMN {col}")
