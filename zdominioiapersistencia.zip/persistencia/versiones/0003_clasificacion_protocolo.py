"""Reforma del 14/11/2026: clasificación obligatoria al mandar a la firma y protocolo interno de informes."""
import sqlite3

COLUMNAS_NOTAS = ("clasif_subtipo TEXT", "clasif_alcance TEXT", "confidencialidad TEXT", "clasif_expediente TEXT",
                  "clasif_destinatario TEXT", "clasificado_por TEXT", "clasificado_en TEXT", "protocolo_numero TEXT")


def aplicar(con: sqlite3.Connection) -> None:
    hay_notas = con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'notas'").fetchone()
    if hay_notas:  # la tabla la crea database.inicializar_db() antes de las migraciones
        existentes = {f[1] for f in con.execute("PRAGMA table_info(notas)")}
        for col in COLUMNAS_NOTAS:
            if col.split()[0] not in existentes:
                con.execute(f"ALTER TABLE notas ADD COLUMN {col}")
        con.execute("CREATE INDEX IF NOT EXISTS ix_notas_protocolo ON notas(protocolo_numero)")
    con.execute("""CREATE TABLE IF NOT EXISTS protocolo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero TEXT NOT NULL UNIQUE,
        sigla TEXT NOT NULL, area TEXT NOT NULL, anio INTEGER NOT NULL, correlativo INTEGER NOT NULL,
        nota_id INTEGER,
        estado TEXT NOT NULL DEFAULT 'ASIGNADO',        -- ASIGNADO | ANULADO (nunca se reutiliza)
        motivo_anulacion TEXT, anulado_por TEXT, anulado_en TEXT,
        asignado_por TEXT NOT NULL, asignado_por_id INTEGER, asignado_en TEXT NOT NULL,
        UNIQUE (sigla, area, anio, correlativo))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_protocolo_nota ON protocolo(nota_id)")
