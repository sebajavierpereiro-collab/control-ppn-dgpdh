"""Propuesta 80 (viajes 27): terminar de cumplir «no se borra nada» en Autos PPN. Las licencias de choferes y los vínculos de
equipos del historial pasan a baja lógica (quién, cuándo y por qué) y se pueden recuperar. Solo agrega columnas."""
import sqlite3

COLUMNAS = {
    "chofer_licencias": ("anulada_en TEXT", "anulada_por TEXT", "motivo_anulacion TEXT"),
    "equipos_alias": ("anulado_en TEXT", "anulado_por TEXT"),
}


def aplicar(con: sqlite3.Connection) -> None:
    for tabla, columnas in COLUMNAS.items():
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone():
            continue  # la crea database.inicializar_db() antes de las migraciones
        existentes = {f[1] for f in con.execute(f"PRAGMA table_info({tabla})")}
        for col in columnas:
            if col.split()[0] not in existentes:
                con.execute(f"ALTER TABLE {tabla} ADD COLUMN {col}")
