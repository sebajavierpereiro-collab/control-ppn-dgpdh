"""Propuestas 57 y 58 (viajes 4 y 5): horarios de ingreso estructurados por unidad (versionados con «vigente desde», nunca se
pisan) y etiquetas de requisitos/habilidades para viajes, vehículos y choferes. Solo agrega."""
import sqlite3


def _columnas(con: sqlite3.Connection, tabla: str, columnas: tuple[str, ...]) -> None:
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone():
        return
    existentes = {f[1] for f in con.execute(f"PRAGMA table_info({tabla})")}
    for col in columnas:
        if col.split()[0] not in existentes:
            con.execute(f"ALTER TABLE {tabla} ADD COLUMN {col}")


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS unidad_ventanas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        unidad_id INTEGER NOT NULL,
        dia_semana INTEGER NOT NULL,                 -- 0 = lunes … 6 = domingo
        desde TEXT NOT NULL, hasta TEXT NOT NULL,    -- HH:MM
        tipo TEXT NOT NULL DEFAULT 'AUDIENCIAS',     -- AUDIENCIAS | VISITA | PROFESIONALES
        vigente_desde TEXT NOT NULL,
        observacion TEXT,
        activo INTEGER NOT NULL DEFAULT 1,
        cargado_por TEXT NOT NULL, cargado_en TEXT NOT NULL,
        baja_por TEXT, baja_en TEXT, motivo_baja TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_unidad_ventanas ON unidad_ventanas(unidad_id, activo)")
    _columnas(con, "viajes", ("requisitos TEXT",))
    _columnas(con, "vehiculos", ("habilidades TEXT",))
    _columnas(con, "choferes", ("habilidades TEXT",))
