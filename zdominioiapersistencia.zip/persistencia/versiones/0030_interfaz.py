"""Interfaz (propuestas 98–164): preferencias de pantalla por persona, sugerencias de la banda «Beta» y borradores guardados.
Solo agrega tablas; no toca las existentes."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    # Una fila por persona con un JSON de preferencias (atajos, tema, densidad, columnas, avisos ya vistos…).
    con.execute("""CREATE TABLE IF NOT EXISTS ui_preferencias (
        usuario_id INTEGER PRIMARY KEY, datos TEXT NOT NULL DEFAULT '{}', actualizado_en TEXT NOT NULL)""")
    # Propuesta 106: «Contanos qué te trabó». Guarda la pantalla y el rol; no sale nada del servidor.
    con.execute("""CREATE TABLE IF NOT EXISTS ui_sugerencias (
        id INTEGER PRIMARY KEY AUTOINCREMENT, usuario_id INTEGER, usuario TEXT NOT NULL, rol TEXT, url TEXT,
        texto TEXT NOT NULL, creada_en TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'NUEVA', atendida_por TEXT, atendida_en TEXT)""")
    # Propuesta 122: borradores de formularios largos. No se borran: se marcan como usados o descartados.
    con.execute("""CREATE TABLE IF NOT EXISTS ui_borradores (
        usuario_id INTEGER NOT NULL, clave TEXT NOT NULL, datos TEXT NOT NULL, guardado_en TEXT NOT NULL,
        descartado_en TEXT, PRIMARY KEY (usuario_id, clave))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_ui_sugerencias_estado ON ui_sugerencias(estado)")
