"""Propuestas 20 y 27: en cada llamada a la IA local, la ventana de contexto, el tamaño estimado del pedido, la versión exacta
del modelo (digest), la versión del prompt y los parámetros. Más el último digest visto de cada modelo, para avisar cuando cambia."""
import sqlite3

COLUMNAS = ("num_ctx INTEGER", "tokens_estimados INTEGER", "uso_ctx REAL", "aviso_ctx TEXT", "modelo_digest TEXT",
            "version_prompt TEXT", "parametros TEXT")


def aplicar(con: sqlite3.Connection) -> None:
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'ia_registro'").fetchone():
        existentes = {f[1] for f in con.execute("PRAGMA table_info(ia_registro)")}
        for col in COLUMNAS:
            if col.split()[0] not in existentes:
                con.execute(f"ALTER TABLE ia_registro ADD COLUMN {col}")
    con.execute("""CREATE TABLE IF NOT EXISTS ia_modelos_digest (
        modelo TEXT PRIMARY KEY, digest TEXT NOT NULL, visto_en TEXT NOT NULL,
        digest_anterior TEXT, cambio_en TEXT)""")
