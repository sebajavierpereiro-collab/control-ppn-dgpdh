"""Propuesta 39: vínculo entre una nota y la ficha de una persona detenida, propuesto por el sistema y confirmado (o
descartado) por una persona."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS nota_persona (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nota_id INTEGER NOT NULL, detenido_id INTEGER NOT NULL,
        estado TEXT NOT NULL,                    -- CONFIRMADO | DESCARTADO
        puntaje INTEGER, motivo TEXT, usuario TEXT, usuario_id INTEGER, fecha TEXT NOT NULL,
        UNIQUE (nota_id, detenido_id))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_nota_persona_det ON nota_persona(detenido_id, estado)")
