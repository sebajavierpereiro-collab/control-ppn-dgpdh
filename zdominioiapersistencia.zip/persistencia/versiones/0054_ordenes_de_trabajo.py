"""Propuesta 65 (viajes 12): órdenes de trabajo de taller vinculadas a una o varias novedades mecánicas, con etapas
Nueva / En curso / Hecha / Cancelada, taller, presupuesto, fecha prometida, costo final y repuestos. Una orden cancelada se
conserva. Solo tablas nuevas."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS ordenes_trabajo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehiculo_id INTEGER NOT NULL,
        etapa TEXT NOT NULL DEFAULT 'NUEVA',
        proveedor_id INTEGER,
        taller TEXT,
        descripcion TEXT NOT NULL,
        presupuesto REAL,
        fecha_prometida TEXT,
        costo_final REAL,
        repuestos TEXT,
        motivo_cancelacion TEXT,
        creado_por TEXT, creado_en TEXT NOT NULL,
        actualizado_en TEXT, iniciada_en TEXT, cerrada_en TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_ordenes_trabajo_vehiculo ON ordenes_trabajo (vehiculo_id, etapa)")
    con.execute("""CREATE TABLE IF NOT EXISTS orden_trabajo_novedades (
        orden_id INTEGER NOT NULL,
        registro_id INTEGER NOT NULL,
        PRIMARY KEY (orden_id, registro_id))""")
    con.execute("""CREATE TABLE IF NOT EXISTS orden_trabajo_etapas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        orden_id INTEGER NOT NULL,
        etapa TEXT NOT NULL,
        nota TEXT, usuario TEXT, fecha TEXT NOT NULL)""")
