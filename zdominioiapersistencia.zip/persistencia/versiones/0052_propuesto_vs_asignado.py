"""Propuesta 77 (viajes 24): se guarda la última propuesta del planificador para cada pedido con chofer (mientras está sin
asignar), para compararla al cerrar la semana con lo que se asignó. Tabla nueva; no toca las existentes."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS planificador_propuesto (
        viaje_id INTEGER PRIMARY KEY,
        lunes TEXT NOT NULL,
        fecha TEXT NOT NULL,
        clave TEXT NOT NULL,
        chofer_id INTEGER,
        vehiculo_id INTEGER,
        guardado_en TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_planificador_propuesto_lunes ON planificador_propuesto (lunes)")
