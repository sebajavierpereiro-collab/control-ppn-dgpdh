"""Pedido del usuario (14/11): lo que Metas toma de los viajes se calcula una vez por día (o a pedido) y se guarda como foto,
en vez de recalcularse en cada pantalla. Una fila por año y equipo con lo de los viajes (por persona, mes e indicador) y la
calidad de las visitas (propuesta 89). Es un dato derivado: se regenera, no lo carga nadie."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS metas_foto (
        anio INTEGER NOT NULL, equipo_id INTEGER NOT NULL,
        generado_en TEXT NOT NULL,            -- UTC ISO
        generado_por TEXT,                    -- «Sistema» (tarea diaria) o la persona que tocó «Actualizar ahora»
        datos TEXT NOT NULL,                  -- JSON: persona, equipo, calidad, calidad_dir
        PRIMARY KEY (anio, equipo_id))""")
