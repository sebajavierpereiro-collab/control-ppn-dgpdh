"""Propuesta 11: índice de búsqueda por raíces de palabras (castellano), aparte del de siempre; se llena con lo ya indexado."""
import sqlite3

from dgpdh.dominio.raices import raices


def aplicar(con: sqlite3.Connection) -> None:
    try:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS notas_raices USING fts5(contenido)")
    except sqlite3.OperationalError:
        return  # SQLite sin FTS5: la búsqueda sigue como siempre
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'notas_texto'").fetchone():
        for nota_id, contenido in con.execute("SELECT nota_id, contenido FROM notas_texto").fetchall():
            con.execute("INSERT INTO notas_raices (rowid, contenido) VALUES (?, ?)", (nota_id, raices(contenido)))
