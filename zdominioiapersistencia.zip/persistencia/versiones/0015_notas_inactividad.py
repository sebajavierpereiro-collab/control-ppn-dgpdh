"""Modificación 2: último aviso de seguimiento por inactividad de cada documento rechazado."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS notas_inactividad (
        nota_id INTEGER PRIMARY KEY, ultimo_aviso TEXT NOT NULL, avisos INTEGER NOT NULL DEFAULT 1)""")
