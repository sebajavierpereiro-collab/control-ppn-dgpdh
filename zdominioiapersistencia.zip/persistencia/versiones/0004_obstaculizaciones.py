"""Módulo «Registro de Obstaculizaciones» (14/11/2026): tipos (catálogo editable), registros, intervinientes, vínculos y adjuntos.
Nada se borra: los tipos se dan de baja, los registros se anulan con motivo y los adjuntos se desactivan."""
import sqlite3
from datetime import datetime, timezone

TIPOS_INICIALES = (
    "Demora injustificada en el ingreso al establecimiento",
    "Prohibición o restricción de entrevistas confidenciales",
    "Negativa de entrega de documentación o registros",
    "Requisa vejatoria o irregular a agentes/equipos",
    "Restricción de circulación en pabellones",
    "Falta de respuesta o colaboración de la autoridad responsable",
)


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizacion_tipos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL UNIQUE COLLATE NOCASE, descripcion TEXT,
        orden INTEGER NOT NULL DEFAULT 0, activo INTEGER NOT NULL DEFAULT 1,
        creado_por TEXT NOT NULL, creado_en TEXT NOT NULL, actualizado_por TEXT, actualizado_en TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizaciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero TEXT NOT NULL UNIQUE, anio INTEGER NOT NULL, correlativo INTEGER NOT NULL,
        fecha_hecho TEXT NOT NULL, hora_hecho TEXT NOT NULL,
        unidad_id INTEGER, lugar_otro TEXT, sector TEXT,
        tipo_id INTEGER NOT NULL REFERENCES obstaculizacion_tipos(id),
        equipo_id INTEGER, circuito TEXT,
        fuerza_id INTEGER, autoridad TEXT,
        descripcion TEXT NOT NULL,
        subsanado INTEGER NOT NULL, como_se_subsano TEXT, demora_minutos INTEGER,
        cargado_por_id INTEGER NOT NULL, cargado_por TEXT NOT NULL, creado_en TEXT NOT NULL,
        actualizado_por TEXT, actualizado_en TEXT,
        estado TEXT NOT NULL DEFAULT 'REGISTRADO', motivo_anulacion TEXT, anulado_por TEXT, anulado_en TEXT,
        informe_nota_id INTEGER,
        UNIQUE (anio, correlativo))""")
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizacion_tipos_extra (
        obstaculizacion_id INTEGER NOT NULL, tipo_id INTEGER NOT NULL, PRIMARY KEY (obstaculizacion_id, tipo_id))""")
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizacion_agentes (
        id INTEGER PRIMARY KEY AUTOINCREMENT, obstaculizacion_id INTEGER NOT NULL, usuario_id INTEGER, nombre TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizacion_vinculos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, obstaculizacion_id INTEGER NOT NULL,
        clase TEXT NOT NULL, ref_id INTEGER, ref_texto TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS obstaculizacion_adjuntos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, obstaculizacion_id INTEGER NOT NULL,
        nombre_original TEXT NOT NULL, ruta TEXT NOT NULL, tipo_mime TEXT, bytes INTEGER NOT NULL, sha256 TEXT NOT NULL,
        subido_por TEXT NOT NULL, subido_en TEXT NOT NULL, activo INTEGER NOT NULL DEFAULT 1)""")
    for i in ("CREATE INDEX IF NOT EXISTS ix_obst_fecha ON obstaculizaciones(fecha_hecho)",
              "CREATE INDEX IF NOT EXISTS ix_obst_unidad ON obstaculizaciones(unidad_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_tipo ON obstaculizaciones(tipo_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_equipo ON obstaculizaciones(equipo_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_cargado ON obstaculizaciones(cargado_por_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_agentes ON obstaculizacion_agentes(obstaculizacion_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_agentes_u ON obstaculizacion_agentes(usuario_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_vinculos ON obstaculizacion_vinculos(obstaculizacion_id)",
              "CREATE INDEX IF NOT EXISTS ix_obst_adjuntos ON obstaculizacion_adjuntos(obstaculizacion_id)"):
        con.execute(i)
    if not con.execute("SELECT 1 FROM obstaculizacion_tipos LIMIT 1").fetchone():
        ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
        con.executemany("INSERT INTO obstaculizacion_tipos (nombre, orden, creado_por, creado_en) VALUES (?, ?, 'Sistema', ?)",
                        [(n, i, ahora) for i, n in enumerate(TIPOS_INICIALES, 1)])
    hay_usuarios = con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'usuarios'").fetchone()
    if hay_usuarios and "consulta_obstaculizaciones" not in {f[1] for f in con.execute("PRAGMA table_info(usuarios)")}:
        con.execute("ALTER TABLE usuarios ADD COLUMN consulta_obstaculizaciones INTEGER NOT NULL DEFAULT 0")
