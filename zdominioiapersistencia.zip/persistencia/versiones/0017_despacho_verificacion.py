"""Propuesta 51: código de verificación (QR) de la copia de despacho y la huella del PDF ya sellado."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS despacho_verificacion (
        codigo TEXT PRIMARY KEY, nota_id INTEGER NOT NULL, sha256_pdf TEXT NOT NULL, creado_en TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_desp_verif_nota ON despacho_verificacion(nota_id)")
