-- Registro de auditoría único (hito 3, ADR-0008). Quién, qué, cuándo, antes y después.
-- `hash` encadena cada fila con la anterior; lo completa el sellado periódico (dgpdh.seguridad.auditoria.sellar),
-- así registrar nunca compite por la última fila con otra escritura.
CREATE TABLE IF NOT EXISTS auditoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TEXT NOT NULL,
    usuario_id INTEGER,
    usuario TEXT NOT NULL,
    accion TEXT NOT NULL,
    entidad TEXT NOT NULL,
    entidad_id TEXT,
    antes TEXT,
    despues TEXT,
    motivo TEXT,
    ip TEXT,
    origen TEXT,
    hash TEXT
);
CREATE INDEX IF NOT EXISTS ix_auditoria_entidad ON auditoria(entidad, entidad_id);
CREATE INDEX IF NOT EXISTS ix_auditoria_fecha ON auditoria(fecha);
CREATE INDEX IF NOT EXISTS ix_auditoria_usuario ON auditoria(usuario_id);
CREATE INDEX IF NOT EXISTS ix_auditoria_sin_sellar ON auditoria(id) WHERE hash IS NULL
