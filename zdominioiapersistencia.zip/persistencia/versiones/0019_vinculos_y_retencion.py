"""Propuestas 3 y 5 (último número del rango de Notas).

- 3: vínculos con tipo entre documentos (responde a, reitera a, amplía, anexo de, reemplaza a), hacia otra nota del sistema
  o hacia una referencia externa (número GDE). Propuestos por el sistema o cargados a mano; los confirma una persona.
- 5: series documentales (plazo de guarda y destino final) y marcas de retención. Nada se borra: lo vencido se marca, se
  autoriza y queda «retirado», con el documento intacto.
"""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS vinculos_documentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, origen_id INTEGER NOT NULL, destino_id INTEGER, referencia_externa TEXT,
        tipo TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'CONFIRMADO',     -- CONFIRMADO | DESCARTADO
        origen_dato TEXT, quien TEXT, fecha TEXT NOT NULL,
        UNIQUE (origen_id, destino_id, referencia_externa, tipo))""")
    con.execute("CREATE INDEX IF NOT EXISTS ix_vinculos_origen ON vinculos_documentos(origen_id)")
    con.execute("CREATE INDEX IF NOT EXISTS ix_vinculos_destino ON vinculos_documentos(destino_id)")
    con.execute("""CREATE TABLE IF NOT EXISTS series_documentales (
        tipo_documental TEXT PRIMARY KEY, plazo_anios INTEGER NOT NULL, destino TEXT NOT NULL,   -- PERMANENTE | BAJA
        actualizado_por TEXT, actualizado_en TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS retencion_documentos (
        nota_id INTEGER PRIMARY KEY, estado TEXT NOT NULL,                 -- VENCIDA | RETIRADA
        vence_en TEXT, marcado_en TEXT NOT NULL, autorizado_por TEXT, autorizado_en TEXT, motivo TEXT)""")
