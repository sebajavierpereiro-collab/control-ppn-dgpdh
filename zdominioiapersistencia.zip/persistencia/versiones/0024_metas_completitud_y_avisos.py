"""Propuestas 84 y 91 (viajes 31 y 38): registro de qué períodos cargó cada coordinación (aunque haya cargado ceros) y el
último estado de cada indicador, para avisar solo cuando PASA a «atrasada». Solo agrega tablas."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS metas_periodos_cargados (
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, periodo TEXT NOT NULL,      -- M01…M12 | T1…T4
        cargado_por TEXT, cargado_en TEXT,
        PRIMARY KEY (equipo_id, anio, periodo))""")
    con.execute("""CREATE TABLE IF NOT EXISTS metas_estado_aviso (
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, indicador TEXT NOT NULL,
        estado TEXT NOT NULL, desde TEXT NOT NULL, avisado_en TEXT,
        PRIMARY KEY (equipo_id, anio, indicador))""")
    hay = con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'metas_realizado'").fetchone()
    if hay:  # lo ya cargado cuenta como período cargado (con quién y cuándo de la última carga)
        con.execute("""INSERT OR IGNORE INTO metas_periodos_cargados (equipo_id, anio, periodo, cargado_por, cargado_en)
                       SELECT equipo_id, anio, periodo, MAX(cargado_por), MAX(cargado_en) FROM metas_realizado GROUP BY equipo_id, anio, periodo""")
