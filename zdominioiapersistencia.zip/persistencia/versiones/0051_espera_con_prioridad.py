"""Propuesta 75 (viajes 22): la lista de espera de un viaje tiene motivo tipificado (urgencia o rutina) y un orden que la
coordinación puede cambiar (queda registrado). Solo agrega columnas a viaje_espera."""
import sqlite3

COLUMNAS = ("motivo TEXT", "motivo_detalle TEXT", "orden_manual INTEGER", "orden_por TEXT", "orden_en TEXT")


def aplicar(con: sqlite3.Connection) -> None:
    if not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'viaje_espera'").fetchone():
        return  # la crea database.inicializar_db() antes de las migraciones
    existentes = {f[1] for f in con.execute("PRAGMA table_info(viaje_espera)")}
    for col in COLUMNAS:
        if col.split()[0] not in existentes:
            con.execute(f"ALTER TABLE viaje_espera ADD COLUMN {col}")
