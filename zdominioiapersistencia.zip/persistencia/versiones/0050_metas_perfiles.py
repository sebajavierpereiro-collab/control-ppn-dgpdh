"""Perfiles de indicadores de Metas por equipo (salud mental, salud médica; por defecto el general) y lo realizado por equipo
o por unidad/complejo de esos perfiles. Primera migración del rango nuevo 0050–0059 del área Viajes y Metas."""
import sqlite3


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS equipos_perfil_metas (
        equipo_id INTEGER PRIMARY KEY, perfil TEXT NOT NULL DEFAULT 'general', actualizado_por TEXT, actualizado_en TEXT)""")
    # dimension: '' = un número del equipo en el período; si no, la unidad o el complejo (unidad_id o el nombre escrito)
    con.execute("""CREATE TABLE IF NOT EXISTS metas_realizado_dim (
        equipo_id INTEGER NOT NULL, anio INTEGER NOT NULL, periodo TEXT NOT NULL, indicador TEXT NOT NULL,
        dimension TEXT NOT NULL DEFAULT '', etiqueta TEXT, cantidad INTEGER NOT NULL DEFAULT 0, origen TEXT,
        cargado_por TEXT, cargado_en TEXT,
        PRIMARY KEY (equipo_id, anio, periodo, indicador, dimension))""")
