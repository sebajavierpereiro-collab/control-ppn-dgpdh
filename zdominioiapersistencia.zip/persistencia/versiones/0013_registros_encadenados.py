"""Propuesta 50: sellos encadenados de historial_estados, detenidos_cambios, seguridad_eventos e ia_registro, y triggers de
«solo agregar» en las dos que ningún proceso del sistema modifica ni borra (seguridad_eventos e ia_registro)."""
import sqlite3

SOLO_AGREGAR = ("seguridad_eventos", "ia_registro")


def aplicar(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS cadenas_filas (
        tabla TEXT NOT NULL, fila_id INTEGER NOT NULL, hash TEXT NOT NULL, PRIMARY KEY (tabla, fila_id))""")
    con.execute("""CREATE TABLE IF NOT EXISTS cadenas_registro (
        tabla TEXT PRIMARY KEY, ultimo_id INTEGER NOT NULL, ultimo_hash TEXT NOT NULL, sellado_en TEXT NOT NULL,
        reiniciada_en TEXT, motivo_reinicio TEXT)""")
    for tabla in SOLO_AGREGAR:
        if not con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone():
            continue
        for evento in ("UPDATE", "DELETE"):
            con.execute(f"""CREATE TRIGGER IF NOT EXISTS {tabla}_solo_agregar_{evento.lower()} BEFORE {evento} ON {tabla}
                            BEGIN SELECT RAISE(ABORT, 'Este registro es inalterable: solo se agregan filas'); END""")
