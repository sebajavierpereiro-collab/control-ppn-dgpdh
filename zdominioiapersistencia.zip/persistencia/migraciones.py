"""Ejecutor de migraciones numeradas (ADR-0003).

Cada cambio de esquema es un archivo en `dgpdh/persistencia/versiones/`:
  NNNN_descripcion.sql   SQL plano (varias sentencias separadas por «;»)
  NNNN_descripcion.py    con una función `aplicar(con: sqlite3.Connection) -> None`
Se aplican en orden, cada una en su propia transacción, y quedan registradas en `schema_migrations` con su huella
(SHA-256 del archivo). Si un archivo ya aplicado cambia, se avisa y se frena: una migración aplicada no se edita, se agrega otra.
Antes de aplicar migraciones pendientes sobre una base con datos se llama a `antes_de_migrar` (el respaldo de la base).
"""
from __future__ import annotations

import hashlib
import importlib.util
import logging
import re
import sqlite3
import time
from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from dgpdh.errores import ErrorDGPDH

CARPETA = Path(__file__).resolve().parent / "versiones"
_PATRON = re.compile(r"^(\d{4})_([a-z0-9_]+)\.(sql|py)$")
Conectar = Callable[[], AbstractContextManager[sqlite3.Connection]]
log = logging.getLogger("dgpdh.migraciones")


class ErrorMigracion(ErrorDGPDH):
    codigo_http = 500


@dataclass(frozen=True)
class Migracion:
    numero: int
    nombre: str
    ruta: Path

    @property
    def huella(self) -> str:
        return hashlib.sha256(self.ruta.read_bytes()).hexdigest()

    def aplicar(self, con: sqlite3.Connection) -> None:
        if self.ruta.suffix == ".sql":
            for sentencia in _sentencias(self.ruta.read_text(encoding="utf-8")):
                con.execute(sentencia)
            return
        spec = importlib.util.spec_from_file_location(f"dgpdh_migracion_{self.numero:04d}", self.ruta)
        if spec is None or spec.loader is None:
            raise ErrorMigracion(f"No se pudo cargar la migración {self.ruta.name}.")
        modulo = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modulo)
        funcion = getattr(modulo, "aplicar", None)
        if not callable(funcion):
            raise ErrorMigracion(f"La migración {self.ruta.name} no tiene la función aplicar(con).")
        funcion(con)


@dataclass(frozen=True)
class Aplicada:
    numero: int
    nombre: str
    duracion_ms: int


def _sentencias(texto: str) -> Iterator[str]:
    sin_comentarios = "\n".join(linea for linea in texto.splitlines() if not linea.strip().startswith("--"))
    for parte in sin_comentarios.split(";"):
        if parte.strip():
            yield parte.strip()


def disponibles(carpeta: Path = CARPETA) -> list[Migracion]:
    vistas: dict[int, Migracion] = {}
    for ruta in sorted(carpeta.iterdir()):
        m = _PATRON.match(ruta.name)
        if not m:
            continue
        numero = int(m.group(1))
        if numero in vistas:
            raise ErrorMigracion(f"Hay dos migraciones con el número {numero:04d}: {vistas[numero].ruta.name} y {ruta.name}.")
        vistas[numero] = Migracion(numero, m.group(2), ruta)
    return [vistas[n] for n in sorted(vistas)]


def _asegurar_tabla(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS schema_migrations (
        numero INTEGER PRIMARY KEY, nombre TEXT NOT NULL, huella TEXT NOT NULL, aplicada_en TEXT NOT NULL, duracion_ms INTEGER NOT NULL)""")


def aplicadas(con: sqlite3.Connection) -> dict[int, str]:
    _asegurar_tabla(con)
    return {int(f[0]): str(f[1]) for f in con.execute("SELECT numero, huella FROM schema_migrations")}


def pendientes(conectar: Conectar, carpeta: Path = CARPETA) -> list[Migracion]:
    with conectar() as con:
        hechas = aplicadas(con)
    todas = disponibles(carpeta)
    for m in todas:
        if m.numero in hechas and hechas[m.numero] != m.huella:
            raise ErrorMigracion(f"La migración {m.ruta.name} cambió después de aplicada. No se editan: agregá una nueva.")
    return [m for m in todas if m.numero not in hechas]


def aplicar_pendientes(conectar: Conectar, *, antes_de_migrar: Callable[[], object] | None = None,
                       carpeta: Path = CARPETA) -> list[Aplicada]:
    """Aplica en orden las migraciones que falten. Devuelve las aplicadas. Si una falla, se deshace esa sola y se
    frena (las anteriores quedan aplicadas y registradas) con un ErrorMigracion que dice cuál y por qué."""
    faltan = pendientes(conectar, carpeta)
    if not faltan:
        return []
    if antes_de_migrar is not None:
        antes_de_migrar()
    hechas: list[Aplicada] = []
    for m in faltan:
        inicio = time.monotonic()
        with conectar() as con:
            con.commit()  # cierra cualquier transacción implícita abierta por los PRAGMA
            try:
                con.execute("BEGIN")
                m.aplicar(con)
                ms = round((time.monotonic() - inicio) * 1000)
                con.execute("INSERT INTO schema_migrations (numero, nombre, huella, aplicada_en, duracion_ms) VALUES (?, ?, ?, ?, ?)",
                            (m.numero, m.nombre, m.huella, datetime.now(timezone.utc).isoformat(timespec="seconds"), ms))
                con.execute("COMMIT")
            except Exception as e:
                con.execute("ROLLBACK")
                raise ErrorMigracion(f"Falló la migración {m.ruta.name}: {e}", detalle=repr(e)) from e
        log.info("Migración %04d_%s aplicada en %d ms", m.numero, m.nombre, ms)
        hechas.append(Aplicada(m.numero, m.nombre, ms))
    return hechas


def estado(conectar: Conectar, carpeta: Path = CARPETA) -> dict[str, object]:
    """Para Administración → Base de datos: versión del esquema y migraciones pendientes."""
    with conectar() as con:
        hechas = aplicadas(con)
    todas = disponibles(carpeta)
    return {"version": max(hechas) if hechas else 0, "aplicadas": len(hechas),
            "pendientes": [f"{m.numero:04d}_{m.nombre}" for m in todas if m.numero not in hechas]}
