"""Propuesta 26: filtro contra invenciones para los textos que la IA escribe a partir de un documento (resumen, proveído).

Cada número (dos cifras o más), fecha, DNI, LPU, expediente y nombre propio de la salida tiene que estar en el texto fuente.
Si algo no está, la salida se descarta y se usa la versión por reglas. Es el mismo criterio de `analisis.validar_sugerencia`
(mejoras desde el informe), pero en el dominio y sin dependencias.
"""
from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable

_MESES = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "setiembre", "octubre",
          "noviembre", "diciembre")
_NUMERO = re.compile(r"\d[\d.\-/]*\d|\d")
_FECHA_TXT = re.compile(r"\b(\d{1,2})\s+de\s+(" + "|".join(_MESES) + r")(?:\s+de\s+(\d{4}))?", re.I)
_PALABRA = re.compile(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+")
# Palabras con mayúscula que el sistema usa siempre y no son datos: no hace falta que figuren en la fuente.
INSTITUCIONALES = frozenset({
    "procuracion", "penitenciaria", "nacion", "direccion", "general", "proteccion", "derechos", "humanos", "dgpdh", "ppn",
    "visto", "considerando", "cumplase", "notifiquese", "remitase", "agreguese", "expediente", "nota", "informe", "sr", "sra",
    "servicio", "federal", "unidad", "complejo", "juzgado", "ppl", "dni", "lpu", "n", "nro", "buenos", "aires",
})


def _sin_acentos(texto: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn")


def numeros(texto: str | None) -> set[str]:
    """Números de dos cifras o más, sin puntos ni espacios (30.123.456 → 30123456; 1234/2025 → 1234/2025)."""
    salida = set()
    for t in _NUMERO.findall(texto or ""):
        limpio = re.sub(r"[.\s]", "", t)
        if sum(c.isdigit() for c in limpio) >= 2:
            salida.add(limpio)
            salida.update(p for p in re.split(r"[/\-]", limpio) if len(p) >= 2)
    return salida


def fechas(texto: str | None) -> set[str]:
    """Fechas escritas con palabras («3 de marzo de 2025»), normalizadas a «d-mes[-aaaa]»."""
    return {f"{int(d)}-{_sin_acentos(m.lower()).replace('setiembre', 'septiembre')}" + (f"-{a}" if a else "")
            for d, m, a in _FECHA_TXT.findall(texto or "")}


def nombres_propios(texto: str | None) -> set[str]:
    """Palabras con mayúscula inicial que no empiezan una oración ni una línea (candidatas a nombres propios)."""

    def _recortar(tok: str) -> str:  # sin expresión regular: lineal aunque el «token» sea una tira de miles de puntos
        i, j = 0, len(tok)
        while i < j and (not tok[i].isalnum() or tok[i].isdigit()):
            i += 1
        while j > i and not tok[j - 1].isalnum():
            j -= 1
        return tok[i:j]

    salida, inicio = set(), True
    for linea in (texto or "").splitlines():
        inicio = True
        for tok in linea.split():
            limpio = _recortar(tok)
            if not inicio and re.fullmatch(r"[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ]{2,}", limpio):
                salida.add(_sin_acentos(limpio.lower()))
            inicio = tok.endswith((".", "?", "!", ":")) or bool(re.fullmatch(r"\d+[).]", tok))
    return salida


def _palabras(texto: str) -> set[str]:
    return {_sin_acentos(w.lower()) for w in _PALABRA.findall(texto)}


def datos_inventados(salida: str | Iterable[str], *fuentes: str | None, permitidas: Iterable[str] = ()) -> list[str]:
    """Lo que la salida menciona y no está en ninguna fuente. Lista vacía = la salida pasa el filtro."""
    texto = salida if isinstance(salida, str) else "\n".join(salida)
    fuente = "\n".join(f or "" for f in fuentes)
    faltan: list[str] = []
    nums_fuente = numeros(fuente)
    faltan += [f"número {n}" for n in sorted(numeros(texto) - nums_fuente)]
    fechas_fuente = fechas(fuente)
    for f in sorted(fechas(texto)):
        dia_mes = f.rsplit("-", 1)[0] if f.count("-") == 2 else f
        if f not in fechas_fuente and not any(x.startswith(dia_mes) for x in fechas_fuente):
            faltan.append(f"fecha {f}")
    conocidas = _palabras(fuente) | INSTITUCIONALES | {_sin_acentos(p.lower()) for p in permitidas}
    faltan += [f"nombre {p}" for p in sorted(nombres_propios(texto) - conocidas)]
    return faltan
