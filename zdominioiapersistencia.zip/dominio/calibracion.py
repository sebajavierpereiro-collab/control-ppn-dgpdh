"""Propuestas 30 y 41: aprender de las decisiones ya tomadas sobre posibles fichas duplicadas.

- 41: «para decidir primero»: los pares más inciertos (cerca del umbral, donde reglas e IA no coinciden, fichas activas).
  Ahí una decisión humana enseña más (aprendizaje activo, como dedupe).
- 30: con las decisiones (unificar = misma persona, distintas = personas distintas) se estima cuánto pesa de verdad cada
  coincidencia, al estilo Fellegi-Sunter: m = P(motivo | misma), u = P(motivo | distinta), peso = log2(m/u). Y el umbral que
  mejor separa lo decidido. Es un **informe con el antes y el después**: los puntos del sistema no cambian solos.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Iterable, Sequence
from dataclasses import dataclass

MINIMO_DECISIONES = 20
_DETALLE = re.compile(r"\s*\(.*?\)\s*")


def incertidumbre(puntaje: int | None, veredicto: str | None, confianza: int | None, *, ambas_activas: bool, umbral: int) -> float:
    """0 a 3: más alto = conviene decidirla antes."""
    p = int(puntaje or 0)
    cerca = max(0.0, 1 - abs(p - umbral) / 45)
    ver = (veredicto or "").lower()
    desacuerdo = 0.0
    if ver == "distinta" and p >= umbral + 15:
        desacuerdo = 1.0                   # las reglas dicen «misma» con fuerza y la IA dice que no
    elif ver == "misma" and p < umbral + 10:
        desacuerdo = 0.6
    elif ver == "dudosa":
        desacuerdo = 0.7
    elif not ver:
        desacuerdo = 0.3                   # sin opinión de la IA
    duda_ia = 0.3 * (1 - abs((confianza if confianza is not None else 50) - 50) / 50) if ver else 0.0
    return round(cerca + desacuerdo + duda_ia + (0.3 if ambas_activas else 0.0), 3)


def motivo_base(motivo: str) -> str:
    """«DNI con un dígito distinto (30123456 / 30123457)» → «DNI con un dígito distinto»."""
    return _DETALLE.sub(" ", motivo).strip()


@dataclass(frozen=True)
class Peso:
    motivo: str
    en_misma: int
    en_distinta: int
    m: float
    u: float

    @property
    def peso(self) -> float:
        return round(math.log2(self.m / self.u), 2)


def pesos(decisiones: Iterable[tuple[Sequence[str], bool]], suavizado: float = 1.0) -> list[Peso]:
    """`decisiones`: (motivos del par, fue la misma persona). Con suavizado de Laplace para motivos poco vistos."""
    lista = list(decisiones)
    n_misma = sum(1 for _, es in lista if es)
    n_dist = len(lista) - n_misma
    cm: Counter[str] = Counter()
    cd: Counter[str] = Counter()
    for motivos, es in lista:
        for x in {motivo_base(m) for m in motivos}:
            (cm if es else cd)[x] += 1
    salida = [Peso(x, cm[x], cd[x], (cm[x] + suavizado) / (n_misma + 2 * suavizado), (cd[x] + suavizado) / (n_dist + 2 * suavizado))
              for x in sorted(set(cm) | set(cd))]
    return sorted(salida, key=lambda p: -abs(p.peso))


@dataclass(frozen=True)
class Umbral:
    actual: int
    aciertos_actual: float
    sugerido: int
    aciertos_sugerido: float
    decisiones: int


def umbral_sugerido(decisiones: Sequence[tuple[int, bool]], actual: int) -> Umbral | None:
    """El umbral (entre 30 y 95) que mejor separa lo decidido. Las propuestas existen solo por encima del umbral actual,
    así que la sugerencia sirve sobre todo para subirlo; para bajarlo hacen falta pares por debajo."""
    if len(decisiones) < MINIMO_DECISIONES:
        return None

    def aciertos(u: int) -> float:
        return sum(1 for p, es in decisiones if (p >= u) == es) / len(decisiones)
    mejor = max(range(30, 96), key=lambda u: (aciertos(u), -abs(u - actual)))
    return Umbral(actual, round(aciertos(actual), 3), mejor, round(aciertos(mejor), 3), len(decisiones))
