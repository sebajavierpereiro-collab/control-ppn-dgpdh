"""Perfiles de indicadores de Metas (pedido del usuario, 14/11): cada equipo tiene un perfil; por defecto, el «general» (el
de siempre, que no cambia). Los equipos de salud tienen otro formato, tomado de sus planillas del 3.er trimestre de 2026.

Cada indicador dice:
  * fuente: «viajes» (sale de Autos PPN), «carga» (lo carga la coordinación) o «viajes_o_carga» (de los viajes si hay dato
    ese mes; si no, lo cargado);
  * dimension: «persona» (cada integrante; la meta del equipo es también la de cada persona), «equipo» (un solo número por
    período) o «unidad» (desglosado por unidad o complejo);
  * propuesta: de dónde se puede proponer un valor que la coordinación confirma o corrige (p. ej. las notas del equipo).
Las metas mínimas de los perfiles de salud todavía no se cargaron: quedan «sin meta» hasta que la Dirección las fije.
"""
from __future__ import annotations

from typing import Any

Indicador = dict[str, Any]


def _i(clave: str, nombre: str, grupo: str, fuente: str = "carga", dimension: str = "equipo", **extra: Any) -> Indicador:
    return {"clave": clave, "nombre": nombre, "grupo": grupo, "fuente": fuente, "dimension": dimension, **extra}


SALUD_MENTAL: list[Indicador] = [
    _i("visitas_equipo", "Cantidad de viajes", "sm", "viajes"),
    _i("entrevistas", "Entrevistas presenciales a PPL", "sm", "viajes_o_carga"),
    _i("sm_entrevistas_telefonicas", "Entrevistas telefónicas a PPL", "sm"),
    _i("sm_recorridas", "Recorridas", "sm"),
    _i("sm_reuniones", "Reuniones de trabajo", "sm"),
    _i("sm_monitoreo_asistencial", "Monitoreo asistencial / entrevistas psicológicas y otros", "sm"),
    _i("sm_monitoreo_practicas", "Monitoreo de las prácticas de los equipos del SPF", "sm"),
    _i("sm_articulacion", "Articulación de las demandas de salud mental de las PPL", "sm"),
]

SALUD_MEDICA: list[Indicador] = [
    _i("med_entrevistas", "Entrevistas", "med_prof", dimension="persona"),
    _i("med_historias_clinicas", "Relevamientos de historias clínicas", "med_prof", dimension="persona"),
    _i("med_intervenciones", "Intervenciones", "med_prof", dimension="persona"),
    _i("med_recomendaciones", "Recomendaciones", "med_prof", dimension="persona"),
    _i("visitas_equipo", "Visitas a unidades", "med_unidad", "viajes", "unidad"),
    _i("med_informes_golpeados", "Informes de golpeados", "med_unidad", dimension="unidad"),
    _i("med_casos_individuales", "Casos individuales trabajados por notas y reiteraciones", "med_casos", dimension="unidad",
       propuesta="notas_individual"),
    _i("med_casos_colectivos", "Casos colectivos trabajados por notas y reiteraciones", "med_casos", dimension="unidad",
       propuesta="notas_colectivo"),
    _i("med_respuestas_spf", "Respuestas individuales recibidas del SPF", "med_casos", dimension="unidad"),
    _i("med_reuniones", "Reuniones de equipo o con otros equipos", "med_reuniones"),
]

PERFILES: dict[str, dict[str, Any]] = {
    "general": {"nombre": "General (el de siempre)", "grupos": None, "indicadores": None},  # se completa con metas.INDICADORES
    "salud_mental": {"nombre": "Salud mental", "grupos": [("sm", "Salud mental")], "indicadores": SALUD_MENTAL},
    "salud_medica": {"nombre": "Salud médica", "indicadores": SALUD_MEDICA,
                     "grupos": [("med_prof", "Por profesional"), ("med_unidad", "Por unidad o complejo"),
                                ("med_casos", "Casos y respuestas por complejo"), ("med_reuniones", "Reuniones")]},
}


def claves_por_persona_de_carga() -> set[str]:
    return {i["clave"] for p in PERFILES.values() for i in (p["indicadores"] or []) if i["dimension"] == "persona" and i["fuente"] == "carga"}


def indicadores_extra() -> list[Indicador]:
    """Indicadores de los perfiles especiales que no existen en el general (para validar claves y nombres)."""
    vistos: dict[str, Indicador] = {}
    for p in PERFILES.values():
        for i in p["indicadores"] or []:
            vistos.setdefault(i["clave"], i)
    return list(vistos.values())
