"""Propuesta 66 (viajes 13): disponibilidad de la flota. Con los cambios de estado de cada vehículo (que ya quedan en su
historial) se calcula cuántos días por mes estuvo disponible, en taller, suspendido o dado de baja, y el % de
disponibilidad por vehículo y para toda la flota. Sirve para fundamentar pedidos de presupuesto."""
from __future__ import annotations

from datetime import date, timedelta

ESTADOS = ("DISPONIBLE", "TALLER", "FUERA_DE_CIRCULACION", "BAJA")


def estado_de_texto(texto: str | None) -> str | None:
    """El historial guarda «TALLER — motivo»: se toma el estado del principio."""
    t = (texto or "").split("—")[0].strip().upper()
    return t if t in ESTADOS else None


def dias_por_mes(alta: date, inicial: str, cambios: list[tuple[date, str]], desde: date, hasta: date) -> dict[str, dict[str, int]]:
    """{AAAA-MM: {estado: días}} entre desde y hasta (inclusive), contando desde el alta del vehículo. Un cambio vale desde su
    día (ese día ya cuenta con el estado nuevo)."""
    orden = sorted(cambios)
    out: dict[str, dict[str, int]] = {}
    d = max(desde, alta)
    estado = inicial
    i = 0
    while i < len(orden) and orden[i][0] < d:
        estado = orden[i][1]
        i += 1
    while d <= hasta:
        while i < len(orden) and orden[i][0] <= d:
            estado = orden[i][1]
            i += 1
        mes = out.setdefault(d.strftime("%Y-%m"), {})
        mes[estado] = mes.get(estado, 0) + 1
        d += timedelta(days=1)
    return out


def pct_disponible(dias: dict[str, int]) -> int | None:
    """% de días disponible sobre los días en que el vehículo estaba en la flota (la baja no cuenta)."""
    en_flota = sum(n for e, n in dias.items() if e != "BAJA")
    return round(100 * dias.get("DISPONIBLE", 0) / en_flota) if en_flota else None
