"""Reglas del negocio puras (sin base de datos ni web)."""
