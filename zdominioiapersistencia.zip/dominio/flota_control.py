"""Propuestas 61 y 63 (viajes 8 y 10): controles de consistencia de la flota. Solo avisan; nunca corrigen ni bloquean.

61) Odómetro: km de regreso menor que el de salida, km de salida menor que el último registrado del vehículo, o km recorridos
    que se apartan mucho de la distancia estimada del recorrido (haversine × factor, o la matriz de distancias si hay).
63) Combustible: rendimiento de cada carga por el método de tanque lleno (km desde la carga anterior / litros de esta carga)
    comparado con la mediana de las últimas 10 cargas del vehículo.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def recorrido_km(puntos: list[tuple[float, float]], factor: float = 1.3) -> float | None:
    """Distancia estimada de un recorrido (ida por las paradas en orden y vuelta al primer punto)."""
    if len(puntos) < 2:
        return None
    tramos = list(zip(puntos, puntos[1:] + puntos[:1], strict=True))
    return round(sum(haversine_km(a[0], a[1], b[0], b[1]) for a, b in tramos) * factor, 1)


def avisos_odometro(km_salida: int | None, km_regreso: int | None, km_previo: int | None, estimado_km: float | None,
                    desvio_pct: int) -> list[str]:
    out: list[str] = []
    if km_salida is not None and km_regreso is not None and km_regreso < km_salida:
        out.append(f"los km de regreso ({km_regreso}) son menos que los de salida ({km_salida})")
    if km_salida is not None and km_previo is not None and km_salida < km_previo:
        out.append(f"los km de salida ({km_salida}) son menos que el último kilometraje registrado del vehículo ({km_previo})")
    if km_salida is not None and km_regreso is not None and estimado_km and km_regreso >= km_salida:
        recorridos = km_regreso - km_salida
        if abs(recorridos - estimado_km) > estimado_km * desvio_pct / 100:
            out.append(f"se recorrieron {recorridos} km y la distancia estimada del recorrido es de unos {round(estimado_km)} km")
    return out


@dataclass(frozen=True)
class Carga:
    id: str            # «R12» (registro de combustible) o «D5» (cierre de salida)
    fecha: str
    km: int
    litros: float


@dataclass(frozen=True)
class Rendimiento:
    carga: Carga
    km_por_litro: float
    mediana: float | None
    desvio_pct: int | None
    fuera: bool


def rendimientos(cargas: list[Carga], desvio_pct: int = 25, ventana: int = 10) -> list[Rendimiento]:
    """En orden de km. La primera carga no tiene rendimiento (no se sabe desde dónde). Con menos de 3 anteriores no se
    compara (la mediana no es confiable todavía)."""
    orden = sorted((c for c in cargas if c.litros > 0), key=lambda c: (c.km, c.fecha))
    salida: list[Rendimiento] = []
    previos: list[float] = []
    for ant, c in zip(orden, orden[1:], strict=False):
        if c.km <= ant.km:
            continue
        kml = round((c.km - ant.km) / c.litros, 2)
        base = previos[-ventana:]
        med = round(statistics.median(base), 2) if len(base) >= 3 else None
        desvio = round(100 * (kml - med) / med) if med else None
        salida.append(Rendimiento(c, kml, med, desvio, desvio is not None and abs(desvio) > desvio_pct))
        previos.append(kml)
    return salida
