"""Propuesta 62 (viajes 9): costo por viaje a la unidad y por equipo. El importe de cada salida (combustible y gastos que se
cargan al cerrarla) se reparte entre sus paradas (por km estimados si se conocen todos; si no, en partes iguales) y el de
cada parada, en partes iguales entre los equipos que viajaron a esa unidad."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass(frozen=True)
class Parada:
    unidad: str
    equipos: tuple[str, ...]
    km: float | None = None


def repartir(importe: float, paradas: list[Parada]) -> list[tuple[Parada, float, dict[str, float]]]:
    """[(parada, importe de la parada, {equipo: importe})]."""
    if not paradas or importe <= 0:
        return []
    kms = [p.km for p in paradas]
    if all(k is not None and k > 0 for k in kms):
        total = sum(k for k in kms if k is not None)
        partes = [importe * (k or 0) / total for k in kms]
    else:
        partes = [importe / len(paradas)] * len(paradas)
    out = []
    for p, parte in zip(paradas, partes, strict=True):
        eqs = p.equipos or ("(sin equipo)",)
        out.append((p, round(parte, 2), {e: round(parte / len(eqs), 2) for e in eqs}))
    return out


def acumular(salidas: list[tuple[str, float, list[Parada]]]) -> dict[str, dict[str, float]]:
    """salidas = [(fecha, importe, paradas)] → {"unidad": {...}, "equipo": {...}, "trimestre": {...}}."""
    por_unidad: dict[str, float] = defaultdict(float)
    por_equipo: dict[str, float] = defaultdict(float)
    por_tri: dict[str, float] = defaultdict(float)
    for fecha, importe, paradas in salidas:
        for p, parte, eqs in repartir(importe, paradas):
            por_unidad[p.unidad] += parte
            for e, x in eqs.items():
                por_equipo[e] += x
        if paradas and importe > 0:
            por_tri[f"{fecha[:4]}-T{(int(fecha[5:7]) - 1) // 3 + 1}"] += importe
    return {"unidad": {k: round(v, 2) for k, v in por_unidad.items()}, "equipo": {k: round(v, 2) for k, v in por_equipo.items()},
            "trimestre": {k: round(v, 2) for k, v in sorted(por_tri.items())}}
