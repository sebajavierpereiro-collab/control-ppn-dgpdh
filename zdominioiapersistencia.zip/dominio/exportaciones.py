"""Propuesta 46: exportaciones y API de la base de personas detenidas con datos mínimos y motivo (Ley 25.326, art. 9).

- Perfil «mínima» (nombre, DNI y alojamiento) o «completa» (todo). La completa puede exigir un motivo ([detenidos]
  exigir_motivo_exportacion = true); cada exportación tiene un identificador que va en el archivo (hoja «Constancia» del
  Excel) y en el registro de seguridad.
- Aviso a la Dirección cuando una persona exporta más de N fichas en el día ([detenidos] aviso_exportacion_fichas).
- El token de la API puede limitarse a ciertos campos ([detenidos] api_campos).
"""
from __future__ import annotations

import re
import secrets
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

PERFILES = ("minima", "completa")
COLUMNAS_MINIMAS = ("id", "nombre_completo", "dni", "centro", "modulo", "pabellon")
UMBRAL_AVISO = 2000
_N = re.compile(r"(\d+) persona")


def columnas(perfil: str, todas: Sequence[tuple[str, str]]) -> list[tuple[str, str]]:
    if perfil == "minima":
        return [c for c in todas if c[0] in COLUMNAS_MINIMAS]
    return list(todas)


def identificador() -> str:
    return "EXP-" + secrets.token_hex(4).upper()


def constancia(*, usuario: str, fecha: str, ident: str, perfil: str, motivo: str | None, cantidad: int) -> list[tuple[str, str]]:
    return [("Exportación", ident), ("Quién", usuario), ("Cuándo", fecha), ("Perfil", "mínima" if perfil == "minima" else "completa"),
            ("Motivo", motivo or "—"), ("Personas", str(cantidad)),
            ("Reserva", "Datos personales sensibles (Ley 25.326). Uso exclusivo para el motivo indicado; no difundir.")]


def cantidad_exportada(detalles: Iterable[str]) -> int:
    """Suma las personas exportadas a partir de los detalles del registro de seguridad («xlsx: 120 persona(s)…»)."""
    return sum(int(m.group(1)) for d in detalles if (m := _N.search(d or "")))


def campos_api(d: Mapping[str, Any], permitidos: Iterable[str] | None) -> dict[str, Any]:
    lista = [c for c in (permitidos or []) if c]
    if not lista:
        return dict(d)
    return {k: v for k, v in d.items() if k in lista or k == "id"}
