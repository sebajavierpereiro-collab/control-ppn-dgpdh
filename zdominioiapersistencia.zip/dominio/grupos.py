"""Propuesta 31: agrupar los pares de posibles duplicados en «posibles grupos de la misma persona» (componentes conexos).

Si A se parece a B y B a C, se muestran juntos, con una ficha sugerida para conservar, en vez de dos propuestas sueltas que se
pueden decidir de forma contradictoria.
"""
from __future__ import annotations

from collections.abc import Callable, Iterable


def componentes(pares: Iterable[tuple[int, int]]) -> list[list[int]]:
    """Grupos de dos o más fichas conectadas, cada uno ordenado, del más grande al más chico."""
    padre: dict[int, int] = {}

    def raiz(x: int) -> int:
        padre.setdefault(x, x)
        while padre[x] != x:
            padre[x] = padre[padre[x]]
            x = padre[x]
        return x
    for a, b in pares:
        ra, rb = raiz(a), raiz(b)
        if ra != rb:
            padre[max(ra, rb)] = min(ra, rb)
    grupos: dict[int, list[int]] = {}
    for x in padre:
        grupos.setdefault(raiz(x), []).append(x)
    return sorted((sorted(g) for g in grupos.values() if len(g) > 1), key=lambda g: (-len(g), g[0]))


def sugerida(grupo: list[int], conservar: Callable[[list[int]], int | None]) -> int:
    """La ficha a conservar: la que elige la regla de siempre (`detenidos.ficha_a_conservar`) o la primera."""
    elegida = conservar(grupo)
    return elegida if elegida in grupo else grupo[0]
