"""Propuesta 70 (viajes 17): vista del día por recurso. Cada vehículo o chofer es una fila; las horas, columnas. Se arma en el
servidor (HTML y CSS grid, sin JavaScript de terceros): barras para salidas, reservas, licencias y taller, y los huecos libres."""
from __future__ import annotations

from dataclasses import dataclass, field

INICIO, FIN = 6 * 60, 22 * 60  # rango visible: 6 a 22 h
HUECO_MINIMO = 90              # minutos libres seguidos para mostrar un hueco


def minutos(h: str | None) -> int | None:
    if not h or len(h) < 5 or not (h[:2].isdigit() and h[3:5].isdigit()):
        return None
    return int(h[:2]) * 60 + int(h[3:5])


@dataclass(frozen=True)
class Bloque:
    inicio: int
    fin: int
    clase: str          # salida | reserva | licencia | taller | pedido
    texto: str
    url: str | None = None

    @property
    def izq(self) -> float:
        return round(100 * (max(self.inicio, INICIO) - INICIO) / (FIN - INICIO), 2)

    @property
    def ancho(self) -> float:
        return round(100 * max(15, min(self.fin, FIN) - max(self.inicio, INICIO)) / (FIN - INICIO), 2)

    @property
    def horario(self) -> str:
        return f"{self.inicio // 60:02d}:{self.inicio % 60:02d}–{self.fin // 60:02d}:{self.fin % 60:02d}"


@dataclass
class Fila:
    id: int
    nombre: str
    detalle: str
    url: str
    bloques: list[Bloque] = field(default_factory=list)

    @property
    def todo_el_dia(self) -> bool:
        return any(b.clase in ("licencia", "taller") and b.inicio <= INICIO and b.fin >= FIN for b in self.bloques)

    @property
    def huecos(self) -> list[Bloque]:
        if self.todo_el_dia:
            return []
        ocupado = sorted((max(b.inicio, INICIO), min(b.fin, FIN)) for b in self.bloques)
        libres, desde = [], INICIO
        for a, z in ocupado:
            if a - desde >= HUECO_MINIMO:
                libres.append(Bloque(desde, a, "hueco", "libre"))
            desde = max(desde, z)
        if FIN - desde >= HUECO_MINIMO:
            libres.append(Bloque(desde, FIN, "hueco", "libre"))
        return libres

    @property
    def choques(self) -> bool:
        salidas = sorted((b.inicio, b.fin) for b in self.bloques if b.clase in ("salida", "reserva"))
        return any(b[0] < a[1] for a, b in zip(salidas, salidas[1:], strict=False))


def bloque(salida: str | None, regreso: str | None, clase: str, texto: str, url: str | None = None, defecto_horas: int = 4) -> Bloque:
    a = minutos(salida)
    if a is None:
        a = 8 * 60
    z = minutos(regreso)
    if z is None or z <= a:
        z = a + defecto_horas * 60
    return Bloque(a, z, clase, texto, url)


def todo_el_dia(clase: str, texto: str, url: str | None = None) -> Bloque:
    return Bloque(INICIO, FIN, clase, texto, url)


def horas() -> list[int]:
    return list(range(INICIO // 60, FIN // 60))
