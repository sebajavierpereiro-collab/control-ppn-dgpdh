"""Propuesta 96 (viajes 43): borrador de lectura del trimestre redactado por la IA local.

El servidor arma los hechos con números (desde los datos) y la IA solo redacta usando marcas [H1], [H2]… en lugar de
cifras. Después se reemplazan las marcas por los hechos: los números nunca los escribe el modelo. Si la respuesta trae
cifras propias o no usa las marcas, se descarta y queda un borrador armado sin IA. Siempre es un borrador para revisar.
"""
from __future__ import annotations

import re
from typing import Any

_MARCA = re.compile(r"\[H(\d+)\]")


def hechos(nombre_equipo: str, filas: list[dict[str, Any]], trimestre: int) -> list[str]:
    """Una frase con números por indicador con meta (y los que más se apartan primero)."""
    out = []
    con_meta = [f for f in filas if f.get("meta")]
    for f in sorted(con_meta, key=lambda f: (f["hecho"] / f["esperado"]) if f.get("esperado") else 99):
        pct = round(100 * f["hecho"] / f["esperado"]) if f.get("esperado") else None
        t = f["trimestres"][trimestre - 1] if f.get("trimestres") else 0
        estado = str(f.get("estado", "")).replace("_", " ")
        out.append(f"{f['nombre']}: {f['hecho']} en el año ({pct} % de lo esperado a la fecha, {estado}); {t} en el {trimestre}.º trimestre"
                   if pct is not None else f"{f['nombre']}: {f['hecho']} en el año ({estado}); {t} en el {trimestre}.º trimestre")
    return out[:10]


def prompt(nombre_equipo: str, trimestre: int, anio: int, lista: list[str]) -> str:
    marcas = "\n".join(f"[H{i}] = {h}" for i, h in enumerate(lista, 1))
    return (f"Redactá en español rioplatense, en un párrafo de 4 a 6 oraciones, una lectura del {trimestre}.º trimestre {anio} del equipo "
            f"«{nombre_equipo}» para la Dirección. No escribas ningún número: cuando quieras mencionar un dato, escribí solo su marca "
            f"([H1], [H2], …) tal cual. Señalá lo que va bien, lo atrasado y qué convendría revisar, sin inventar causas.\n\nDatos:\n{marcas}")


def sin_ia(nombre_equipo: str, trimestre: int, anio: int, lista: list[str]) -> str:
    if not lista:
        return f"{nombre_equipo} no tiene metas cargadas para {anio}."
    return f"Lectura del {trimestre}.º trimestre {anio} de {nombre_equipo}. " + " ".join(f"{h}." for h in lista)


def armar(respuesta: str | None, nombre_equipo: str, trimestre: int, anio: int, lista: list[str]) -> tuple[str, bool]:
    """(texto, redactado_por_ia). Reemplaza las marcas por los hechos; si la IA escribió cifras o no usó marcas, se descarta."""
    if not respuesta or not lista:
        return sin_ia(nombre_equipo, trimestre, anio, lista), False
    sin_marcas = _MARCA.sub("", respuesta)
    if re.search(r"\d", sin_marcas) or not _MARCA.search(respuesta):
        return sin_ia(nombre_equipo, trimestre, anio, lista), False
    def poner(m: re.Match[str]) -> str:
        i = int(m.group(1))
        return f"({lista[i - 1]})" if 1 <= i <= len(lista) else ""
    return _MARCA.sub(poner, respuesta).strip(), True
