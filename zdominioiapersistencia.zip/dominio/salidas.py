"""Modificación 6: jerarquía de los viajes unificados. Una salida (mismo vehículo y horario que se pisa, o pedidos unidos en
un solo viaje) se muestra en dos niveles: arriba transporte, vehículo, horario y chofer; abajo un subbloque por unidad de
destino con sus pasajeros y pedidos. Nunca se mezclan destinos distintos en una lista plana."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

Viaje = dict[str, Any]


def _clave_destino(v: Viaje) -> str:
    return str(v.get("unidad_id") or (v.get("destino") or "").strip().lower())


def paradas(viajes: list[Viaje], pedidos_unificados: Callable[[int], list[int]] | None = None) -> list[dict[str, Any]]:
    """[{destino, viajes: [ids], pedidos: [ids de pedidos unidos], participantes}] por unidad de destino, en orden de horario."""
    por: dict[str, dict[str, Any]] = {}
    for v in sorted(viajes, key=lambda x: (x.get("hora_salida") or "99:99", x["id"])):
        k = _clave_destino(v)
        b = por.setdefault(k, {"destino": v.get("destino") or "—", "viajes": [], "pedidos": [], "participantes": [], "hora": v.get("hora_salida")})
        b["viajes"].append(v["id"])
        b["pedidos"] += [v["id"]] + (pedidos_unificados(v["id"]) if pedidos_unificados else [])
        b["participantes"] += list(v.get("participantes") or [])
    return list(por.values())


def agrupar_dia(viajes: list[Viaje]) -> list[dict[str, Any]]:
    """Para la grilla: cada salida con varias paradas queda como UNA tarjeta («salida») y el resto, como siempre («viaje»).
    Une los viajes que se señalan entre sí en `misma_salida`."""
    ids = {v["id"] for v in viajes}
    por_id = {v["id"]: v for v in viajes}
    vistos: set[int] = set()
    salida: list[dict[str, Any]] = []
    for v in viajes:
        if v["id"] in vistos:
            continue
        grupo = [v]
        vistos.add(v["id"])
        pendientes = [o["id"] for o in v.get("misma_salida") or [] if o["id"] in ids]
        while pendientes:
            i = pendientes.pop()
            if i in vistos:
                continue
            vistos.add(i)
            grupo.append(por_id[i])
            pendientes += [o["id"] for o in por_id[i].get("misma_salida") or [] if o["id"] in ids and o["id"] not in vistos]
        if len(grupo) == 1:
            salida.append({"tipo": "viaje", "viaje": v})
            continue
        grupo.sort(key=lambda x: (x.get("hora_salida") or "99:99", x["id"]))
        salida.append({"tipo": "salida", "cabecera": grupo[0], "viajes": grupo, "paradas": paradas(grupo),
                       "hora_salida": min((str(x["hora_salida"]) for x in grupo if x.get("hora_salida")), default=None),
                       "hora_regreso": max((str(x["hora_regreso"]) for x in grupo if x.get("hora_regreso")), default=None),
                       "personas": sum(int(x.get("con_transporte") or 0) for x in grupo)})
    return salida
