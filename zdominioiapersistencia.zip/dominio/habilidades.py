"""Propuestas 58 y 59 (viajes 5 y 6): requisitos del viaje frente a habilidades de vehículos y choferes, y descanso mínimo
del chofer entre jornadas. Reglas puras: el sugeridor descarta o avisa y explica por qué; la coordinación decide."""
from __future__ import annotations

import re
from collections.abc import Iterable


def etiquetas(texto: str | None) -> frozenset[str]:
    """«Ruta larga, 7 plazas; licencia D1» → {"ruta larga", "7 plazas", "licencia d1"}."""
    return frozenset(t for t in (re.sub(r"\s+", " ", x).strip().lower() for x in re.split(r"[,;\n]", texto or "")) if t)


def texto(tags: Iterable[str]) -> str:
    return ", ".join(sorted(tags))


def faltantes(requisitos: frozenset[str], propias: frozenset[str], conocidas: frozenset[str]) -> frozenset[str]:
    """Requisitos que este recurso no cumple. Solo cuentan los que alguno de los recursos del mismo tipo tiene cargados:
    «licencia D1» no descarta vehículos y «7 plazas» no descarta choferes."""
    return (requisitos & conocidas) - propias


def sin_quien_cumpla(requisitos: frozenset[str], conocidas_choferes: frozenset[str], conocidas_vehiculos: frozenset[str]) -> frozenset[str]:
    return requisitos - conocidas_choferes - conocidas_vehiculos


def minutos(h: str | None) -> int | None:
    if not h or len(h) < 5 or not (h[:2].isdigit() and h[3:5].isdigit()):
        return None
    return int(h[:2]) * 60 + int(h[3:5])


def descanso_horas(regreso_dia_anterior: str | None, salida_dia_siguiente: str | None) -> float | None:
    """Horas entre el último regreso de un día y la primera salida del día siguiente."""
    r, s = minutos(regreso_dia_anterior), minutos(salida_dia_siguiente)
    if r is None or s is None:
        return None
    return round((24 * 60 - r + s) / 60, 1)
