"""Clasificación de documentos al mandarlos a la firma y formato del protocolo interno (reforma del 14/11/2026).

Todo documento se clasifica antes de entrar al circuito de firma: tipo documental (con subtipo si corresponde), alcance
(individual o colectivo, para informes), confidencialidad (interno, reservado o público), expediente y destinatario. El sistema
propone y una persona confirma. Los INFORMES reciben al firmarse un número de protocolo interno con el formato
SIGLA-ÁREA-AÑO-NNNN; el área sale de quién firma (Director General → DGPDH, Subdirector/a → SGPDH).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from dgpdh.errores import DatoInvalido

CONFIDENCIALIDAD: dict[str, str] = {"INTERNO": "Interno", "RESERVADO": "Reservado", "PUBLICO": "Público"}
ALCANCE: dict[str, str] = {"INDIVIDUAL": "Individual", "COLECTIVO": "Colectivo"}
# Subtipos por tipo documental (clave del tipo → {clave: etiqueta}). Los tipos sin subtipos no lo piden.
SUBTIPOS: dict[str, dict[str, str]] = {
    "INFORME": {"GENERAL": "Informe", "OBSTACULIZACION": "Informe de obstaculización"},
}
TIPOS_CON_ALCANCE = frozenset({"INFORME"})
# Protocolo: qué tipos se numeran (por ahora solo informes) y con qué sigla
SIGLA_PROTOCOLO: dict[str, str] = {"INFORME": "INF"}
AREA_POR_ROL: dict[str, str] = {"DIRECTOR": "DGPDH", "SUBDIRECTOR": "SGPDH"}
_NUMERO = re.compile(r"^([A-Z]{2,5})-([A-Z]{2,8})-(\d{4})-(\d{4,})$")
MAX_TEXTO = 300


@dataclass(frozen=True)
class Clasificacion:
    tipo: str
    confidencialidad: str
    destinatario: str
    subtipo: str | None = None
    alcance: str | None = None
    expediente: str | None = None

    @property
    def lleva_protocolo(self) -> bool:
        return self.tipo in SIGLA_PROTOCOLO

    def etiqueta_subtipo(self) -> str | None:
        return SUBTIPOS.get(self.tipo, {}).get(self.subtipo or "")


def _limpio(v: object) -> str:
    return re.sub(r"\s+", " ", str(v or "")).strip()[:MAX_TEXTO]


def validar(datos: dict[str, object], tipos_validos: dict[str, str]) -> Clasificacion:
    """Arma la clasificación desde un formulario. Lanza DatoInvalido con un mensaje para la persona."""
    tipo = _limpio(datos.get("tipo")).upper()
    if tipo not in tipos_validos:
        raise DatoInvalido("Elegí el tipo de documento.")
    subtipos = SUBTIPOS.get(tipo, {})
    subtipo = _limpio(datos.get("subtipo")).upper() or None
    if subtipos:
        subtipo = subtipo or next(iter(subtipos))
        if subtipo not in subtipos:
            raise DatoInvalido("El subtipo no corresponde a ese tipo de documento.")
    else:
        subtipo = None
    alcance = _limpio(datos.get("alcance")).upper() or None
    if tipo in TIPOS_CON_ALCANCE:
        if alcance not in ALCANCE:
            raise DatoInvalido("Indicá si el informe es individual o colectivo.")
    else:
        alcance = None
    confidencialidad = _limpio(datos.get("confidencialidad")).upper()
    if confidencialidad not in CONFIDENCIALIDAD:
        raise DatoInvalido("Indicá si el documento es interno, reservado o público.")
    destinatario = _limpio(datos.get("destinatario"))
    if not destinatario:
        raise DatoInvalido("Indicá el destinatario.")
    expediente = _limpio(datos.get("expediente")) or None
    return Clasificacion(tipo=tipo, subtipo=subtipo, alcance=alcance, confidencialidad=confidencialidad,
                         destinatario=destinatario, expediente=expediente)


def area_de_firmante(rol: str) -> str:
    try:
        return AREA_POR_ROL[rol]
    except KeyError:
        raise DatoInvalido("Solo la Dirección General o la Subdirección firman documentos protocolizados.") from None


def formato_numero(sigla: str, area: str, anio: int, correlativo: int) -> str:
    if correlativo < 1:
        raise DatoInvalido("El correlativo del protocolo empieza en 1.")
    return f"{sigla}-{area}-{anio}-{correlativo:04d}"


def parece_numero(texto: str) -> bool:
    return bool(_NUMERO.match(texto.strip().upper()))
