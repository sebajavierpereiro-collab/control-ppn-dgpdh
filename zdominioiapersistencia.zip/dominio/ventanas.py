"""Propuesta 57 (viajes 4): horarios de ingreso de cada unidad en formato estructurado.

Cada ventana dice qué día de la semana, de qué hora a qué hora y para qué (audiencias, visita general o profesionales). Los
cambios no pisan lo anterior: se carga una ventana nueva con «vigente desde» y la anterior se da de baja. El texto libre
de siempre (`unidades.horarios_visita`) se conserva como nota. El aviso al pedir un viaje no bloquea nada.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

TIPOS: dict[str, str] = {"AUDIENCIAS": "Audiencias", "VISITA": "Visita general", "PROFESIONALES": "Profesionales"}
DIAS = ("lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo")
_HORA = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


@dataclass(frozen=True)
class Ventana:
    id: int
    unidad_id: int
    dia_semana: int
    desde: str
    hasta: str
    tipo: str
    vigente_desde: str

    def contiene(self, hora: str) -> bool:
        return self.desde <= hora <= self.hasta

    @property
    def texto(self) -> str:
        return f"{DIAS[self.dia_semana]} de {self.desde} a {self.hasta} ({TIPOS.get(self.tipo, self.tipo).lower()})"


def validar_hora(h: str) -> bool:
    return bool(_HORA.match(h or ""))


def vigentes(ventanas: list[Ventana], fecha: date) -> list[Ventana]:
    """Las que valen ese día: ya vigentes y, si hay varias versiones para el mismo día y tipo, la más reciente."""
    mejores: dict[tuple[int, int, str], str] = {}
    for v in ventanas:
        if v.vigente_desde <= fecha.isoformat():
            k = (v.unidad_id, v.dia_semana, v.tipo)
            mejores[k] = max(mejores.get(k, ""), v.vigente_desde)
    return sorted((v for v in ventanas if v.vigente_desde <= fecha.isoformat() and mejores.get((v.unidad_id, v.dia_semana, v.tipo)) == v.vigente_desde),
                  key=lambda v: (v.dia_semana, v.desde, v.tipo))


def aviso(ventanas: list[Ventana], fecha: date, hora_salida: str | None, tipo: str | None = None) -> str | None:
    """Texto de aviso si el viaje parece caer fuera del horario de ingreso; None si está bien o si la unidad no tiene horarios.
    Como la hora cargada es la de salida, solo se avisa cuando el día no tiene ingreso o se sale cuando ya cerró."""
    todas = vigentes(ventanas, fecha)
    if tipo:
        todas = [v for v in todas if v.tipo == tipo] or todas
    if not todas:
        return None
    del_dia = [v for v in todas if v.dia_semana == fecha.weekday()]
    if not del_dia:
        otros = sorted({DIAS[v.dia_semana] for v in todas}, key=DIAS.index)
        return f"La unidad no tiene horario de ingreso los {DIAS[fecha.weekday()]} (recibe: {', '.join(otros)})."
    if hora_salida and validar_hora(hora_salida) and all(v.hasta <= hora_salida for v in del_dia):
        ultimo = max(v.hasta for v in del_dia)
        return f"El horario de ingreso de ese día termina a las {ultimo} y la salida está prevista a las {hora_salida}."
    return None
