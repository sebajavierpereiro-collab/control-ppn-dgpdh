"""Propuesta 36 (sin Pandera): las reglas de cada listado escritas como esquema.

Por fuerza se declara qué columnas se esperan, de qué tipo, con qué rango o valores permitidos y cuáles son obligatorias.
El control es completo («lazy»): junta todos los problemas con su fila y su columna en vez de parar en el primero. Sirve para
ver de un vistazo qué controla el sistema de cada columna y para la devolución a la fuerza. No reemplaza las validaciones de
la carga (siguen en detenidos.py): las complementa en la vista previa.
"""
from __future__ import annotations

import re
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass(frozen=True)
class Columna:
    clave: str
    etiqueta: str
    tipo: str = "texto"                    # texto | entero | documento | fecha
    obligatoria: bool = False
    minimo: int | None = None
    maximo: int | None = None
    permitidos: tuple[str, ...] = ()
    largo_max: int | None = None


@dataclass(frozen=True)
class Esquema:
    nombre: str
    columnas: tuple[Columna, ...]
    extra: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Falla:
    fila: int
    columna: str
    valor: str
    problema: str


GENERAL = Esquema("General", (
    Columna("nombre_completo", "Nombre completo", obligatoria=True, largo_max=200),
    Columna("dni", "DNI", "documento", minimo=6, maximo=8),
    Columna("lpu", "LPU", "documento", minimo=3, maximo=12),
    Columna("fecha_nacimiento", "Fecha de nacimiento", "fecha"),
    Columna("condena_anios", "Años de condena", "entero", minimo=0, maximo=99),
    Columna("condena_meses", "Meses de condena", "entero", minimo=0, maximo=11),
    Columna("condena_dias", "Días de condena", "entero", minimo=0, maximo=31),
    Columna("situacion_procesal", "Situación procesal", permitidos=("Procesado/a", "Condenado/a", "Con prisión preventiva",
                                                                    "Arresto domiciliario", "Otra", "procesado", "condenado", "procesada",
                                                                    "condenada", "prision preventiva", "arresto domiciliario")),
))


def _norm(v: object) -> str:
    return re.sub(r"\s+", " ", str(v if v is not None else "")).strip()


def _fecha(v: object) -> bool:
    if isinstance(v, date):
        return True
    t = _norm(v)
    m = re.fullmatch(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})", t) or re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", t)
    if not m:
        return False
    a, b, c = (int(x) for x in m.groups())
    try:
        (date(a, b, c) if a > 31 else date(c, b, a))
    except ValueError:
        return False
    return True


def controlar(registros: Iterable[Mapping[str, Any]], esquema: Esquema = GENERAL) -> list[Falla]:
    fallas: list[Falla] = []
    for n, r in enumerate(registros, 1):
        for c in esquema.columnas:
            crudo = r.get(c.clave)
            v = _norm(crudo)
            if not v:
                if c.obligatoria:
                    fallas.append(Falla(n, c.etiqueta, "", "falta (es obligatoria)"))
                continue
            if c.tipo == "documento":
                dig = re.sub(r"\D", "", v)
                if not dig:
                    fallas.append(Falla(n, c.etiqueta, v, "no tiene números"))
                elif (c.minimo and len(dig) < c.minimo) or (c.maximo and len(dig) > c.maximo):
                    fallas.append(Falla(n, c.etiqueta, v, f"tiene {len(dig)} dígitos (se esperan entre {c.minimo} y {c.maximo})"))
            elif c.tipo == "entero":
                if not re.fullmatch(r"\d+(\.0)?", v):
                    fallas.append(Falla(n, c.etiqueta, v, "no es un número entero"))
                elif (c.minimo is not None and int(float(v)) < c.minimo) or (c.maximo is not None and int(float(v)) > c.maximo):
                    fallas.append(Falla(n, c.etiqueta, v, f"fuera de rango ({c.minimo} a {c.maximo})"))
            elif c.tipo == "fecha" and not _fecha(crudo):
                fallas.append(Falla(n, c.etiqueta, v, "no es una fecha válida (DD/MM/AAAA)"))
            if c.permitidos and v.lower() not in {p.lower() for p in c.permitidos}:
                fallas.append(Falla(n, c.etiqueta, v, "valor que no está en el catálogo"))
            if c.largo_max and len(v) > c.largo_max:
                fallas.append(Falla(n, c.etiqueta, v[:40] + "…", f"más de {c.largo_max} caracteres"))
    return fallas


def resumen(fallas: Iterable[Falla]) -> dict[str, int]:
    """Cantidad de problemas por columna (para la vista previa y la devolución)."""
    return dict(Counter(f.columna for f in fallas).most_common())


def esquema_desde(datos: Mapping[str, Any] | None) -> Esquema:
    """Esquema propio de una fuerza (por ejemplo desde un JSON): {"nombre": …, "columnas": [{clave, etiqueta, tipo, …}]}.
    Lo que no trae, se toma del general."""
    if not datos or not isinstance(datos.get("columnas"), list):
        return GENERAL
    propias = {}
    for c in datos["columnas"]:
        if isinstance(c, Mapping) and c.get("clave"):
            propias[str(c["clave"])] = Columna(str(c["clave"]), str(c.get("etiqueta") or c["clave"]), str(c.get("tipo") or "texto"),
                                               bool(c.get("obligatoria")), c.get("minimo"), c.get("maximo"),
                                               tuple(str(x) for x in c.get("permitidos") or ()), c.get("largo_max"))
    base = {c.clave: c for c in GENERAL.columnas}
    base.update(propias)
    return Esquema(str(datos.get("nombre") or "Propio"), tuple(base.values()))
