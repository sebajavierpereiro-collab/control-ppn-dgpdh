"""Propuesta 45: campos especialmente protegidos de la ficha de una persona detenida (Ley 25.326, art. 7: datos sensibles;
inc. 4, antecedentes penales). Con [detenidos] ocultar_sensibles = true se muestran tapados por defecto a quien no mantiene
la base; «Ver» pide un motivo y queda registrado en seguridad_eventos. Sin la opción, todo se ve como hoy.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

CAMPOS = ("situacion_procesal", "condena_anios", "condena_meses", "condena_dias", "fecha_cumplimiento", "observaciones")
MINUTOS_VISIBLE = 30


def tapar(ficha: Mapping[str, Any]) -> dict[str, Any]:
    return {k: (None if k in CAMPOS else v) for k, v in ficha.items()}


def tapar_historial(filas: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    return [dict(f, antes="(dato protegido)", despues="(dato protegido)") if f.get("campo") in CAMPOS else dict(f) for f in filas]


def hay_sensibles(ficha: Mapping[str, Any]) -> bool:
    return any(ficha.get(k) not in (None, "") for k in CAMPOS)
