"""Propuesta 43: copias anonimizadas de notas y fichas para pruebas, capacitación y el examen de la IA (Ley 25.326, art. 2,
«disociación de datos»).

- Nombres de personas → «[PERSONA_1]», siempre el mismo reemplazo para la misma persona en todo el material.
- DNI, CUIL, LPU, expedientes propios (EP 1234/2025) y números GDE → valores ficticios con el mismo formato.
- Las unidades y los juzgados se conservan (o se generalizan con `generalizar_lugares`).
- Los reemplazos son deterministas para una misma `semilla`: dos corridas dan el mismo resultado y se pueden comparar.
Nada de esto toca la base: trabaja sobre textos y devuelve copias. Una persona revisa una muestra antes de usarlas
(`herramientas/anonimizar.py` arma esa muestra).
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

_NOM = r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+"
_MAY = r"(?!(?:DNI|CUIL|CUIT|PPN|SPF|DGPDH|CPF|GDE|LPU|EP|APN|CABA|SR|SRA)\b)[A-ZÁÉÍÓÚÑ]{2,}"
_TITULO = r"(?:[Ss]r|[Ss]ra|[Ss]eñor|[Ss]eñora|[Dd]r|[Dd]ra|interno|interna|detenido|detenida|joven|PPL)\.?"
_NOMBRE_COMA = re.compile(rf"\b({_MAY}(?:\s+{_MAY})?),\s+({_NOM}(?:\s+{_NOM}){{0,2}})\b")
_NOMBRE_TITULO = re.compile(rf"\b{_TITULO}\s+((?:{_NOM}|{_MAY})(?:\s+(?:(?:de|del|la)\s+)?(?:{_NOM}|{_MAY})){{1,3}})")
_DNI = re.compile(r"\b(?:\d{1,2}\.\d{3}\.\d{3}|\d{7,8})\b")
_CUIL = re.compile(r"\b(20|23|24|27)-?(\d{8})-?(\d)\b")
_LPU = re.compile(r"(\b(?:L\.?\s?P\.?\s?U\.?|legajo(?:\s+penitenciario)?)\s*+(?:N\s?[°ºo]\.?|nro\.?)?\s*+:?\s*+)(\d[\d.]{2,11}\d)", re.I)
_EXPTE = re.compile(r"\b([A-Z]{2})\s?(\d{1,7})\s?/\s?(\d{2,4})\b")
_GDE = re.compile(r"\b(EX|NO|IF|PV|RS|DI|ME|CE)-(\d{4})-(\d{4,8})\b")
_LIMPIA = re.compile(r"\s+")


def _sin_acentos(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn")


def _clave_persona(nombre: str) -> str:
    return " ".join(sorted(_sin_acentos(nombre).lower().replace(",", " ").split()))


@dataclass
class Anonimizador:
    semilla: str = "dgpdh"
    nombres_conocidos: Iterable[str] = ()
    lugares: Iterable[str] = ()
    generalizar_lugares: bool = False
    personas: dict[str, str] = field(default_factory=dict)
    numeros: dict[str, str] = field(default_factory=dict)
    cuenta: Counter[str] = field(default_factory=Counter)

    def __post_init__(self) -> None:
        conocidos = sorted({n.strip() for n in self.nombres_conocidos if n and len(n.split()) >= 2}, key=len, reverse=True)
        self._conocidos = [re.compile(r"(?<!\w)" + r"[\s,]+".join(re.escape(p) for p in re.split(r"[\s,]+", n) if p) + r"(?!\w)", re.I)
                           for n in conocidos]
        self._lugares = [re.compile(r"(?<!\w)" + re.escape(x) + r"(?!\w)", re.I) for x in sorted(set(self.lugares), key=len, reverse=True) if x]

    # ------------------------------------------------------------ reemplazos consistentes
    def _persona(self, nombre: str) -> str:
        clave = _clave_persona(nombre)
        if clave not in self.personas:
            self.personas[clave] = f"[PERSONA_{len(self.personas) + 1}]"
        self.cuenta["persona"] += 1
        return self.personas[clave]

    def _digitos(self, original: str, tipo: str) -> str:
        """Mismos dígitos de largo y mismos separadores, valores ficticios (deterministas)."""
        clave = f"{tipo}:{re.sub(r'\D', '', original)}"
        if clave not in self.numeros:
            h = hashlib.sha256(f"{self.semilla}|{clave}".encode()).hexdigest()
            fuente = iter(str(int(h, 16)))
            self.numeros[clave] = "".join(next(fuente) if c.isdigit() else c for c in original)
            if self.numeros[clave][:1] == "0" and original[:1] != "0":
                self.numeros[clave] = "1" + self.numeros[clave][1:]
        self.cuenta[tipo] += 1
        return self.numeros[clave]

    # ------------------------------------------------------------ texto
    def texto(self, texto: str | None) -> str:
        t = texto or ""
        t = _GDE.sub(lambda m: f"{m.group(1)}-{m.group(2)}-{self._digitos(m.group(3), 'gde')}", t)
        t = _CUIL.sub(lambda m: self._digitos(m.group(0), "cuil"), t)
        t = _LPU.sub(lambda m: m.group(1) + self._digitos(m.group(2), "lpu"), t)
        t = _EXPTE.sub(lambda m: f"{m.group(1)} {self._digitos(m.group(2), 'expediente')}/{m.group(3)}", t)
        t = _DNI.sub(lambda m: self._digitos(m.group(0), "dni"), t)
        for rx in self._conocidos:
            t = rx.sub(lambda m: self._persona(m.group(0)), t)
        t = _NOMBRE_COMA.sub(lambda m: self._persona(f"{m.group(1)} {m.group(2)}"), t)
        t = _NOMBRE_TITULO.sub(lambda m: m.group(0)[:m.start(1) - m.start(0)] + self._persona(m.group(1)), t)
        if self.generalizar_lugares:
            for rx in self._lugares:
                t, n = rx.subn("[UNIDAD]", t)
                self.cuenta["lugar"] += n
        return t

    # ------------------------------------------------------------ fichas
    def ficha(self, f: Mapping[str, Any]) -> dict[str, Any]:
        """Copia de una ficha de persona detenida sin datos que la identifiquen."""
        salida = dict(f)
        if f.get("nombre_completo"):
            salida["nombre_completo"] = self._persona(str(f["nombre_completo"]))
        for campo in ("apellido", "nombres", "nombre_norm", "alias", "codigo", "defensor", "externo_id"):
            if campo in salida:
                salida[campo] = None
        for campo, tipo in (("dni", "dni"), ("lpu", "lpu"), ("lpu_norm", "lpu"), ("doc_extranjero", "doc"), ("nro_expediente_ppn", "expediente")):
            if salida.get(campo):
                salida[campo] = self._digitos(str(salida[campo]), tipo)
        fn = str(f.get("fecha_nacimiento") or "")
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", fn):  # se conserva el año (la edad), no el día
            h = int(hashlib.sha256(f"{self.semilla}|fn|{fn}".encode()).hexdigest(), 16)
            salida["fecha_nacimiento"] = f"{fn[:4]}-{h % 12 + 1:02d}-{h // 12 % 28 + 1:02d}"
        if salida.get("observaciones"):
            salida["observaciones"] = self.texto(str(salida["observaciones"]))
        return salida

    def sospechosos(self, texto: str) -> list[str]:
        return restos_sospechosos(texto, self.numeros.values())

    def resumen(self) -> dict[str, int]:
        return dict(self.cuenta, personas_distintas=len(self.personas))


def restos_sospechosos(texto: str, ficticios: Iterable[str] = ()) -> list[str]:
    """Para la revisión humana: lo que todavía parece un dato personal (números largos, palabras en mayúscula seguidas).
    `ficticios`: los valores que ya puso el anonimizador (no son sospechosos)."""
    puestos = {re.sub(r"\D", "", x) for x in ficticios}
    sospechas = [m.group(0) for m in re.finditer(r"\b\d{7,}\b", texto) if m.group(0) not in puestos]
    sospechas += [m.group(0) for m in re.finditer(r"\b[A-ZÁÉÍÓÚÑ]{3,}\s+[A-ZÁÉÍÓÚÑ]{3,}\b", texto)
                  if not re.search(r"PERSONA|UNIDAD|DGPDH|PPN|SPF|CPF|APN", m.group(0))]
    return sorted(set(sospechas))


# ---------------------------------------------------------------- propuesta 44: versión testada de un documento
_SALUD = re.compile(r"\b(VIH|HIV|sida|hepatitis\s+[ABC]|tuberculosis|diabetes|epilepsia|tratamiento\s+psiqui[aá]trico|psicof[aá]rmacos?|"
                    r"autolesi[oó]n(?:es)?|intento\s+de\s+suicidio|embarazo|diagn[oó]stico\s+de\s+[\wáéíóú]+)\b", re.I)


def a_testar(texto: str | None, nombres_conocidos: Iterable[str] = ()) -> list[tuple[str, str]]:
    """Propuesta de lo que conviene tachar: [(tipo, texto tal como figura)] sin repetidos, en orden de aparición."""
    t = texto or ""
    hallados: list[tuple[int, str, str]] = []
    for tipo, rx, grupo in (("DNI", _DNI, 0), ("CUIL", _CUIL, 0), ("LPU", _LPU, 2), ("Expediente", _EXPTE, 0), ("Salud", _SALUD, 0),
                            ("Persona", _NOMBRE_COMA, 0), ("Persona", _NOMBRE_TITULO, 1)):
        for m in rx.finditer(t):
            hallados.append((m.start(grupo), tipo, m.group(grupo)))
    for n in sorted({x.strip() for x in nombres_conocidos if x and len(x.split()) >= 2}, key=len, reverse=True):
        for m in re.finditer(r"(?<!\w)" + r"[\s,]+".join(re.escape(p) for p in re.split(r"[\s,]+", n) if p) + r"(?!\w)", t, re.I):
            hallados.append((m.start(), "Persona", m.group(0)))
    vistos: set[str] = set()
    salida = []
    for _, tipo, valor in sorted(hallados):
        if valor.lower() not in vistos:
            vistos.add(valor.lower())
            salida.append((tipo, valor))
    return salida


def testar(texto: str | None, tachar: Iterable[str], marca: str = "[TESTADO]") -> str:
    """El texto con cada valor elegido reemplazado por la marca (el dato desaparece del texto, no se tapa con un rectángulo)."""
    t = texto or ""
    for v in sorted({x for x in tachar if x and x.strip()}, key=len, reverse=True):
        t = re.sub(re.escape(v), marca, t, flags=re.I)
    return t
