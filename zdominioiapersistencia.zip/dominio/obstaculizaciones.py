"""Registro de Obstaculizaciones: reglas puras (validación de la carga y quién ve / edita qué).

Visibilidad (decisión del usuario, 14/11/2026):
- Dirección (Director/a y Subdirector/a) y quien tenga el permiso individual «Consulta de obstaculizaciones»: todo.
- Coordinación: lo de su equipo y lo ocurrido en las unidades de los viajes frecuentes activos de su equipo.
- Resto de las personas con Notas: lo que cargaron y aquello en lo que figuran como intervinientes.
Edición: quien cargó, hasta que se genera el informe o pasan 72 horas; la coordinación de su equipo y la Dirección mientras no
haya informe. Anulación (con motivo): las mismas personas, mientras no haya informe (con informe, solo la Dirección).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from dgpdh.errores import DatoInvalido

HORAS_EDICION = 72
MAX_DESCRIPCION = 8000
CLASES_VINCULO = {"VIAJE": "Viaje", "NOTA": "Nota", "EXPEDIENTE": "Expediente"}
EXTENSIONES_ADJUNTO = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
                       ".heic": "image/heic", ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                       ".mp3": "audio/mpeg", ".m4a": "audio/mp4"}
_HORA = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


@dataclass(frozen=True)
class Persona:
    id: int
    nombre: str
    rol: str
    equipo_id: int | None = None
    es_direccion: bool = False
    consulta: bool = False            # permiso individual «Consulta de obstaculizaciones»
    tiene_notas: bool = True

    @property
    def es_coordinacion(self) -> bool:
        return self.rol == "COORDINADOR"

    @property
    def puede_cargar(self) -> bool:
        return self.tiene_notas and self.rol != "CHOFER"

    @property
    def ve_todo(self) -> bool:
        # el permiso «Consulta» no saltea las exclusiones: choferes y personas sin Notas no acceden nunca
        return (self.es_direccion or self.consulta) and self.puede_cargar

    @property
    def puede_administrar_tipos(self) -> bool:
        return self.es_direccion


@dataclass(frozen=True)
class Carga:
    fecha_hecho: str
    hora_hecho: str
    tipo_id: int
    descripcion: str
    subsanado: bool
    unidad_id: int | None = None
    lugar_otro: str | None = None
    sector: str | None = None
    tipos_extra: tuple[int, ...] = ()
    equipo_id: int | None = None
    fuerza_id: int | None = None
    autoridad: str | None = None
    como_se_subsano: str | None = None
    demora_minutos: int | None = None
    agentes: tuple[tuple[int | None, str], ...] = ()          # (usuario_id o None, nombre)
    vinculos: tuple[tuple[str, int | None, str | None], ...] = field(default=())  # (clase, ref_id, ref_texto)


def _texto(v: object, maximo: int = 300) -> str | None:
    t = re.sub(r"\s+", " ", str(v or "")).strip()[:maximo]
    return t or None


def _lista(v: object) -> list[object]:
    if v is None or v == "":
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [v]


def _entero(v: object, nombre: str, minimo: int = 0, maximo: int = 10**9) -> int | None:
    t = str(v or "").strip()
    if not t:
        return None
    if not t.isdigit() or not (minimo <= int(t) <= maximo):
        raise DatoInvalido(f"{nombre}: tiene que ser un número entre {minimo} y {maximo}.")
    return int(t)


def validar(datos: dict[str, object], *, tipos_activos: set[int], hoy: date | None = None) -> Carga:
    """Valida el formulario de carga. Lanza DatoInvalido con un mensaje para la persona."""
    hoy = hoy or date.today()
    fecha = str(datos.get("fecha_hecho") or "").strip()
    try:
        f = date.fromisoformat(fecha)
    except ValueError:
        raise DatoInvalido("Indicá la fecha del hecho.") from None
    if f > hoy:
        raise DatoInvalido("La fecha del hecho no puede ser posterior a hoy.")
    if f < hoy - timedelta(days=3650):
        raise DatoInvalido("La fecha del hecho es demasiado antigua: revisala.")
    hora = str(datos.get("hora_hecho") or "").strip()[:5]
    if not _HORA.match(hora):
        raise DatoInvalido("Indicá la hora del hecho (HH:MM).")
    unidad_id = _entero(datos.get("unidad_id"), "Establecimiento", 1)
    lugar_otro = _texto(datos.get("lugar_otro"), 200)
    if not unidad_id and not lugar_otro:
        raise DatoInvalido("Indicá el establecimiento, unidad o dependencia afectada.")
    tipo_id = _entero(datos.get("tipo_id"), "Tipo", 1)
    if tipo_id is None or tipo_id not in tipos_activos:
        raise DatoInvalido("Elegí el tipo de obstaculización.")
    extra = tuple(sorted({int(str(x)) for x in _lista(datos.get("tipos_extra")) if str(x).isdigit() and int(str(x)) in tipos_activos and int(str(x)) != tipo_id}))
    equipo_id = _entero(datos.get("equipo_id"), "Equipo", 1)
    agentes: list[tuple[int | None, str]] = []
    for a in _lista(datos.get("agentes")):
        if isinstance(a, tuple) and len(a) == 2:
            uid, nombre = a
            n = _texto(nombre, 120)
            if n:
                agentes.append((int(uid) if uid is not None and str(uid).isdigit() else None, n))
    if not equipo_id and not agentes:
        raise DatoInvalido("Indicá el equipo, la delegación o al menos un agente interviniente.")
    fuerza_id = _entero(datos.get("fuerza_id"), "Fuerza", 1)
    autoridad = _texto(datos.get("autoridad"), 200)
    if not fuerza_id and not autoridad:
        raise DatoInvalido("Indicá la fuerza o autoridad responsable de la obstaculización.")
    descripcion = str(datos.get("descripcion") or "").strip()[:MAX_DESCRIPCION]
    if len(descripcion) < 20:
        raise DatoInvalido("Describí el hecho con más detalle (al menos unas líneas).")
    sub = str(datos.get("subsanado") or "").strip().upper()
    if sub not in ("SI", "NO"):
        raise DatoInvalido("Indicá si se pudo subsanar en el lugar (Sí / No).")
    como = _texto(datos.get("como_se_subsano"), 1000) if sub == "SI" else None
    if sub == "SI" and not como:
        raise DatoInvalido("Contá brevemente cómo se subsanó en el lugar.")
    vinculos: list[tuple[str, int | None, str | None]] = []
    for v in _lista(datos.get("vinculos")):
        if isinstance(v, tuple) and len(v) == 3 and v[0] in CLASES_VINCULO:
            vinculos.append((str(v[0]), int(v[1]) if v[1] is not None and str(v[1]).isdigit() else None, _texto(v[2], 120)))
    return Carga(fecha_hecho=f.isoformat(), hora_hecho=hora, tipo_id=tipo_id, descripcion=descripcion, subsanado=sub == "SI",
                 unidad_id=unidad_id, lugar_otro=None if unidad_id else lugar_otro, sector=_texto(datos.get("sector"), 120),
                 tipos_extra=extra, equipo_id=equipo_id, fuerza_id=fuerza_id, autoridad=autoridad, como_se_subsano=como,
                 demora_minutos=_entero(datos.get("demora_minutos"), "Demora (minutos)", 0, 24 * 60),
                 agentes=tuple(agentes), vinculos=tuple(vinculos))


@dataclass(frozen=True)
class Registro:
    """Lo mínimo de un registro para decidir permisos."""
    cargado_por_id: int
    equipo_id: int | None
    unidad_id: int | None
    creado_en: str
    estado: str
    informe_nota_id: int | None
    agentes_ids: frozenset[int] = frozenset()


def puede_ver(p: Persona, r: Registro, unidades_a_cargo: frozenset[int] = frozenset()) -> bool:
    if p.ve_todo:
        return True
    if not p.tiene_notas or p.rol == "CHOFER":
        return False
    if r.cargado_por_id == p.id or p.id in r.agentes_ids:
        return True
    if p.es_coordinacion:
        return (p.equipo_id is not None and r.equipo_id == p.equipo_id) or (r.unidad_id is not None and r.unidad_id in unidades_a_cargo)
    return False


def _dentro_de_plazo(creado_en: str, ahora: datetime) -> bool:
    try:
        c = datetime.fromisoformat(creado_en)
    except ValueError:
        return False
    if c.tzinfo is None and ahora.tzinfo is not None:
        ahora = ahora.replace(tzinfo=None)
    return ahora - c <= timedelta(hours=HORAS_EDICION)


def puede_editar(p: Persona, r: Registro, ahora: datetime) -> bool:
    if r.estado != "REGISTRADO" or r.informe_nota_id:
        return False
    if p.es_direccion:
        return True
    if p.es_coordinacion and p.equipo_id is not None and r.equipo_id == p.equipo_id:
        return True
    return r.cargado_por_id == p.id and _dentro_de_plazo(r.creado_en, ahora)


def puede_anular(p: Persona, r: Registro, ahora: datetime) -> bool:
    if r.estado != "REGISTRADO":
        return False
    if p.es_direccion:
        return True
    if r.informe_nota_id:
        return False
    return puede_editar(p, r, ahora)


def equipo_permitido(p: Persona, equipo_id: int | None) -> bool:
    """Quien no es de la Dirección registra para su propio equipo (no puede «pasarle» un registro a otro equipo)."""
    return p.es_direccion or equipo_id is None or p.equipo_id is None or equipo_id == p.equipo_id


def puede_adjuntar(p: Persona, r: Registro, ahora: datetime) -> bool:
    """Agregar evidencia es modificar el registro: mismas personas y plazos que editar (no el permiso «Consulta»)."""
    return puede_editar(p, r, ahora)


def puede_generar_informe(p: Persona, r: Registro) -> bool:
    return r.estado == "REGISTRADO" and not r.informe_nota_id and (
        r.cargado_por_id == p.id or p.id in r.agentes_ids or p.es_direccion
        or (p.es_coordinacion and p.equipo_id is not None and r.equipo_id == p.equipo_id))


def formato_numero(anio: int, correlativo: int) -> str:
    return f"OB-{anio}-{correlativo:04d}"
