"""Propuesta 77 (viajes 24): cuadro «propuesto vs. asignado» de una semana. Cálculo puro: salidas, km estimados, horas de
chofer y pedidos sin cubrir, de un lado con los grupos que propuso el planificador y del otro con lo que se asignó."""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

Punto = tuple[float, float]
KmDe = Callable[[list[Punto]], float | None]


@dataclass
class Lado:
    salidas: int = 0
    km: float = 0.0
    horas: float = 0.0
    sin_cubrir: int = 0
    sin_coordenadas: int = 0  # salidas a las que no se les pudo estimar km
    grupos: list[list[int]] = field(default_factory=list)


def _min(h: str | None) -> int | None:
    try:
        hh, mm = (h or "").split(":")[:2]
        return int(hh) * 60 + int(mm)
    except ValueError:
        return None


def _horas(viajes: Sequence[Mapping[str, Any]]) -> float:
    ss = [m for m in (_min(v.get("hora_salida")) for v in viajes) if m is not None]
    rr = [m for m in (_min(v.get("hora_regreso")) for v in viajes) if m is not None]
    if not ss or not rr or max(rr) <= min(ss):
        return 0.0
    return (max(rr) - min(ss)) / 60


def _sumar(lado: Lado, viajes: Sequence[Mapping[str, Any]], km_de: KmDe) -> None:
    lado.salidas += 1
    lado.grupos.append(sorted(int(v["id"]) for v in viajes))
    lado.horas += _horas(viajes)
    puntos: list[Punto] = []
    for v in viajes:
        if v.get("lat") is None or v.get("lng") is None:
            lado.sin_coordenadas += 1
            return
        p = (float(v["lat"]), float(v["lng"]))
        if p not in puntos:
            puntos.append(p)
    km = km_de(puntos)
    if km is None:
        lado.sin_coordenadas += 1
    else:
        lado.km += km


def comparar(viajes: Sequence[Mapping[str, Any]], propuesto: Mapping[int, Mapping[str, Any]], km_de: KmDe) -> dict[str, Any]:
    """viajes: pedidos con chofer de la semana (no cancelados), con id, fecha, horas, chofer_id, vehiculo_id, lat, lng.
    propuesto: {viaje_id: {"clave", "chofer_id", "vehiculo_id"}} (lo último que propuso el planificador).
    Solo se comparan los pedidos que pasaron por el planificador; los demás se cuentan aparte."""
    con_prop = [v for v in viajes if int(v["id"]) in propuesto]
    p, a = Lado(), Lado()
    por_clave: dict[str, list[Mapping[str, Any]]] = {}
    for v in con_prop:
        por_clave.setdefault(str(propuesto[int(v["id"])]["clave"]), []).append(v)
    for clave in sorted(por_clave):
        g = por_clave[clave]
        pr = propuesto[int(g[0]["id"])]
        if not pr.get("chofer_id") or not pr.get("vehiculo_id"):
            p.sin_cubrir += len(g)
            continue
        _sumar(p, g, km_de)
    por_salida: dict[tuple[str, int, int], list[Mapping[str, Any]]] = {}
    for v in con_prop:
        if not v.get("chofer_id") or not v.get("vehiculo_id"):
            a.sin_cubrir += 1
            continue
        por_salida.setdefault((str(v["fecha"]), int(v["chofer_id"]), int(v["vehiculo_id"])), []).append(v)
    for k in sorted(por_salida):
        _sumar(a, por_salida[k], km_de)
    iguales = sum(1 for g in a.grupos if g in p.grupos)
    return {"propuesto": p, "asignado": a, "comparados": len(con_prop), "sin_propuesta": len(viajes) - len(con_prop),
            "salidas_iguales": iguales,
            "diferencia": {"salidas": a.salidas - p.salidas, "km": round(a.km - p.km, 1), "horas": round(a.horas - p.horas, 1),
                           "sin_cubrir": a.sin_cubrir - p.sin_cubrir}}
