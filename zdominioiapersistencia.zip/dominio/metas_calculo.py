"""Cálculos de Metas sin base ni web (propuestas 83, 84, 89 y 91).

83) Proyección al cierre al ritmo actual y lo que falta por mes; «esperado» en días hábiles (con el calendario único).
84) Cambio de estado que merece aviso: solo cuando un indicador PASA a «atrasada» (no cada día que sigue atrasado).
89) Calidad de la visita: proporciones que salen de lo ya cargado (pabellones, audiencias, obstáculos, entrevistas informadas).
91) Completitud de la carga: «no se cargó» es distinto de «se cargó 0».
"""
from __future__ import annotations

import math
from collections.abc import Collection, Iterable
from dataclasses import dataclass
from datetime import date

from dgpdh.dominio import calendario as cal


@dataclass(frozen=True)
class Proyeccion:
    esperado_habil: int            # meta × días hábiles transcurridos / días hábiles del año
    proyeccion: int | None         # cómo cerraría el año al ritmo actual (None si todavía no empezó)
    pct_proyeccion: int | None     # proyección / meta
    por_mes: int | None            # cuánto hay que hacer por mes, desde este mes, para llegar
    meses_restantes: int


def meses_restantes(anio: int, hoy: date) -> int:
    """Meses que quedan para trabajar en el año, contando el actual (0 si el año ya terminó)."""
    if hoy.year > anio:
        return 0
    if hoy.year < anio:
        return 12
    return 12 - hoy.month + 1


def proyectar(meta: int, hecho: int, anio: int, hoy: date, feriados: Collection[date] = ()) -> Proyeccion:
    frac = cal.fraccion_habil(date(anio, 1, 1), date(anio, 12, 31), hoy, feriados)
    esperado = math.floor(meta * frac) if meta else 0
    proy = round(hecho / frac) if frac > 0 else None
    pct = round(100 * proy / meta) if (meta and proy is not None) else None
    quedan = meses_restantes(anio, hoy)
    falta = max(0, meta - hecho)
    por_mes = (math.ceil(falta / quedan) if quedan else None) if meta else None
    return Proyeccion(esperado, proy, pct, por_mes, quedan)


# ---------------------------------------------------------------- 91) completitud
def meses_cerrados(anio: int, hoy: date) -> list[int]:
    """Meses ya terminados del año (los que tendrían que estar cargados)."""
    if hoy.year > anio:
        return list(range(1, 13))
    if hoy.year < anio:
        return []
    return list(range(1, hoy.month))


def meses_de_periodo(periodo: str) -> list[int]:
    p = periodo.upper()
    if p.startswith("M") and p[1:].isdigit():
        return [int(p[1:])]
    if p.startswith("T") and p[1:].isdigit():
        t = int(p[1:])
        return [3 * (t - 1) + 1, 3 * (t - 1) + 2, 3 * (t - 1) + 3]
    return []


@dataclass(frozen=True)
class Completitud:
    cerrados: tuple[int, ...]
    cargados: tuple[int, ...]
    faltan: tuple[int, ...]

    @property
    def nivel(self) -> str:
        """ok: todo cargado · medio: falta un mes · alto: faltan dos o más · sin: todavía no hay meses cerrados."""
        if not self.cerrados:
            return "sin"
        return "ok" if not self.faltan else ("medio" if len(self.faltan) == 1 else "alto")


def completitud(anio: int, hoy: date, periodos_cargados: Iterable[str]) -> Completitud:
    cerr = meses_cerrados(anio, hoy)
    carg = sorted({m for p in periodos_cargados for m in meses_de_periodo(p)})
    return Completitud(tuple(cerr), tuple(m for m in carg if m in cerr), tuple(m for m in cerr if m not in carg))


def estado_con_carga(estado: str, fuente: str, hecho: int, completo: Completitud) -> str:
    """Un indicador de carga manual en 0 y sin ningún mes cerrado cargado no está «atrasado»: está «sin carga»."""
    if estado == "atrasada" and fuente == "carga" and hecho == 0 and completo.cerrados and not completo.cargados:
        return "sin_carga"
    return estado


# ---------------------------------------------------------------- 84) avisos de cambio de estado
def pasa_a_atrasada(anterior: str | None, nuevo: str) -> bool:
    """Avisa solo al cambiar: la primera evaluación (sin estado anterior) no avisa, y si ya estaba atrasada tampoco."""
    return anterior is not None and anterior != "atrasada" and nuevo == "atrasada"


# ---------------------------------------------------------------- 89) calidad de la visita
@dataclass(frozen=True)
class Visita:
    con_pabellones: bool
    audiencias: int
    informada: bool        # alguien del equipo informó sus audiencias (aunque sean 0)
    con_obstaculos: bool


def _pct(n: int, total: int) -> int | None:
    return round(100 * n / total) if total else None


def calidad(visitas: list[Visita]) -> dict[str, object]:
    n = len(visitas)
    informadas = [v for v in visitas if v.informada]
    return {
        "visitas": n,
        "pct_pabellones": _pct(sum(1 for v in visitas if v.con_pabellones), n),
        "audiencias_por_visita": round(sum(v.audiencias for v in informadas) / len(informadas), 1) if informadas else None,
        "pct_obstaculos": _pct(sum(1 for v in visitas if v.con_obstaculos), n),
        "pct_informadas": _pct(len(informadas), n),
    }


# ---------------------------------------------------------------- 93) esperado ajustado por días disponibles
def esperado_ajustado(meta: int, anio: int, hoy: date, feriados: Collection[date], no_disponible: Collection[date]) -> int | None:
    """Meta × días hábiles en que la persona estuvo disponible / días hábiles del año. No reemplaza al esperado lineal: la
    meta fijada por la Dirección no cambia. None si no hay datos de ausencias para esa persona."""
    if not meta or not no_disponible:
        return None
    fin = min(hoy, date(anio, 12, 31))
    if fin < date(anio, 1, 1):
        return 0
    total = cal.habiles_entre(date(anio, 1, 1), date(anio, 12, 31), feriados)
    disponibles = sum(1 for d in cal.dias(date(anio, 1, 1), fin) if cal.es_habil(d, feriados) and d not in no_disponible)
    return math.floor(meta * disponibles / total) if total else None
