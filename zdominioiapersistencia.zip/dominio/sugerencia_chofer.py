"""Modificación 5: sugerencia de chofer por ruta compartida (lógica pura, sin base ni web).

Prioridad 1: chofer que ya tiene un viaje asignado el mismo día a ±1 hora, hacia la misma unidad, complejo o ciudad (el
             criterio de «misma salida»), con plazas libres suficientes. Va preseleccionado: «comparte viaje #N (k plazas libres)».
Prioridad 2: choferes libres, primero los de menos salidas en la semana.
Prioridad 3: ocupados en otra zona o sin lugar.
Los bloqueos que ya existen (licencia, licencia de conducir vencida, reserva, requisitos) mandan: un chofer bloqueado nunca se
preselecciona y va al final, con su motivo. La coordinación decide.
"""
from __future__ import annotations

from dataclasses import dataclass

VENTANA_MINUTOS = 60


@dataclass(frozen=True)
class Chofer:
    id: int
    nombre: str
    salidas_semana: int
    bloqueado: bool = False
    motivo_bloqueo: str = ""


@dataclass(frozen=True)
class ViajeDelDia:
    id: int
    chofer_id: int
    salida_min: int | None
    misma_zona: bool            # destinos vecinos (misma unidad, complejo o ciudad)
    plazas_libres: int | None   # None: el vehículo no tiene capacidad cargada
    se_pisa: bool = True        # el horario se superpone con el pedido


@dataclass(frozen=True)
class Sugerencia:
    chofer_id: int
    prioridad: int              # 1, 2, 3 (4 = bloqueado)
    etiqueta: str
    preseleccionar: bool
    comparte_viaje: int | None = None
    plazas_libres: int | None = None


def _cerca(a: int | None, b: int | None, ventana: int) -> bool:
    return abs((a if a is not None else 8 * 60) - (b if b is not None else 8 * 60)) <= ventana


def ordenar(choferes: list[Chofer], viajes: list[ViajeDelDia], personas: int, salida_min: int | None,
            ventana: int = VENTANA_MINUTOS) -> list[Sugerencia]:
    salida: list[tuple[tuple[int, int, int, str], Sugerencia]] = []
    for c in choferes:
        propios = [v for v in viajes if v.chofer_id == c.id]
        semana = f"{c.salidas_semana} salida{'s' if c.salidas_semana != 1 else ''} esta semana"
        if c.bloqueado:
            s = Sugerencia(c.id, 4, f"{c.motivo_bloqueo or 'no disponible'}", False)
            salida.append(((4, 0, c.salidas_semana, c.nombre), s))
            continue
        compartible = sorted((v for v in propios if v.misma_zona and _cerca(v.salida_min, salida_min, ventana)
                              and (v.plazas_libres is None or v.plazas_libres >= personas)),
                             key=lambda v: (-(v.plazas_libres if v.plazas_libres is not None else 0), v.id))
        if compartible:
            v = compartible[0]
            libres = f"{v.plazas_libres} plaza{'s' if v.plazas_libres != 1 else ''} libre{'s' if v.plazas_libres != 1 else ''}" if v.plazas_libres is not None else "capacidad sin cargar"
            s = Sugerencia(c.id, 1, f"comparte viaje #{v.id} ({libres})", False, v.id, v.plazas_libres)
            salida.append(((1, -(v.plazas_libres or 0), c.salidas_semana, c.nombre), s))
        elif any(v.se_pisa for v in propios):
            otro = next(v for v in propios if v.se_pisa)
            por = "sin lugar" if otro.misma_zona else "en otra zona"
            s = Sugerencia(c.id, 3, f"ocupado en el viaje #{otro.id} ({por}) · {semana}", False, None)
            salida.append(((3, 0, c.salidas_semana, c.nombre), s))
        else:
            s = Sugerencia(c.id, 2, semana, False)
            salida.append(((2, 0, c.salidas_semana, c.nombre), s))
    salida.sort(key=lambda x: x[0])
    ordenadas = [s for _, s in salida]
    for i, s in enumerate(ordenadas):  # se preselecciona el primero que no esté bloqueado ni ocupado sin lugar
        if s.prioridad in (1, 2):
            ordenadas[i] = Sugerencia(s.chofer_id, s.prioridad, s.etiqueta, True, s.comparte_viaje, s.plazas_libres)
            break
    return ordenadas
