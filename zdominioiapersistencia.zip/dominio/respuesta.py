"""Propuesta 74 (viajes 21): tiempo de respuesta de la coordinación (pedido → asignación de chofer).

Semáforo de antigüedad para cada pedido sin asignar: ámbar desde 24 horas hábiles de espera, rojo desde 48 horas hábiles o
si faltan menos de 48 horas para el viaje. Las horas hábiles descuentan sábados, domingos y feriados del calendario único.
"""
from __future__ import annotations

import statistics
from collections.abc import Collection, Iterable
from datetime import date, datetime, timedelta

from dgpdh.dominio import calendario as cal

AMBAR_H, ROJO_H, CERCA_H = 24, 48, 48


def horas_habiles(desde: datetime, hasta: datetime, feriados: Collection[date] = ()) -> float:
    """Horas transcurridas contando solo los días hábiles (un día hábil completo son 24 h)."""
    if hasta <= desde:
        return 0.0
    total, t = 0.0, desde
    while t < hasta:
        fin_dia = datetime.combine(t.date() + timedelta(days=1), datetime.min.time(), tzinfo=t.tzinfo)
        tramo = min(fin_dia, hasta)
        if cal.es_habil(t.date(), feriados):
            total += (tramo - t).total_seconds() / 3600
        t = tramo
    return round(total, 1)


def semaforo(espera_h: float, horas_hasta_viaje: float | None) -> tuple[str, str]:
    """(nivel, texto) para un pedido sin asignar."""
    texto = f"espera {round(espera_h)} h hábiles"
    if espera_h >= ROJO_H or (horas_hasta_viaje is not None and horas_hasta_viaje < CERCA_H):
        return "alto", texto + (" · el viaje es en menos de 48 h" if horas_hasta_viaje is not None and horas_hasta_viaje < CERCA_H else "")
    if espera_h >= AMBAR_H:
        return "medio", texto
    return "ok", texto


def mediana_por_mes(pares: Iterable[tuple[str, float]]) -> list[dict[str, object]]:
    """pares = [(mes AAAA-MM de la asignación, horas hábiles hasta asignar)] → [{mes, pedidos, mediana_h}]."""
    por: dict[str, list[float]] = {}
    for mes, h in pares:
        por.setdefault(mes, []).append(h)
    return [{"mes": m, "pedidos": len(v), "mediana_h": round(statistics.median(v), 1)} for m, v in sorted(por.items())]
