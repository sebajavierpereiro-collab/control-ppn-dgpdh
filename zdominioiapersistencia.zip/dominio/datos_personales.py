"""Datos personales (Ley 25.326): reglas puras para documentos de identidad.

- Propuesta 40: reconocer un CUIL/CUIT, controlar su dígito verificador (módulo 11), sacar el DNI y avisar si no coincide.
- Propuesta 47: tapar parcialmente los números de documento en lo que se guarda como constancia (`30.xxx.x45`).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

PREFIJOS_PERSONA = ("20", "23", "24", "27")
PREFIJOS_EMPRESA = ("30", "33", "34")
_PESOS = (5, 4, 3, 2, 7, 6, 5, 4, 3, 2)
_DOCUMENTO = re.compile(r"(?<![\d.\-/])(\d{1,3}(?:\.\d{3}){1,3}|\d{2}-\d{7,8}-\d|\d{6,11})(?![\d/]|\.\d)")


def solo_digitos(valor: object) -> str:
    return re.sub(r"\D", "", str(valor or ""))


def digito_verificador(base10: str) -> int | None:
    """Dígito verificador de los primeros 10 dígitos de un CUIL/CUIT. None si no corresponde ninguno (resto 1)."""
    if len(base10) != 10 or not base10.isdigit():
        return None
    resto = sum(int(d) * p for d, p in zip(base10, _PESOS, strict=True)) % 11
    if resto == 0:
        return 0
    if resto == 1:
        return 9 if base10[:2] == "23" else None
    return 11 - resto


@dataclass(frozen=True)
class Cuil:
    numero: str          # 11 dígitos
    valido: bool
    dni: str             # el documento que contiene (sin ceros a la izquierda)
    motivo: str | None   # por qué no es válido


def parece_cuil(valor: object) -> bool:
    d = solo_digitos(valor)
    return len(d) == 11 and d[:2] in PREFIJOS_PERSONA + PREFIJOS_EMPRESA


def analizar_cuil(valor: object) -> Cuil | None:
    """None si no tiene forma de CUIL/CUIT (11 dígitos con prefijo conocido)."""
    d = solo_digitos(valor)
    if not parece_cuil(d):
        return None
    esperado = digito_verificador(d[:10])
    dni = d[2:10].lstrip("0")
    if esperado is None:
        return Cuil(d, False, dni, "el número no admite dígito verificador")
    if esperado != int(d[10]):
        return Cuil(d, False, dni, f"el dígito verificador debería ser {esperado}")
    return Cuil(d, True, dni, None)


def avisos_cuil(cuil: object, dni_ficha: object) -> list[str]:
    """Avisos (nunca bloquea): dígito verificador mal o DNI distinto al de la ficha."""
    c = analizar_cuil(cuil)
    if c is None:
        return []
    avisos = []
    if not c.valido:
        avisos.append(f"El CUIL {c.numero} no es válido: {c.motivo}.")
    d = solo_digitos(dni_ficha).lstrip("0")
    if d and c.dni != d:
        avisos.append(f"El CUIL {c.numero} contiene el DNI {c.dni}, distinto del DNI de la ficha ({d}).")
    return avisos


def tapar(numero: str) -> str:
    """Deja los dos primeros y los dos últimos dígitos: 30.123.445 → 30.xxx.x45. Respeta puntos y guiones."""
    total = sum(c.isdigit() for c in numero)
    if total < 6:
        return numero
    salida, visto = [], 0
    for c in numero:
        if c.isdigit():
            visto += 1
            salida.append(c if visto <= 2 or visto > total - 2 else "x")
        else:
            salida.append(c)
    return "".join(salida)


def tapar_documentos(texto: str | None) -> str:
    """Tapa en un texto los números con forma de DNI, CUIL o LPU (6 a 11 dígitos, con o sin puntos)."""
    if not texto:
        return texto or ""
    return _DOCUMENTO.sub(lambda m: tapar(m.group(0)), texto)
