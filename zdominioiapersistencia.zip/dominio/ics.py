"""Propuesta 67 (viajes 14): exportar viajes a un calendario .ics (RFC 5545), a pedido.

Un VEVENT por viaje con UID estable, STATUS (TENTATIVE si falta confirmar o asignar, CONFIRMED, CANCELLED) y SEQUENCE que
sube con cada reprogramación: así el calendario de la PC actualiza el evento en vez de duplicarlo. Solo lleva la unidad, el
horario y quiénes viajan: nunca datos de personas detenidas.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone

ESTADOS = {"A_CONFIRMAR": "TENTATIVE", "SOLICITADO": "TENTATIVE", "CONFIRMADO": "CONFIRMED", "CANCELADO": "CANCELLED"}


@dataclass(frozen=True)
class Evento:
    id: int
    fecha: str                # AAAA-MM-DD
    hora_salida: str | None   # HH:MM
    hora_regreso: str | None
    destino: str
    lugar: str
    estado: str
    secuencia: int
    personas: tuple[str, ...]
    detalle: str = ""


def _esc(t: str) -> str:
    return t.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r", "").replace("\n", "\\n")


def _plegar(linea: str) -> list[str]:
    """Líneas de hasta 75 octetos (RFC 5545 §3.1), sin cortar caracteres UTF-8."""
    out: list[str] = []
    actual = ""
    for ch in linea:
        if len((actual + ch).encode("utf-8")) > (75 if not out else 74):
            out.append(actual)
            actual = ch
        else:
            actual += ch
    out.append(actual)
    return [out[0]] + [" " + x for x in out[1:]]


def _hora(fecha: str, hora: str | None, defecto: str) -> str:
    h = hora if hora and len(hora) >= 5 else defecto
    return fecha.replace("-", "") + "T" + h[:2] + h[3:5] + "00"


def calendario(eventos: Iterable[Evento], nombre: str, ahora: datetime | None = None) -> str:
    sello = (ahora or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%SZ")
    lineas = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//PPN DGPDH//Autos PPN//ES", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
              f"X-WR-CALNAME:{_esc(nombre)}"]
    for e in eventos:
        salida = e.hora_salida if e.hora_salida and len(e.hora_salida) >= 5 else "08:00"
        regreso = e.hora_regreso if e.hora_regreso and len(e.hora_regreso) >= 5 and e.hora_regreso > salida else None
        inicio = _hora(e.fecha, salida, salida)
        fin = _hora(e.fecha, regreso, f"{min(23, int(salida[:2]) + 4):02d}:{salida[3:5]}")
        desc = "Viajan: " + ", ".join(e.personas) + (f"\n{e.detalle}" if e.detalle else "")
        for ln in ("BEGIN:VEVENT", f"UID:viaje-{e.id}@dgpdh", f"DTSTAMP:{sello}", f"DTSTART:{inicio}", f"DTEND:{fin}",
                   f"SUMMARY:{_esc('Viaje a ' + e.destino)}", f"LOCATION:{_esc(e.lugar or e.destino)}", f"DESCRIPTION:{_esc(desc)}",
                   f"STATUS:{ESTADOS.get(e.estado, 'TENTATIVE')}", f"SEQUENCE:{max(0, e.secuencia)}", "END:VEVENT"):
            lineas.extend(_plegar(ln))
    lineas.append("END:VCALENDAR")
    return "\r\n".join(lineas) + "\r\n"
