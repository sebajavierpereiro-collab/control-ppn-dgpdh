"""Propuesta 53: reconocer los números GDE (Gestión Documental Electrónica del Estado nacional) como referencia externa.

Formato (Decreto 561/2016): `TIPO-AAAA-NNNNNNNN-APN-REPARTICIÓN#ORGANISMO`, por ejemplo `NO-2025-12345678-APN-DGPDH#PPN` o
`EX-2025-00123456- -APN-DD#MJ` (el expediente suele llevar un guion de más). Se normalizan a `TIPO-AAAA-NNNNNNNN` para poder
cruzar notas que citan el mismo documento, y se propone el tipo de vínculo cuando el texto lo dice («en respuesta a la NO-…»).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

TIPOS = {"EX": "Expediente", "NO": "Nota", "IF": "Informe", "PV": "Providencia", "RS": "Resolución", "RESOL": "Resolución",
         "DI": "Disposición", "DECTO": "Decreto", "ME": "Memorándum", "CE": "Comunicación", "ACTA": "Acta", "DCTO": "Decreto"}
_GDE = re.compile(r"\b(" + "|".join(sorted(TIPOS, key=len, reverse=True)) + r")\s*-\s*(\d{4})\s*-\s*(\d{4,8})"
                  r"(?:\s*-\s*(?:-\s*)?([A-Z]{2,5})\s*-\s*([A-Z0-9]+(?:#[A-Z0-9]+)?))?", re.I)
_VINCULOS = (("responde a", re.compile(r"(en\s+respuesta\s+a|respondiendo\s+a|en\s+contestaci[oó]n\s+a|contestando)\W+(?:\w+\W+){0,4}$", re.I)),
             ("reitera a", re.compile(r"(reiter\w+|se\s+reitera)\W+(?:\w+\W+){0,4}$", re.I)),
             ("amplía", re.compile(r"(ampl[ií]\w+)\W+(?:\w+\W+){0,4}$", re.I)))


@dataclass(frozen=True)
class ReferenciaGDE:
    numero: str            # normalizado: NO-2025-12345678
    texto: str             # tal como figura
    tipo: str              # Nota, Expediente…
    reparticion: str | None
    vinculo: str | None    # tipo de vínculo propuesto (responde a, reitera a, amplía) o None


def gde_del_texto(texto: str | None) -> list[ReferenciaGDE]:
    salida: dict[str, ReferenciaGDE] = {}
    for m in _GDE.finditer(texto or ""):
        sigla = m.group(1).upper()
        numero = f"{sigla}-{m.group(2)}-{int(m.group(3)):08d}"
        antes = (texto or "")[max(0, m.start() - 60):m.start()]
        vinculo = next((nombre for nombre, rx in _VINCULOS if rx.search(antes)), None)
        if numero not in salida or (vinculo and not salida[numero].vinculo):
            salida[numero] = ReferenciaGDE(numero, re.sub(r"\s+", " ", m.group(0)).strip(), TIPOS[sigla],
                                           m.group(5).upper() if m.group(5) else None, vinculo)
    return list(salida.values())
