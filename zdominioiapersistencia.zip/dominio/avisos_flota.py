"""Propuesta 64: días de aviso por tipo de control y qué avisos internos corresponden. Cálculo puro."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import date
from typing import Any

TIPOS_PROVEEDOR = {"ASEGURADORA": "Aseguradora", "TALLER": "Taller", "ESTACION": "Estación de servicio", "GOMERIA": "Gomería",
                   "VTV": "Planta de VTV", "OTRO": "Otro"}
DIAS_POR_DEFECTO = {"VTV": 45, "SEGURO": 30, "MATAFUEGO": 15}
DIAS_GENERAL = 30
DIAS_MIN, DIAS_MAX = 1, 365


def dias_aviso(tipo: str, configurados: Mapping[str, int] | None = None) -> int:
    if configurados and tipo in configurados:
        return int(configurados[tipo])
    return DIAS_POR_DEFECTO.get(tipo, DIAS_GENERAL)


def validar_dias(valor: object) -> int | None:
    """None si el texto está vacío (vuelve al valor por defecto); ValueError si no es un número válido."""
    t = str(valor or "").strip()
    if not t:
        return None
    if not t.isdigit() or not DIAS_MIN <= int(t) <= DIAS_MAX:
        raise ValueError(f"Los días de aviso van de {DIAS_MIN} a {DIAS_MAX}.")
    return int(t)


def pendientes(controles: Iterable[Mapping[str, Any]], configurados: Mapping[str, int], hoy: date,
               enviados: set[tuple[int, int, str]]) -> list[dict[str, Any]]:
    """controles: el último control de cada tipo y vehículo, con id, tipo, vence_fecha y responsable_id.
    Devuelve los avisos a mandar: «pronto» al entrar en los días de aviso y «vencido» al pasar la fecha, una sola vez cada uno."""
    out = []
    for c in controles:
        uid, vence = c.get("responsable_id"), c.get("vence_fecha")
        if not uid or not vence:
            continue
        faltan = (date.fromisoformat(str(vence)[:10]) - hoy).days
        nivel = "vencido" if faltan < 0 else ("pronto" if faltan <= dias_aviso(str(c["tipo"]), configurados) else None)
        if nivel and (int(c["id"]), int(uid), nivel) not in enviados:
            out.append({"control_id": int(c["id"]), "usuario_id": int(uid), "nivel": nivel, "faltan": faltan, "control": c})
    return out
