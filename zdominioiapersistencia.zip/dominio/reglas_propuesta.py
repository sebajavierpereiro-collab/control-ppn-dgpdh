"""Propuesta 2: reglas «si pasa esto, proponé aquello».

Disparador (al subir, al enviar a Coordinación, al firmar) + condición (el texto contiene…, tipo documental, unidad, equipo)
→ acción **propuesta** (prioridad, aviso a un equipo, plazo, etiqueta). La regla nunca cambia la nota: deja una sugerencia que
una persona acepta o descarta.
"""
from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from dgpdh.errores import DatoInvalido

DISPARADORES = {"SUBIDA": "Al subir", "ENVIO": "Al enviar a Coordinación", "FIRMA": "Al firmar"}
CONDICIONES = {"texto_contiene": "El texto contiene", "tipo_documental": "El tipo documental es", "unidad": "Menciona la unidad",
               "equipo": "Es del equipo"}
ACCIONES = {"prioridad": "Proponer prioridad", "aviso_equipo": "Proponer avisar al equipo", "plazo_dias": "Proponer plazo (días)",
            "etiqueta": "Proponer etiqueta"}
PRIORIDADES = ("URGENTE", "PRIORITARIA", "NORMAL")


def _norm(t: object) -> str:
    s = "".join(c for c in unicodedata.normalize("NFD", str(t or "").lower()) if unicodedata.category(c) != "Mn")
    return " ".join(s.split())


@dataclass(frozen=True)
class Regla:
    id: int
    nombre: str
    disparador: str
    condicion: str
    condicion_valor: str
    accion: str
    accion_valor: str
    activa: bool = True

    @property
    def descripcion(self) -> str:
        return (f"{DISPARADORES.get(self.disparador, self.disparador)}, si {CONDICIONES.get(self.condicion, self.condicion).lower()} "
                f"«{self.condicion_valor}»: {ACCIONES.get(self.accion, self.accion).lower()} «{self.accion_valor}»")


def validar(datos: Mapping[str, Any]) -> dict[str, str]:
    d = {k: str(datos.get(k) or "").strip() for k in ("nombre", "disparador", "condicion", "condicion_valor", "accion", "accion_valor")}
    if not d["nombre"]:
        raise DatoInvalido("Poné un nombre a la regla.")
    if d["disparador"] not in DISPARADORES or d["condicion"] not in CONDICIONES or d["accion"] not in ACCIONES:
        raise DatoInvalido("Elegí cuándo corre, la condición y la acción.")
    if not d["condicion_valor"] or not d["accion_valor"]:
        raise DatoInvalido("Completá el valor de la condición y el de la acción.")
    if d["accion"] == "prioridad":
        d["accion_valor"] = d["accion_valor"].upper()
        if d["accion_valor"] not in PRIORIDADES:
            raise DatoInvalido("La prioridad es URGENTE, PRIORITARIA o NORMAL.")
    if d["accion"] == "plazo_dias" and not re.fullmatch(r"\d{1,3}", d["accion_valor"]):
        raise DatoInvalido("El plazo es una cantidad de días.")
    if d["condicion"] in ("unidad", "equipo", "aviso_equipo") and not d["condicion_valor"].isdigit():
        raise DatoInvalido("Elegí la unidad o el equipo de la lista.")
    if d["accion"] == "aviso_equipo" and not d["accion_valor"].isdigit():
        raise DatoInvalido("Elegí el equipo al que se propone avisar.")
    d["nombre"], d["condicion_valor"], d["accion_valor"] = d["nombre"][:120], d["condicion_valor"][:200], d["accion_valor"][:120]
    return d


def cumple(regla: Regla, *, disparador: str, texto: str, tipo_documental: str | None, unidades: Iterable[int], equipo_id: int | None) -> bool:
    if not regla.activa or regla.disparador != disparador:
        return False
    if regla.condicion == "texto_contiene":
        return _norm(regla.condicion_valor) in _norm(texto)
    if regla.condicion == "tipo_documental":
        return (tipo_documental or "").upper() == regla.condicion_valor.upper()
    if regla.condicion == "unidad":
        return regla.condicion_valor in {str(u) for u in unidades}
    if regla.condicion == "equipo":
        return str(equipo_id or "") == regla.condicion_valor
    return False
