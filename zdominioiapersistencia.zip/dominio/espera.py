"""Propuesta 75: orden sugerido de la lista de espera. Primero las urgencias (medida de fuerza, huelga de hambre, hábeas
corpus, pedido judicial), después la rutina; dentro de cada grupo, por antigüedad. Si la coordinación reordenó la lista, manda
ese orden (y queda registrado quién y cuándo)."""
from __future__ import annotations

from typing import Any

MOTIVOS: dict[str, str] = {
    "MEDIDA_FUERZA": "Medida de fuerza", "HUELGA_HAMBRE": "Huelga de hambre", "HABEAS_CORPUS": "Hábeas corpus",
    "PEDIDO_JUDICIAL": "Pedido judicial", "RUTINA": "Rutina",
}


def es_urgente(motivo: str | None) -> bool:
    return bool(motivo) and motivo in MOTIVOS and motivo != "RUTINA"


def ordenar(lista: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def clave(e: dict[str, Any]) -> tuple[int, int, int, str, int]:
        manual = e.get("orden_manual")
        return (0 if manual is not None else 1, int(manual or 0), 0 if es_urgente(e.get("motivo")) else 1, str(e.get("creado_en") or ""), int(e["id"]))
    return sorted(lista, key=clave)


def mover(ids: list[int], espera_id: int, hacia: str) -> list[int]:
    """Nuevo orden al subir o bajar un lugar a `espera_id`."""
    if espera_id not in ids:
        return ids
    i = ids.index(espera_id)
    j = i - 1 if hacia == "subir" else i + 1
    if not 0 <= j < len(ids):
        return ids
    nuevo = list(ids)
    nuevo[i], nuevo[j] = nuevo[j], nuevo[i]
    return nuevo
