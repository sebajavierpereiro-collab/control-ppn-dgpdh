"""Propuesta 38: historial de alojamiento por persona («dónde estuvo y desde cuándo»).

Los cambios de unidad ya quedan campo por campo en `detenidos_cambios`. Acá se arman los tramos (unidad, desde, hasta,
listado de origen) recorriendo esos cambios hacia atrás desde el alojamiento actual de la ficha. La fecha de cada tramo es la
fecha del listado que informó el cambio cuando se conoce (más fiel que la fecha de carga).
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

CAMPOS = ("unidad_id", "centro_otro")


@dataclass(frozen=True)
class Tramo:
    unidad_id: int | None
    centro_otro: str | None
    desde: str | None      # AAAA-MM-DD (None: desde el alta, sin fecha)
    hasta: str | None      # None: sigue ahí
    listado_id: int | None

    def lugar(self, nombres: Mapping[int, str]) -> str:
        if self.unidad_id is not None:
            return nombres.get(self.unidad_id, f"Unidad #{self.unidad_id}")
        return self.centro_otro or "Sin dato"


def _entero(v: object) -> int | None:
    try:
        return int(str(v)) if v not in (None, "") else None
    except ValueError:
        return None


def tramos(actual: Mapping[str, Any], cambios: Iterable[Mapping[str, Any]], fechas_listado: Mapping[int, str] | None = None) -> list[Tramo]:
    """`actual`: la ficha (unidad_id, centro_otro, creado_en). `cambios`: filas de detenidos_cambios (cualquier orden).
    Devuelve los tramos del más nuevo al más viejo."""
    fechas_listado = fechas_listado or {}
    eventos: dict[tuple[str, int | None], dict[str, Any]] = {}
    for c in sorted(cambios, key=lambda c: (str(c.get("fecha") or ""), int(c.get("id") or 0))):
        if c.get("campo") not in CAMPOS:
            continue
        lid = _entero(c.get("listado_id"))
        fecha = (fechas_listado.get(lid) if lid else None) or str(c.get("fecha") or "")[:10]
        clave = (str(c.get("fecha") or "")[:19], lid)
        ev = eventos.setdefault(clave, {"fecha": fecha, "listado_id": lid, "antes": {}, "despues": {}})
        ev["antes"][c["campo"]] = c.get("antes")
        ev["despues"][c["campo"]] = c.get("despues")
    salida: list[Tramo] = []
    unidad, otro = _entero(actual.get("unidad_id")), actual.get("centro_otro") or None
    hasta: str | None = None
    for ev in sorted(eventos.values(), key=lambda e: e["fecha"], reverse=True):
        salida.append(Tramo(unidad, otro, ev["fecha"], hasta, ev["listado_id"]))
        if "unidad_id" in ev["antes"]:
            unidad = _entero(ev["antes"]["unidad_id"])
        if "centro_otro" in ev["antes"]:
            otro = ev["antes"]["centro_otro"] or None
        hasta = ev["fecha"]
    if unidad is not None or otro:
        salida.append(Tramo(unidad, otro, None, hasta, None))
    return [t for t in salida if t.unidad_id is not None or t.centro_otro]


def en_fecha(lista: Iterable[Tramo], fecha: str) -> Tramo | None:
    """El tramo vigente en esa fecha (AAAA-MM-DD)."""
    for t in lista:
        if (t.desde is None or t.desde <= fecha) and (t.hasta is None or fecha < t.hasta):
            return t
    return None
