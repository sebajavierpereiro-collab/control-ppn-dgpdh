"""Propuesta 55 (viajes 2): orden sugerido de las paradas de una salida. Vecino más cercano y mejora 2-opt, en Python puro,
con la distancia que se le pase (OSRM local si está configurado; si no, línea recta × factor). El sistema solo propone:
la coordinación confirma y queda en el historial."""
from __future__ import annotations

from collections.abc import Callable, Sequence

Distancia = Callable[[int, int], float]


def largo(orden: Sequence[int], dist: Distancia, origen: int | None = None) -> float:
    """Largo del recorrido (desde el origen, si hay, por las paradas en orden y de vuelta al origen)."""
    puntos = ([origen] if origen is not None else []) + list(orden) + ([origen] if origen is not None else [])
    return sum(dist(a, b) for a, b in zip(puntos, puntos[1:], strict=False))


def vecino_mas_cercano(nodos: Sequence[int], dist: Distancia, origen: int | None = None) -> list[int]:
    pendientes = list(nodos)
    if not pendientes:
        return []
    actual = origen if origen is not None else pendientes.pop(0)
    orden = [] if origen is not None else [actual]
    while pendientes:
        siguiente = min(pendientes, key=lambda n: (dist(actual, n), n))
        pendientes.remove(siguiente)
        orden.append(siguiente)
        actual = siguiente
    return orden


def dos_opt(orden: list[int], dist: Distancia, origen: int | None = None) -> list[int]:
    mejor = list(orden)
    mejoro = True
    while mejoro:
        mejoro = False
        for i in range(len(mejor) - 1):
            for j in range(i + 1, len(mejor)):
                prueba = mejor[:i] + mejor[i:j + 1][::-1] + mejor[j + 1:]
                if largo(prueba, dist, origen) + 1e-9 < largo(mejor, dist, origen):
                    mejor, mejoro = prueba, True
    return mejor


def sugerir(nodos: Sequence[int], dist: Distancia, origen: int | None = None) -> list[int]:
    if len(nodos) <= 1:
        return list(nodos)
    return dos_opt(vecino_mas_cercano(nodos, dist, origen), dist, origen)
