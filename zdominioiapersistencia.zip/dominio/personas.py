"""Reglas puras para comparar fichas de personas detenidas (revisión de posibles duplicados).

- Propuesta 29: los puntos por «mismo nombre» dependen de qué tan común es el nombre en la base.
- Propuesta 32: clave fonética para castellano (b=v, c/s/z, ll=y, g=j delante de e/i, h muda, qu=k): agrupa y suma
  «nombre que suena igual» con los errores típicos de carga (Vázquez/Básquez, Jiménez/Giménez, Sosa/Zoza).
- Propuesta 34: parecido entre nombres con RapidFuzz si está instalado (más rápido); si no, con difflib, como hoy.
- Propuesta 35: más tolerancias en fechas de nacimiento (dígitos del año invertidos, siglo mal leído, fechas de relleno).
"""
from __future__ import annotations

import difflib
import functools
import math
import re
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field

try:  # optativo: si no está, se usa difflib
    from rapidfuzz import fuzz as _fuzz
except ImportError:  # pragma: no cover - depende del entorno
    _fuzz = None

RAPIDFUZZ = _fuzz is not None


# ---------------------------------------------------------------- 32: clave fonética
_REGLAS_FONETICAS: tuple[tuple[str, str], ...] = (
    (r"ch", "C"),               # se protege antes de quitar la h
    (r"h", ""),                 # h muda
    (r"ll", "y"),
    (r"y(?=[^aeiou]|$)", "i"),  # «Ruy», «Yrigoyen» → vocal
    (r"qu(?=[ei])", "k"),
    (r"q", "k"),
    (r"gu(?=[ei])", "g"),
    (r"g(?=[ei])", "j"),
    (r"sc(?=[ei])", "s"),
    (r"c(?=[ei])", "s"),
    (r"c", "k"),
    (r"z", "s"),
    (r"x", "ks"),
    (r"[vw]", "b"),
)


@functools.lru_cache(maxsize=65536)
def clave_fonetica(palabra: str) -> str:
    """Clave de cómo suena una palabra ya normalizada (minúsculas, sin tildes). «vazquez» y «basquez» → «baskes»."""
    p = re.sub(r"[^a-z]", "", (palabra or "").lower())
    for patron, reemplazo in _REGLAS_FONETICAS:
        p = re.sub(patron, reemplazo, p)
    p = re.sub(r"(.)\1+", r"\1", p)  # dobles: rr, ss, nn…
    return p.replace("C", "ch")


@functools.lru_cache(maxsize=65536)
def tokens_foneticos(nombre_norm: str) -> frozenset[str]:
    return frozenset(c for c in (clave_fonetica(t) for t in (nombre_norm or "").split()) if c)


# ---------------------------------------------------------------- 34: parecido de nombres
def parecido(a: str, b: str) -> float:
    """0 a 1, sobre las palabras ordenadas (igual criterio que antes con difflib)."""
    x, y = " ".join(sorted(a.split())), " ".join(sorted(b.split()))
    if _fuzz is not None:
        return float(_fuzz.ratio(x, y)) / 100
    return difflib.SequenceMatcher(None, x, y).ratio()


# ---------------------------------------------------------------- 29: frecuencia de nombres
@dataclass
class FrecuenciaNombres:
    """Cuántas fichas tienen cada palabra del nombre. Se arma una vez por corrida con todas las fichas."""
    cuenta: Counter[str] = field(default_factory=Counter)
    fichas: int = 0
    MINIMO_FICHAS = 200          # con menos fichas, la frecuencia no dice nada: no se ajusta
    COMUN = 0.01                 # una palabra en el 1 % o más de las fichas es común
    MAX_RARO = 2                 # una palabra que solo tienen estas dos fichas (o una) es rara

    @classmethod
    def desde(cls, nombres: Iterable[str]) -> FrecuenciaNombres:
        f = cls()
        for n in nombres:
            f.fichas += 1
            f.cuenta.update(set((n or "").split()))
        return f

    def es_comun(self, palabra: str) -> bool:
        return self.cuenta.get(palabra, 0) >= max(20, math.ceil(self.fichas * self.COMUN))

    def ajuste(self, compartidas: Iterable[str]) -> tuple[int, str | None]:
        """(puntos, motivo) para sumar a «mismo nombre»: −10 si todas las palabras en común son muy comunes, +8 si alguna es rara."""
        palabras = [p for p in set(compartidas) if len(p) >= 3]
        if self.fichas < self.MINIMO_FICHAS or not palabras:
            return 0, None
        if any(self.cuenta.get(p, 0) <= self.MAX_RARO for p in palabras):
            return 8, "nombre poco frecuente en la base"
        if all(self.es_comun(p) for p in palabras):
            return -10, "nombre muy común en la base (pesa menos)"
        return 0, None


# ---------------------------------------------------------------- 35: fechas de nacimiento
def es_fecha_de_relleno(fecha: str | None) -> bool:
    """01/01/1900, 01/01 de cualquier año o un año imposible: la fecha se cargó para completar el campo."""
    if not fecha or len(fecha) < 10:
        return False
    return fecha[5:10] == "01-01" or not fecha[:4].isdigit() or fecha[:4] < "1910"


def comparar_fechas(a: str | None, b: str | None) -> str | None:
    """None (falta alguna), «dudosa» (alguna es de relleno), «igual», «invertida» (día y mes), «año» (un año de diferencia),
    «año_invertido» (1987/1978), «siglo» (1905/2005: año de dos cifras mal leído) o «distinta». Fechas en formato AAAA-MM-DD."""
    if not a or not b:
        return None
    a, b = a[:10], b[:10]
    if (len(a) == len(b) == 10 and a[5:] == b[5:] != "01-01" and a[2:4] == b[2:4] and a[:4].isdigit() and b[:4].isdigit()
            and abs(int(a[:4]) - int(b[:4])) == 100):
        return "siglo"  # 1905/2005: año de dos cifras mal leído (antes de mirar el relleno: uno de los dos años es imposible)
    if es_fecha_de_relleno(a) or es_fecha_de_relleno(b):
        return "dudosa"
    if a == b:
        return "igual"
    ya, ma, da = a[:4], a[5:7], a[8:10]
    yb, mb, dbb = b[:4], b[5:7], b[8:10]
    if len(a) != 10 or len(b) != 10 or a[4] != "-" or b[4] != "-" or not (ya.isdigit() and yb.isdigit()):
        return "distinta"
    if ya == yb and ma == dbb and da == mb:
        return "invertida"
    if a[5:] == b[5:]:
        dif = abs(int(ya) - int(yb))
        if dif == 1:
            return "año"
        if ya[:2] == yb[:2] and ya[2:] == yb[3] + yb[2]:
            return "año_invertido"
    return "distinta"


PUNTOS_FECHA = {"igual": (15, "misma fecha de nacimiento"),
                "invertida": (12, "fecha de nacimiento con día y mes invertidos"),
                "año": (6, "fecha de nacimiento con un año de diferencia"),
                "año_invertido": (6, "fecha de nacimiento con los dígitos del año invertidos"),
                "siglo": (6, "fecha de nacimiento con el siglo mal leído (año de dos cifras)"),
                "dudosa": (0, "fecha de nacimiento dudosa (de relleno): no se tiene en cuenta"),
                "distinta": (-20, "fechas de nacimiento distintas")}
