"""Reglas puras de la interfaz (propuestas 98–164): textos visibles, grupos de urgencia de la bandeja, tiempos relativos,
mensajes de error accionables y preferencias por defecto. No importa nada del resto del sistema."""
from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any

# ---------------------------------------------------------------- 137 (U40): lenguaje claro, una sola tabla de estados
ETIQUETAS_ESTADO: dict[str, str] = {
    "BORRADOR": "Sin enviar",
    "SUBIDA": "Espera a Coordinación",
    "PROCESANDO": "En corrección automática",
    "EN_REVISION": "En revisión de correcciones",
    "PROCESADA": "Lista para firmar",
    "FIRMADA": "Firmada",
    "PARA_REMITIR": "Para remitir (solo Mesa de Entradas)",
    "DESPACHADA": "Despachada",
    "ARCHIVADA": "Archivada",
    "ADJUNTO": "Adjunto del bloque (PDF, sin firma)",
    "A_CONFIRMAR": "PDF pendiente de confirmación de Dirección",
    "RECHAZADA": "Devuelta para corregir",
    "ERROR": "Con error",
    "DESCARTADA": "Descartada (duplicado)",
}


def etiqueta_estado(estado: str | None) -> str:
    """El texto que ve la persona para un estado interno. Nunca devuelve el código crudo con guiones bajos."""
    if not estado:
        return "—"
    return ETIQUETAS_ESTADO.get(estado, estado.replace("_", " ").capitalize())


# Siglas que aparecen en pantalla: se muestran con <abbr title="…"> y forman el glosario de la Ayuda.
SIGLAS: dict[str, str] = {
    "LPU": "Legajo Personal Único",
    "DNI": "Documento Nacional de Identidad",
    "PPN": "Procuración Penitenciaria de la Nación",
    "DGPDH": "Dirección General de Protección de Derechos Humanos",
    "SPF": "Servicio Penitenciario Federal",
    "CPF": "Complejo Penitenciario Federal",
    "AMBA": "Área Metropolitana de Buenos Aires",
    "Expte.": "Expediente",
    "PIN": "Número personal de 4 cifras que confirma la firma",
    "IA": "Inteligencia artificial (local, en el servidor del organismo)",
}


# ---------------------------------------------------------------- 110 (U13): bandeja por urgencia real
@dataclass(frozen=True)
class Grupo:
    clave: str
    titulo: str
    orden: int


GRUPOS_URGENCIA: tuple[Grupo, ...] = (
    Grupo("vencida", "Plazo vencido", 0),
    Grupo("hoy", "Vence hoy", 1),
    Grupo("semana", "Vence en los próximos 7 días", 2),
    Grupo("urgente", "URGENTES", 3),
    Grupo("resto", "Resto", 4),
)
_POR_CLAVE = {g.clave: g for g in GRUPOS_URGENCIA}


def _a_fecha(valor: object) -> date | None:
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    if isinstance(valor, str) and re.match(r"^\d{4}-\d{2}-\d{2}", valor):
        try:
            return date.fromisoformat(valor[:10])
        except ValueError:
            return None
    return None


def grupo_urgencia(vence: object, prioridad: str | None, hoy: date) -> Grupo:
    """Corte de la bandeja para una nota según su plazo (fecha AAAA-MM-DD) y su prioridad efectiva."""
    f = _a_fecha(vence)
    if f is not None:
        if f < hoy:
            return _POR_CLAVE["vencida"]
        if f == hoy:
            return _POR_CLAVE["hoy"]
        if (f - hoy).days <= 7:
            return _POR_CLAVE["semana"]
    if (prioridad or "").upper() == "URGENTE":
        return _POR_CLAVE["urgente"]
    return _POR_CLAVE["resto"]


def agrupar_por_urgencia(filas: Sequence[Mapping[str, Any]], hoy: date, clave_vence: str = "vence",
                         clave_prioridad: str = "prioridad_efectiva") -> list[dict[str, Any]]:
    """[{grupo, titulo, filas}] sin grupos vacíos, en el orden fijo de GRUPOS_URGENCIA. Dentro de cada grupo se respeta el orden
    recibido (prioridad y antigüedad)."""
    salida: dict[str, list[Mapping[str, Any]]] = {g.clave: [] for g in GRUPOS_URGENCIA}
    for f in filas:
        salida[grupo_urgencia(f.get(clave_vence), f.get(clave_prioridad), hoy).clave].append(f)
    return [{"grupo": g.clave, "titulo": g.titulo, "filas": salida[g.clave]} for g in GRUPOS_URGENCIA if salida[g.clave]]


# ---------------------------------------------------------------- 131 (U34): «hace 3 días» con la fecha exacta al lado
def _a_momento(valor: object) -> datetime | None:
    if isinstance(valor, datetime):
        return valor if valor.tzinfo else valor.replace(tzinfo=timezone.utc)
    if isinstance(valor, str) and valor.strip():
        texto = valor.strip().replace("Z", "+00:00")
        try:
            m = datetime.fromisoformat(texto)
        except ValueError:
            return None
        return m if m.tzinfo else m.replace(tzinfo=timezone.utc)
    return None


def hace(valor: object, ahora: datetime | None = None) -> str:
    """Tiempo transcurrido en palabras: «recién», «hace 5 min», «hace 3 h», «ayer», «hace 4 días», «hace 2 semanas»."""
    m = _a_momento(valor)
    if m is None:
        return ""
    ahora = ahora or datetime.now(timezone.utc)
    seg = int((ahora - m).total_seconds())
    if seg < 0:
        return "en el futuro" if seg < -120 else "recién"
    if seg < 90:
        return "recién"
    if seg < 3600:
        return f"hace {seg // 60} min"
    if seg < 86400:
        return f"hace {seg // 3600} h"
    dias = seg // 86400
    if dias == 1:
        return "ayer"
    if dias < 14:
        return f"hace {dias} días"
    if dias < 60:
        return f"hace {dias // 7} semanas"
    return f"hace {dias // 30} meses"


def nivel_antiguedad(valor: object, ahora: datetime | None = None) -> str:
    """verde / ambar / rojo según los días transcurridos (mismo criterio que la antigüedad en la etapa: 3 y 7 días)."""
    m = _a_momento(valor)
    if m is None:
        return ""
    dias = ((ahora or datetime.now(timezone.utc)) - m).days
    return "rojo" if dias >= 7 else ("ambar" if dias >= 3 else "verde")


# ---------------------------------------------------------------- 138 (U41): errores que explican qué hacer
@dataclass(frozen=True)
class MensajeError:
    que_paso: str
    que_hacer: str
    actualizar: bool = False


_POR_CODIGO: dict[int, MensajeError] = {
    400: MensajeError("Faltan datos o hay un dato que no es válido.", "Revisá lo que cargaste y probá de nuevo."),
    401: MensajeError("Tu sesión se cerró.", "Volvé a ingresar con tu usuario y contraseña."),
    403: MensajeError("No tenés permiso para hacer esto.", "Si creés que deberías poder, pedilo en Administración."),
    404: MensajeError("Lo que buscás ya no está disponible.", "Puede que otra persona lo haya movido. Volvé a la bandeja."),
    409: MensajeError("Otra persona ya actuó sobre esto.", "Actualizá la pantalla para ver cómo quedó.", actualizar=True),
    413: MensajeError("El archivo es demasiado grande.", "Probá con un archivo más chico o dividilo."),
    422: MensajeError("Faltan datos o hay un dato que no es válido.", "Revisá los campos marcados y probá de nuevo."),
    500: MensajeError("Algo falló en el servidor.", "Probá de nuevo en un momento. Si se repite, avisá a soporte con el código de referencia."),
    503: MensajeError("El sistema está ocupado o en mantenimiento.", "Esperá un minuto y probá de nuevo."),
}


def mensaje_error(codigo: int, detalle: str | None = None) -> dict[str, Any]:
    """Qué pasó (el detalle del servidor si lo hay), qué podés hacer y si conviene ofrecer «Actualizar»."""
    base = _POR_CODIGO.get(codigo) or (_POR_CODIGO[500] if codigo >= 500 else _POR_CODIGO[400])
    texto = (detalle or "").strip()
    if not texto or texto in ("Internal Server Error", "Not Found", "No se pudo completar la acción."):
        texto = base.que_paso
    actualizar = base.actualizar or bool(re.search(r"\b(ya (la|lo|las|los) |otra persona|cambió|ya fue)", texto, re.I))
    return {"que_paso": texto, "que_hacer": base.que_hacer, "actualizar": actualizar, "codigo": codigo}


def referencia_soporte(semilla: str) -> str:
    """Código corto para que soporte encuentre el error en el registro (4 caracteres hexadecimales en mayúscula)."""
    import hashlib
    return hashlib.sha1(semilla.encode("utf-8")).hexdigest()[:4].upper()


# ---------------------------------------------------------------- 143 (U46): atajos de una tecla
ROLES_CON_ATAJOS = frozenset({"DIRECTOR", "SUBDIRECTOR", "MESA_JEFE", "MESA_COORDINADOR", "MESA_ASESOR"})
TEMAS = ("sistema", "claro", "oscuro")
DENSIDADES = ("comoda", "compacta")


def atajos_por_defecto(rol: str | None) -> bool:
    """Vienen activados solo para Dirección y Mesa de Entradas; el resto los prende en «Mi perfil»."""
    return (rol or "") in ROLES_CON_ATAJOS


def preferencias_efectivas(guardadas: Mapping[str, Any] | None, rol: str | None) -> dict[str, Any]:
    g = dict(guardadas or {})
    atajos = g.get("atajos")
    tema = g.get("tema")
    densidad = g.get("densidad")
    columnas = g.get("columnas_ocultas")
    return {
        "atajos": bool(atajos) if isinstance(atajos, bool) else atajos_por_defecto(rol),
        "tema": tema if tema in TEMAS else "sistema",
        "tema_guardado": tema if tema in TEMAS else None,
        "densidad": densidad if densidad in DENSIDADES else "comoda",
        "columnas_ocultas": [str(c) for c in columnas][:20] if isinstance(columnas, list) else [],
        "vistos": dict(g.get("vistos") or {}) if isinstance(g.get("vistos"), dict) else {},
    }


# ---------------------------------------------------------------- 105 (U8): «Volver» seguro
def destino_interno(desde: str | None, defecto: str = "/") -> str:
    """Solo rutas internas («/algo»), nunca otro sitio («//x», «https://…») ni saltos de línea."""
    d = (desde or "").strip()
    if not d.startswith("/") or d.startswith("//") or "\\" in d or any(c in d for c in "\r\n\t") or len(d) > 300:
        return defecto
    return d


def normalizar(texto: str | None) -> str:
    """Minúsculas y sin acentos, para buscar «gonzalez» y encontrar «González»."""
    import unicodedata
    t = unicodedata.normalize("NFD", str(texto or "")).encode("ascii", "ignore").decode("ascii")
    return " ".join(t.lower().split())


# ---------------------------------------------------------------- 139 (U42): avisos agrupados, con acción
_ACTUAR = (("para firmar", "Firmar"), ("firmá", "Firmar"), ("para aprobar", "Aprobar"), ("aprobá", "Aprobar"), ("para revisar", "Revisar"),
           ("revisá", "Revisar"), ("para despachar", "Despachar"), ("despachá", "Despachar"), ("confirm", "Confirmar viaje"),
           ("rechaz", "Corregir"), ("devuelt", "Corregir"), ("volver a corregir", "Corregir"), ("te espera", "Abrir"),
           ("esperando", "Abrir"), ("atención", "Ver"), ("vence", "Ver"), ("pendiente", "Ver"))


def clasificar_aviso(texto: str | None) -> dict[str, Any]:
    """¿El aviso pide que la persona actúe? Y si es así, el verbo del botón. El resto es «para que sepas»."""
    t = normalizar(texto)
    for clave, accion in _ACTUAR:
        if normalizar(clave) in t:
            return {"actuar": True, "accion": accion}
    return {"actuar": False, "accion": "Ver"}


def grupo_fecha(valor: object, hoy: date) -> str:
    """«Hoy», «Ayer», «Esta semana» o «Antes» (fecha local del aviso)."""
    m = _a_momento(valor)
    if m is None:
        return "Antes"
    try:
        from zoneinfo import ZoneInfo
        d = m.astimezone(ZoneInfo("America/Argentina/Buenos_Aires")).date()
    except Exception:
        d = m.date()
    dias = (hoy - d).days
    return "Hoy" if dias <= 0 else ("Ayer" if dias == 1 else ("Esta semana" if dias < 7 else "Antes"))


def agrupar_avisos(avisos: Sequence[Mapping[str, Any]], hoy: date) -> list[dict[str, Any]]:
    """[{titulo, grupos: [{fecha, avisos}]}]: primero «Te toca actuar», después «Para que sepas»; dentro, por fecha."""
    orden = ("Hoy", "Ayer", "Esta semana", "Antes")
    salida = []
    for titulo, actuar in (("Te toca actuar", True), ("Para que sepas", False)):
        por_fecha: dict[str, list[dict[str, Any]]] = {k: [] for k in orden}
        for a in avisos:
            c = clasificar_aviso(str(a.get("texto") or ""))
            if c["actuar"] == actuar:
                por_fecha[grupo_fecha(a.get("creada_en"), hoy)].append(dict(a, accion=c["accion"]))
        grupos = [{"fecha": k, "avisos": por_fecha[k]} for k in orden if por_fecha[k]]
        if grupos:
            salida.append({"titulo": titulo, "actuar": actuar, "grupos": grupos})
    return salida


# ---------------------------------------------------------------- 156 (U59): «Qué cambió» después de cada versión
_ROL_A_GRUPO = {"DIRECTOR": "direccion", "SUBDIRECTOR": "direccion", "COORDINADOR": "coordinacion", "ASESOR": "asesoria",
                "MESA_JEFE": "mesa", "MESA_COORDINADOR": "mesa", "MESA_ASESOR": "mesa", "CHOFER": "chofer"}


def leer_novedades(texto: str) -> list[dict[str, Any]]:
    """[{version, titulo, items: [{roles, texto}]}] del archivo novedades.md, de la más nueva a la más vieja."""
    versiones: list[dict[str, Any]] = []
    for linea in texto.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", linea)
        if m:
            titulo = m.group(1)
            versiones.append({"version": titulo.split(" (")[0].strip(), "titulo": titulo, "items": []})
            continue
        m = re.match(r"^-\s*\[([^\]]+)\]\s*(.+)$", linea)
        if m and versiones:
            versiones[-1]["items"].append({"roles": [r.strip() for r in m.group(1).split(",")], "texto": m.group(2).strip()})
    return versiones


def novedades_para(versiones: Sequence[Mapping[str, Any]], rol: str | None, autos: bool = False, cuantas: int = 3) -> list[str]:
    if not versiones:
        return []
    grupos = {"todos", _ROL_A_GRUPO.get(rol or "", "")} | ({"autos"} if autos else set())
    return [i["texto"] for i in versiones[0]["items"] if grupos & set(i["roles"])][:cuantas]
