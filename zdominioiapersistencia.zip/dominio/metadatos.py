"""Propuesta 1: metadatos propios por tipo documental.

Cada tipo documental tiene una lista corta de campos (texto, fecha, número, vínculo a persona detenida, a unidad o a otra
nota). Los asistentes proponen el valor leído del texto y quien lleva la nota lo confirma o lo corrige en un solo lugar.
Este módulo define los campos y valida los valores; no toca la base.
"""
from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date

from dgpdh.errores import DatoInvalido

TIPOS_CAMPO = ("texto", "fecha", "numero", "detenido", "unidad", "nota")


@dataclass(frozen=True)
class Campo:
    clave: str
    etiqueta: str
    tipo: str


_ORGANISMO = Campo("organismo_requerido", "Organismo requerido", "texto")
_PLAZO = Campo("plazo_dias", "Plazo pedido (días)", "numero")
_PERSONA = Campo("persona_detenida", "Persona detenida (ficha)", "detenido")
_UNIDAD = Campo("unidad", "Unidad", "unidad")
_JUZGADO = Campo("juzgado", "Juzgado o tribunal", "texto")
_RESPONDE = Campo("responde_a", "Responde a la nota (N° interno)", "nota")
_EXPTE_JUD = Campo("causa_judicial", "Causa o expediente judicial", "texto")
_VENCE = Campo("fecha_limite", "Fecha límite", "fecha")

POR_TIPO: dict[str, tuple[Campo, ...]] = {
    "NOTA": (_ORGANISMO, _PERSONA, _UNIDAD, _PLAZO),
    "NOTA_PPL": (_PERSONA, _UNIDAD),
    "OFICIO": (_ORGANISMO, _JUZGADO, _PERSONA, _PLAZO),
    "PEDIDO_INFORME": (_ORGANISMO, _PERSONA, _UNIDAD, _PLAZO, _VENCE),
    "REQUERIMIENTO": (_ORGANISMO, _PERSONA, _UNIDAD, _PLAZO, _VENCE),
    "SOLICITUD": (_ORGANISMO, _PERSONA, _UNIDAD, _PLAZO),
    "CONTESTACION": (_ORGANISMO, _RESPONDE, _JUZGADO),
    "RESPUESTA_ORGANISMO": (_ORGANISMO, _RESPONDE),
    "PRESENTACION_JUDICIAL": (_JUZGADO, _EXPTE_JUD, _PERSONA),
    "COMUNICACION_UNIDAD": (_UNIDAD, _PERSONA, _PLAZO),
    "COMUNICACION_INTERNA": (_ORGANISMO,),
    "INFORME": (_UNIDAD, _PERSONA),
    "PROVEIDO": (_RESPONDE,),
}


def campos_de(tipo_documental: str | None) -> tuple[Campo, ...]:
    return POR_TIPO.get((tipo_documental or "NOTA").upper(), POR_TIPO["NOTA"])


def normalizar(campo: Campo, valor: object) -> str | None:
    """Valor limpio para guardar, o None si está vacío. Levanta DatoInvalido si no tiene la forma del tipo."""
    v = str(valor if valor is not None else "").strip()
    if not v:
        return None
    if campo.tipo == "texto":
        return v[:300]
    if campo.tipo == "numero":
        if not re.fullmatch(r"\d{1,4}", v):
            raise DatoInvalido(f"«{campo.etiqueta}» tiene que ser un número.")
        return str(int(v))
    if campo.tipo == "fecha":
        m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", v)
        try:
            return (date(int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else date.fromisoformat(v)).isoformat()
        except ValueError as e:
            raise DatoInvalido(f"«{campo.etiqueta}» no es una fecha válida (usá DD/MM/AAAA).") from e
    if not v.isdigit():  # detenido, unidad, nota: el id
        raise DatoInvalido(f"«{campo.etiqueta}»: elegí una opción de la lista.")
    return v


def propuestas(campos: tuple[Campo, ...], entidades: Mapping[str, list[Mapping[str, str]]], fichas_por_dni: Mapping[str, int],
               plazo_dias: int | None, organismo: str | None) -> dict[str, str]:
    """Lo que el sistema propone para cada campo a partir de lo que ya leyó del texto."""
    salida: dict[str, str] = {}
    for c in campos:
        if c.clave == "unidad":
            u = next((e["norm"][2:] for e in entidades.get("UNIDAD", []) if str(e.get("norm", "")).startswith("u:")), None)
            if u:
                salida[c.clave] = u
        elif c.clave == "persona_detenida":
            dni = next((e["norm"][4:] for e in entidades.get("PERSONA", []) if str(e.get("norm", "")).startswith("dni:")), None)
            if dni and dni in fichas_por_dni:
                salida[c.clave] = str(fichas_por_dni[dni])
        elif c.clave == "juzgado" and entidades.get("JUZGADO"):
            salida[c.clave] = str(entidades["JUZGADO"][0]["valor"])
        elif c.clave == "plazo_dias" and plazo_dias:
            salida[c.clave] = str(plazo_dias)
        elif c.clave == "organismo_requerido" and organismo:
            salida[c.clave] = organismo[:300]
    return salida
