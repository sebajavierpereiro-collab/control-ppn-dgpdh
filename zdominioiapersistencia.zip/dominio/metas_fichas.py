"""Propuesta 92 (viajes 39): ficha técnica de cada indicador de Metas («¿Cómo se calcula?»): definición, fórmula, fuente,
frecuencia, responsable de la carga, desde cuándo vale y cambios de criterio. Se arma a partir de la definición del
indicador (fuente y dimensión) y de estas notas; un indicador sin nota propia igual tiene ficha."""
from __future__ import annotations

from typing import Any

DESDE = "Metas 2026"
NOTAS: dict[str, dict[str, str]] = {
    "visitas_equipo": {"definicion": "Viajes a la unidad realizados por el equipo.",
                       "formula": "Un día + una unidad + un equipo = una visita, aunque viajen varias personas o parte vaya por sus medios.",
                       "cambios": "Desde v40 se calcula una vez por día (o con «Actualizar ahora»)."},
    "entrevistas": {"definicion": "Audiencias o entrevistas a personas privadas de libertad en la unidad.",
                    "formula": "Suma de las audiencias que cada persona informa en sus viajes realizados."},
    "ingreso_pabellones": {"definicion": "Visitas en las que alguien del equipo ingresó a pabellones o sectores.",
                           "formula": "Un día + una unidad en la que al menos una persona del equipo informó el ingreso."},
    "med_casos_individuales": {"definicion": "Casos individuales trabajados por notas y reiteraciones, por complejo.",
                               "formula": "Lo propone el sistema con las notas del equipo de cada mes y su unidad; la coordinación lo confirma o corrige."},
    "med_casos_colectivos": {"definicion": "Casos colectivos trabajados por notas, por complejo.",
                             "formula": "Notas del equipo clasificadas con alcance colectivo; la coordinación lo confirma o corrige."},
}
FUENTES = {"viajes": "Autos PPN (viajes realizados)", "carga": "Carga de la coordinación del equipo",
           "viajes_o_carga": "Autos PPN si hay dato ese mes; si no, carga de la coordinación"}
DIMENSIONES = {"persona": "por persona (la meta del equipo es también la de cada integrante)", "equipo": "del equipo",
               "unidad": "por unidad o complejo"}


def ficha(indicador: dict[str, Any]) -> dict[str, str]:
    n = NOTAS.get(str(indicador["clave"]), {})
    fuente = str(indicador.get("fuente", "carga"))
    dimension = str(indicador.get("dimension", "persona"))
    return {
        "definicion": n.get("definicion", f"{indicador['nombre']}."),
        "formula": n.get("formula", "Suma de lo cargado en el período (por mes o por trimestre, sin contar dos veces)." if fuente != "viajes"
                         else "Se cuenta desde los viajes realizados."),
        "fuente": FUENTES.get(fuente, fuente),
        "dimension": DIMENSIONES.get(dimension, dimension),
        "frecuencia": "Diaria (foto de los viajes) o a pedido" if fuente == "viajes" else "Mensual o trimestral, al cargar",
        "responsable": "Sistema (no se carga a mano)" if fuente == "viajes" else "Coordinación del equipo",
        "desde": n.get("desde", DESDE),
        "cambios": n.get("cambios", "Sin cambios de criterio registrados."),
    }
