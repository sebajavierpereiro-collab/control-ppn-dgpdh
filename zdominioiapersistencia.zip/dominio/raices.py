"""Propuesta 11: búsqueda por raíces de palabras en castellano mientras siga SQLite (en PostgreSQL: `tsvector` con
`spanish` y `unaccent`). «traslado», «traslados», «trasladaron» y «trasladar» comparten la raíz «traslad».

Es un recortador liviano de terminaciones (plurales, sustantivos en -ción/-miento y verbos frecuentes). No pretende ser un
analizador morfológico: solo suma resultados a la búsqueda de siempre, nunca le saca.
"""
from __future__ import annotations

import re
import unicodedata

_TERMINACIONES = ("aciones", "iciones", "amientos", "imientos", "amiento", "imiento", "aremos", "eremos", "iremos", "acion", "icion",
                  "aron", "ieron", "aban", "ando", "iendo", "aria", "eria", "iria", "ara", "era", "ira", "an", "en", "as", "es", "os",
                  "ar", "er", "ir", "a", "e", "o", "s")
MINIMO = 3
_PALABRA = re.compile(r"[a-zñ]+")


def _normal(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn" or c == "̃")


def raiz(palabra: str) -> str:
    p = unicodedata.normalize("NFC", _normal(palabra)).replace("ñ", "ny")
    p = "".join(c for c in unicodedata.normalize("NFD", p) if unicodedata.category(c) != "Mn")
    if len(p) <= MINIMO + 1:
        return p
    for t in _TERMINACIONES:
        if p.endswith(t) and len(p) - len(t) >= MINIMO:
            return p[: -len(t)]
    return p


def raices(texto: str | None) -> str:
    """El texto como secuencia de raíces (para indexar)."""
    norm = "".join(c for c in unicodedata.normalize("NFD", (texto or "").lower()) if unicodedata.category(c) != "Mn")
    return " ".join(raiz(w) for w in _PALABRA.findall(norm))
