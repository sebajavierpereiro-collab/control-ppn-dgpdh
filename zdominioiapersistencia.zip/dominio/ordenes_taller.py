"""Propuesta 65: etapas de una orden de trabajo de taller y qué le pasa al vehículo en cada cambio. Cálculo puro."""
from __future__ import annotations

import re

ETAPAS = {"NUEVA": "Nueva", "EN_CURSO": "En curso", "HECHA": "Hecha", "CANCELADA": "Cancelada"}
CLASE = {"NUEVA": "info", "EN_CURSO": "frecuente", "HECHA": "ok", "CANCELADA": "neutro"}
CERRADAS = ("HECHA", "CANCELADA")
_PASOS = {"NUEVA": ("EN_CURSO", "CANCELADA"), "EN_CURSO": ("HECHA", "CANCELADA"), "HECHA": (), "CANCELADA": ()}


def siguientes(etapa: str) -> tuple[str, ...]:
    return _PASOS.get(etapa, ())


def validar(desde: str, hacia: str, nota: str | None) -> str | None:
    """Mensaje de error, o None si el cambio es válido."""
    if hacia not in ETAPAS:
        return "Etapa no válida."
    if hacia not in siguientes(desde):
        return f"Una orden «{ETAPAS.get(desde, desde)}» no puede pasar a «{ETAPAS[hacia]}»."
    if hacia == "CANCELADA" and not (nota or "").strip():
        return "Contá por qué se cancela la orden (queda registrada)."
    return None


def pone_en_taller(desde: str, hacia: str) -> bool:
    """Al pasar a «En curso», el vehículo queda en TALLER automáticamente."""
    return hacia == "EN_CURSO" and desde != "EN_CURSO"


def ofrece_volver(desde: str, hacia: str, otras_en_curso: int) -> bool:
    """Al cerrar una orden que estaba en curso se ofrece (con confirmación) devolver el vehículo a DISPONIBLE, salvo que
    haya otra orden del mismo vehículo todavía en curso."""
    return desde == "EN_CURSO" and hacia in CERRADAS and otras_en_curso == 0


def importe(valor: object) -> float | None:
    """«12.500,50», «47.300» o «12500.5» → número; vacío → None; ValueError si no es un número válido."""
    t = str(valor or "").strip().replace("$", "").replace(" ", "")
    if not t:
        return None
    if "," in t or re.fullmatch(r"\d{1,3}(\.\d{3})+", t):  # 12.500,50 o 47.300 (separador de miles)
        t = t.replace(".", "").replace(",", ".")
    v = float(t)
    if v < 0:
        raise ValueError("El importe no puede ser negativo.")
    return round(v, 2)
