"""Propuesta 42: tablero de calidad de los listados por fuerza y por trimestre.

Lee las inconsistencias que ya se guardan en el informe de cada carga (tal como vino el listado) y calcula, por fuerza y
trimestre, el porcentaje de filas con problemas y de cada tipo, con la tendencia contra el trimestre anterior. Sirve de anexo
para las devoluciones institucionales a cada fuerza.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any


def trimestre(fecha: str | None) -> str | None:
    if not fecha or len(fecha) < 7 or not fecha[:4].isdigit() or not fecha[5:7].isdigit():
        return None
    return f"{fecha[:4]}-T{(int(fecha[5:7]) - 1) // 3 + 1}"


@dataclass
class Periodo:
    fuerza: str
    trimestre: str
    listados: int = 0
    filas: int = 0
    con_problemas: int = 0
    por_tipo: dict[str, int] = field(default_factory=dict)
    tendencia: float | None = None    # puntos porcentuales contra el trimestre anterior (negativo = mejora)

    @property
    def pct(self) -> float:
        return round(100 * self.con_problemas / self.filas, 1) if self.filas else 0.0

    def pct_tipo(self, tipo: str) -> float:
        return round(100 * self.por_tipo.get(tipo, 0) / self.filas, 1) if self.filas else 0.0


def tablero(cargas: Iterable[Mapping[str, Any]]) -> list[Periodo]:
    """`cargas`: {fuerza, fecha_listado, inconsistencias: {filas, filas_con_problemas, por_tipo}}. Las que no tienen fecha o
    inconsistencias no cuentan. Ordenado por fuerza y trimestre."""
    periodos: dict[tuple[str, str], Periodo] = {}
    for c in cargas:
        t = trimestre(c.get("fecha_listado"))
        inc = c.get("inconsistencias") or {}
        if not t or not inc or not inc.get("filas"):
            continue
        fuerza = str(c.get("fuerza") or "Sin fuerza")
        p = periodos.setdefault((fuerza, t), Periodo(fuerza, t))
        p.listados += 1
        p.filas += int(inc.get("filas") or 0)
        p.con_problemas += int(inc.get("filas_con_problemas") or 0)
        for tipo, n in (inc.get("por_tipo") or {}).items():
            p.por_tipo[str(tipo)] = p.por_tipo.get(str(tipo), 0) + int(n or 0)
    salida = [periodos[k] for k in sorted(periodos)]
    anterior: dict[str, Periodo] = {}
    for p in salida:
        if p.fuerza in anterior:
            p.tendencia = round(p.pct - anterior[p.fuerza].pct, 1)
        anterior[p.fuerza] = p
    return salida
