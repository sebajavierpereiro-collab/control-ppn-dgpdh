"""Calendario laboral (propuesta 69): días hábiles con feriados, puentes, asuetos y feria judicial.

Reglas puras, sin base ni web. Un día es hábil si es de lunes a viernes y no figura en el conjunto de feriados.
Las funciones reciben los feriados como un conjunto de fechas (lo arma `dgpdh.servicios.feriados.conjunto`).
"""
from __future__ import annotations

from collections.abc import Collection, Iterator
from datetime import date, timedelta

TIPOS_FERIADO: dict[str, str] = {
    "NACIONAL": "Feriado nacional",
    "PUENTE": "Día no laborable / puente",
    "ASUETO": "Asueto PPN",
    "FERIA": "Feria judicial",
}

Feriados = Collection[date]


def es_habil(d: date, feriados: Feriados = ()) -> bool:
    return d.weekday() < 5 and d not in feriados


def dias(desde: date, hasta: date) -> Iterator[date]:
    d = desde
    while d <= hasta:
        yield d
        d += timedelta(days=1)


def habiles_entre(desde: date, hasta: date, feriados: Feriados = ()) -> int:
    """Cantidad de días hábiles entre dos fechas, ambas incluidas (0 si `hasta` es anterior)."""
    return sum(1 for d in dias(desde, hasta) if es_habil(d, feriados))


def habil_anterior_o_igual(d: date, feriados: Feriados = ()) -> date:
    """El mismo día si es hábil; si no, el último día hábil anterior."""
    for _ in range(60):  # una feria judicial dura menos de un mes: 60 días alcanzan siempre
        if es_habil(d, feriados):
            return d
        d -= timedelta(days=1)
    return d


def habil_anterior(d: date, feriados: Feriados = ()) -> date:
    """El día hábil inmediatamente anterior a `d` (sin contar `d`)."""
    return habil_anterior_o_igual(d - timedelta(days=1), feriados)


def sumar_habiles(desde: date, n: int, feriados: Feriados = ()) -> date:
    """La fecha que cae `n` días hábiles después de `desde` (sin contar `desde`)."""
    d, restantes = desde, max(0, n)
    while restantes:
        d += timedelta(days=1)
        if es_habil(d, feriados):
            restantes -= 1
    return d


def primeros_habiles_del_mes(anio: int, mes: int, n: int, feriados: Feriados = ()) -> list[date]:
    """Los primeros `n` días hábiles del mes (para los recordatorios de comienzo de mes)."""
    salida: list[date] = []
    d = date(anio, mes, 1)
    while d.month == mes and len(salida) < n:
        if es_habil(d, feriados):
            salida.append(d)
        d += timedelta(days=1)
    return salida


def fraccion_habil(desde: date, hasta: date, hoy: date, feriados: Feriados = ()) -> float:
    """Qué parte del período [desde, hasta] ya transcurrió, medida en días hábiles (0 antes, 1 después)."""
    if hoy < desde:
        return 0.0
    if hoy >= hasta:
        return 1.0
    total = habiles_entre(desde, hasta, feriados)
    if not total:
        return 1.0
    return habiles_entre(desde, hoy, feriados) / total


def leer_ics(texto: str) -> list[tuple[date, str]]:
    """Fechas de un calendario .ics (descargado a mano): [(fecha, resumen)]. Admite eventos de un día o de varios
    (DTEND es exclusivo, como dice RFC 5545). Ignora lo que no entiende; no lanza errores por líneas raras."""
    # RFC 5545 §3.1: una línea que empieza con espacio o tabulación continúa la anterior
    lineas: list[str] = []
    for cruda in texto.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if cruda[:1] in (" ", "\t") and lineas:
            lineas[-1] += cruda[1:]
        else:
            lineas.append(cruda)
    salida: list[tuple[date, str]] = []
    evento: dict[str, str] | None = None
    for linea in lineas:
        if linea.strip().upper() == "BEGIN:VEVENT":
            evento = {}
            continue
        if linea.strip().upper() == "END:VEVENT":
            if evento is not None:
                salida.extend(_fechas_evento(evento))
            evento = None
            continue
        if evento is None or ":" not in linea:
            continue
        nombre, valor = linea.split(":", 1)
        evento[nombre.split(";", 1)[0].strip().upper()] = valor.strip()
    return salida


def _fecha_ics(valor: str) -> date | None:
    v = valor.strip()[:8]
    if len(v) != 8 or not v.isdigit():
        return None
    try:
        return date(int(v[:4]), int(v[4:6]), int(v[6:8]))
    except ValueError:
        return None


def _fechas_evento(ev: dict[str, str]) -> list[tuple[date, str]]:
    inicio = _fecha_ics(ev.get("DTSTART", ""))
    if inicio is None:
        return []
    resumen = (ev.get("SUMMARY") or "Feriado").replace("\\,", ",").replace("\\;", ";").replace("\\n", " ").strip()[:200]
    fin = _fecha_ics(ev.get("DTEND", ""))
    ultimo = (fin - timedelta(days=1)) if fin and fin > inicio else inicio
    if (ultimo - inicio).days > 45:  # no es un feriado: se descarta un evento que dura meses
        return []
    return [(d, resumen) for d in dias(inicio, ultimo)]
