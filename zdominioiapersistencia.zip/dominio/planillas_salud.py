"""Lectura de las planillas trimestrales de los equipos de salud (formato del 3.er trimestre de 2026). Recibe las filas de
la hoja (tuplas de celdas) y devuelve valores normalizados para Metas; no toca la base. Lo que no entiende lo informa.

Salud mental: «Detalle | <mes> | <mes> | <mes> | | Total», un renglón por indicador.
Salud médica: tres bloques — por profesional y mes; visitas e informes de golpeados por unidad en el trimestre; casos por
nota (individuales por mes, colectivos en el trimestre) y respuestas del SPF por complejo y mes; y las reuniones del equipo.
"""
from __future__ import annotations

import re
import unicodedata
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

MESES = {"enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6, "julio": 7, "agosto": 8, "septiembre": 9,
         "setiembre": 9, "septembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12}
SALUD_MENTAL = [("cantidad de viajes", "visitas_equipo"), ("entrevistas presenciales", "entrevistas"),
                ("entrevistas telefonicas", "sm_entrevistas_telefonicas"), ("recorridas", "sm_recorridas"),
                ("reuniones de trabajo", "sm_reuniones"), ("monitoreo asistencial", "sm_monitoreo_asistencial"),
                ("monitoreo de las practicas", "sm_monitoreo_practicas"), ("articulacion de las demandas", "sm_articulacion")]
MEDICA_PERSONA = [("entrevistas", "med_entrevistas"), ("historias clinicas", "med_historias_clinicas"),
                  ("intervenciones", "med_intervenciones"), ("recomendaciones", "med_recomendaciones")]
Fila = Sequence[Any]


def norm(v: Any) -> str:
    t = "".join(c for c in unicodedata.normalize("NFD", str(v or "")) if unicodedata.category(c) != "Mn")
    return " ".join(re.sub(r"[^a-z0-9 ]", " ", t.lower()).split())


def entero(v: Any) -> int | None:
    if v is None or str(v).strip() == "":
        return None
    try:
        n = int(float(str(v).replace(",", ".")))
    except ValueError:
        return None
    return n if n >= 0 else None


def meses_del_trimestre(t: int) -> list[int]:
    return [3 * (t - 1) + 1, 3 * (t - 1) + 2, 3 * (t - 1) + 3]


def mes_de(texto: Any, trimestre: int | None) -> int | None:
    """«Junio/Julio» en el 3.er trimestre → 7 (el mes que cae en el trimestre)."""
    encontrados = [MESES[p] for p in norm(texto).split() if p in MESES]
    if not encontrados:
        return None
    if trimestre:
        dentro = [m for m in encontrados if m in meses_del_trimestre(trimestre)]
        if dentro:
            return dentro[-1]
    return encontrados[-1]


@dataclass
class Lectura:
    formato: str                                   # salud_mental | salud_medica
    anio: int | None = None
    trimestre: int | None = None
    equipo: list[tuple[str, str, int]] = field(default_factory=list)                 # (periodo, indicador, cantidad)
    unidad: list[tuple[str, str, str, int]] = field(default_factory=list)            # (periodo, indicador, unidad, cantidad)
    persona: list[tuple[str, str, str, int]] = field(default_factory=list)           # (nombre en la planilla, periodo, indicador, cantidad)
    control: list[str] = field(default_factory=list)                                 # lo que se calcula solo (p. ej. visitas)
    avisos: list[str] = field(default_factory=list)


def _trimestre_y_anio(filas: list[Fila]) -> tuple[int | None, int | None]:
    for f in filas[:6]:
        for c in f:
            m = re.search(r"(\d)\s*(?:er|ro|do|to|º|°)?\s*trimestre\s*(\d{4})?", norm(c))
            if m:
                return int(m.group(1)), int(m.group(2)) if m.group(2) else None
    return None, None


def detectar(filas: list[Fila]) -> str | None:
    texto = " ".join(norm(c) for f in filas[:10] for c in f if c is not None)
    if "medicos" in texto:
        return "salud_medica"
    if "detalle" in texto:
        return "salud_mental"
    return None


def leer_salud_mental(filas: list[Fila], anio: int | None = None) -> Lectura:
    t, a = _trimestre_y_anio(filas)
    lec = Lectura("salud_mental", a or anio, t)
    cab = next((i for i, f in enumerate(filas) if f and norm(f[0]) == "detalle"), None)
    if cab is None:
        lec.avisos.append("No encontré la fila «Detalle» con los meses.")
        return lec
    columnas = [(j, mes_de(c, t)) for j, c in enumerate(filas[cab]) if j > 0 and mes_de(c, t)]
    if t is None and columnas:
        lec.trimestre = (columnas[0][1] - 1) // 3 + 1  # type: ignore[operator]
    for f in filas[cab + 1:]:
        if not f or not norm(f[0]):
            continue
        clave = next((k for prefijo, k in SALUD_MENTAL if norm(f[0]).startswith(prefijo)), None)
        if not clave:
            lec.avisos.append(f"Fila sin reconocer: «{str(f[0])[:60]}».")
            continue
        for j, mes in columnas:
            n = entero(f[j]) if j < len(f) else None
            if n is not None and mes:
                lec.equipo.append((f"M{mes:02d}", clave, n))
    return lec


def leer_salud_medica(filas: list[Fila], anio: int | None = None) -> Lectura:
    t, a = _trimestre_y_anio(filas)
    lec = Lectura("salud_medica", a or anio, t)
    i = 0
    while i < len(filas):
        f = [norm(c) for c in filas[i]]
        if "medicos" in f:  # bloque por profesional
            col = f.index("medicos")
            cols = {j: k for j, c in enumerate(f) for pref, k in MEDICA_PERSONA if pref in c}
            j_mes = f.index("mes") if "mes" in f else col + 2
            j_tri = f.index("trimestre") if "trimestre" in f else None
            persona = None
            i += 1
            while i < len(filas):
                r = filas[i]
                nombre = norm(r[col]) if col < len(r) else ""
                if nombre == "total":
                    break
                if nombre:
                    persona = str(r[col]).strip()
                if j_tri is not None and lec.trimestre is None and entero(r[j_tri]):
                    lec.trimestre = entero(r[j_tri])
                mes = mes_de(r[j_mes], lec.trimestre) if j_mes < len(r) else None
                if persona and mes:
                    for j, k in cols.items():
                        n = entero(r[j]) if j < len(r) else None
                        if n is not None:
                            lec.persona.append((persona, f"M{mes:02d}", k, n))
                i += 1
        elif any(c.startswith("visitas a las unidades") for c in f):
            i += 2  # la fila siguiente son los títulos de columna
            per = f"T{lec.trimestre}" if lec.trimestre else None
            while i < len(filas) and per:
                r = filas[i]
                vu, vn, gu, gn = (r[1] if len(r) > 1 else None), (r[2] if len(r) > 2 else None), (r[4] if len(r) > 4 else None), (r[5] if len(r) > 5 else None)
                if not norm(vu) and not norm(gu):
                    break
                if norm(vu) and norm(vu) != "total" and entero(vn) is not None:
                    lec.control.append(f"Visitas a {str(vu).strip()}: la planilla dice {entero(vn)} (en el sistema salen de los viajes)")
                if norm(gu) and norm(gu) != "total" and entero(gn) is not None:
                    lec.unidad.append((per, "med_informes_golpeados", str(gu).strip(), int(entero(gn) or 0)))
                if norm(vu) == "total" and not norm(gu):
                    break
                i += 1
        elif any(c.startswith("casos individuales") for c in f):
            i += 1
            cab = [norm(c) for c in filas[i]] if i < len(filas) else []
            meses = [(j, mes_de(filas[i][j], lec.trimestre)) for j, c in enumerate(cab) if mes_de(filas[i][j], lec.trimestre)]
            j_col = next((j for j, c in enumerate(cab) if c.startswith("total colectiv")), None)
            j_resp = next((j for j, c in enumerate(cab) if c.startswith("total respuesta")), None)
            individuales = [x for x in meses if j_col is None or x[0] < j_col]
            respuestas = [x for x in meses if j_col is not None and x[0] > j_col and (j_resp is None or x[0] < j_resp)]
            i += 1
            while i < len(filas):
                r = filas[i]
                u = norm(r[1]) if len(r) > 1 else ""
                if not u or u.startswith("total"):
                    break
                nombre = str(r[1]).strip()
                for j, m in individuales:
                    n = entero(r[j])
                    if n is not None and m:
                        lec.unidad.append((f"M{m:02d}", "med_casos_individuales", nombre, n))
                if j_col is not None and lec.trimestre and entero(r[j_col]) is not None:
                    lec.unidad.append((f"T{lec.trimestre}", "med_casos_colectivos", nombre, int(entero(r[j_col]) or 0)))
                for j, m in respuestas:
                    n = entero(r[j])
                    if n is not None and m:
                        lec.unidad.append((f"M{m:02d}", "med_respuestas_spf", nombre, n))
                i += 1
        elif any(c.startswith("reuniones de equipo") for c in f):
            n = next((entero(c) for c in filas[i][2:] if entero(c) is not None), None)
            if n is not None and lec.trimestre:
                lec.equipo.append((f"T{lec.trimestre}", "med_reuniones", n))
        i += 1
    if lec.trimestre is None:
        lec.avisos.append("No pude saber de qué trimestre es la planilla.")
    return lec


def leer(filas: list[Fila], anio: int | None = None) -> Lectura:
    formato = detectar(filas)
    if formato == "salud_medica":
        return leer_salud_medica(filas, anio)
    if formato == "salud_mental":
        return leer_salud_mental(filas, anio)
    lec = Lectura("desconocido")
    lec.avisos.append("No reconozco el formato: se esperaba la planilla de salud mental o la de salud médica.")
    return lec
