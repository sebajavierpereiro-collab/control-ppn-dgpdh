"""Modificación 2: documentos pendientes de acción del agente (RECHAZADA) sin movimiento.

La cuenta se hace desde la ÚLTIMA ACTIVIDAD del documento, no desde su creación: cualquier movimiento la reinicia.
- Cada `dias_aviso` días sin actividad: un aviso de seguimiento al agente (no se repite antes de `dias_aviso` días).
- A los `dias_archivo` días: archivo automático («Vencimiento por inactividad (15 días)»); se puede recuperar.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

AVISO_DIAS = 7
ARCHIVO_DIAS = 15


@dataclass(frozen=True)
class Decision:
    accion: str        # archivar | avisar | mantener
    motivo: str
    dias: int


def evaluar(ultima_actividad: date, ultimo_aviso: date | None, hoy: date, *, dias_aviso: int = AVISO_DIAS,
            dias_archivo: int = ARCHIVO_DIAS) -> Decision:
    dias = (hoy - ultima_actividad).days
    if dias >= dias_archivo:
        return Decision("archivar", f"Vencimiento por inactividad ({dias_archivo} días)", dias)
    aviso = ultimo_aviso if ultimo_aviso is not None and ultimo_aviso >= ultima_actividad else None  # la actividad nueva lo invalida
    if dias >= dias_aviso and (aviso is None or (hoy - aviso).days >= dias_aviso):
        return Decision("avisar", "Primer aviso de seguimiento" if aviso is None else "Aviso semanal de seguimiento", dias)
    return Decision("mantener", "En plazo vigente", dias)
