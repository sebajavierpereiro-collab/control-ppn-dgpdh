"""Propuestas 13, 14 y 17: control de lenguaje claro por reglas, con un perfil por tipo documental.

Sigue la ficha «Lenguaje claro» de la ANDIS y la guía del Gobierno de la Ciudad: oraciones de hasta 30 palabras, párrafos de
hasta 6 líneas, voz activa, una idea por oración, sin doble negación y sin tecnicismos cuando hay una palabra común. Cada aviso
explica el porqué y **nunca reescribe**: decide quien redacta. La «Nota a persona detenida» la lee alguien privado de la
libertad y se controla con umbrales más exigentes. Un oficio o una presentación judicial admiten el lenguaje técnico.
"""
from __future__ import annotations

import re
from collections import OrderedDict
from dataclasses import dataclass

PALABRAS_POR_LINEA = 15   # una línea de Arial 12 en A4 tiene unas 15 palabras


@dataclass(frozen=True)
class Perfil:
    clave: str
    max_palabras_oracion: int = 30
    max_lineas_parrafo: int = 6
    controlar_pasivas: bool = True
    controlar_tecnicismos: bool = False
    proponer_ia: bool = True          # propuesta 17: si la corrección de la IA corre para este tipo ([lenguaje_claro] sin_ia)


PERFILES: dict[str, Perfil] = {
    "NOTA_PPL": Perfil("NOTA_PPL", max_palabras_oracion=20, max_lineas_parrafo=4, controlar_tecnicismos=True),
    "OFICIO": Perfil("OFICIO", max_palabras_oracion=40, max_lineas_parrafo=8, controlar_pasivas=False),
    "PRESENTACION_JUDICIAL": Perfil("PRESENTACION_JUDICIAL", max_palabras_oracion=45, max_lineas_parrafo=10, controlar_pasivas=False),
    "CONTESTACION": Perfil("CONTESTACION", max_palabras_oracion=40, max_lineas_parrafo=8, controlar_pasivas=False),
    "INFORME": Perfil("INFORME", max_palabras_oracion=35, max_lineas_parrafo=8),
    "COMUNICACION_UNIDAD": Perfil("COMUNICACION_UNIDAD", controlar_tecnicismos=True),
    "SOLICITUD": Perfil("SOLICITUD", controlar_tecnicismos=True),
}
PERFIL_GENERAL = Perfil("GENERAL")


def perfil_de(tipo_documental: str | None, sin_ia: frozenset[str] = frozenset()) -> Perfil:
    """Perfil del tipo documental. `sin_ia`: tipos para los que no corre la corrección de la IA (config.ini)."""
    clave = (tipo_documental or "").upper()
    base = PERFILES.get(clave, PERFIL_GENERAL)
    if clave and clave in sin_ia:
        return Perfil(base.clave if base is not PERFIL_GENERAL else clave, base.max_palabras_oracion, base.max_lineas_parrafo,
                      base.controlar_pasivas, base.controlar_tecnicismos, proponer_ia=False)
    return base


# Fórmulas institucionales que no se marcan aunque tengan forma pasiva o técnica.
FORMULAS_PROTEGIDAS = ("se solicita", "se informa", "se requiere", "se remite", "se adjunta", "sin otro particular",
                       "en el marco de las atribuciones", "habeas corpus", "a los efectos de su conocimiento")

# Tecnicismo → alternativa común (ANDIS, guía CABA y uso del organismo).
GLOSARIO: dict[str, str] = {
    "a los fines de": "para", "a efectos de": "para", "a fin de": "para", "en virtud de": "por", "toda vez que": "porque",
    "sin perjuicio de": "aunque", "conforme": "según", "dar curso": "tramitar", "obrante": "que está", "ut supra": "más arriba",
    "intramuros": "dentro de la unidad", "requerimiento": "pedido", "articular": "coordinar", "en orden a": "para",
    "en tal sentido": "por eso", "por intermedio de": "por medio de", "elevar": "enviar", "efectuar": "hacer", "proceder a": "el verbo solo («notificar» en lugar de «proceder a notificar»)",
    "PPL": "persona detenida", "LPU": "número de legajo", "fs.": "fojas (páginas)",
}

_ORACION = re.compile(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÑ¿¡«\"(])")
_PARTICIPIO = (r"(?:\w+(?:ad|id)[oa]s?|(?:hech|dich|puest|vist|escrit|abiert|cubiert|resuelt|devuelt|impres|dispuest|propuest|"
               r"expuest|compuest|interpuest|suspendid)[oa]s?)")
_PASIVA = re.compile(rf"\b(?:fue|fueron|ha sido|han sido|había sido|habían sido|será|serán|sea|sean|fuera|fueran|fuese|fuesen)\s+{_PARTICIPIO}\b",
                     re.I)
_SE_COMPUESTO = re.compile(rf"\bse\s+(?:ha|han|había|habían|hubiera|hubieran)\s+{_PARTICIPIO}\b", re.I)
_DOBLE_NEGACION = re.compile(r"\bno\s+(?:es|son|resulta|resultan|parece|parecen|era|eran|sería)\s+(?:in|im|des|i)\w{3,}"
                             r"|\bno\s+(?:deja|dejan|dejó|dejaron)\s+de\b|\bno\s+carece[n]?\s+de\b|\bno\s+es\s+menos\b", re.I)


@dataclass(frozen=True)
class Aviso:
    regla: str
    mensaje: str
    porque: str
    fragmento: str


POR_QUE = {
    "oracion_larga": "Una oración larga obliga a releer. La guía de lenguaje claro recomienda no pasar de {n} palabras.",
    "parrafo_largo": "Un párrafo de más de {n} líneas cansa: conviene una idea por párrafo.",
    "varias_ideas": "Varias ideas separadas por punto y coma se leen mejor como oraciones aparte.",
    "pasiva": "La voz activa dice quién hace qué («la Unidad informó» en lugar de «fue informado por la Unidad»).",
    "doble_negacion": "La doble negación obliga a pensar dos veces: decilo en positivo («es probable» en lugar de «no es improbable»).",
    "tecnicismo": "Hay una palabra más común que dice lo mismo.",
}


def _oraciones(texto: str) -> list[str]:
    return [o.strip() for linea in texto.splitlines() for o in _ORACION.split(linea) if o.strip()]


def _corto(texto: str, palabras: int = 8) -> str:
    p = texto.split()
    return " ".join(p[:palabras]) + ("…" if len(p) > palabras else "")


def _protegido(fragmento: str) -> bool:
    f = fragmento.lower()
    return any(x in f for x in FORMULAS_PROTEGIDAS)


def revisar(texto: str | None, perfil: Perfil = PERFIL_GENERAL) -> list[Aviso]:
    """Avisos de lenguaje claro sobre el texto. No cambia nada."""
    avisos: list[Aviso] = []
    if not texto or not texto.strip():
        return avisos
    max_par = perfil.max_lineas_parrafo * PALABRAS_POR_LINEA
    for parrafo in (p.strip() for p in texto.splitlines()):
        if len(parrafo.split()) > max_par:
            avisos.append(Aviso("parrafo_largo", f"Párrafo de unas {len(parrafo.split()) // PALABRAS_POR_LINEA} líneas",
                                POR_QUE["parrafo_largo"].format(n=perfil.max_lineas_parrafo), _corto(parrafo)))
    for o in _oraciones(texto):
        n = len(o.split())
        if n > perfil.max_palabras_oracion:
            avisos.append(Aviso("oracion_larga", f"Oración de {n} palabras", POR_QUE["oracion_larga"].format(n=perfil.max_palabras_oracion),
                                _corto(o)))
        if o.count(";") >= 2:
            avisos.append(Aviso("varias_ideas", "Varias ideas en una oración", POR_QUE["varias_ideas"], _corto(o)))
        if perfil.controlar_pasivas:
            for m in list(_PASIVA.finditer(o)) + list(_SE_COMPUESTO.finditer(o)):
                if not _protegido(m.group(0)):
                    avisos.append(Aviso("pasiva", f"Voz pasiva: «{m.group(0)}»", POR_QUE["pasiva"], _corto(o)))
        for m in _DOBLE_NEGACION.finditer(o):
            avisos.append(Aviso("doble_negacion", f"Doble negación: «{m.group(0)}»", POR_QUE["doble_negacion"], _corto(o)))
    if perfil.controlar_tecnicismos:
        for termino, alternativa in GLOSARIO.items():
            sensible = termino.isupper()
            patron = re.compile(r"(?<!\w)" + re.escape(termino) + r"(?!\w)", 0 if sensible else re.I)
            hallado = patron.search(texto)
            if hallado and not _protegido(texto[max(0, hallado.start() - 20):hallado.end() + 20]):
                avisos.append(Aviso("tecnicismo", f"«{hallado.group(0)}» → «{alternativa}»", POR_QUE["tecnicismo"], hallado.group(0)))
    return avisos


ETIQUETAS = OrderedDict([("oracion_larga", "oración(es) larga(s)"), ("parrafo_largo", "párrafo(s) largo(s)"),
                         ("varias_ideas", "oración(es) con varias ideas"), ("pasiva", "voz pasiva"),
                         ("doble_negacion", "doble negación"), ("tecnicismo", "tecnicismo(s) con alternativa común")])


def observaciones(texto: str | None, perfil: Perfil = PERFIL_GENERAL, maximo_ejemplos: int = 3) -> list[str]:
    """Una línea por regla, para la lista de observaciones de la nota: cuántas, ejemplos y por qué."""
    por_regla: dict[str, list[Aviso]] = {}
    for a in revisar(texto, perfil):
        por_regla.setdefault(a.regla, []).append(a)
    salida = []
    for regla, etiqueta in ETIQUETAS.items():
        lista = por_regla.get(regla)
        if not lista:
            continue
        ejemplos = "; ".join(a.mensaje if regla in ("pasiva", "doble_negacion", "tecnicismo") else f"«{a.fragmento}»"
                             for a in lista[:maximo_ejemplos])
        salida.append(f"Lenguaje claro: {len(lista)} {etiqueta} ({ejemplos}). {lista[0].porque}")
    return salida


def interpretacion_inflesz(indice: float | None) -> str:
    """Propuesta 13: escala INFLESZ (Barrio Cantalejo) para el índice de Szigriszt-Pazos."""
    if indice is None:
        return ""
    for tope, nombre in ((40, "muy difícil"), (55, "algo difícil"), (65, "normal"), (80, "bastante fácil")):
        if indice < tope:
            return nombre
    return "muy fácil"
