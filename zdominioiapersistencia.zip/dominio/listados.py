"""Propuesta 37: comparar cada listado de personas detenidas con el anterior de la misma fuerza antes de confirmar.

La vista previa ya muestra altas, actualizaciones y errores, pero no si el listado en sí es raro. Un listado al que le falta una
unidad entera puede generar decenas de egresos. Acá se arma el «perfil» de un listado (personas por unidad, porcentaje sin DNI,
columnas con datos) y se compara con el del listado anterior. Las alertas no frenan la carga: piden una confirmación aparte.
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

BAJA_UNIDAD = 0.30      # una unidad que baja más del 30 %
MINIMO_UNIDAD = 10      # solo para unidades con al menos 10 personas en el listado anterior
SUBA_SIN_DNI = 10.0     # puntos porcentuales
BAJA_TOTAL = 0.30


def _norm(t: object) -> str:
    s = "".join(c for c in unicodedata.normalize("NFD", str(t or "")) if unicodedata.category(c) != "Mn")
    return " ".join(s.lower().split())


def clave_unidad(reg: Mapping[str, Any]) -> str:
    if reg.get("unidad_id") not in (None, ""):
        return f"u:{reg['unidad_id']}"
    otro = _norm(reg.get("centro_otro"))
    return f"o:{otro}" if otro else "sin_lugar"


def perfil(registros: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    regs = list(registros)
    por_unidad = Counter(clave_unidad(r) for r in regs)
    sin_dni = sum(1 for r in regs if not re.sub(r"\D", "", str(r.get("dni") or "")))
    columnas = sorted({str(k) for r in regs for k, v in r.items() if not str(k).startswith("_") and v not in (None, "")})
    return {"filas": len(regs), "por_unidad": dict(por_unidad), "sin_dni_pct": round(100 * sin_dni / len(regs), 1) if regs else 0.0,
            "columnas": columnas}


@dataclass(frozen=True)
class Alerta:
    tipo: str
    mensaje: str


def comparar(nuevo: Mapping[str, Any], anterior: Mapping[str, Any] | None, *, fecha_nuevo: str | None = None,
             fecha_anterior: str | None = None, fecha_ultima: str | None = None,
             nombres: Mapping[str, str] | None = None, etiquetas: Mapping[str, str] | None = None) -> list[Alerta]:
    """Alertas del listado nuevo contra el anterior de la misma fuerza. `nombres`: clave de unidad → nombre para mostrar.
    `fecha_ultima`: la fecha más nueva ya cargada de esa fuerza."""
    alertas: list[Alerta] = []
    nombres = nombres or {}
    if fecha_nuevo and fecha_ultima and fecha_nuevo < fecha_ultima:
        alertas.append(Alerta("fecha", f"La fecha del listado ({fecha_nuevo}) es anterior a la del último cargado de esta fuerza "
                                       f"({fecha_ultima}): no va a pisar datos más nuevos, pero revisá que sea el archivo correcto."))
    if not anterior:
        return alertas
    desde = f" del listado anterior ({fecha_anterior})" if fecha_anterior else " del listado anterior"
    filas_ant, filas = int(anterior.get("filas") or 0), int(nuevo.get("filas") or 0)
    if filas_ant >= MINIMO_UNIDAD and filas < filas_ant * (1 - BAJA_TOTAL):
        alertas.append(Alerta("total", f"Trae {filas} personas contra {filas_ant}{desde} (baja del {round(100 * (1 - filas / filas_ant))} %)."))
    ant_u: Mapping[str, int] = anterior.get("por_unidad") or {}
    nue_u: Mapping[str, int] = nuevo.get("por_unidad") or {}
    for clave, n_ant in sorted(ant_u.items(), key=lambda x: -x[1]):
        if n_ant < MINIMO_UNIDAD or clave == "sin_lugar":
            continue
        n = int(nue_u.get(clave, 0))
        nombre = nombres.get(clave) or clave.split(":", 1)[-1]
        if n == 0:
            alertas.append(Alerta("unidad", f"{nombre}: no figura nadie (tenía {n_ant}{desde}). ¿Falta esa unidad en el archivo?"))
        elif n < n_ant * (1 - BAJA_UNIDAD):
            alertas.append(Alerta("unidad", f"{nombre}: {n} personas contra {n_ant}{desde} (baja del {round(100 * (1 - n / n_ant))} %)."))
    pct_ant, pct = float(anterior.get("sin_dni_pct") or 0), float(nuevo.get("sin_dni_pct") or 0)
    if pct - pct_ant > SUBA_SIN_DNI:
        alertas.append(Alerta("sin_dni", f"El {pct:g} % de las filas viene sin DNI (antes era el {pct_ant:g} %)."))
    faltan = sorted(set(anterior.get("columnas") or []) - set(nuevo.get("columnas") or []))
    if faltan:
        alertas.append(Alerta("columnas", "Columnas que venían con datos y ahora vienen vacías o no están: "
                                            + ", ".join((etiquetas or {}).get(c, c) for c in faltan) + "."))
    return alertas
