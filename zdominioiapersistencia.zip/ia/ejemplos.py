"""Propuesta 18: ejemplos elegidos por parecido para la corrección de la IA (few-shot).

De las decisiones de la Dirección (`correcciones_director`: texto original → texto final aprobado) se eligen los 2 o 3 pares
más parecidos al párrafo a corregir (palabras en común, con peso por rareza) y se le muestran a la IA como ejemplos de lo que
se aprueba. Se activa con config.ini [ollama] ejemplos_correccion = 2 (por defecto 0: el pedido queda como hoy).
"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Sequence
from dataclasses import dataclass

_PAL = re.compile(r"[a-zñ]{3,}")
MAX_CARACTERES = 400


def _palabras(t: str) -> set[str]:
    n = "".join(c for c in unicodedata.normalize("NFD", (t or "").lower()) if unicodedata.category(c) != "Mn")
    return set(_PAL.findall(n))


@dataclass(frozen=True)
class Par:
    original: str
    final: str


def elegir(texto: str, pares: Sequence[Par], n: int) -> list[Par]:
    """Los `n` pares más parecidos al texto (con algo en común). Pares iguales o demasiado largos no sirven de ejemplo."""
    if n <= 0 or not pares:
        return []
    utiles = [p for p in pares if p.original != p.final and len(p.original) <= MAX_CARACTERES]
    df: Counter[str] = Counter()
    conjuntos = [_palabras(p.original) for p in utiles]
    for c in conjuntos:
        df.update(c)
    total = len(utiles) or 1
    buscadas = _palabras(texto)

    def puntaje(c: set[str]) -> float:
        return sum(math.log(1 + total / df[w]) for w in buscadas & c)
    orden = sorted(((puntaje(c), i) for i, c in enumerate(conjuntos)), key=lambda x: (-x[0], x[1]))
    return [utiles[i] for s, i in orden if s > 0][:n]


def bloque(pares: Iterable[Par]) -> str:
    """Texto para agregar al pedido (antes del texto a corregir)."""
    lista = list(pares)
    if not lista:
        return ""
    lineas = ["CORRECCIONES QUE LA DIRECCIÓN YA APROBÓ EN TEXTOS PARECIDOS (solo como referencia de estilo, no copies su contenido):", ""]
    for p in lista:
        lineas += [f"Antes: \"{p.original}\"", f"Aprobado: \"{p.final}\"", ""]
    return "\n".join(lineas) + "\n"
