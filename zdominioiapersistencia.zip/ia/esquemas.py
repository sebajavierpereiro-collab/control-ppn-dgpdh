"""Propuesta 19: respuestas de la IA con esquema JSON validado.

`"format": "json"` garantiza un JSON pero no su forma. Desde Ollama 0.5 se puede mandar en `format` el **esquema**: el
modelo queda obligado a respetar los `enum` y los rangos. La misma clase Pydantic valida después la respuesta, así que
cada asistente recibe un objeto con los campos correctos o `None` (y usa la versión por reglas).
Pydantic ya viene con FastAPI: no es una dependencia nueva.
"""
from __future__ import annotations

import json
import re
from typing import Annotated, Any, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, ValidationError

M = TypeVar("M", bound=BaseModel)
_LLAVES = re.compile(r"\{.*\}", re.S)


class _Base(BaseModel):
    model_config = ConfigDict(extra="ignore", str_strip_whitespace=True)


class OpinionDuplicado(_Base):
    """Revisión de la base de personas detenidas: ¿estas dos fichas son la misma persona?"""
    veredicto: Literal["misma", "distinta", "dudosa"]
    confianza: Annotated[int, Field(ge=0, le=100)]
    motivo: Annotated[str, Field(max_length=500)] = ""


class Resumen(_Base):
    """«Pendientes de tu firma»: resumen de 2 o 3 líneas."""
    lineas: Annotated[list[Annotated[str, Field(min_length=1, max_length=400)]], Field(min_length=2, max_length=3)]


class Proveido(_Base):
    texto: Annotated[str, Field(min_length=80, max_length=6000)]


def esquema(modelo: type[BaseModel]) -> dict[str, Any]:
    """Esquema JSON para mandar en `format` (sin títulos, que solo agregan tokens)."""
    def limpiar(nodo: Any) -> Any:
        if isinstance(nodo, dict):
            return {k: limpiar(v) for k, v in nodo.items() if k != "title"}
        if isinstance(nodo, list):
            return [limpiar(v) for v in nodo]
        return nodo
    resultado: dict[str, Any] = limpiar(modelo.model_json_schema())
    return resultado


def validar(modelo: type[M], salida: str | None) -> M | None:
    """El objeto validado, o None si la salida no tiene la forma pedida. Tolera texto alrededor del JSON
    (modelos viejos de Ollama sin soporte de esquemas)."""
    if not salida:
        return None
    encontrado = _LLAVES.search(salida)
    for candidato in (salida, encontrado.group(0) if encontrado else None):
        if not candidato:
            continue
        try:
            return modelo.model_validate(json.loads(candidato))
        except (ValueError, ValidationError, TypeError):
            continue
    return None
