"""IA local (Ollama): reglas puras para armar y controlar los pedidos (ADR-0004). Nada de este paquete llama a la red."""
