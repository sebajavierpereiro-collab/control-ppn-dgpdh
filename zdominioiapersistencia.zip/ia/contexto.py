"""Propuesta 20: ventana de contexto (num_ctx) explícita y control del tamaño de cada pedido a Ollama.

Ollama usa por defecto una ventana chica (2048 o 4096 tokens) y, si el pedido no entra, recorta el comienzo sin avisar: el
modelo responde sin parte de las instrucciones. Acá se estima el tamaño del pedido, se elige la ventana y se marca cuándo el
pedido queda cerca del límite (más del 90 %) o directamente no entra, para que quede en `ia_registro`.
"""
from __future__ import annotations

from dataclasses import dataclass

CARACTERES_POR_TOKEN = 3.5   # promedio prudente para castellano administrativo
MARGEN_TOKENS = 256          # plantilla del chat y separadores que agrega Ollama
VENTANA_MINIMA = 4096
UMBRAL_AVISO = 0.9


@dataclass(frozen=True)
class Medida:
    tokens_estimados: int   # pedido + respuesta reservada + margen
    num_ctx: int            # ventana que se le pide a Ollama
    uso: float              # tokens_estimados / num_ctx

    @property
    def cerca_del_limite(self) -> bool:
        return self.uso > UMBRAL_AVISO

    @property
    def excede(self) -> bool:
        return self.tokens_estimados > self.num_ctx

    def aviso(self) -> str | None:
        if self.excede:
            return (f"El pedido (≈{self.tokens_estimados} tokens) no entra en la ventana de {self.num_ctx}: "
                    "el modelo puede haber leído solo una parte.")
        if self.cerca_del_limite:
            return f"El pedido usa el {round(self.uso * 100)} % de la ventana de {self.num_ctx} tokens."
        return None


def estimar_tokens(texto: str | None) -> int:
    return int(len(texto or "") / CARACTERES_POR_TOKEN)


def medir(prompt: str | None, num_predict: int | None, *, maximo: int, fijo: int | None = None) -> Medida:
    """Ventana para un pedido. Sin `fijo`: la que hace falta, en múltiplos de 1024, entre 4096 y `maximo`.
    Con `fijo` (config.ini `[ollama] num_ctx_<proceso>`): esa, aunque el pedido no entre (se marca como excedido)."""
    necesarios = estimar_tokens(prompt) + max(0, int(num_predict or 0)) + MARGEN_TOKENS
    if fijo and fijo > 0:
        ctx = int(fijo)
    else:
        ctx = min(max(VENTANA_MINIMA, -(-necesarios // 1024) * 1024), max(VENTANA_MINIMA, int(maximo)))
    return Medida(tokens_estimados=necesarios, num_ctx=ctx, uso=round(necesarios / ctx, 3))
