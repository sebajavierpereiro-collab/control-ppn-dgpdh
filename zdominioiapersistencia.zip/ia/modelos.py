"""Propuestas 22 y 27: qué modelo usa cada proceso y con qué versión exacta.

- 22: los procesos que escriben castellano (corrección y redacción) necesitan un modelo de 7B o más. Con uno más chico
  (por ejemplo `phi3:mini`, ≈3,8B, entrenado sobre todo en inglés) se avisa en Administración → IA. La elección del modelo
  se hace con el examen propio (herramientas/examen_ia.py, propuesta 23) entre candidatos locales como `qwen2.5:7b` o
  Salamandra 7B Instruct (GGUF). El sistema no descarga modelos: lo hace una persona con `ollama pull`.
- 27: el nombre de un modelo (`qwen2.5:7b`) puede apuntar a otros pesos después de un `ollama pull`. Lo que identifica la
  versión es el *digest* que informa Ollama al listar los modelos. Se guarda en cada llamada y se avisa cuando cambia.
"""
from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

PROCESOS_QUE_REDACTAN = frozenset({"correccion", "redaccion"})
MINIMO_REDACCION_B = 7.0
RECOMENDACION = ("Para corrección y redacción en castellano conviene un modelo de 7B o más, evaluado con el examen propio "
                 "(herramientas/examen_ia.py; ver docs/propuestas/config_notas_ia.md). Candidatos locales: qwen2.5:7b o Salamandra 7B Instruct (GGUF). "
                 "Se configura en config.ini, [ollama] modelo_correccion y modelo_redaccion.")
# Tamaños conocidos de etiquetas sin número (cuando Ollama no informa parameter_size)
_CONOCIDOS = {"phi3:mini": 3.8, "phi3:medium": 14.0, "phi3.5:latest": 3.8, "phi3:latest": 3.8, "phi4-mini:latest": 3.8,
              "gemma2:latest": 9.0, "llama3:latest": 8.0, "mistral:latest": 7.0, "qwen2.5:latest": 7.0}
_TAMANO = re.compile(r"(\d+(?:[.,]\d+)?)\s*([bm])\b", re.I)


@dataclass(frozen=True)
class InfoModelo:
    nombre: str
    digest: str | None
    tamano_b: float | None      # miles de millones de parámetros


def _normalizar(nombre: str) -> str:
    n = (nombre or "").strip().lower()
    return n if ":" in n else f"{n}:latest"


def tamano_desde_texto(texto: str | None) -> float | None:
    """«7.6B» → 7.6; «494.35M» → 0.49; «qwen2.5:7b» → 7.0; «llama3.1:8b-instruct-q4» → 8.0."""
    if not texto:
        return None
    m = _TAMANO.search(texto.split(":", 1)[-1] if ":" in texto else texto)
    if m is None:
        return None
    valor = float(m.group(1).replace(",", "."))
    return valor / 1000 if m.group(2).lower() == "m" else valor


def info_desde_tags(respuesta: Mapping[str, Any] | None) -> dict[str, InfoModelo]:
    """Lee la respuesta de `/api/tags` de Ollama: nombre → digest y tamaño."""
    salida: dict[str, InfoModelo] = {}
    for m in (respuesta or {}).get("models") or []:
        if not isinstance(m, Mapping):
            continue
        nombre = str(m.get("name") or m.get("model") or "").strip()
        if not nombre:
            continue
        detalles = m.get("details") if isinstance(m.get("details"), Mapping) else {}
        tam = tamano_desde_texto(str(detalles.get("parameter_size") or "")) if detalles else None
        salida[_normalizar(nombre)] = InfoModelo(nombre, str(m.get("digest") or "") or None, tam)
    return salida


def tamano_de(modelo: str, conocidos: Mapping[str, InfoModelo] | None = None) -> float | None:
    clave = _normalizar(modelo)
    info = (conocidos or {}).get(clave)
    if info and info.tamano_b:
        return info.tamano_b
    return _CONOCIDOS.get(clave) or tamano_desde_texto(clave)


def advertencia(proceso: str, modelo: str, conocidos: Mapping[str, InfoModelo] | None = None) -> str | None:
    """Texto para Administración → IA si un proceso que redacta usa un modelo chico (o de tamaño desconocido)."""
    if proceso not in PROCESOS_QUE_REDACTAN:
        return None
    tam = tamano_de(modelo, conocidos)
    if tam is None:
        return f"No se sabe el tamaño de {modelo}: verificá con el examen propio que corrija bien en castellano."
    if tam < MINIMO_REDACCION_B:
        return (f"{modelo} tiene ≈{tam:g}B de parámetros: es chico para escribir en castellano. " + RECOMENDACION)
    return None


def digest_de(modelo: str, conocidos: Mapping[str, InfoModelo] | None) -> str | None:
    info = (conocidos or {}).get(_normalizar(modelo))
    return info.digest if info else None


def cambios_de_digest(anteriores: Mapping[str, str], actuales: Mapping[str, InfoModelo],
                      en_uso: Iterable[str]) -> list[tuple[str, str, str]]:
    """(modelo, digest anterior, digest nuevo) de los modelos en uso cuyo digest cambió desde la última vez."""
    cambios = []
    for modelo in sorted({_normalizar(m) for m in en_uso}):
        info = actuales.get(modelo)
        previo = anteriores.get(modelo)
        if info and info.digest and previo and previo != info.digest:
            cambios.append((modelo, previo, info.digest))
    return cambios


def version_prompt(plantilla: str) -> str:
    """Identificador corto de la versión de una plantilla de prompt (la parte fija, sin el documento)."""
    return hashlib.sha256(plantilla.encode("utf-8")).hexdigest()[:12]
