"""Registro de Obstaculizaciones: casos de uso sobre la base (sqlite3). Cada cambio queda en la auditoría única."""
from __future__ import annotations

import hashlib
import re
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dgpdh.dominio import obstaculizaciones as dom
from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

REINTENTOS = 5


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def _filas(con: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        yield con
    finally:
        con.row_factory = previo


def _actor(p: dom.Persona) -> au.Actor:
    return au.Actor(p.id, p.nombre)


# ---------------------------------------------------------------- tipos (ABM)
def listar_tipos(con: sqlite3.Connection, solo_activos: bool = True) -> list[dict[str, Any]]:
    with _filas(con):
        filas = con.execute("""SELECT t.*, (SELECT COUNT(*) FROM obstaculizaciones o WHERE o.tipo_id = t.id) AS usos
                               FROM obstaculizacion_tipos t""" + (" WHERE t.activo = 1" if solo_activos else "")
                            + " ORDER BY t.activo DESC, t.orden, t.nombre").fetchall()
    return [dict(f) for f in filas]


def guardar_tipo(con: sqlite3.Connection, p: dom.Persona, nombre: str, descripcion: str | None = None,
                 tipo_id: int | None = None, orden: int | None = None) -> int:
    if not p.puede_administrar_tipos:
        raise PermisoDenegado("Solo la Dirección administra los tipos de obstaculización.")
    n = re.sub(r"\s+", " ", nombre or "").strip()[:200]
    if len(n) < 4:
        raise DatoInvalido("Escribí el nombre del tipo.")
    d = re.sub(r"\s+", " ", descripcion or "").strip()[:500] or None
    otro = con.execute("SELECT id FROM obstaculizacion_tipos WHERE nombre = ? COLLATE NOCASE AND id != ?", (n, tipo_id or -1)).fetchone()
    if otro:
        raise Conflicto("Ya existe un tipo con ese nombre.")
    if tipo_id is None:
        o = orden if orden is not None else int(con.execute("SELECT COALESCE(MAX(orden), 0) + 1 FROM obstaculizacion_tipos").fetchone()[0])
        cur = con.execute("INSERT INTO obstaculizacion_tipos (nombre, descripcion, orden, creado_por, creado_en) VALUES (?, ?, ?, ?, ?)",
                          (n, d, o, p.nombre, _ahora()))
        nuevo = int(cur.lastrowid or 0)
        au.registrar(con, accion="Tipo de obstaculización creado", entidad="obstaculizacion_tipo", entidad_id=nuevo,
                     despues={"nombre": n, "descripcion": d}, actor=_actor(p))
        return nuevo
    with _filas(con):
        antes = con.execute("SELECT nombre, descripcion, orden FROM obstaculizacion_tipos WHERE id = ?", (tipo_id,)).fetchone()
    if not antes:
        raise NoEncontrado("El tipo no existe.")
    con.execute("UPDATE obstaculizacion_tipos SET nombre = ?, descripcion = ?, orden = COALESCE(?, orden), actualizado_por = ?, actualizado_en = ? WHERE id = ?",
                (n, d, orden, p.nombre, _ahora(), tipo_id))
    au.registrar(con, accion="Tipo de obstaculización modificado", entidad="obstaculizacion_tipo", entidad_id=tipo_id,
                 antes=dict(antes), despues={"nombre": n, "descripcion": d, "orden": orden}, actor=_actor(p))
    return tipo_id


def cambiar_estado_tipo(con: sqlite3.Connection, p: dom.Persona, tipo_id: int, activo: bool) -> None:
    """Baja lógica (deja de ofrecerse en la carga; los registros que lo usan lo siguen mostrando) o reactivación."""
    if not p.puede_administrar_tipos:
        raise PermisoDenegado("Solo la Dirección administra los tipos de obstaculización.")
    n = con.execute("UPDATE obstaculizacion_tipos SET activo = ?, actualizado_por = ?, actualizado_en = ? WHERE id = ?",
                    (1 if activo else 0, p.nombre, _ahora(), tipo_id)).rowcount
    if not n:
        raise NoEncontrado("El tipo no existe.")
    au.registrar(con, accion="Tipo de obstaculización " + ("reactivado" if activo else "dado de baja"), entidad="obstaculizacion_tipo",
                 entidad_id=tipo_id, actor=_actor(p))


def ids_tipos_activos(con: sqlite3.Connection) -> set[int]:
    return {int(f[0]) for f in con.execute("SELECT id FROM obstaculizacion_tipos WHERE activo = 1")}


# ---------------------------------------------------------------- alcance de visibilidad
def unidades_a_cargo(con: sqlite3.Connection, p: dom.Persona) -> frozenset[int]:
    """Unidades de los viajes frecuentes activos del equipo de la coordinación (por nombre de equipo, como los guarda Autos PPN)."""
    if not p.es_coordinacion or p.equipo_id is None:
        return frozenset()
    try:
        filas = con.execute("""SELECT DISTINCT f.unidad_id FROM viajes_frecuentes f JOIN equipos e ON lower(trim(e.nombre)) = lower(trim(f.equipo_nombre))
                               WHERE e.id = ? AND f.activo = 1 AND f.unidad_id IS NOT NULL""", (p.equipo_id,)).fetchall()
    except sqlite3.OperationalError:  # base sin Autos PPN
        return frozenset()
    return frozenset(int(f[0]) for f in filas)


def _registro(fila: dict[str, Any], agentes: frozenset[int]) -> dom.Registro:
    return dom.Registro(cargado_por_id=int(fila["cargado_por_id"]), equipo_id=fila.get("equipo_id"), unidad_id=fila.get("unidad_id"),
                        creado_en=str(fila["creado_en"]), estado=str(fila["estado"]), informe_nota_id=fila.get("informe_nota_id"),
                        agentes_ids=agentes)


def _agentes_ids(con: sqlite3.Connection, ids: list[int]) -> dict[int, frozenset[int]]:
    out: dict[int, set[int]] = {i: set() for i in ids}
    for i in range(0, len(ids), 500):
        lote = ids[i:i + 500]
        for oid, uid in con.execute(f"SELECT obstaculizacion_id, usuario_id FROM obstaculizacion_agentes WHERE usuario_id IS NOT NULL AND obstaculizacion_id IN ({','.join('?' * len(lote))})", lote):
            out[int(oid)].add(int(uid))
    return {k: frozenset(v) for k, v in out.items()}


# ---------------------------------------------------------------- alta, edición, anulación
def _siguiente(con: sqlite3.Connection, anio: int) -> int:
    return int(con.execute("SELECT COALESCE(MAX(correlativo), 0) + 1 FROM obstaculizaciones WHERE anio = ?", (anio,)).fetchone()[0])


def _escribir_detalle(con: sqlite3.Connection, oid: int, c: dom.Carga) -> None:
    con.execute("DELETE FROM obstaculizacion_tipos_extra WHERE obstaculizacion_id = ?", (oid,))  # detalle derivado del formulario; el cambio queda en la auditoría
    con.executemany("INSERT INTO obstaculizacion_tipos_extra (obstaculizacion_id, tipo_id) VALUES (?, ?)", [(oid, t) for t in c.tipos_extra])
    con.execute("DELETE FROM obstaculizacion_agentes WHERE obstaculizacion_id = ?", (oid,))
    con.executemany("INSERT INTO obstaculizacion_agentes (obstaculizacion_id, usuario_id, nombre) VALUES (?, ?, ?)", [(oid, u, n) for u, n in c.agentes])
    con.execute("DELETE FROM obstaculizacion_vinculos WHERE obstaculizacion_id = ?", (oid,))
    con.executemany("INSERT INTO obstaculizacion_vinculos (obstaculizacion_id, clase, ref_id, ref_texto) VALUES (?, ?, ?, ?)",
                    [(oid, cl, ri, rt) for cl, ri, rt in c.vinculos])


def _como_dict(c: dom.Carga) -> dict[str, Any]:
    return {"fecha_hecho": c.fecha_hecho, "hora_hecho": c.hora_hecho, "unidad_id": c.unidad_id, "lugar_otro": c.lugar_otro,
            "sector": c.sector, "tipo_id": c.tipo_id, "tipos_extra": list(c.tipos_extra), "equipo_id": c.equipo_id, "fuerza_id": c.fuerza_id,
            "autoridad": c.autoridad, "descripcion": c.descripcion, "subsanado": c.subsanado, "como_se_subsano": c.como_se_subsano,
            "demora_minutos": c.demora_minutos, "agentes": [n for _, n in c.agentes], "vinculos": [list(v) for v in c.vinculos]}


def crear(con: sqlite3.Connection, p: dom.Persona, c: dom.Carga, circuito: str | None = None) -> tuple[int, str]:
    """Registra la obstaculización. Devuelve (id, número OB-AAAA-NNNN). `con` no debe tener una transacción abierta."""
    if not p.puede_cargar:
        raise PermisoDenegado("No tenés habilitada la carga de obstaculizaciones.")
    if not dom.equipo_permitido(p, c.equipo_id):
        raise DatoInvalido("Elegí tu propio equipo: solo la Dirección registra hechos de otros equipos.")
    anio = int(c.fecha_hecho[:4])
    for _ in range(REINTENTOS):
        con.commit()
        con.execute("BEGIN IMMEDIATE")
        try:
            correlativo = _siguiente(con, anio)
            numero = dom.formato_numero(anio, correlativo)
            cur = con.execute(
                """INSERT INTO obstaculizaciones (numero, anio, correlativo, fecha_hecho, hora_hecho, unidad_id, lugar_otro, sector, tipo_id,
                   equipo_id, circuito, fuerza_id, autoridad, descripcion, subsanado, como_se_subsano, demora_minutos, cargado_por_id,
                   cargado_por, creado_en) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (numero, anio, correlativo, c.fecha_hecho, c.hora_hecho, c.unidad_id, c.lugar_otro, c.sector, c.tipo_id, c.equipo_id, circuito,
                 c.fuerza_id, c.autoridad, c.descripcion, 1 if c.subsanado else 0, c.como_se_subsano, c.demora_minutos, p.id, p.nombre, _ahora()))
            oid = int(cur.lastrowid or 0)
            _escribir_detalle(con, oid, c)
            au.registrar(con, accion="Obstaculización registrada", entidad="obstaculizacion", entidad_id=oid,
                         despues={"numero": numero, **_como_dict(c)}, actor=_actor(p))
            con.execute("COMMIT")
            return oid, numero
        except sqlite3.IntegrityError:
            con.execute("ROLLBACK")
        except Exception:
            con.execute("ROLLBACK")
            raise
    raise Conflicto("No se pudo numerar el registro (muchas cargas simultáneas). Probá de nuevo.")


def _fila(con: sqlite3.Connection, oid: int) -> dict[str, Any]:
    with _filas(con):
        f = con.execute("SELECT * FROM obstaculizaciones WHERE id = ?", (oid,)).fetchone()
    if not f:
        raise NoEncontrado("La obstaculización no existe.")
    return dict(f)


def registro_de(con: sqlite3.Connection, oid: int) -> dom.Registro:
    fila = _fila(con, oid)
    return _registro(fila, _agentes_ids(con, [oid])[oid])


def editar(con: sqlite3.Connection, p: dom.Persona, oid: int, c: dom.Carga, ahora: datetime | None = None) -> None:
    antes = obtener(con, p, oid)
    if not dom.puede_editar(p, registro_de(con, oid), ahora or datetime.now(timezone.utc)):
        raise PermisoDenegado("Ya no podés modificar este registro (pasaron 72 horas, tiene informe o no es tuyo).")
    if c.equipo_id != antes.get("equipo_id") and not dom.equipo_permitido(p, c.equipo_id):
        raise DatoInvalido("Elegí tu propio equipo: solo la Dirección registra hechos de otros equipos.")
    if int(c.fecha_hecho[:4]) != int(antes["anio"]):
        raise DatoInvalido("La fecha del hecho tiene que quedar en el mismo año del número asignado. Si el año está mal, anulalo y cargalo de nuevo.")
    con.execute("""UPDATE obstaculizaciones SET fecha_hecho=?, hora_hecho=?, unidad_id=?, lugar_otro=?, sector=?, tipo_id=?, equipo_id=?,
                   fuerza_id=?, autoridad=?, descripcion=?, subsanado=?, como_se_subsano=?, demora_minutos=?, actualizado_por=?, actualizado_en=?
                   WHERE id = ?""",
                (c.fecha_hecho, c.hora_hecho, c.unidad_id, c.lugar_otro, c.sector, c.tipo_id, c.equipo_id, c.fuerza_id, c.autoridad,
                 c.descripcion, 1 if c.subsanado else 0, c.como_se_subsano, c.demora_minutos, p.nombre, _ahora(), oid))
    _escribir_detalle(con, oid, c)
    au.registrar(con, accion="Obstaculización modificada", entidad="obstaculizacion", entidad_id=oid,
                 antes={k: antes.get(k) for k in _como_dict(c)}, despues=_como_dict(c), actor=_actor(p))


def anular(con: sqlite3.Connection, p: dom.Persona, oid: int, motivo: str, ahora: datetime | None = None) -> None:
    motivo = re.sub(r"\s+", " ", motivo or "").strip()[:300]
    if not motivo:
        raise DatoInvalido("Indicá el motivo de la anulación (queda registrado).")
    obtener(con, p, oid)
    if not dom.puede_anular(p, registro_de(con, oid), ahora or datetime.now(timezone.utc)):
        raise PermisoDenegado("No podés anular este registro.")
    con.execute("UPDATE obstaculizaciones SET estado = 'ANULADO', motivo_anulacion = ?, anulado_por = ?, anulado_en = ? WHERE id = ?",
                (motivo, p.nombre, _ahora(), oid))
    au.registrar(con, accion="Obstaculización anulada", entidad="obstaculizacion", entidad_id=oid, antes={"estado": "REGISTRADO"},
                 despues={"estado": "ANULADO", "motivo": motivo}, actor=_actor(p), motivo=motivo)


RESERVADO_INFORME = -1


def reservar_informe(con: sqlite3.Connection, oid: int) -> bool:
    """Evita dos informes del mismo hecho con pedidos simultáneos: marca el registro «informe en preparación» en una
    transacción inmediata. Devuelve False si otro pedido ya lo tomó."""
    con.commit()
    con.execute("BEGIN IMMEDIATE")
    try:
        n = con.execute("UPDATE obstaculizaciones SET informe_nota_id = ? WHERE id = ? AND informe_nota_id IS NULL AND estado = 'REGISTRADO'",
                        (RESERVADO_INFORME, oid)).rowcount
        con.execute("COMMIT")
    except Exception:
        con.execute("ROLLBACK")
        raise
    return n == 1


def liberar_informe(con: sqlite3.Connection, oid: int) -> None:
    con.execute("UPDATE obstaculizaciones SET informe_nota_id = NULL WHERE id = ? AND informe_nota_id = ?", (oid, RESERVADO_INFORME))


def marcar_informe(con: sqlite3.Connection, p: dom.Persona, oid: int, nota_id: int) -> None:
    n = con.execute("UPDATE obstaculizaciones SET informe_nota_id = ? WHERE id = ? AND (informe_nota_id IS NULL OR informe_nota_id = ?)",
                    (nota_id, oid, RESERVADO_INFORME)).rowcount
    if n != 1:
        raise Conflicto("Este registro ya tiene informe.")
    au.registrar(con, accion="Informe generado", entidad="obstaculizacion", entidad_id=oid, despues={"nota_id": nota_id}, actor=_actor(p))


# ---------------------------------------------------------------- adjuntos
def agregar_adjunto(con: sqlite3.Connection, p: dom.Persona, oid: int, nombre: str, contenido: bytes, carpeta: Path,
                    max_bytes: int) -> int:
    fila = obtener(con, p, oid)
    if fila["estado"] != "REGISTRADO":
        raise Conflicto("El registro está anulado.")
    if not dom.puede_adjuntar(p, registro_de(con, oid), datetime.now(timezone.utc)):
        raise PermisoDenegado("No podés agregar adjuntos a este registro (solo quien puede editarlo y antes del informe).")
    ext = Path(nombre or "").suffix.lower()
    if ext not in dom.EXTENSIONES_ADJUNTO:
        raise DatoInvalido(f"Tipo de archivo no admitido ({ext or 'sin extensión'}). Se aceptan: {', '.join(sorted(dom.EXTENSIONES_ADJUNTO))}.")
    if not contenido:
        raise DatoInvalido("El archivo está vacío.")
    if len(contenido) > max_bytes:
        raise DatoInvalido(f"El archivo supera el máximo de {max_bytes // (1024 * 1024)} MB.")
    huella = hashlib.sha256(contenido).hexdigest()
    destino_dir = carpeta / str(fila["anio"]) / str(oid)
    destino_dir.mkdir(parents=True, exist_ok=True)
    seguro = re.sub(r"[^\w.\- ]+", "_", Path(nombre).name)[:120] or f"adjunto{ext}"
    destino = destino_dir / f"{huella[:12]}_{seguro}"
    destino.write_bytes(contenido)  # el original, sin tocar (valor probatorio)
    cur = con.execute("""INSERT INTO obstaculizacion_adjuntos (obstaculizacion_id, nombre_original, ruta, tipo_mime, bytes, sha256, subido_por, subido_en)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", (oid, Path(nombre).name[:200], str(destino), dom.EXTENSIONES_ADJUNTO[ext], len(contenido),
                                                              huella, p.nombre, _ahora()))
    aid = int(cur.lastrowid or 0)
    au.registrar(con, accion="Adjunto agregado", entidad="obstaculizacion", entidad_id=oid,
                 despues={"adjunto_id": aid, "nombre": Path(nombre).name, "sha256": huella, "bytes": len(contenido)}, actor=_actor(p))
    return aid


def desactivar_adjunto(con: sqlite3.Connection, p: dom.Persona, oid: int, aid: int, ahora: datetime | None = None) -> None:
    obtener(con, p, oid)
    if not dom.puede_editar(p, registro_de(con, oid), ahora or datetime.now(timezone.utc)):
        raise PermisoDenegado("No podés quitar adjuntos de este registro.")
    n = con.execute("UPDATE obstaculizacion_adjuntos SET activo = 0 WHERE id = ? AND obstaculizacion_id = ?", (aid, oid)).rowcount
    if not n:
        raise NoEncontrado("El adjunto no existe.")
    au.registrar(con, accion="Adjunto quitado (el archivo se conserva)", entidad="obstaculizacion", entidad_id=oid,
                 antes={"adjunto_id": aid}, actor=_actor(p))


def adjunto(con: sqlite3.Connection, p: dom.Persona, oid: int, aid: int) -> dict[str, Any]:
    obtener(con, p, oid)
    with _filas(con):
        f = con.execute("SELECT * FROM obstaculizacion_adjuntos WHERE id = ? AND obstaculizacion_id = ?", (aid, oid)).fetchone()
    if not f:
        raise NoEncontrado("El adjunto no existe.")
    return dict(f)


# ---------------------------------------------------------------- consulta
_BASE = """SELECT o.*, t.nombre AS tipo_nombre, t.activo AS tipo_activo, u.nombre AS unidad_nombre, e.nombre AS equipo_nombre,
                  f.nombre AS fuerza_nombre
           FROM obstaculizaciones o JOIN obstaculizacion_tipos t ON t.id = o.tipo_id
           LEFT JOIN unidades u ON u.id = o.unidad_id LEFT JOIN equipos e ON e.id = o.equipo_id LEFT JOIN fuerzas f ON f.id = o.fuerza_id"""


@dataclass(frozen=True)
class Filtros:
    desde: str | None = None
    hasta: str | None = None
    unidad_id: int | None = None
    tipo_id: int | None = None
    equipo_id: int | None = None
    fuerza_id: int | None = None
    subsanado: bool | None = None
    vinculo: str | None = None        # VIAJE / NOTA / EXPEDIENTE / CON / SIN
    estado: str | None = "REGISTRADO"  # REGISTRADO / ANULADO / None (todos)
    texto: str | None = None


def _completar(con: sqlite3.Connection, filas: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ids = [int(f["id"]) for f in filas]
    if not ids:
        return filas
    agentes: dict[int, list[str]] = {i: [] for i in ids}
    vinculos: dict[int, list[dict[str, Any]]] = {i: [] for i in ids}
    extra: dict[int, list[str]] = {i: [] for i in ids}
    adj: dict[int, int] = {i: 0 for i in ids}
    for i in range(0, len(ids), 500):
        lote = ids[i:i + 500]
        q = ",".join("?" * len(lote))
        for oid, nombre in con.execute(f"SELECT obstaculizacion_id, nombre FROM obstaculizacion_agentes WHERE obstaculizacion_id IN ({q}) ORDER BY id", lote):
            agentes[int(oid)].append(str(nombre))
        for oid, clase, ri, rt in con.execute(f"SELECT obstaculizacion_id, clase, ref_id, ref_texto FROM obstaculizacion_vinculos WHERE obstaculizacion_id IN ({q}) ORDER BY id", lote):
            vinculos[int(oid)].append({"clase": clase, "ref_id": ri, "ref_texto": rt})
        for oid, nombre in con.execute(f"""SELECT x.obstaculizacion_id, t.nombre FROM obstaculizacion_tipos_extra x JOIN obstaculizacion_tipos t ON t.id = x.tipo_id
                                          WHERE x.obstaculizacion_id IN ({q})""", lote):
            extra[int(oid)].append(str(nombre))
        for oid, n in con.execute(f"SELECT obstaculizacion_id, COUNT(*) FROM obstaculizacion_adjuntos WHERE activo = 1 AND obstaculizacion_id IN ({q}) GROUP BY obstaculizacion_id", lote):
            adj[int(oid)] = int(n)
    for f in filas:
        oid = int(f["id"])
        f["agentes"], f["vinculos"], f["tipos_extra"], f["adjuntos"] = agentes[oid], vinculos[oid], extra[oid], adj[oid]
        f["lugar"] = f.get("unidad_nombre") or f.get("lugar_otro") or "—"
    return filas


def listar(con: sqlite3.Connection, p: dom.Persona, filtros: Filtros | None = None, limite: int = 5000) -> list[dict[str, Any]]:
    """Registros que la persona puede ver, con los filtros combinados."""
    fl = filtros or Filtros()
    sql, args = _BASE + " WHERE 1=1", []
    for campo, valor in (("o.fecha_hecho >=", fl.desde), ("o.fecha_hecho <=", fl.hasta), ("o.unidad_id =", fl.unidad_id),
                         ("o.equipo_id =", fl.equipo_id), ("o.fuerza_id =", fl.fuerza_id), ("o.estado =", fl.estado)):
        if valor not in (None, ""):
            sql += f" AND {campo} ?"
            args.append(valor)
    if fl.tipo_id:
        sql += " AND (o.tipo_id = ? OR EXISTS (SELECT 1 FROM obstaculizacion_tipos_extra x WHERE x.obstaculizacion_id = o.id AND x.tipo_id = ?))"
        args += [fl.tipo_id, fl.tipo_id]
    if fl.subsanado is not None:
        sql += " AND o.subsanado = ?"
        args.append(1 if fl.subsanado else 0)
    if fl.vinculo in dom.CLASES_VINCULO:
        sql += " AND EXISTS (SELECT 1 FROM obstaculizacion_vinculos v WHERE v.obstaculizacion_id = o.id AND v.clase = ?)"
        args.append(fl.vinculo)
    elif fl.vinculo == "CON":
        sql += " AND EXISTS (SELECT 1 FROM obstaculizacion_vinculos v WHERE v.obstaculizacion_id = o.id)"
    elif fl.vinculo == "SIN":
        sql += " AND NOT EXISTS (SELECT 1 FROM obstaculizacion_vinculos v WHERE v.obstaculizacion_id = o.id)"
    if fl.texto:
        sql += " AND (o.descripcion LIKE ? OR o.numero LIKE ? OR o.autoridad LIKE ? OR o.sector LIKE ?)"
        t = f"%{fl.texto.strip()[:100]}%"
        args += [t, t, t, t]
    if not p.ve_todo:  # filtro de seguridad en la consulta y, además, control fino abajo
        sql += """ AND (o.cargado_por_id = ? OR EXISTS (SELECT 1 FROM obstaculizacion_agentes a WHERE a.obstaculizacion_id = o.id AND a.usuario_id = ?)"""
        args += [p.id, p.id]
        if p.es_coordinacion and p.equipo_id is not None:
            a_cargo = sorted(unidades_a_cargo(con, p))
            sql += " OR o.equipo_id = ?" + (f" OR o.unidad_id IN ({','.join('?' * len(a_cargo))})" if a_cargo else "")
            args += [p.equipo_id, *a_cargo]
        sql += ")"
    sql += " ORDER BY o.fecha_hecho DESC, o.hora_hecho DESC, o.id DESC LIMIT ?"
    args.append(limite)
    with _filas(con):
        filas = [dict(f) for f in con.execute(sql, args).fetchall()]
    if not p.ve_todo:
        a_cargo_set = unidades_a_cargo(con, p)
        agentes = _agentes_ids(con, [int(f["id"]) for f in filas])
        filas = [f for f in filas if dom.puede_ver(p, _registro(f, agentes[int(f["id"])]), a_cargo_set)]
    return _completar(con, filas)


def obtener(con: sqlite3.Connection, p: dom.Persona, oid: int) -> dict[str, Any]:
    with _filas(con):
        f = con.execute(_BASE + " WHERE o.id = ?", (oid,)).fetchone()
    if not f:
        raise NoEncontrado("La obstaculización no existe.")
    fila = dict(f)
    if not dom.puede_ver(p, _registro(fila, _agentes_ids(con, [oid])[oid]), unidades_a_cargo(con, p)):
        raise PermisoDenegado("No tenés acceso a este registro.")
    fila = _completar(con, [fila])[0]
    with _filas(con):
        fila["lista_adjuntos"] = [dict(a) for a in con.execute(
            "SELECT * FROM obstaculizacion_adjuntos WHERE obstaculizacion_id = ? ORDER BY activo DESC, id", (oid,)).fetchall()]
        fila["agentes_detalle"] = [dict(a) for a in con.execute(
            "SELECT usuario_id, nombre FROM obstaculizacion_agentes WHERE obstaculizacion_id = ? ORDER BY id", (oid,)).fetchall()]
        fila["tipos_extra_ids"] = [int(x[0]) for x in con.execute("SELECT tipo_id FROM obstaculizacion_tipos_extra WHERE obstaculizacion_id = ?", (oid,))]
    return fila


def resumen(filas: list[dict[str, Any]]) -> dict[str, Any]:
    """Para los indicadores del panel: totales por tipo, unidad y fuerza, % subsanadas y demora media."""
    from collections import Counter
    vigentes = [f for f in filas if f["estado"] == "REGISTRADO"]
    demoras = [int(f["demora_minutos"]) for f in vigentes if f.get("demora_minutos") is not None]
    return {"total": len(vigentes), "subsanadas": sum(1 for f in vigentes if f["subsanado"]),
            "por_tipo": Counter(str(f["tipo_nombre"]) for f in vigentes).most_common(),
            "por_unidad": Counter(str(f["lugar"]) for f in vigentes).most_common(10),
            "por_fuerza": Counter(str(f.get("fuerza_nombre") or f.get("autoridad") or "—") for f in vigentes).most_common(),
            "demora_media": round(sum(demoras) / len(demoras)) if demoras else None}
