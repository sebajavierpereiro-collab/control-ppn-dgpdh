"""Protocolo interno (registro de numeración). El número se asigna AL FIRMAR, es correlativo por sigla, área y año,
no se repite ni se edita, y si se anula queda anulado con su motivo (no se reutiliza). Todo queda en la auditoría."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone

from dgpdh.dominio import clasificacion as cl
from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado
from dgpdh.seguridad import auditoria as au

REINTENTOS = 5


@dataclass(frozen=True)
class Numero:
    numero: str
    nota_id: int | None
    estado: str
    asignado_por: str
    asignado_en: str
    motivo_anulacion: str | None = None


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _fila(f: sqlite3.Row | tuple[object, ...]) -> Numero:
    """Fila con las columnas de _COLUMNAS, en ese orden (sirve con o sin row_factory)."""
    numero, nota_id, estado, por, en, motivo = tuple(f)
    return Numero(str(numero), int(str(nota_id)) if nota_id is not None else None, str(estado), str(por), str(en),
                  str(motivo) if motivo is not None else None)


_COLUMNAS = "numero, nota_id, estado, asignado_por, asignado_en, motivo_anulacion"


def vigente_de_nota(con: sqlite3.Connection, nota_id: int) -> Numero | None:
    f = con.execute(f"SELECT {_COLUMNAS} FROM protocolo WHERE nota_id = ? AND estado = 'ASIGNADO' ORDER BY id DESC LIMIT 1",
                    (nota_id,)).fetchone()
    return _fila(f) if f else None


def asignar(con: sqlite3.Connection, *, nota_id: int, tipo: str, area: str, anio: int, actor: au.Actor) -> str:
    """Asigna (o devuelve, si ya lo tiene) el número del documento. Usa su propia transacción inmediata para que dos firmas
    simultáneas no tomen el mismo correlativo; `con` no debe tener una transacción abierta."""
    sigla = cl.SIGLA_PROTOCOLO.get(tipo)
    if sigla is None:
        raise DatoInvalido("Este tipo de documento no lleva número de protocolo.")
    for _ in range(REINTENTOS):
        con.commit()
        con.execute("BEGIN IMMEDIATE")
        try:
            previo = vigente_de_nota(con, nota_id)
            if previo is not None:
                con.execute("COMMIT")
                return previo.numero
            ultimo = con.execute("SELECT MAX(correlativo) FROM protocolo WHERE sigla = ? AND area = ? AND anio = ?",
                                 (sigla, area, anio)).fetchone()[0]
            correlativo = int(ultimo or 0) + 1
            numero = cl.formato_numero(sigla, area, anio, correlativo)
            con.execute("""INSERT INTO protocolo (numero, sigla, area, anio, correlativo, nota_id, estado, asignado_por, asignado_por_id, asignado_en)
                           VALUES (?, ?, ?, ?, ?, ?, 'ASIGNADO', ?, ?, ?)""",
                        (numero, sigla, area, anio, correlativo, nota_id, actor.nombre, actor.id, _ahora()))
            con.execute("UPDATE notas SET protocolo_numero = ? WHERE id = ?", (numero, nota_id))
            au.registrar(con, accion="Protocolo asignado", entidad="nota", entidad_id=nota_id, despues={"numero": numero}, actor=actor)
            con.execute("COMMIT")
            return numero
        except sqlite3.IntegrityError:
            con.execute("ROLLBACK")  # otro proceso tomó el mismo correlativo: se reintenta con el siguiente
        except Exception:
            con.execute("ROLLBACK")
            raise
    raise Conflicto("No se pudo asignar el número de protocolo (demasiados intentos simultáneos). Probá de nuevo.")


def anular(con: sqlite3.Connection, numero: str, motivo: str, actor: au.Actor) -> Numero:
    motivo = " ".join(str(motivo or "").split())[:300]
    if not motivo:
        raise DatoInvalido("Indicá el motivo de la anulación (queda registrado).")
    f = con.execute(f"SELECT {_COLUMNAS} FROM protocolo WHERE numero = ?", (numero.strip().upper(),)).fetchone()
    if not f:
        raise NoEncontrado(f"No existe el número de protocolo {numero}.")
    actual = _fila(f)
    if actual.estado == "ANULADO":
        raise Conflicto(f"El número {actual.numero} ya está anulado.")
    con.execute("UPDATE protocolo SET estado = 'ANULADO', motivo_anulacion = ?, anulado_por = ?, anulado_en = ? WHERE numero = ?",
                (motivo, actor.nombre, _ahora(), actual.numero))
    if actual.nota_id is not None:
        con.execute("UPDATE notas SET protocolo_numero = NULL WHERE id = ? AND protocolo_numero = ?", (actual.nota_id, actual.numero))
    au.registrar(con, accion="Protocolo anulado", entidad="nota", entidad_id=actual.nota_id, antes={"numero": actual.numero},
                 actor=actor, motivo=motivo)
    return Numero(actual.numero, actual.nota_id, "ANULADO", actual.asignado_por, actual.asignado_en, motivo)


def de_nota(con: sqlite3.Connection, nota_id: int) -> list[Numero]:
    return [_fila(f) for f in con.execute(f"SELECT {_COLUMNAS} FROM protocolo WHERE nota_id = ? ORDER BY id", (nota_id,))]


def buscar(con: sqlite3.Connection, texto: str, limite: int = 100) -> list[Numero]:
    t = "%" + texto.strip().upper().replace("%", "") + "%"
    return [_fila(f) for f in con.execute(f"SELECT {_COLUMNAS} FROM protocolo WHERE numero LIKE ? ORDER BY id DESC LIMIT ?", (t, limite))]
