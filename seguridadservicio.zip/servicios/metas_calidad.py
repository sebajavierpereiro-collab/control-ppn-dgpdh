"""Propuesta 97 (viajes 44): controles de calidad de los datos de Metas: consultas que deberían dar vacío. Si alguna trae
filas, se muestran con un enlace para corregir. No corrigen nada solas."""
from __future__ import annotations

import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date


@dataclass
class Control:
    clave: str
    titulo: str
    ayuda: str
    filas: list[dict[str, object]] = field(default_factory=list)


def _mins(h: object) -> int | None:
    t = str(h or "")
    return int(t[:2]) * 60 + int(t[3:5]) if len(t) >= 5 and t[:2].isdigit() and t[3:5].isdigit() else None


def controles(con: sqlite3.Connection, anio: int, hoy: date) -> list[Control]:
    desde, hasta = f"{anio}-01-01", f"{anio}-12-31"
    out: list[Control] = []
    c = Control("audiencias_sin_viaje", "Audiencias informadas en viajes que no se realizaron",
                "El viaje está cancelado, sin confirmar o todavía no pasó, pero tiene audiencias cargadas.")
    for vid, fecha, nombre, n, estado in con.execute(
            """SELECT v.id, v.fecha, p.nombre, p.entrevistas, v.estado FROM viaje_participantes p JOIN viajes v ON v.id = p.viaje_id
               WHERE p.entrevistas IS NOT NULL AND p.entrevistas > 0 AND v.fecha BETWEEN ? AND ?
               AND (v.estado != 'CONFIRMADO' OR v.fecha >= ?) ORDER BY v.fecha""", (desde, hasta, hoy.isoformat())):
        c.filas.append({"texto": f"{fecha[8:10]}/{fecha[5:7]} · {nombre}: {n} audiencia(s) · viaje {str(estado).lower()}", "url": f"/traslados/{vid}"})
    out.append(c)
    c = Control("pabellones_sin_viaje", "Ingreso a pabellones marcado sin viaje realizado", "Se marcó el ingreso en un viaje que no se hizo.")
    for vid, fecha, nombre in con.execute(
            """SELECT v.id, v.fecha, p.nombre FROM viaje_participantes p JOIN viajes v ON v.id = p.viaje_id
               WHERE p.ingreso_pabellones = 1 AND v.fecha BETWEEN ? AND ? AND (v.estado != 'CONFIRMADO' OR v.fecha >= ?)""",
            (desde, hasta, hoy.isoformat())):
        c.filas.append({"texto": f"{fecha[8:10]}/{fecha[5:7]} · {nombre}", "url": f"/traslados/{vid}"})
    out.append(c)
    c = Control("dos_unidades_a_la_vez", "Una persona en dos unidades a la misma hora",
                "La misma persona figura en dos viajes confirmados del mismo día, a unidades distintas, con horarios que se pisan y sin ser la misma salida.")
    por: dict[tuple[int, str], list[tuple[int, int | None, int | None, object, object]]] = defaultdict(list)
    for uid, vid, fecha, unidad, s, r, veh in con.execute(
            """SELECT p.usuario_id, v.id, v.fecha, v.unidad_id, v.hora_salida, v.hora_regreso, v.vehiculo_id FROM viaje_participantes p
               JOIN viajes v ON v.id = p.viaje_id WHERE p.usuario_id IS NOT NULL AND v.estado = 'CONFIRMADO' AND v.fecha BETWEEN ? AND ?
               AND v.unidad_id IS NOT NULL""", (desde, hasta)):
        por[(int(uid), str(fecha))].append((int(vid), _mins(s), _mins(r), unidad, veh))
    nombres = {int(f[0]): str(f[1]) for f in con.execute("SELECT id, nombre FROM usuarios")}
    for (uid, fecha), vs in sorted(por.items(), key=lambda kv: kv[0][1]):
        for i, a in enumerate(vs):
            for b in vs[i + 1:]:
                if a[3] == b[3] or (a[4] and a[4] == b[4]) or None in (a[1], b[1]):
                    continue
                fa, fb = (a[2] or (a[1] or 0) + 240), (b[2] or (b[1] or 0) + 240)
                if (a[1] or 0) < fb and (b[1] or 0) < fa:
                    c.filas.append({"texto": f"{fecha[8:10]}/{fecha[5:7]} · {nombres.get(uid, uid)}: viajes #{a[0]} y #{b[0]}", "url": f"/traslados/{a[0]}"})
    out.append(c)
    c = Control("carga_futura", "Carga manual de meses que todavía no terminaron", "Se cargó lo realizado de un mes posterior al actual.")
    limite = f"M{hoy.month:02d}" if anio == hoy.year else ("M00" if anio > hoy.year else "M99")
    for eid, periodo, n in con.execute("""SELECT equipo_id, periodo, SUM(cantidad) FROM metas_realizado WHERE anio = ? AND periodo LIKE 'M%'
                                          AND periodo > ? AND cantidad > 0 GROUP BY equipo_id, periodo""", (anio, limite)):
        c.filas.append({"texto": f"Equipo #{eid}: {periodo} con {n} cargado(s)", "url": f"/metas/carga?anio={anio}&periodo={periodo}&equipo_id={eid}"})
    out.append(c)
    return out
