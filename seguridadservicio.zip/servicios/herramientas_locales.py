"""Integraciones OPTATIVAS con programas locales del servidor (regla 6 de la guía: si falta el programa, todo sigue como hoy).

- Propuesta 7: conversión de Word y PDF con un servicio unoserver siempre abierto (`unoconvert`), en lugar de arrancar
  LibreOffice en cada conversión. config.ini [libreoffice] unoserver = true (puerto 2003 en 127.0.0.1).
- Propuesta 4: OCR de los PDF escaneados con OCRmyPDF (Tesseract en castellano). Se guarda una COPIA con capa de texto
  (PDF/A); el original queda intacto con su huella. config.ini [ocr] activo = true.
- Propuesta 12: LanguageTool como servidor HTTP local fijo ([languagetool] servidor = http://127.0.0.1:8081), lo usa
  `nucleo.inicializar_languagetool`.
Solo se aceptan servicios en esta misma máquina: nada sale a la red.
"""
from __future__ import annotations

import configparser
import hashlib
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

LOCALES = ("127.0.0.1", "localhost", "::1")
log = logging.getLogger("dgpdh.herramientas_locales")

UNOSERVER: dict[str, Any] = {"activo": False, "comando": "unoconvert", "host": "127.0.0.1", "puerto": 2003, "timeout": 120}
OCR: dict[str, Any] = {"activo": False, "comando": "ocrmypdf", "idioma": "spa", "timeout": 900, "carpeta": None}
LANGUAGETOOL: dict[str, Any] = {"servidor": None}


def es_local(host_o_url: str | None) -> bool:
    if not host_o_url:
        return False
    host = urlparse(host_o_url).hostname if "://" in host_o_url else host_o_url
    return (host or "").strip("[]").lower() in LOCALES


def configurar(config: configparser.ConfigParser, carpeta_datos: Path | None = None) -> None:
    UNOSERVER["activo"] = config.getboolean("libreoffice", "unoserver", fallback=False)
    UNOSERVER["comando"] = config.get("libreoffice", "unoconvert", fallback="unoconvert")
    host = config.get("libreoffice", "unoserver_host", fallback="127.0.0.1")
    if not es_local(host):
        log.warning("[libreoffice] unoserver_host tiene que ser esta máquina (127.0.0.1): se ignora %s", host)
        host = "127.0.0.1"
    UNOSERVER["host"] = host
    UNOSERVER["puerto"] = config.getint("libreoffice", "unoserver_puerto", fallback=2003)
    OCR["activo"] = config.getboolean("ocr", "activo", fallback=False)
    OCR["comando"] = config.get("ocr", "comando", fallback="ocrmypdf")
    OCR["idioma"] = config.get("ocr", "idioma", fallback="spa")
    OCR["carpeta"] = Path(config.get("ocr", "carpeta", fallback=str((carpeta_datos or Path("datos")) / "ocr")))
    servidor = config.get("languagetool", "servidor", fallback="").strip() or None
    if servidor and not es_local(servidor):
        log.warning("[languagetool] servidor tiene que ser local (http://127.0.0.1:8081): se ignora %s", servidor)
        servidor = None
    LANGUAGETOOL["servidor"] = servidor
    from dgpdh.servicios import qr_verificacion  # propuesta 51
    qr_verificacion.CONFIG["activo"] = config.getboolean("despacho", "qr_verificacion", fallback=False)
    qr_verificacion.CONFIG["url"] = config.get("despacho", "url_verificacion", fallback="").strip()


# ---------------------------------------------------------------- 7: unoserver
def unoconvert(origen: Path, destino: Path, formato: str) -> bool:
    """True si unoserver convirtió el archivo. False (sin error) si no está activo o falló: se sigue con el método de hoy."""
    if not UNOSERVER["activo"]:
        return False
    exe = shutil.which(str(UNOSERVER["comando"]))
    if not exe:
        log.warning("unoserver activado pero no se encontró %s: se usa LibreOffice como siempre", UNOSERVER["comando"])
        return False
    try:
        r = subprocess.run([exe, "--host", str(UNOSERVER["host"]), "--port", str(UNOSERVER["puerto"]), "--convert-to", formato,
                            str(origen), str(destino)], capture_output=True, timeout=int(UNOSERVER["timeout"]))
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning("unoconvert no respondió (%s): se usa LibreOffice como siempre", e)
        return False
    if r.returncode != 0 or not destino.is_file():
        log.warning("unoconvert no pudo convertir %s: %s", origen.name, r.stderr.decode(errors="ignore")[:200])
        return False
    return True


# ---------------------------------------------------------------- 4: OCR
def _sha256(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def copia_ocr(pdf: Path) -> Path | None:
    """La copia con texto del PDF (se crea una sola vez por contenido). None si el OCR no está activo o no se pudo."""
    if not OCR["activo"] or not OCR["carpeta"]:
        return None
    exe = shutil.which(str(OCR["comando"]))
    if not exe:
        log.warning("OCR activado pero no se encontró %s: el PDF se archiva sin texto, como siempre", OCR["comando"])
        return None
    carpeta = Path(OCR["carpeta"])
    carpeta.mkdir(parents=True, exist_ok=True)
    destino = carpeta / f"{_sha256(pdf)}.pdf"
    if destino.is_file():
        return destino
    try:
        r = subprocess.run([exe, "-l", str(OCR["idioma"]), "--skip-text", "--output-type", "pdfa", str(pdf), str(destino)],
                           capture_output=True, timeout=int(OCR["timeout"]))
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning("El OCR de %s no terminó (%s)", pdf.name, e)
        return None
    if r.returncode != 0 or not destino.is_file():
        log.warning("El OCR de %s falló: %s", pdf.name, r.stderr.decode(errors="ignore")[:200])
        destino.unlink(missing_ok=True)
        return None
    return destino


def texto_pdf(pdf: Path, permitir_ocr: bool = True) -> str:
    """Texto del PDF con pypdf; si no tiene y el OCR está activo, el de la copia con OCR (el original no se toca)."""
    texto = ""
    try:
        from pypdf import PdfReader
        texto = "\n".join((p.extract_text() or "") for p in PdfReader(str(pdf)).pages[:200])
    except Exception:
        log.info("No se pudo leer el texto de %s con pypdf", pdf.name)
    if texto.strip() or not permitir_ocr:
        return texto
    copia = copia_ocr(pdf)
    if copia is None:
        return texto
    try:
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(str(copia)).pages[:200])
    except Exception:
        log.info("No se pudo leer la copia con OCR de %s", pdf.name)
        return texto
