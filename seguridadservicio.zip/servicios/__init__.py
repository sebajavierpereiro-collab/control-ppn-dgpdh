"""Casos de uso: abren la transacción, controlan reglas y auditan."""
