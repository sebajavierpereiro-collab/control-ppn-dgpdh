"""Propuesta 86: al cerrar cada trimestre, la coordinación completa un balance (estado verde / ámbar / rojo con sugerencia
automática, comentario, obstáculos y acciones) y la Dirección lo lee junto al número y responde. Cada cambio es una versión
nueva: nada se pisa."""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone

from dgpdh.errores import DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au

COLORES = {"VERDE": "En línea con lo previsto", "AMBAR": "Con demoras que se pueden recuperar", "ROJO": "Atrasado: hace falta un cambio"}


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _t(texto: str | None, largo: int) -> str:
    return re.sub(r"[ \t]+", " ", texto or "").strip()[:largo]


def sugerir(estados: list[str]) -> str:
    """Con los estados de los indicadores con meta: ninguno atrasado → verde; hasta un tercio → ámbar; más → rojo."""
    con_meta = [e for e in estados if e != "sin_meta"]
    if not con_meta:
        return "VERDE"
    atrasados = sum(1 for e in con_meta if e in ("atrasada", "sin_carga"))
    if not atrasados:
        return "VERDE"
    return "AMBAR" if atrasados / len(con_meta) <= 1 / 3 else "ROJO"


def _dicts(con: sqlite3.Connection, sql: str, args: tuple[object, ...]) -> list[dict[str, object]]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        return [dict(f) for f in con.execute(sql, args)]
    finally:
        con.row_factory = previo


def versiones(con: sqlite3.Connection, equipo_id: int, anio: int, trimestre: int) -> list[dict[str, object]]:
    return _dicts(con, "SELECT * FROM metas_revisiones WHERE equipo_id = ? AND anio = ? AND trimestre = ? ORDER BY version DESC",
                  (equipo_id, anio, trimestre))


def respuestas(con: sqlite3.Connection, equipo_id: int, anio: int, trimestre: int) -> list[dict[str, object]]:
    return _dicts(con, "SELECT * FROM metas_revisiones_respuestas WHERE equipo_id = ? AND anio = ? AND trimestre = ? ORDER BY id",
                  (equipo_id, anio, trimestre))


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, equipo_id: int, anio: int, trimestre: int, color: str, sugerido: str,
            comentario: str, obstaculos: str, acciones: str) -> int:
    if not puede:
        raise PermisoDenegado("El balance lo completa la coordinación del equipo (o la Dirección).")
    if trimestre not in (1, 2, 3, 4):
        raise DatoInvalido("Elegí el trimestre.")
    if color not in COLORES:
        raise DatoInvalido("Elegí el estado (verde, ámbar o rojo).")
    c = _t(comentario, 2000)
    if len(c) < 10:
        raise DatoInvalido("Escribí un comentario breve sobre el trimestre.")
    v = int(con.execute("SELECT COALESCE(MAX(version), 0) + 1 FROM metas_revisiones WHERE equipo_id = ? AND anio = ? AND trimestre = ?",
                        (equipo_id, anio, trimestre)).fetchone()[0])
    rid = int(con.execute("""INSERT INTO metas_revisiones (equipo_id, anio, trimestre, version, color, color_sugerido, comentario, obstaculos,
                             acciones, autor, autor_id, creado_en) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                          (equipo_id, anio, trimestre, v, color, sugerido if sugerido in COLORES else None, c, _t(obstaculos, 2000) or None,
                           _t(acciones, 2000) or None, actor.nombre, actor.id, _ahora())).lastrowid or 0)
    au.registrar(con, accion="Balance trimestral de metas", entidad="metas_revision", entidad_id=f"{equipo_id}-{anio}-T{trimestre}",
                 despues={"version": v, "color": color, "sugerido": sugerido}, actor=actor)
    return rid


def responder(con: sqlite3.Connection, actor: au.Actor, es_direccion: bool, equipo_id: int, anio: int, trimestre: int, texto: str) -> int:
    if not es_direccion:
        raise PermisoDenegado("Responde la Dirección.")
    t = _t(texto, 2000)
    if len(t) < 3:
        raise DatoInvalido("Escribí la respuesta.")
    if not versiones(con, equipo_id, anio, trimestre):
        raise DatoInvalido("Todavía no hay balance para responder.")
    rid = int(con.execute("""INSERT INTO metas_revisiones_respuestas (equipo_id, anio, trimestre, texto, autor, autor_id, creado_en)
                             VALUES (?, ?, ?, ?, ?, ?, ?)""", (equipo_id, anio, trimestre, t, actor.nombre, actor.id, _ahora())).lastrowid or 0)
    au.registrar(con, accion="Respuesta de la Dirección al balance", entidad="metas_revision", entidad_id=f"{equipo_id}-{anio}-T{trimestre}",
                 despues={"texto": t}, actor=actor)
    return rid
