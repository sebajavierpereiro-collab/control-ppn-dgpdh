"""Opciones del área Autos PPN y Metas en config.ini (sección [viajes]). Todas tienen un valor por defecto que deja el
sistema igual que antes: si la sección no está, nada cambia. Las integraciones con software externo (OSRM, OR-Tools,
mapa local) se activan acá y, si el software no está, se sigue con el cálculo propio."""
from __future__ import annotations

import configparser
from dataclasses import dataclass
from pathlib import Path

RUTA_CONFIG = Path(__file__).resolve().parents[2] / "config.ini"


@dataclass(frozen=True)
class Opciones:
    dias_constancia: int = 7             # 73: días después del viaje para marcarlo «sin constancia»
    descanso_minimo_horas: int = 10      # 59: descanso mínimo del chofer entre jornadas
    desvio_odometro_pct: int = 50        # 61: aviso si los km se apartan más que esto de lo estimado
    desvio_combustible_pct: int = 25     # 63: aviso si una carga se aparta más que esto de la mediana
    factor_ruta: float = 1.3             # 54: haversine × factor cuando no hay OSRM
    osrm_url: str = ""                   # 54: OSRM local, p. ej. http://127.0.0.1:5000 (vacío = no se usa)
    optimizador: str = ""                # 56: «ortools» o «vroom» si están instalados (vacío = planificador actual)
    mapa_pmtiles: str = ""               # 71: archivo .pmtiles dentro de static/ (vacío = listado actual)
    sede_lat: float | None = None        # 54/55/61: de dónde salen los vehículos (para estimar recorridos)
    sede_lng: float | None = None


def _int(p: configparser.ConfigParser, clave: str, defecto: int) -> int:
    try:
        return int(p.get("viajes", clave, fallback=str(defecto)).strip() or defecto)
    except ValueError:
        return defecto


def _float(p: configparser.ConfigParser, clave: str, defecto: float) -> float:
    try:
        return float(p.get("viajes", clave, fallback=str(defecto)).strip().replace(",", ".") or defecto)
    except ValueError:
        return defecto


def leer(ruta: Path | None = None) -> Opciones:
    p = configparser.ConfigParser()
    r = ruta or RUTA_CONFIG
    if r.is_file():
        try:
            p.read(r, encoding="utf-8")
        except (configparser.Error, OSError, UnicodeDecodeError):
            return Opciones()
    d = Opciones()
    return Opciones(
        dias_constancia=max(1, _int(p, "dias_constancia", d.dias_constancia)),
        descanso_minimo_horas=max(0, _int(p, "descanso_minimo_horas", d.descanso_minimo_horas)),
        desvio_odometro_pct=max(1, _int(p, "desvio_odometro_pct", d.desvio_odometro_pct)),
        desvio_combustible_pct=max(1, _int(p, "desvio_combustible_pct", d.desvio_combustible_pct)),
        factor_ruta=max(1.0, _float(p, "factor_ruta", d.factor_ruta)),
        osrm_url=p.get("viajes", "osrm_url", fallback="").strip(),
        optimizador=p.get("viajes", "optimizador", fallback="").strip().lower(),
        mapa_pmtiles=p.get("viajes", "mapa_pmtiles", fallback="").strip(),
        sede_lat=_opcional(p, "sede_lat"), sede_lng=_opcional(p, "sede_lng"),
    )


def _opcional(p: configparser.ConfigParser, clave: str) -> float | None:
    v = p.get("viajes", clave, fallback="").strip().replace(",", ".")
    try:
        return float(v) if v else None
    except ValueError:
        return None
