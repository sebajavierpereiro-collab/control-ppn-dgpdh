"""Calendario único de feriados y días no laborables (propuesta 69).

Se carga a mano o se importa desde un .ics que alguien descargó (nada se descarga solo). Nada se borra: un feriado se da
de baja (queda con quién, cuándo y por qué) y se puede reactivar. Cada cambio va a la auditoría única.
"""
from __future__ import annotations

import re
import sqlite3
from datetime import date, datetime, timezone

from dgpdh.dominio import calendario as cal
from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

ENTIDAD = "feriado"


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _hay_tabla(con: sqlite3.Connection) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'feriados'").fetchone() is not None


def conjunto(con: sqlite3.Connection, desde: date | None = None, hasta: date | None = None) -> frozenset[date]:
    """Las fechas no laborables vigentes (activas) del rango. Sin tabla (base vieja) devuelve un conjunto vacío."""
    if not _hay_tabla(con):
        return frozenset()
    sql, args = "SELECT fecha FROM feriados WHERE activo = 1", []
    if desde:
        sql += " AND fecha >= ?"
        args.append(desde.isoformat())
    if hasta:
        sql += " AND fecha <= ?"
        args.append(hasta.isoformat())
    salida: set[date] = set()
    for (f,) in con.execute(sql, args):
        try:
            salida.add(date.fromisoformat(str(f)))
        except ValueError:
            continue
    return frozenset(salida)


def listar(con: sqlite3.Connection, anio: int | None = None, incluir_bajas: bool = False) -> list[dict[str, object]]:
    if not _hay_tabla(con):
        return []
    sql, args = "SELECT * FROM feriados WHERE 1 = 1", []
    if anio:
        sql += " AND fecha BETWEEN ? AND ?"
        args += [f"{anio}-01-01", f"{anio}-12-31"]
    if not incluir_bajas:
        sql += " AND activo = 1"
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        filas = [dict(f) for f in con.execute(sql + " ORDER BY fecha", args)]
    finally:
        con.row_factory = previo
    for f in filas:
        f["tipo_etiqueta"] = cal.TIPOS_FERIADO.get(str(f["tipo"]), str(f["tipo"]))
    return filas


def _validar(fecha: str, motivo: str, tipo: str) -> tuple[date, str, str]:
    try:
        d = date.fromisoformat(str(fecha or "").strip()[:10])
    except ValueError as e:
        raise DatoInvalido("Indicá la fecha del feriado.") from e
    m = re.sub(r"\s+", " ", motivo or "").strip()[:200]
    if len(m) < 3:
        raise DatoInvalido("Escribí el motivo (por ejemplo, «Día de la Independencia»).")
    t = (tipo or "NACIONAL").strip().upper()
    if t not in cal.TIPOS_FERIADO:
        raise DatoInvalido("Elegí el tipo de día no laborable.")
    return d, m, t


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, fecha: str, motivo: str, tipo: str = "NACIONAL",
            origen: str = "manual") -> int:
    """Alta (o reactivación, si esa fecha estaba dada de baja) de un día no laborable. Devuelve el id."""
    if not puede:
        raise PermisoDenegado("El calendario de feriados lo administran la Dirección y la coordinación de traslados.")
    d, m, t = _validar(fecha, motivo, tipo)
    previo = con.execute("SELECT id, motivo, tipo, activo FROM feriados WHERE fecha = ?", (d.isoformat(),)).fetchone()
    if previo:
        fid = int(previo[0])
        antes = {"motivo": previo[1], "tipo": previo[2], "activo": previo[3]}
        con.execute("""UPDATE feriados SET motivo = ?, tipo = ?, activo = 1, actualizado_por = ?, actualizado_en = ?,
                       baja_por = NULL, baja_en = NULL, motivo_baja = NULL WHERE id = ?""", (m, t, actor.nombre, _ahora(), fid))
        au.registrar(con, accion="Feriado modificado" if previo[3] else "Feriado reactivado", entidad=ENTIDAD, entidad_id=fid,
                     antes=antes, despues={"fecha": d.isoformat(), "motivo": m, "tipo": t}, actor=actor, origen=origen)
        return fid
    cur = con.execute("INSERT INTO feriados (fecha, motivo, tipo, activo, cargado_por, cargado_en, origen) VALUES (?, ?, ?, 1, ?, ?, ?)",
                      (d.isoformat(), m, t, actor.nombre, _ahora(), origen))
    fid = int(cur.lastrowid or 0)
    au.registrar(con, accion="Feriado cargado", entidad=ENTIDAD, entidad_id=fid, despues={"fecha": d.isoformat(), "motivo": m, "tipo": t},
                 actor=actor, origen=origen)
    return fid


def dar_de_baja(con: sqlite3.Connection, actor: au.Actor, puede: bool, feriado_id: int, motivo: str) -> None:
    if not puede:
        raise PermisoDenegado("El calendario de feriados lo administran la Dirección y la coordinación de traslados.")
    m = re.sub(r"\s+", " ", motivo or "").strip()[:300]
    if len(m) < 3:
        raise DatoInvalido("Contá por qué se quita (queda en el historial).")
    f = con.execute("SELECT fecha, motivo, tipo FROM feriados WHERE id = ? AND activo = 1", (feriado_id,)).fetchone()
    if not f:
        raise NoEncontrado("Ese feriado no existe o ya estaba dado de baja.")
    con.execute("UPDATE feriados SET activo = 0, baja_por = ?, baja_en = ?, motivo_baja = ? WHERE id = ?", (actor.nombre, _ahora(), m, feriado_id))
    au.registrar(con, accion="Feriado dado de baja", entidad=ENTIDAD, entidad_id=feriado_id,
                 antes={"fecha": f[0], "motivo": f[1], "tipo": f[2]}, motivo=m, actor=actor)


def importar_ics(con: sqlite3.Connection, actor: au.Actor, puede: bool, texto: str, tipo: str = "NACIONAL",
                 desde: date | None = None) -> dict[str, int]:
    """Carga las fechas de un .ics. No pisa las que ya están activas (las informa como «ya estaban»)."""
    if not puede:
        raise PermisoDenegado("El calendario de feriados lo administran la Dirección y la coordinación de traslados.")
    eventos = cal.leer_ics(texto or "")
    if not eventos:
        raise DatoInvalido("El archivo no tiene fechas que se puedan leer (¿es un calendario .ics?).")
    activas = conjunto(con)
    nuevos = ya = 0
    for d, resumen in eventos:
        if desde and d < desde:
            continue
        if d in activas:
            ya += 1
            continue
        guardar(con, actor, puede, d.isoformat(), resumen if len(resumen) >= 3 else "Feriado", tipo, origen="ics")
        activas = activas | {d}
        nuevos += 1
    return {"nuevos": nuevos, "ya_estaban": ya, "leidos": len(eventos)}
