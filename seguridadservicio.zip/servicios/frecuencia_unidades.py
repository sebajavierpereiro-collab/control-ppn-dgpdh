"""Propuesta 88: frecuencia mínima de visita por unidad a cargo de cada equipo, con nivel de riesgo (manual, con una
sugerencia a partir de los obstáculos recientes). Indicador: % de unidades a cargo visitadas dentro de su frecuencia, y las
«vencidas» ordenadas por días de atraso."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timezone

from dgpdh.errores import DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au

FRECUENCIAS = {7: "Semanal", 15: "Quincenal", 30: "Mensual", 60: "Bimestral", 90: "Trimestral", 180: "Semestral"}
RIESGOS = {"BAJO": "Bajo", "MEDIO": "Medio", "ALTO": "Alto"}


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, equipo_id: int, valores: dict[int, tuple[int | None, str | None]]) -> int:
    """valores = {unidad_id: (frecuencia_dias, riesgo)}. Solo para unidades a cargo del equipo."""
    if not puede:
        raise PermisoDenegado("La frecuencia la fijan la Dirección y la coordinación del equipo.")
    a_cargo = {int(f[0]) for f in con.execute("SELECT unidad_id FROM equipo_unidades WHERE equipo_id = ?", (equipo_id,))}
    n = 0
    for uid, (dias, riesgo) in valores.items():
        if uid not in a_cargo:
            continue
        if dias is not None and dias not in FRECUENCIAS:
            raise DatoInvalido("Elegí una frecuencia de la lista.")
        if riesgo is not None and riesgo not in RIESGOS:
            raise DatoInvalido("Elegí el nivel de riesgo.")
        previo = con.execute("SELECT frecuencia_dias, riesgo FROM unidad_frecuencias WHERE equipo_id = ? AND unidad_id = ?", (equipo_id, uid)).fetchone()
        if previo is not None and (previo[0], previo[1]) == (dias, riesgo):
            continue
        con.execute("""INSERT INTO unidad_frecuencias (equipo_id, unidad_id, frecuencia_dias, riesgo, actualizado_por, actualizado_en)
                       VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(equipo_id, unidad_id) DO UPDATE SET frecuencia_dias = excluded.frecuencia_dias,
                       riesgo = excluded.riesgo, actualizado_por = excluded.actualizado_por, actualizado_en = excluded.actualizado_en""",
                    (equipo_id, uid, dias, riesgo, actor.nombre, datetime.now(timezone.utc).isoformat(timespec="seconds")))
        au.registrar(con, accion="Frecuencia de visita", entidad="unidad_frecuencia", entidad_id=f"{equipo_id}-{uid}",
                     antes={"dias": previo[0], "riesgo": previo[1]} if previo else None, despues={"dias": dias, "riesgo": riesgo}, actor=actor)
        n += 1
    return n


def riesgo_sugerido(obstaculos_90: int) -> str:
    return "ALTO" if obstaculos_90 >= 2 else ("MEDIO" if obstaculos_90 == 1 else "BAJO")


def estado(con: sqlite3.Connection, equipo_id: int, equipo_nombre: str, hoy: date,
           obstaculos_90: dict[int, int] | None = None) -> dict[str, object]:
    """Unidades a cargo con su frecuencia, última visita del equipo, días de atraso y riesgo (cargado y sugerido)."""
    filas = con.execute("""SELECT eu.unidad_id, u.nombre, f.frecuencia_dias, f.riesgo FROM equipo_unidades eu JOIN unidades u ON u.id = eu.unidad_id
                           LEFT JOIN unidad_frecuencias f ON f.equipo_id = eu.equipo_id AND f.unidad_id = eu.unidad_id
                           WHERE eu.equipo_id = ? ORDER BY eu.orden, u.nombre""", (equipo_id,)).fetchall()
    unidades = []
    for uid, nombre, dias, riesgo in filas:
        ultima = con.execute("""SELECT MAX(v.fecha) FROM viajes v WHERE v.unidad_id = ? AND v.estado = 'CONFIRMADO' AND v.fecha < ?
                                AND EXISTS (SELECT 1 FROM viaje_participantes p WHERE p.viaje_id = v.id AND p.equipo_nombre = ? COLLATE NOCASE)""",
                             (uid, hoy.isoformat(), equipo_nombre)).fetchone()[0]
        desde = (hoy - date.fromisoformat(ultima)).days if ultima else None
        atraso = None
        if dias:
            atraso = (desde - int(dias)) if desde is not None else int(dias)
        n_obst = (obstaculos_90 or {}).get(int(uid), 0)
        unidades.append({"unidad_id": int(uid), "unidad": nombre, "frecuencia_dias": dias, "frecuencia": FRECUENCIAS.get(int(dias)) if dias else None,
                         "riesgo": riesgo, "riesgo_sugerido": riesgo_sugerido(n_obst), "obstaculos_90": n_obst, "ultima": ultima,
                         "dias_desde": desde, "atraso": atraso, "vencida": atraso is not None and atraso > 0})
    con_frec = [u for u in unidades if u["frecuencia_dias"]]
    al_dia = [u for u in con_frec if not u["vencida"]]
    return {"unidades": unidades, "con_frecuencia": len(con_frec), "al_dia": len(al_dia),
            "pct": round(100 * len(al_dia) / len(con_frec)) if con_frec else None,
            "vencidas": sorted((u for u in unidades if u["vencida"]), key=lambda u: -int(str(u["atraso"])))}
