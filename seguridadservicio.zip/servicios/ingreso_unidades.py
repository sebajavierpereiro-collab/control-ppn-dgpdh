"""Propuesta 79 (viajes 26): la demora para ingresar a la unidad como indicador de obstáculos al monitoreo.

Por unidad y mes: visitas realizadas (día + unidad, el mismo criterio del organismo), % de visitas con obstáculos,
denegaciones de ingreso y mediana de minutos de espera. Las fuentes son tres, todas ya cargadas por personas:
  * novedades del viaje («Ingreso denegado», «Demora para ingresar» con minutos, «Requisa»);
  * la hora de llegada y la de ingreso que se marcan en la parada (propuesta 72);
  * el Registro de Obstaculizaciones (demora en minutos), solo si quien mira tiene permiso para verlo.
No cambia ningún dato: solo cuenta. Nunca muestra personas, solo cantidades por unidad.
"""
from __future__ import annotations

import sqlite3
import statistics
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date

NOVEDADES_OBSTACULO = ("INGRESO_DENEGADO", "DEMORA_INGRESO", "REQUISA")


@dataclass
class _Visita:
    obstaculo: bool = False
    denegada: bool = False
    minutos: list[int] = field(default_factory=list)


def _mins(h: object) -> int | None:
    t = str(h or "")
    if len(t) < 5 or not (t[:2].isdigit() and t[3:5].isdigit()):
        return None
    return int(t[:2]) * 60 + int(t[3:5])


def _hay(con: sqlite3.Connection, tabla: str) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone() is not None


def _visitas(con: sqlite3.Connection, desde: str, hasta: str, hoy: date, unidad_id: int | None,
             incluir_obstaculizaciones: bool) -> tuple[dict[tuple[int, str], _Visita], dict[int, str]]:
    """Visitas realizadas (unidad, fecha) con sus obstáculos. Solo cuenta viajes confirmados con fecha anterior a hoy."""
    tope = min(hasta, hoy.isoformat()) if hasta else hoy.isoformat()
    filtro = ""
    args: list[object] = [desde, tope, hoy.isoformat()]
    if unidad_id:
        filtro = " AND v.unidad_id = ?"
        args.append(unidad_id)
    columnas = {f[1] for f in con.execute("PRAGMA table_info(viajes)")}
    tiempos = "v.llegada_unidad, v.ingreso_unidad" if "llegada_unidad" in columnas else "NULL, NULL"
    visitas: dict[tuple[int, str], _Visita] = defaultdict(_Visita)
    viaje_visita: dict[int, tuple[int, str]] = {}
    nombres: dict[int, str] = {}
    for vid, uid, fecha, nombre, llegada, ingreso in con.execute(
            f"""SELECT v.id, v.unidad_id, v.fecha, u.nombre, {tiempos} FROM viajes v JOIN unidades u ON u.id = v.unidad_id
                WHERE v.estado = 'CONFIRMADO' AND v.fecha >= ? AND v.fecha <= ? AND v.fecha < ?{filtro}""", args):
        clave = (int(uid), str(fecha))
        vis = visitas[clave]
        nombres[int(uid)] = str(nombre)
        viaje_visita[int(vid)] = clave
        a, b = _mins(llegada), _mins(ingreso)
        if a is not None and b is not None and b >= a:
            vis.minutos.append(b - a)
            if b - a >= 30:  # media hora o más esperando en la puerta ya es una demora para informar
                vis.obstaculo = True
    if viaje_visita and _hay(con, "viaje_novedades"):
        ids = list(viaje_visita)
        for i in range(0, len(ids), 500):
            parte = ids[i:i + 500]
            for vid, tipo, minutos in con.execute(
                    "SELECT viaje_id, tipo, minutos FROM viaje_novedades WHERE viaje_id IN (%s)" % ",".join("?" * len(parte)), parte):
                if tipo not in NOVEDADES_OBSTACULO:
                    continue
                vis = visitas[viaje_visita[int(vid)]]
                vis.obstaculo = True
                if tipo == "INGRESO_DENEGADO":
                    vis.denegada = True
                if tipo == "DEMORA_INGRESO" and minutos is not None:
                    vis.minutos.append(int(minutos))
    if incluir_obstaculizaciones and _hay(con, "obstaculizaciones"):
        sql = """SELECT unidad_id, fecha_hecho, demora_minutos FROM obstaculizaciones
                 WHERE estado != 'ANULADO' AND unidad_id IS NOT NULL AND fecha_hecho >= ? AND fecha_hecho <= ?"""
        oargs: list[object] = [desde, tope]
        if unidad_id:
            sql += " AND unidad_id = ?"
            oargs.append(unidad_id)
        for uid, fecha, minutos in con.execute(sql, oargs):
            clave = (int(uid), str(fecha))
            if clave not in visitas:
                continue  # el hecho no coincide con una visita registrada en Autos PPN: no se inventa la visita
            visitas[clave].obstaculo = True
            if minutos is not None:
                visitas[clave].minutos.append(int(minutos))
    return visitas, nombres


def visitas_con_obstaculo(con: sqlite3.Connection, desde: str, hasta: str, hoy: date,
                          incluir_obstaculizaciones: bool = False) -> set[tuple[int, str]]:
    """{(unidad_id, fecha)} de las visitas realizadas que tuvieron algún obstáculo para ingresar (para la propuesta 89)."""
    visitas, _ = _visitas(con, desde, hasta, hoy, None, incluir_obstaculizaciones)
    return {k for k, v in visitas.items() if v.obstaculo}


def _fila(uid: int, nombre: str, lista: list[_Visita]) -> dict[str, object]:
    con_min = [max(v.minutos) for v in lista if v.minutos]
    obst = sum(1 for v in lista if v.obstaculo)
    return {"unidad_id": uid, "unidad": nombre, "visitas": len(lista), "con_obstaculos": obst,
            "pct_obstaculos": round(100 * obst / len(lista)) if lista else 0, "denegaciones": sum(1 for v in lista if v.denegada),
            "mediana_min": round(statistics.median(con_min)) if con_min else None, "con_minutos": len(con_min)}


def indicador(con: sqlite3.Connection, desde: str, hasta: str, hoy: date, *, unidad_id: int | None = None,
              incluir_obstaculizaciones: bool = False) -> list[dict[str, object]]:
    """[{unidad_id, unidad, mes, visitas, con_obstaculos, pct_obstaculos, denegaciones, mediana_min, con_minutos}] por unidad y mes."""
    visitas, nombres = _visitas(con, desde, hasta, hoy, unidad_id, incluir_obstaculizaciones)
    por_mes: dict[tuple[int, str], list[_Visita]] = defaultdict(list)
    for (uid, fecha), vis in visitas.items():
        por_mes[(uid, fecha[:7])].append(vis)
    return [dict(_fila(uid, nombres[uid], lista), mes=mes)
            for (uid, mes), lista in sorted(por_mes.items(), key=lambda kv: (nombres[kv[0][0]].lower(), kv[0][1]))]


def resumen_por_unidad(con: sqlite3.Connection, desde: str, hasta: str, hoy: date, *,
                       incluir_obstaculizaciones: bool = False) -> list[dict[str, object]]:
    """Total del período por unidad (para el tablero), las de más visitas con obstáculos primero."""
    visitas, nombres = _visitas(con, desde, hasta, hoy, None, incluir_obstaculizaciones)
    por: dict[int, list[_Visita]] = defaultdict(list)
    for (uid, _), vis in visitas.items():
        por[uid].append(vis)
    filas = [_fila(uid, nombres[uid], lista) for uid, lista in por.items()]
    return sorted(filas, key=lambda a: (-int(str(a["con_obstaculos"])), str(a["unidad"]).lower()))


def csv_filas(filas: list[dict[str, object]]) -> list[list[object]]:
    cab: list[object] = ["Unidad", "Mes", "Visitas", "Visitas con obstáculos", "% con obstáculos", "Denegaciones de ingreso",
                         "Mediana de espera (min)", "Visitas con minutos registrados"]
    return [cab] + [[f["unidad"], f["mes"], f["visitas"], f["con_obstaculos"], f["pct_obstaculos"], f["denegaciones"],
                     "" if f["mediana_min"] is None else f["mediana_min"], f["con_minutos"]] for f in filas]
