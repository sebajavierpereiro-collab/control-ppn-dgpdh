"""Propuesta 77: guarda la propuesta del planificador y arma el cuadro «propuesto vs. asignado» de la semana."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta, timezone
from typing import Any

from dgpdh.dominio import flota_control as fc
from dgpdh.dominio import propuesto_asignado as pa
from dgpdh.servicios import opciones_viajes


def guardar(con: sqlite3.Connection, lunes: date, propuesta: list[dict[str, Any]]) -> int:
    """Se llama cada vez que la coordinación abre el planificador. Pisa la propuesta anterior de cada pedido."""
    ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
    n = 0
    for g in propuesta:
        ch, ve = g.get("chofer") or {}, g.get("vehiculo") or {}
        for v in g.get("viajes") or []:
            con.execute("""INSERT INTO planificador_propuesto (viaje_id, lunes, fecha, clave, chofer_id, vehiculo_id, guardado_en)
                           VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(viaje_id) DO UPDATE SET lunes = excluded.lunes,
                           fecha = excluded.fecha, clave = excluded.clave, chofer_id = excluded.chofer_id,
                           vehiculo_id = excluded.vehiculo_id, guardado_en = excluded.guardado_en""",
                        (int(v["id"]), lunes.isoformat(), str(g["fecha"]), f"{g['fecha']}:{g['clave']}", ch.get("id"), ve.get("id"), ahora))
            n += 1
    return n


def cuadro(con: sqlite3.Connection, lunes: date, circuito: str = "AMBA") -> dict[str, Any]:
    o = opciones_viajes.leer()
    hasta = (lunes + timedelta(days=6)).isoformat()
    filas = con.execute("""SELECT v.id, v.fecha, v.hora_salida, v.hora_regreso, v.chofer_id, v.vehiculo_id, u.lat, u.lng
                           FROM viajes v LEFT JOIN unidades u ON u.id = v.unidad_id
                           WHERE v.fecha BETWEEN ? AND ? AND v.modalidad = 'CHOFER' AND v.estado != 'CANCELADO'
                             AND v.circuito = ?""", (lunes.isoformat(), hasta, circuito)).fetchall()
    viajes = [dict(zip(("id", "fecha", "hora_salida", "hora_regreso", "chofer_id", "vehiculo_id", "lat", "lng"), f, strict=True)) for f in filas]
    ids = [int(v["id"]) for v in viajes]
    prop: dict[int, dict[str, Any]] = {}
    if ids:
        for f in con.execute(f"SELECT viaje_id, clave, chofer_id, vehiculo_id FROM planificador_propuesto WHERE viaje_id IN ({','.join('?' * len(ids))})", ids):
            prop[int(f[0])] = {"clave": f[1], "chofer_id": f[2], "vehiculo_id": f[3]}

    def km_de(puntos: list[pa.Punto]) -> float | None:
        sede = [(o.sede_lat, o.sede_lng)] if o.sede_lat is not None and o.sede_lng is not None else []
        return fc.recorrido_km([*sede, *puntos], o.factor_ruta)

    r = pa.comparar(viajes, prop, km_de)
    r["cerrada"] = date.today() > lunes + timedelta(days=6)
    r["factor_ruta"] = o.factor_ruta
    r["con_sede"] = o.sede_lat is not None and o.sede_lng is not None
    return r
