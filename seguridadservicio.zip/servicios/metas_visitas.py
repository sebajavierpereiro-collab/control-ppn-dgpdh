"""Propuesta 82: la meta de visitas de cada equipo es UNA sola, la de Metas (`metas_anuales`, indicador `visitas_equipo`).

El tablero de Dirección la lee de acá, con su reparto trimestral (`metas_trimestres`). Si el reparto guardado no suma la
meta anual (porque después se cambió la anual en Metas), se reparte parejo. La tabla vieja `metas_viajes` ya no se escribe.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

INDICADOR = "visitas_equipo"


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def repartir(anual: int) -> list[int]:
    """Meta anual → cuatro trimestres lo más parejos posible (el resto, en los primeros)."""
    base, resto = divmod(max(0, int(anual or 0)), 4)
    return [base + (1 if i < resto else 0) for i in range(4)]


def metas(con: sqlite3.Connection, anio: int) -> dict[int, dict[object, int]]:
    """{equipo_id: {1: t1, 2: t2, 3: t3, 4: t4, "anual": meta}} de los equipos con meta de visitas cargada en el año."""
    salida: dict[int, dict[object, int]] = {}
    anuales = {int(e): int(m) for e, m in con.execute("SELECT equipo_id, meta FROM metas_anuales WHERE anio = ? AND indicador = ?", (anio, INDICADOR))}
    tri: dict[int, dict[int, int]] = {}
    for e, t, m in con.execute("SELECT equipo_id, trimestre, meta FROM metas_trimestres WHERE anio = ? AND indicador = ?", (anio, INDICADOR)):
        tri.setdefault(int(e), {})[int(t)] = int(m)
    for eid, anual in anuales.items():
        guardado = tri.get(eid, {})
        reparto = [guardado.get(t, 0) for t in (1, 2, 3, 4)]
        if sum(reparto) != anual:
            reparto = repartir(anual)
        d: dict[object, int] = {t: reparto[t - 1] for t in (1, 2, 3, 4)}
        d["anual"] = anual
        salida[eid] = d
    return salida


def fijar(con: sqlite3.Connection, actor: au.Actor, es_direccion: bool, anio: int, filas: dict[int, list[int]],
          origen: str = "tablero") -> int:
    """filas = {equipo_id: [t1, t2, t3, t4]}. Escribe la meta anual (suma) en Metas y el reparto. Devuelve cuántos equipos."""
    if not es_direccion:
        raise PermisoDenegado("Las metas las fija la Dirección General.")
    n = 0
    for eid, trimestres in filas.items():
        if len(trimestres) != 4 or any(int(x) < 0 for x in trimestres):
            raise DatoInvalido("Cada equipo necesita cuatro trimestres con números enteros, sin negativos.")
        reparto = [int(x) for x in trimestres]
        anual = sum(reparto)
        antes = metas(con, anio).get(eid)
        con.execute("""INSERT INTO metas_anuales (equipo_id, anio, indicador, meta, actualizado_por, actualizado_en) VALUES (?, ?, ?, ?, ?, ?)
                       ON CONFLICT(equipo_id, anio, indicador) DO UPDATE SET meta = excluded.meta,
                       actualizado_por = excluded.actualizado_por, actualizado_en = excluded.actualizado_en""",
                    (eid, anio, INDICADOR, anual, actor.nombre, _ahora()))
        for t, meta in enumerate(reparto, 1):
            con.execute("""INSERT INTO metas_trimestres (equipo_id, anio, indicador, trimestre, meta, actualizado_por, actualizado_en)
                           VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(equipo_id, anio, indicador, trimestre) DO UPDATE SET meta = excluded.meta,
                           actualizado_por = excluded.actualizado_por, actualizado_en = excluded.actualizado_en""",
                        (eid, anio, INDICADOR, t, meta, actor.nombre, _ahora()))
        con.execute("""UPDATE metas_unificacion SET resuelto = 'NUEVA', resuelto_por = ?, resuelto_en = ?
                       WHERE equipo_id = ? AND anio = ? AND resuelto IS NULL""", (actor.nombre, _ahora(), eid, anio))
        despues = {"anual": anual, "trimestres": reparto}
        if antes is None or [antes[t] for t in (1, 2, 3, 4)] != reparto:
            au.registrar(con, accion="Meta de visitas fijada", entidad="metas_visitas", entidad_id=f"{eid}-{anio}",
                         antes={"anual": antes["anual"], "trimestres": [antes[t] for t in (1, 2, 3, 4)]} if antes else None,
                         despues=despues, actor=actor, origen=origen)
        n += 1
    return n


def diferencias(con: sqlite3.Connection, anio: int | None = None) -> list[dict[str, object]]:
    """Equipos cuyas dos metas viejas no coincidían y la Dirección todavía no eligió."""
    sql = """SELECT m.*, e.nombre AS equipo FROM metas_unificacion m LEFT JOIN equipos e ON e.id = m.equipo_id WHERE m.resuelto IS NULL"""
    args: list[object] = []
    if anio:
        sql += " AND m.anio = ?"
        args.append(anio)
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        filas = [dict(f) for f in con.execute(sql + " ORDER BY m.anio DESC, e.nombre", args)]
    finally:
        con.row_factory = previo
    for f in filas:
        f["trimestres"] = [int(x) for x in str(f["trimestres_tablero"]).split(",")]
    return filas


def resolver(con: sqlite3.Connection, actor: au.Actor, es_direccion: bool, equipo_id: int, anio: int, eleccion: str) -> None:
    """ANUAL: queda la de Metas (ya vigente). TABLERO: se adopta la del tablero viejo, con su reparto trimestral."""
    if not es_direccion:
        raise PermisoDenegado("Las metas las fija la Dirección General.")
    if eleccion not in ("ANUAL", "TABLERO"):
        raise DatoInvalido("Elegí cuál de las dos metas queda.")
    pend = next((d for d in diferencias(con, anio) if d["equipo_id"] == equipo_id), None)
    if not pend:
        raise NoEncontrado("Esa diferencia ya se resolvió.")
    if eleccion == "TABLERO":
        trimestres = pend["trimestres"]
        assert isinstance(trimestres, list)
        fijar(con, actor, True, anio, {equipo_id: [int(x) for x in trimestres]}, origen="unificación")
    con.execute("UPDATE metas_unificacion SET resuelto = ?, resuelto_por = ?, resuelto_en = ? WHERE equipo_id = ? AND anio = ?",
                (eleccion, actor.nombre, _ahora(), equipo_id, anio))
    au.registrar(con, accion="Diferencia de metas resuelta", entidad="metas_visitas", entidad_id=f"{equipo_id}-{anio}",
                 antes={"metas": pend["meta_anual"], "tablero": pend["meta_tablero"]}, despues={"queda": eleccion}, actor=actor)
