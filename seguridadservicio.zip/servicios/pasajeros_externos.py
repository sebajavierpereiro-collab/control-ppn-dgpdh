"""Modificación 4: pasajeros externos registrados y su vinculación a los pasajeros de un viaje.

Un externo ocupa lugar en el vehículo y figura en la hoja de ruta, pero nunca cuenta para las metas de ningún equipo: al
vincularlo, el pasajero queda sin usuario y sin equipo. No es una persona detenida: nada de esto toca esa base."""
from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone

from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

_PERMISO = "Los pasajeros externos los administran la Dirección y la coordinación de traslados."


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _t(v: str | None, n: int) -> str:
    return re.sub(r"\s+", " ", v or "").strip()[:n]


def _doc(v: str | None) -> str:
    d = re.sub(r"[^0-9A-Za-z]", "", v or "").upper()
    if not 6 <= len(d) <= 20:
        raise DatoInvalido("Indicá el documento (DNI o pasaporte, sin puntos).")
    return d


def _dicts(con: sqlite3.Connection, sql: str, args: tuple[object, ...] = ()) -> list[dict[str, object]]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        return [dict(f) for f in con.execute(sql, args)]
    finally:
        con.row_factory = previo


def categorias(con: sqlite3.Connection, incluir_bajas: bool = False) -> list[dict[str, object]]:
    return _dicts(con, "SELECT * FROM pasajero_categorias" + ("" if incluir_bajas else " WHERE activo = 1") + " ORDER BY activo DESC, orden, nombre")


def guardar_categoria(con: sqlite3.Connection, actor: au.Actor, puede: bool, nombre: str) -> int:
    if not puede:
        raise PermisoDenegado(_PERMISO)
    n = _t(nombre, 120)
    if len(n) < 3:
        raise DatoInvalido("Escribí el nombre de la categoría.")
    previa = con.execute("SELECT id, activo FROM pasajero_categorias WHERE nombre = ? COLLATE NOCASE", (n,)).fetchone()
    if previa and previa[1]:
        raise Conflicto("Esa categoría ya existe.")
    if previa:
        con.execute("UPDATE pasajero_categorias SET activo = 1, baja_por = NULL, baja_en = NULL WHERE id = ?", (previa[0],))
        au.registrar(con, accion="Categoría de pasajero reactivada", entidad="pasajero_categoria", entidad_id=previa[0], actor=actor)
        return int(previa[0])
    orden = int(con.execute("SELECT COALESCE(MAX(orden), 0) + 1 FROM pasajero_categorias").fetchone()[0])
    cid = int(con.execute("INSERT INTO pasajero_categorias (nombre, orden, creado_por, creado_en) VALUES (?, ?, ?, ?)",
                          (n, orden, actor.nombre, _ahora())).lastrowid or 0)
    au.registrar(con, accion="Categoría de pasajero creada", entidad="pasajero_categoria", entidad_id=cid, despues={"nombre": n}, actor=actor)
    return cid


def baja_categoria(con: sqlite3.Connection, actor: au.Actor, puede: bool, categoria_id: int) -> None:
    if not puede:
        raise PermisoDenegado(_PERMISO)
    if not con.execute("UPDATE pasajero_categorias SET activo = 0, baja_por = ?, baja_en = ? WHERE id = ? AND activo = 1",
                       (actor.nombre, _ahora(), categoria_id)).rowcount:
        raise NoEncontrado("Esa categoría no existe o ya estaba dada de baja.")
    au.registrar(con, accion="Categoría de pasajero dada de baja", entidad="pasajero_categoria", entidad_id=categoria_id, actor=actor)


def listar(con: sqlite3.Connection, incluir_bajas: bool = False, texto: str = "") -> list[dict[str, object]]:
    sql = """SELECT p.*, c.nombre AS categoria FROM pasajeros_externos p JOIN pasajero_categorias c ON c.id = p.categoria_id WHERE 1 = 1"""
    args: list[object] = []
    if not incluir_bajas:
        sql += " AND p.activo = 1"
    t = _t(texto, 60)
    if t:
        sql += " AND (p.apellido LIKE ? OR p.nombre LIKE ? OR p.documento LIKE ? OR p.institucion LIKE ?)"
        args += [f"%{t}%"] * 4
    return _dicts(con, sql + " ORDER BY p.activo DESC, p.apellido, p.nombre", tuple(args))


def obtener(con: sqlite3.Connection, pasajero_id: int) -> dict[str, object] | None:
    f = _dicts(con, """SELECT p.*, c.nombre AS categoria FROM pasajeros_externos p JOIN pasajero_categorias c ON c.id = p.categoria_id
                       WHERE p.id = ?""", (pasajero_id,))
    return f[0] if f else None


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, datos: dict[str, str], pasajero_id: int | None = None) -> int:
    if not puede:
        raise PermisoDenegado(_PERMISO)
    nombre, apellido = _t(datos.get("nombre"), 100), _t(datos.get("apellido"), 100)
    if len(nombre) < 2 or len(apellido) < 2:
        raise DatoInvalido("Indicá nombre y apellido.")
    doc = _doc(datos.get("documento"))
    cat = str(datos.get("categoria_id") or "")
    if not cat.isdigit() or not con.execute("SELECT 1 FROM pasajero_categorias WHERE id = ? AND activo = 1", (int(cat),)).fetchone():
        raise DatoInvalido("Elegí la categoría.")
    inst = _t(datos.get("institucion"), 150) or None
    otro = con.execute("SELECT id FROM pasajeros_externos WHERE documento = ? AND id != ?", (doc, pasajero_id or -1)).fetchone()
    if otro:
        raise Conflicto("Ya hay un pasajero externo con ese documento.")
    nuevo = {"nombre": nombre, "apellido": apellido, "documento": doc, "categoria_id": int(cat), "institucion": inst}
    if pasajero_id:
        antes = obtener(con, pasajero_id)
        if not antes:
            raise NoEncontrado("Ese pasajero no existe.")
        con.execute("""UPDATE pasajeros_externos SET nombre = ?, apellido = ?, documento = ?, categoria_id = ?, institucion = ?,
                       actualizado_por = ?, actualizado_en = ? WHERE id = ?""", (nombre, apellido, doc, int(cat), inst, actor.nombre, _ahora(), pasajero_id))
        au.registrar(con, accion="Pasajero externo modificado", entidad="pasajero_externo", entidad_id=pasajero_id,
                     antes={k: antes[k] for k in nuevo}, despues=nuevo, actor=actor)
        return pasajero_id
    pid = int(con.execute("""INSERT INTO pasajeros_externos (nombre, apellido, documento, categoria_id, institucion, creado_por, creado_en)
                             VALUES (?, ?, ?, ?, ?, ?, ?)""", (nombre, apellido, doc, int(cat), inst, actor.nombre, _ahora())).lastrowid or 0)
    au.registrar(con, accion="Pasajero externo registrado", entidad="pasajero_externo", entidad_id=pid, despues=nuevo, actor=actor)
    return pid


def cambiar_activo(con: sqlite3.Connection, actor: au.Actor, puede: bool, pasajero_id: int, activo: bool, motivo: str = "") -> None:
    if not puede:
        raise PermisoDenegado(_PERMISO)
    m = _t(motivo, 300)
    if not activo and len(m) < 3:
        raise DatoInvalido("Contá por qué se da de baja.")
    cur = con.execute("UPDATE pasajeros_externos SET activo = ?, baja_por = ?, baja_en = ?, motivo_baja = ? WHERE id = ? AND activo = ?",
                      (1 if activo else 0, None if activo else actor.nombre, None if activo else _ahora(), None if activo else m,
                       pasajero_id, 0 if activo else 1))
    if not cur.rowcount:
        raise NoEncontrado("Ese pasajero no existe o ya estaba así.")
    au.registrar(con, accion="Pasajero externo " + ("reactivado" if activo else "dado de baja"), entidad="pasajero_externo",
                 entidad_id=pasajero_id, motivo=m or None, actor=actor)


def etiqueta(p: dict[str, object]) -> str:
    """Texto del buscador: «Pérez, Ana · DNI 30111222 · Invitado»."""
    return f"{p['apellido']}, {p['nombre']} · DNI {p['documento']} · {p['categoria']}"


def desde_etiqueta(con: sqlite3.Connection, texto: str) -> dict[str, object] | None:
    m = re.search(r"DNI\s*([0-9A-Za-z]+)", texto or "") or re.fullmatch(r"\s*([0-9A-Za-z]{6,20})\s*", texto or "")
    if not m:
        return None
    f = con.execute("SELECT id FROM pasajeros_externos WHERE documento = ? AND activo = 1", (m.group(1).upper(),)).fetchone()
    return obtener(con, int(f[0])) if f else None


def vincular(con: sqlite3.Connection, actor: au.Actor, puede: bool, viaje_id: int, participante_id: int, pasajero_id: int) -> str:
    """El pasajero cargado a mano en el viaje es este externo registrado: queda sin usuario y sin equipo (no cuenta para metas)."""
    if not puede:
        raise PermisoDenegado("Lo vincula la coordinación de traslados.")
    p = con.execute("SELECT nombre, usuario_id FROM viaje_participantes WHERE id = ? AND viaje_id = ?", (participante_id, viaje_id)).fetchone()
    ext = obtener(con, pasajero_id)
    if not p or not ext or not ext["activo"]:
        raise NoEncontrado("Elegí el pasajero del viaje y un pasajero externo activo.")
    if p[1]:
        raise Conflicto("Esa persona está vinculada a un usuario del sistema: no es externa.")
    if con.execute("SELECT 1 FROM viaje_participantes WHERE viaje_id = ? AND pasajero_externo_id = ? AND id != ?",
                   (viaje_id, pasajero_id, participante_id)).fetchone():
        raise Conflicto("Ese pasajero externo ya figura en este viaje.")
    nombre = f"{ext['nombre']} {ext['apellido']}"
    con.execute("UPDATE viaje_participantes SET pasajero_externo_id = ?, nombre = ?, equipo_nombre = NULL WHERE id = ?",
                (pasajero_id, nombre, participante_id))
    au.registrar(con, accion="Pasajero externo vinculado", entidad="viaje", entidad_id=viaje_id, antes={"nombre": p[0]},
                 despues={"pasajero_externo_id": pasajero_id, "nombre": nombre}, actor=actor)
    if con.execute("SELECT 1 FROM sqlite_master WHERE name = 'traslados_auditoria'").fetchone():
        con.execute("INSERT INTO traslados_auditoria (entidad, entidad_id, accion, anterior, nuevo, usuario, fecha) VALUES ('viaje', ?, ?, ?, ?, ?, ?)",
                    (viaje_id, "Pasajero externo vinculado", p[0], f"{nombre} ({ext['categoria']})", actor.nombre, _ahora()))
    return nombre
