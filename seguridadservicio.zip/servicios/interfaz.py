"""Servicios de la interfaz: preferencias de pantalla por persona, sugerencias de la banda «Beta» y borradores de formularios.
Cada cambio que hace una persona queda en la auditoría, en la misma transacción. Nada se borra: los borradores se descartan."""
from __future__ import annotations

import json
import sqlite3
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from dgpdh.dominio import interfaz as dom
from dgpdh.errores import DatoInvalido
from dgpdh.seguridad import auditoria as au

MAX_BORRADOR = 200_000  # bytes de JSON por borrador
MAX_SUGERENCIA = 2_000


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _actor(usuario: Mapping[str, Any]) -> au.Actor:
    return au.Actor.desde(usuario)


def _cargar(texto: object) -> dict[str, Any]:
    try:
        d = json.loads(str(texto or "{}"))
    except (TypeError, ValueError):
        return {}
    return d if isinstance(d, dict) else {}


# ---------------------------------------------------------------- preferencias
def preferencias(con: sqlite3.Connection, usuario: Mapping[str, Any]) -> dict[str, Any]:
    fila = con.execute("SELECT datos FROM ui_preferencias WHERE usuario_id = ?", (usuario.get("id"),)).fetchone()
    return dom.preferencias_efectivas(_cargar(fila[0]) if fila else {}, str(usuario.get("rol") or ""))


def guardar_preferencias(con: sqlite3.Connection, usuario: Mapping[str, Any], cambios: Mapping[str, Any]) -> dict[str, Any]:
    """Valida y guarda solo las claves conocidas. Devuelve las preferencias efectivas nuevas."""
    uid = usuario.get("id")
    if uid is None:
        raise DatoInvalido("Hace falta una persona para guardar preferencias.")
    fila = con.execute("SELECT datos FROM ui_preferencias WHERE usuario_id = ?", (uid,)).fetchone()
    antes = _cargar(fila[0]) if fila else {}
    nuevo = dict(antes)
    for clave, valor in cambios.items():
        if clave == "atajos":
            nuevo["atajos"] = bool(valor)
        elif clave == "tema":
            if valor not in dom.TEMAS:
                raise DatoInvalido("Elegí «Como el sistema», «Claro» u «Oscuro».")
            nuevo["tema"] = valor
        elif clave == "densidad":
            if valor not in dom.DENSIDADES:
                raise DatoInvalido("Elegí densidad cómoda o compacta.")
            nuevo["densidad"] = valor
        elif clave == "columnas_ocultas":
            if not isinstance(valor, list):
                raise DatoInvalido("Las columnas tienen que venir en una lista.")
            nuevo["columnas_ocultas"] = [str(c)[:40] for c in valor][:20]
        elif clave == "visto":
            # {"clave": "valor"}: avisos que la persona ya cerró (resumen del día, novedades, primeros pasos)
            if not isinstance(valor, Mapping):
                raise DatoInvalido("Dato «visto» no válido.")
            vistos = dict(nuevo.get("vistos") or {})
            for k, v in valor.items():
                vistos[str(k)[:40]] = str(v)[:40]
            nuevo["vistos"] = vistos
        else:
            raise DatoInvalido(f"Preferencia desconocida: {clave}")
    if nuevo != antes:
        con.execute("""INSERT INTO ui_preferencias (usuario_id, datos, actualizado_en) VALUES (?, ?, ?)
                       ON CONFLICT(usuario_id) DO UPDATE SET datos = excluded.datos, actualizado_en = excluded.actualizado_en""",
                    (uid, json.dumps(nuevo, ensure_ascii=False), _ahora()))
        # los «vistos» son marcas de lectura, no decisiones: no ensucian la auditoría
        if {k: v for k, v in nuevo.items() if k != "vistos"} != {k: v for k, v in antes.items() if k != "vistos"}:
            au.registrar(con, accion="Preferencias de pantalla", entidad="usuarios", entidad_id=uid,
                         antes={k: v for k, v in antes.items() if k != "vistos"},
                         despues={k: v for k, v in nuevo.items() if k != "vistos"}, actor=_actor(usuario), origen="interfaz")
    return dom.preferencias_efectivas(nuevo, str(usuario.get("rol") or ""))


# ---------------------------------------------------------------- sugerencias (banda Beta)
def registrar_sugerencia(con: sqlite3.Connection, usuario: Mapping[str, Any], texto: str, url: str | None) -> int:
    t = (texto or "").strip()
    if len(t) < 3:
        raise DatoInvalido("Contanos en pocas palabras qué te trabó.")
    if len(t) > MAX_SUGERENCIA:
        raise DatoInvalido(f"El texto es muy largo (máximo {MAX_SUGERENCIA} caracteres).")
    cur = con.execute("INSERT INTO ui_sugerencias (usuario_id, usuario, rol, url, texto, creada_en) VALUES (?, ?, ?, ?, ?, ?)",
                      (usuario.get("id"), str(usuario.get("nombre") or ""), usuario.get("rol"),
                       dom.destino_interno(url, ""), t, _ahora()))
    sid = int(cur.lastrowid or 0)
    au.registrar(con, accion="Sugerencia", entidad="ui_sugerencias", entidad_id=sid, despues={"url": url, "texto": t},
                 actor=_actor(usuario), origen="interfaz")
    return sid


def listar_sugerencias(con: sqlite3.Connection, estado: str | None = None, limite: int = 200) -> list[dict[str, Any]]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        sql = "SELECT * FROM ui_sugerencias" + (" WHERE estado = ?" if estado else "") + " ORDER BY id DESC LIMIT ?"
        filas = con.execute(sql, ((estado, limite) if estado else (limite,))).fetchall()
    finally:
        con.row_factory = previo
    return [dict(f) for f in filas]


def atender_sugerencia(con: sqlite3.Connection, usuario: Mapping[str, Any], sid: int) -> None:
    fila = con.execute("SELECT estado FROM ui_sugerencias WHERE id = ?", (sid,)).fetchone()
    if not fila:
        raise DatoInvalido("La sugerencia no existe.")
    if fila[0] == "ATENDIDA":
        return
    con.execute("UPDATE ui_sugerencias SET estado = 'ATENDIDA', atendida_por = ?, atendida_en = ? WHERE id = ?",
                (str(usuario.get("nombre") or ""), _ahora(), sid))
    au.registrar(con, accion="Sugerencia atendida", entidad="ui_sugerencias", entidad_id=sid, antes={"estado": fila[0]},
                 despues={"estado": "ATENDIDA"}, actor=_actor(usuario), origen="interfaz")


# ---------------------------------------------------------------- borradores de formularios
def _clave_borrador(clave: str) -> str:
    c = (clave or "").strip()
    if not c or len(c) > 200 or not c.startswith("/"):
        raise DatoInvalido("Clave de borrador no válida.")
    return c


def guardar_borrador(con: sqlite3.Connection, usuario: Mapping[str, Any], clave: str, datos: Mapping[str, Any]) -> str:
    """Guarda (o reemplaza) el borrador de un formulario. Devuelve la hora en que quedó guardado (ISO, UTC)."""
    texto = json.dumps(dict(datos), ensure_ascii=False)
    if len(texto.encode("utf-8")) > MAX_BORRADOR:
        raise DatoInvalido("El borrador es demasiado grande para guardarlo.")
    cuando = _ahora()
    con.execute("""INSERT INTO ui_borradores (usuario_id, clave, datos, guardado_en, descartado_en) VALUES (?, ?, ?, ?, NULL)
                   ON CONFLICT(usuario_id, clave) DO UPDATE SET datos = excluded.datos, guardado_en = excluded.guardado_en,
                   descartado_en = NULL""", (usuario.get("id"), _clave_borrador(clave), texto, cuando))
    return cuando


def leer_borrador(con: sqlite3.Connection, usuario: Mapping[str, Any], clave: str) -> dict[str, Any] | None:
    fila = con.execute("SELECT datos, guardado_en FROM ui_borradores WHERE usuario_id = ? AND clave = ? AND descartado_en IS NULL",
                       (usuario.get("id"), _clave_borrador(clave))).fetchone()
    if not fila:
        return None
    return {"datos": _cargar(fila[0]), "guardado_en": fila[1]}


def descartar_borrador(con: sqlite3.Connection, usuario: Mapping[str, Any], clave: str) -> None:
    """El formulario se envió o la persona no quiso recuperarlo. La fila queda (baja lógica)."""
    con.execute("UPDATE ui_borradores SET descartado_en = ? WHERE usuario_id = ? AND clave = ? AND descartado_en IS NULL",
                (_ahora(), usuario.get("id"), _clave_borrador(clave)))
