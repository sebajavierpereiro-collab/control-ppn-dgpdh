"""Propuesta 57: alta, baja lógica y lectura de los horarios de ingreso de cada unidad (con auditoría)."""
from __future__ import annotations

import re
import sqlite3
from datetime import date, datetime, timezone

from dgpdh.dominio import ventanas as dom
from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _hay(con: sqlite3.Connection) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'unidad_ventanas'").fetchone() is not None


def listar(con: sqlite3.Connection, unidad_id: int, incluir_bajas: bool = False) -> list[dict[str, object]]:
    if not _hay(con):
        return []
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        filas = [dict(f) for f in con.execute("SELECT * FROM unidad_ventanas WHERE unidad_id = ?" + ("" if incluir_bajas else " AND activo = 1")
                                              + " ORDER BY activo DESC, dia_semana, desde", (unidad_id,))]
    finally:
        con.row_factory = previo
    for f in filas:
        f["dia_nombre"] = dom.DIAS[int(str(f["dia_semana"]))].capitalize()
        f["tipo_etiqueta"] = dom.TIPOS.get(str(f["tipo"]), str(f["tipo"]))
    return filas


def ventanas(con: sqlite3.Connection, unidad_id: int) -> list[dom.Ventana]:
    return [dom.Ventana(int(str(f["id"])), int(str(f["unidad_id"])), int(str(f["dia_semana"])), str(f["desde"]), str(f["hasta"]), str(f["tipo"]),
                        str(f["vigente_desde"])) for f in listar(con, unidad_id)]


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, unidad_id: int, dias: list[int], desde: str, hasta: str,
            tipo: str, vigente_desde: str, observacion: str = "") -> list[int]:
    """Carga una ventana para uno o varios días. Si ya había una para el mismo día y tipo, queda la nueva desde su fecha de
    vigencia y la anterior sigue guardada (para los viajes anteriores a esa fecha)."""
    if not puede:
        raise PermisoDenegado("Los horarios de ingreso los carga la Administración (Dirección General).")
    if not dias or any(d not in range(7) for d in dias):
        raise DatoInvalido("Elegí al menos un día de la semana.")
    if not (dom.validar_hora(desde) and dom.validar_hora(hasta)) or hasta <= desde:
        raise DatoInvalido("Indicá el horario (desde y hasta, HH:MM, y que «hasta» sea después de «desde»).")
    if tipo not in dom.TIPOS:
        raise DatoInvalido("Elegí para qué es el horario (audiencias, visita general o profesionales).")
    try:
        vig = date.fromisoformat(vigente_desde).isoformat() if vigente_desde else date.today().isoformat()
    except ValueError as e:
        raise DatoInvalido("La fecha «vigente desde» no es válida.") from e
    if not con.execute("SELECT 1 FROM unidades WHERE id = ?", (unidad_id,)).fetchone():
        raise NoEncontrado("La unidad no existe.")
    obs = re.sub(r"\s+", " ", observacion or "").strip()[:300] or None
    ids = []
    for d in sorted(set(dias)):
        cur = con.execute("""INSERT INTO unidad_ventanas (unidad_id, dia_semana, desde, hasta, tipo, vigente_desde, observacion, cargado_por, cargado_en)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""", (unidad_id, d, desde, hasta, tipo, vig, obs, actor.nombre, _ahora()))
        vid = int(cur.lastrowid or 0)
        ids.append(vid)
        au.registrar(con, accion="Horario de ingreso cargado", entidad="unidad_ventana", entidad_id=vid,
                     despues={"unidad_id": unidad_id, "dia": dom.DIAS[d], "desde": desde, "hasta": hasta, "tipo": tipo, "vigente_desde": vig},
                     actor=actor)
    return ids


def dar_de_baja(con: sqlite3.Connection, actor: au.Actor, puede: bool, ventana_id: int, motivo: str) -> int:
    if not puede:
        raise PermisoDenegado("Los horarios de ingreso los carga la Administración (Dirección General).")
    m = re.sub(r"\s+", " ", motivo or "").strip()[:300]
    if len(m) < 3:
        raise DatoInvalido("Contá por qué se quita el horario.")
    f = con.execute("SELECT unidad_id, dia_semana, desde, hasta, tipo FROM unidad_ventanas WHERE id = ? AND activo = 1", (ventana_id,)).fetchone()
    if not f:
        raise NoEncontrado("Ese horario no existe o ya estaba dado de baja.")
    con.execute("UPDATE unidad_ventanas SET activo = 0, baja_por = ?, baja_en = ?, motivo_baja = ? WHERE id = ?", (actor.nombre, _ahora(), m, ventana_id))
    au.registrar(con, accion="Horario de ingreso dado de baja", entidad="unidad_ventana", entidad_id=ventana_id,
                 antes={"unidad_id": f[0], "dia": dom.DIAS[int(f[1])], "desde": f[2], "hasta": f[3], "tipo": f[4]}, motivo=m, actor=actor)
    return int(f[0])


def aviso_para_viaje(con: sqlite3.Connection, unidad_id: int | None, fecha: str, hora_salida: str | None) -> str | None:
    if not unidad_id:
        return None
    try:
        d = date.fromisoformat(fecha[:10])
    except ValueError:
        return None
    return dom.aviso(ventanas(con, int(unidad_id)), d, hora_salida)
