"""Propuesta 2: alta, edición y evaluación de las reglas; lo que proponen queda en sugerencias_ia (agente REGLA)."""
from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterable, Mapping
from datetime import datetime, timezone
from typing import Any

from dgpdh.dominio import reglas_propuesta as rp
from dgpdh.errores import NoEncontrado
from dgpdh.seguridad import auditoria as au

AGENTE = "REGLA"


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _regla(f: Any) -> rp.Regla:
    return rp.Regla(int(f[0]), str(f[1]), str(f[2]), str(f[3]), str(f[4]), str(f[5]), str(f[6]), bool(f[7]))


_COLUMNAS = "id, nombre, disparador, condicion, condicion_valor, accion, accion_valor, activa"


def todas(con: sqlite3.Connection) -> list[rp.Regla]:
    return [_regla(f) for f in con.execute(f"SELECT {_COLUMNAS} FROM reglas_propuesta ORDER BY id")]


def guardar(con: sqlite3.Connection, datos: Mapping[str, Any], *, actor: au.Actor, regla_id: int | None = None) -> int:
    d = rp.validar(datos)
    if regla_id is None:
        cur = con.execute("""INSERT INTO reglas_propuesta (nombre, disparador, condicion, condicion_valor, accion, accion_valor, creada_por, creada_en)
                             VALUES (?,?,?,?,?,?,?,?)""", (d["nombre"], d["disparador"], d["condicion"], d["condicion_valor"], d["accion"],
                                                          d["accion_valor"], actor.nombre, _ahora()))
        rid = int(cur.lastrowid or 0)
        au.registrar(con, accion="Regla nueva", entidad="regla_propuesta", entidad_id=rid, despues=d, actor=actor, origen="reglas")
        return rid
    previo = con.execute(f"SELECT {_COLUMNAS} FROM reglas_propuesta WHERE id = ?", (regla_id,)).fetchone()
    if not previo:
        raise NoEncontrado("La regla no existe.")
    con.execute("""UPDATE reglas_propuesta SET nombre = ?, disparador = ?, condicion = ?, condicion_valor = ?, accion = ?, accion_valor = ?,
                   actualizada_por = ?, actualizada_en = ? WHERE id = ?""",
                (d["nombre"], d["disparador"], d["condicion"], d["condicion_valor"], d["accion"], d["accion_valor"], actor.nombre, _ahora(), regla_id))
    au.registrar(con, accion="Regla editada", entidad="regla_propuesta", entidad_id=regla_id, antes=dict(zip(_COLUMNAS.split(", "), tuple(previo),
                 strict=True)), despues=d, actor=actor, origen="reglas")
    return regla_id


def activar(con: sqlite3.Connection, regla_id: int, activa: bool, *, actor: au.Actor) -> None:
    if not con.execute("UPDATE reglas_propuesta SET activa = ?, actualizada_por = ?, actualizada_en = ? WHERE id = ?",
                       (1 if activa else 0, actor.nombre, _ahora(), regla_id)).rowcount:
        raise NoEncontrado("La regla no existe.")
    au.registrar(con, accion="Regla activada" if activa else "Regla pausada", entidad="regla_propuesta", entidad_id=regla_id, actor=actor,
                 origen="reglas")


def evaluar(con: sqlite3.Connection, *, nota_id: int, disparador: str, texto: str, tipo_documental: str | None, unidades: Iterable[int],
            equipo_id: int | None) -> int:
    """Deja una sugerencia por cada regla que se cumple (una sola vez por nota y regla). Devuelve cuántas nuevas."""
    unidades = list(unidades)
    n = 0
    for r in todas(con):
        if rp.cumple(r, disparador=disparador, texto=texto, tipo_documental=tipo_documental, unidades=unidades, equipo_id=equipo_id):
            cur = con.execute("""INSERT OR IGNORE INTO sugerencias_ia (nota_id, agente, clave, contenido_json, origen, creado_en)
                                 VALUES (?,?,?,?,?,?)""", (nota_id, AGENTE, f"regla:{r.id}", json.dumps(
                {"regla_id": r.id, "nombre": r.nombre, "accion": r.accion, "valor": r.accion_valor, "descripcion": r.descripcion},
                ensure_ascii=False), "reglas", _ahora()))
            n += cur.rowcount
    return n


def uso(con: sqlite3.Connection) -> dict[int, dict[str, int]]:
    """Por regla: propuestas, aceptadas, descartadas y pendientes (una consulta)."""
    salida: dict[int, dict[str, int]] = {}
    for clave, estado, cant in con.execute("SELECT clave, estado, COUNT(*) FROM sugerencias_ia WHERE agente = ? GROUP BY clave, estado", (AGENTE,)):
        if not str(clave).startswith("regla:") or not str(clave)[6:].isdigit():
            continue
        d = salida.setdefault(int(str(clave)[6:]), {"propuestas": 0, "ACEPTADA": 0, "DESCARTADA": 0, "PENDIENTE": 0})
        d["propuestas"] += int(cant)
        d[str(estado)] = d.get(str(estado), 0) + int(cant)
    return salida
