"""Propuesta 51 (optativa): código QR de verificación en la copia de despacho.

Se estampa en la última página del PDF de despacho un QR con el número de nota y un código, que lleva a una página
**interna** (`/verificar/<código>`) donde se compara un PDF contra la huella guardada. Desde afuera de la red se verifica
pidiéndolo a Mesa. Usa reportlab y pypdf, que ya están. Se activa con config.ini [despacho] qr_verificacion = true y
url_verificacion = la dirección interna del sistema. Si el despacho es PDF/A, estampar el sello puede sacarlo de la norma:
por eso es optativo.
"""
from __future__ import annotations

import hashlib
import io
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CONFIG: dict[str, Any] = {"activo": False, "url": ""}


def codigo_nuevo(nota_id: int) -> str:
    return f"{nota_id}-{secrets.token_hex(4).upper()}"


def sha256(ruta: Path) -> str:
    return hashlib.sha256(ruta.read_bytes()).hexdigest()


def estampar(pdf: Path, texto_qr: str, leyenda: str) -> None:
    """Agrega el QR (2,2 cm, abajo a la izquierda) y una leyenda en la última página. Reescribe el archivo."""
    from pypdf import PdfReader, PdfWriter
    from reportlab.graphics import renderPDF
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    from reportlab.lib.units import cm
    from reportlab.pdfgen import canvas

    lector = PdfReader(str(pdf))
    ultima = lector.pages[-1]
    ancho, alto = float(ultima.mediabox.width), float(ultima.mediabox.height)
    capa = io.BytesIO()
    c = canvas.Canvas(capa, pagesize=(ancho, alto))
    w = QrCodeWidget(texto_qr)
    x1, y1, x2, y2 = w.getBounds()
    lado = 2.2 * cm
    d = Drawing(lado, lado, transform=[lado / (x2 - x1), 0, 0, lado / (y2 - y1), 0, 0])
    d.add(w)
    renderPDF.draw(d, c, 1.2 * cm, 0.8 * cm)
    c.setFont("Helvetica", 6.5)
    c.drawString(3.6 * cm, 1.6 * cm, leyenda[:110])
    c.drawString(3.6 * cm, 1.2 * cm, "Verificación interna: consultar a Mesa de Entradas de la DGPDH (PPN).")
    c.save()
    capa.seek(0)
    sello = PdfReader(capa).pages[0]
    escritor = PdfWriter()
    for i, pagina in enumerate(lector.pages):
        if i == len(lector.pages) - 1:
            pagina.merge_page(sello)
        escritor.add_page(pagina)
    salida = io.BytesIO()
    escritor.write(salida)
    pdf.write_bytes(salida.getvalue())


def sellar_despacho(con: sqlite3.Connection, nota_id: int, nro_nota: str | None, pdf: Path) -> str | None:
    """Estampa el QR (si está activo) y guarda la huella del PDF resultante. Devuelve el código o None."""
    if not CONFIG["activo"] or not pdf.is_file():
        return None
    codigo = codigo_nuevo(nota_id)
    url = f"{str(CONFIG['url']).rstrip('/')}/verificar/{codigo}" if CONFIG["url"] else f"DGPDH {codigo}"
    estampar(pdf, url, f"Nota N° {nro_nota or 's/n'} · código {codigo}")
    con.execute("INSERT INTO despacho_verificacion (codigo, nota_id, sha256_pdf, creado_en) VALUES (?,?,?,?)",
                (codigo, nota_id, sha256(pdf), datetime.now(timezone.utc).isoformat(timespec="seconds")))
    return codigo


def buscar(con: sqlite3.Connection, codigo: str) -> dict[str, Any] | None:
    f = con.execute("SELECT codigo, nota_id, sha256_pdf, creado_en FROM despacho_verificacion WHERE codigo = ?", (codigo.strip().upper(),)).fetchone()
    return {"codigo": f[0], "nota_id": int(f[1]), "sha256_pdf": str(f[2]), "creado_en": str(f[3])} if f else None


def coincide(registro: dict[str, Any], contenido: bytes) -> bool:
    return bool(hashlib.sha256(contenido).hexdigest() == str(registro["sha256_pdf"]))
