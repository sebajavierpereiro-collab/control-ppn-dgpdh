"""Lo que pasa en el lugar (propuestas 72 y 73).

72) «Llegamos a la unidad», «Ingresamos» y «Salimos» por parada, con la hora del servidor. Es un registro manual y
    voluntario: no hay GPS ni se rastrea a nadie. Lo marcan el chofer del viaje o quienes viajan, el mismo día; la
    coordinación puede corregirlo con otra hora. Una vez marcado, solo la coordinación lo cambia.
73) Constancia de que el viaje se hizo: la deja quien viajó (al cargar sus audiencias o con «Confirmo que se hizo»), el
    chofer (al marcar «Salimos» o al cerrar la salida) o la coordinación. El estado del viaje no cambia: un viaje
    confirmado con fecha pasada sigue contando como hasta ahora, y los que no tienen constancia después de N días se
    muestran aparte en el tablero.
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

EVENTOS: dict[str, tuple[str, str]] = {  # evento → (columna, texto del botón)
    "llegada": ("llegada_unidad", "Llegamos a la unidad"),
    "ingreso": ("ingreso_unidad", "Ingresamos"),
    "salida": ("salida_unidad", "Salimos"),
}
ORIGENES: dict[str, str] = {
    "VIAJERO": "lo confirmó quien viajó",
    "CHOFER": "lo confirmó el chofer",
    "CIERRE": "salida cerrada (horario y km)",
    "COORDINACION": "lo confirmó la coordinación",
}
_HORA = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _linea_tiempo(con: sqlite3.Connection, viaje_id: int, accion: str, anterior: str | None, nuevo: str | None, actor: au.Actor) -> None:
    """También en el historial propio del viaje (traslados_auditoria), que es lo que muestra la ficha."""
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'traslados_auditoria'").fetchone():
        con.execute("INSERT INTO traslados_auditoria (entidad, entidad_id, accion, anterior, nuevo, usuario, fecha) VALUES ('viaje', ?, ?, ?, ?, ?, ?)",
                    (viaje_id, accion, anterior, nuevo, actor.nombre, _ahora()))


@dataclass(frozen=True)
class Permiso:
    """Lo calcula la capa web con las funciones de permisos existentes (traslados.puede_coordinar, chofer del viaje)."""
    coordina: bool
    es_chofer_del_viaje: bool
    viaja: bool

    @property
    def opera(self) -> bool:
        return self.coordina or self.es_chofer_del_viaje or self.viaja


def _viaje(con: sqlite3.Connection, viaje_id: int) -> dict[str, object]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        f = con.execute("SELECT * FROM viajes WHERE id = ?", (viaje_id,)).fetchone()
    finally:
        con.row_factory = previo
    if not f:
        raise NoEncontrado("El viaje no existe.")
    return dict(f)


def registrar_evento(con: sqlite3.Connection, actor: au.Actor, permiso: Permiso, viaje_id: int, evento: str, hora: str,
                     hoy: date, correccion: bool = False) -> str:
    """Marca la hora de llegada, ingreso o salida de la parada. Devuelve la hora guardada."""
    if evento not in EVENTOS:
        raise DatoInvalido("No sé qué se quiere marcar.")
    if not permiso.opera:
        raise PermisoDenegado("Lo marcan el chofer del viaje, quienes viajan o la coordinación.")
    if correccion and not permiso.coordina:
        raise PermisoDenegado("Solo la coordinación corrige una hora ya marcada.")
    h = (hora or "").strip()
    if not _HORA.match(h):
        raise DatoInvalido("La hora no es válida (HH:MM).")
    v = _viaje(con, viaje_id)
    if v["estado"] != "CONFIRMADO":
        raise Conflicto("Solo se marcan los viajes confirmados.")
    if str(v["fecha"]) != hoy.isoformat() and not permiso.coordina:
        raise Conflicto("Se marca el mismo día del viaje. Si hace falta corregirlo, pedíselo a la coordinación.")
    if str(v["fecha"]) > hoy.isoformat():
        raise Conflicto("El viaje todavía no se hizo.")
    columna, texto = EVENTOS[evento]
    anterior = str(v[columna]) if v.get(columna) else None
    if anterior and not correccion:
        raise Conflicto(f"«{texto}» ya se marcó a las {anterior}. Si está mal, la coordinación lo corrige.")
    orden = [EVENTOS[e][0] for e in ("llegada", "ingreso", "salida")]
    i = orden.index(columna)
    previos = [str(v[c]) for c in orden[:i] if v.get(c)]
    siguientes = [str(v[c]) for c in orden[i + 1:] if v.get(c)]
    if any(p > h for p in previos) or any(s < h for s in siguientes):
        raise DatoInvalido("La hora no respeta el orden: llegada, ingreso y salida.")
    con.execute(f"UPDATE viajes SET {columna} = ?, tiempos_por = ?, tiempos_en = ? WHERE id = ?", (h, actor.nombre, _ahora(), viaje_id))
    au.registrar(con, accion=f"{texto} ({'corrección' if anterior else 'registro'})", entidad="viaje", entidad_id=viaje_id,
                 antes={columna: anterior} if anterior else None, despues={columna: h}, actor=actor, origen="parada")
    _linea_tiempo(con, viaje_id, texto if not anterior else f"Corrección: {texto.lower()}", anterior, h, actor)
    if evento == "salida":
        marcar_constancia(con, actor, viaje_id, "CHOFER" if permiso.es_chofer_del_viaje else ("VIAJERO" if permiso.viaja else "COORDINACION"))
    return h


def marcar_constancia(con: sqlite3.Connection, actor: au.Actor, viaje_id: int, origen: str) -> bool:
    """Deja la constancia de que el viaje se hizo, si todavía no la tiene. Devuelve True si la dejó ahora."""
    if origen not in ORIGENES:
        raise DatoInvalido("Origen de la constancia desconocido.")
    cur = con.execute("""UPDATE viajes SET constancia_origen = ?, constancia_por = ?, constancia_en = ?
                         WHERE id = ? AND constancia_en IS NULL AND estado = 'CONFIRMADO'""", (origen, actor.nombre, _ahora(), viaje_id))
    if not cur.rowcount:
        return False
    au.registrar(con, accion="Constancia de realización", entidad="viaje", entidad_id=viaje_id, despues={"origen": origen}, actor=actor)
    _linea_tiempo(con, viaje_id, "Constancia: el viaje se hizo", None, ORIGENES[origen], actor)
    return True


def confirmar_realizado(con: sqlite3.Connection, actor: au.Actor, permiso: Permiso, viaje_id: int, hoy: date) -> bool:
    """Botón «Confirmo que el viaje se hizo» (quien viajó o la coordinación)."""
    if not (permiso.viaja or permiso.coordina or permiso.es_chofer_del_viaje):
        raise PermisoDenegado("Lo confirman quienes viajaron, el chofer o la coordinación.")
    v = _viaje(con, viaje_id)
    if v["estado"] != "CONFIRMADO" or str(v["fecha"]) > hoy.isoformat():
        raise Conflicto("Solo se confirma un viaje confirmado que ya pasó (o de hoy).")
    origen = "VIAJERO" if permiso.viaja else ("CHOFER" if permiso.es_chofer_del_viaje else "COORDINACION")
    return marcar_constancia(con, actor, viaje_id, origen)


def constancia_desde(con: sqlite3.Connection) -> str:
    f = None
    if con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'ajustes'").fetchone():
        f = con.execute("SELECT valor FROM ajustes WHERE clave = 'viajes_constancia_desde'").fetchone()
    return str(f[0]) if f and f[0] else date.today().isoformat()


def sin_constancia(con: sqlite3.Connection, hoy: date, dias: int, desde: str | None = None, hasta: str | None = None) -> list[int]:
    """Viajes confirmados ya pasados hace más de `dias` días, posteriores a la puesta en marcha, sin constancia.
    Los importados del Excel anterior no se cuentan (nunca tuvieron cómo dejarla)."""
    tope = (hoy - timedelta(days=dias)).isoformat()
    inicio = max(desde or "0000", constancia_desde(con))
    sql = """SELECT id FROM viajes WHERE estado = 'CONFIRMADO' AND constancia_en IS NULL AND fecha < ? AND fecha >= ?
             AND COALESCE(origen, '') != 'IMPORTADO'"""
    args: list[object] = [tope, inicio]
    if hasta:
        sql += " AND fecha <= ?"
        args.append(hasta)
    return [int(f[0]) for f in con.execute(sql + " ORDER BY fecha, id", args)]
