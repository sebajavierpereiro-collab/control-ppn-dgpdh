"""Propuesta 54 (viajes 1): tiempos y distancias por calle con un OSRM instalado EN EL MISMO SERVIDOR o en la red interna
(optativo: config.ini [viajes] osrm_url). Nunca se usa el servidor público de OSRM: mandaría coordenadas de las unidades al
exterior, así que solo se aceptan direcciones locales o de red privada. Sin OSRM (o si no responde) se usa la línea recta ×
factor de corrección, como siempre. Los resultados se guardan en memoria mientras el sistema está prendido."""
from __future__ import annotations

import ipaddress
import json
import logging
import sqlite3
import urllib.request
from urllib.parse import urlparse

from dgpdh.dominio import flota_control as fc
from dgpdh.servicios import opciones_viajes

log = logging.getLogger("dgpdh.distancias")
_CACHE: dict[tuple[tuple[float, float], ...], tuple[float, float] | None] = {}


def es_local(url: str) -> bool:
    """Solo localhost o direcciones de red privada (10.x, 172.16-31.x, 192.168.x)."""
    try:
        host = urlparse(url).hostname or ""
    except ValueError:
        return False
    if host in ("localhost",):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private


def _osrm(url: str, puntos: list[tuple[float, float]]) -> tuple[float, float] | None:
    """(km, minutos) de la ruta por las paradas en orden, o None si OSRM no responde."""
    clave = tuple(puntos)
    if clave in _CACHE:
        return _CACHE[clave]
    coords = ";".join(f"{lng:.6f},{lat:.6f}" for lat, lng in puntos)
    try:
        with urllib.request.urlopen(f"{url.rstrip('/')}/route/v1/driving/{coords}?overview=false", timeout=3) as r:  # noqa: S310 (local)
            datos = json.loads(r.read().decode("utf-8"))
        ruta = datos["routes"][0]
        valor: tuple[float, float] | None = (round(float(ruta["distance"]) / 1000, 1), round(float(ruta["duration"]) / 60))
    except Exception as e:  # sin OSRM o con error: se sigue con la línea recta
        log.info("OSRM no disponible (%s): se usa la línea recta", e)
        valor = None
    _CACHE[clave] = valor
    return valor


def ruta(puntos: list[tuple[float, float]]) -> tuple[float, float | None, str]:
    """(km, minutos o None, fuente) del recorrido por los puntos en orden."""
    o = opciones_viajes.leer()
    if o.osrm_url and es_local(o.osrm_url) and len(puntos) >= 2:
        r = _osrm(o.osrm_url, puntos)
        if r:
            return r[0], r[1], "OSRM local"
    recta = sum(fc.haversine_km(a[0], a[1], b[0], b[1]) for a, b in zip(puntos, puntos[1:], strict=False))
    return round(recta * o.factor_ruta, 1), None, f"línea recta × {o.factor_ruta:g}"


def recorrido_km(con: sqlite3.Connection, puntos: list[tuple[float, float]]) -> float | None:
    """Ida por los puntos y vuelta al primero (lo que usa el control de odómetro, propuesta 61). None sin OSRM."""
    o = opciones_viajes.leer()
    if not (o.osrm_url and es_local(o.osrm_url)) or len(puntos) < 2:
        return None
    r = _osrm(o.osrm_url, puntos + puntos[:1])
    return r[0] if r else None
