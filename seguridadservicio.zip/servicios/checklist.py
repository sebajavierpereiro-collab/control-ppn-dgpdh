"""Propuesta 60: control del vehículo antes de salir. Cada control queda guardado por salida (nunca se pisa: si se repite,
vale el último de cada ítem y el anterior queda en el historial). Todo va a la auditoría única."""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone

from dgpdh.errores import DatoInvalido, NoEncontrado, PermisoDenegado
from dgpdh.seguridad import auditoria as au

RESULTADOS = {"OK": "OK", "OBSERVACION": "Con observación", "NO_APTO": "No apto"}


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _dicts(con: sqlite3.Connection, sql: str, args: tuple[object, ...] = ()) -> list[dict[str, object]]:
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        return [dict(f) for f in con.execute(sql, args)]
    finally:
        con.row_factory = previo


def items(con: sqlite3.Connection, incluir_bajas: bool = False) -> list[dict[str, object]]:
    return _dicts(con, "SELECT * FROM checklist_items" + ("" if incluir_bajas else " WHERE activo = 1") + " ORDER BY activo DESC, orden, id")


def agregar_item(con: sqlite3.Connection, actor: au.Actor, coordina: bool, texto: str) -> int:
    if not coordina:
        raise PermisoDenegado("Los ítems del control los define la coordinación de traslados.")
    t = re.sub(r"\s+", " ", texto or "").strip()[:120]
    if len(t) < 3:
        raise DatoInvalido("Escribí el ítem a controlar.")
    orden = int(con.execute("SELECT COALESCE(MAX(orden), 0) + 1 FROM checklist_items").fetchone()[0])
    iid = int(con.execute("INSERT INTO checklist_items (texto, orden, cargado_por, cargado_en) VALUES (?, ?, ?, ?)",
                          (t, orden, actor.nombre, _ahora())).lastrowid or 0)
    au.registrar(con, accion="Ítem de control agregado", entidad="checklist_item", entidad_id=iid, despues={"texto": t}, actor=actor)
    return iid


def baja_item(con: sqlite3.Connection, actor: au.Actor, coordina: bool, item_id: int) -> None:
    if not coordina:
        raise PermisoDenegado("Los ítems del control los define la coordinación de traslados.")
    f = con.execute("SELECT texto FROM checklist_items WHERE id = ? AND activo = 1", (item_id,)).fetchone()
    if not f:
        raise NoEncontrado("Ese ítem no existe o ya estaba dado de baja.")
    con.execute("UPDATE checklist_items SET activo = 0, baja_por = ?, baja_en = ? WHERE id = ?", (actor.nombre, _ahora(), item_id))
    au.registrar(con, accion="Ítem de control dado de baja", entidad="checklist_item", entidad_id=item_id, antes={"texto": f[0]}, actor=actor)


@dataclass(frozen=True)
class Respuesta:
    item_id: int
    resultado: str
    observacion: str


def registrar(con: sqlite3.Connection, actor: au.Actor, puede: bool, desplazamiento_id: int, respuestas: list[Respuesta]) -> list[dict[str, object]]:
    """Guarda el control. Devuelve los ítems «no apto» (para crear la novedad mecánica y avisar)."""
    if not puede:
        raise PermisoDenegado("El control lo cargan el chofer de la salida o la coordinación.")
    d = con.execute("SELECT vehiculo_id FROM desplazamientos WHERE id = ?", (desplazamiento_id,)).fetchone()
    if not d:
        raise NoEncontrado("La salida no existe.")
    vigentes = {int(str(i["id"])): str(i["texto"]) for i in items(con)}
    if not respuestas:
        raise DatoInvalido("Marcá el resultado de al menos un ítem.")
    no_aptos: list[dict[str, object]] = []
    for r in respuestas:
        if r.item_id not in vigentes:
            raise DatoInvalido("Hay un ítem que ya no está en el control.")
        if r.resultado not in RESULTADOS:
            raise DatoInvalido("Resultado no válido.")
        obs = re.sub(r"\s+", " ", r.observacion or "").strip()[:300] or None
        if r.resultado != "OK" and not obs:
            raise DatoInvalido(f"Contá qué pasa con «{vigentes[r.item_id]}».")
        cid = int(con.execute("""INSERT INTO checklist_controles (desplazamiento_id, vehiculo_id, item_id, item_texto, resultado, observacion,
                                 registrado_por, registrado_en) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                              (desplazamiento_id, d[0], r.item_id, vigentes[r.item_id], r.resultado, obs, actor.nombre, _ahora())).lastrowid or 0)
        if r.resultado == "NO_APTO":
            no_aptos.append({"control_id": cid, "item": vigentes[r.item_id], "observacion": obs, "vehiculo_id": d[0]})
    au.registrar(con, accion="Control antes de salir", entidad="desplazamiento", entidad_id=desplazamiento_id,
                 despues={vigentes[r.item_id]: r.resultado for r in respuestas}, actor=actor)
    return no_aptos


def vincular_novedad(con: sqlite3.Connection, control_id: int, novedad_id: int) -> None:
    con.execute("UPDATE checklist_controles SET novedad_id = ? WHERE id = ?", (novedad_id, control_id))


def ultimo(con: sqlite3.Connection, desplazamiento_id: int) -> list[dict[str, object]]:
    """El último resultado de cada ítem en esa salida."""
    filas = _dicts(con, "SELECT * FROM checklist_controles WHERE desplazamiento_id = ? ORDER BY id", (desplazamiento_id,))
    por: dict[object, dict[str, object]] = {}
    for f in filas:
        por[f["item_id"]] = dict(f, etiqueta=RESULTADOS.get(str(f["resultado"]), str(f["resultado"])))
    return list(por.values())
