"""Propuesta 39: vincular la nota con la ficha de la persona detenida, y que lo confirme una persona.

Hoy la ficha busca sus notas en cada consulta por DNI o por todas las palabras del nombre, y eso falla con nombres comunes o
escritos de otra forma. Acá, a partir de lo que la prerrevisión ya leyó del texto (`nota_entidades`: DNI y nombres), se
**proponen** fichas con su puntaje (DNI exacto; nombre igual, en otro orden o que suena igual, propuesta 32). Quien ve la nota
confirma o descarta; el vínculo confirmado lo lee la ficha. Todo queda en la auditoría.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from dgpdh.dominio import personas
from dgpdh.errores import DatoInvalido, NoEncontrado
from dgpdh.seguridad import auditoria as au

ESTADOS = {"confirmar": "CONFIRMADO", "descartar": "DESCARTADO"}


@dataclass(frozen=True)
class Propuesta:
    detenido_id: int
    nombre: str
    dni: str | None
    activo: bool
    puntaje: int
    motivo: str


def _filas(con: sqlite3.Connection, sql: str, params: tuple[object, ...] = ()) -> list[dict[str, Any]]:
    cur = con.execute(sql, params)
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


def proponer(con: sqlite3.Connection, nota_id: int, limite: int = 6) -> list[Propuesta]:
    """Fichas que probablemente nombra la nota y que todavía nadie confirmó ni descartó."""
    ents = _filas(con, "SELECT valor, norm FROM nota_entidades WHERE nota_id = ? AND tipo = 'PERSONA'", (nota_id,))
    decididas = {int(f["detenido_id"]) for f in _filas(con, "SELECT detenido_id FROM nota_persona WHERE nota_id = ?", (nota_id,))}
    mejores: dict[int, Propuesta] = {}

    def sumar(f: dict[str, Any], puntaje: int, motivo: str) -> None:
        i = int(f["id"])
        if i in decididas or str(f.get("motivo_baja") or "").startswith("Unificada"):
            return
        if i not in mejores or mejores[i].puntaje < puntaje:
            mejores[i] = Propuesta(i, str(f["nombre_completo"]), f.get("dni"), bool(f.get("activo")), puntaje, motivo)
    columnas = "id, nombre_completo, nombre_norm, dni, activo, motivo_baja"
    for e in ents:
        norm = str(e["norm"] or "")
        if norm.startswith("dni:"):
            for f in _filas(con, f"SELECT {columnas} FROM detenidos WHERE dni = ?", (norm[4:],)):
                sumar(f, 100, f"DNI {norm[4:]} en el texto")
            continue
        tokens = sorted(norm.split())
        if len(tokens) < 2:
            continue
        foneticos = personas.tokens_foneticos(norm)
        # candidatas: fichas que comparten el comienzo de alguna palabra (así entran también las que suenan igual: Vázquez/Básquez)
        claves = sorted({t[:4] for t in tokens if len(t) >= 3})
        if not claves:
            continue
        donde = " OR ".join("nombre_norm LIKE ?" for _ in claves)
        for f in _filas(con, f"SELECT {columnas} FROM detenidos WHERE {donde} LIMIT 1000", tuple(f"%{c}%" for c in claves)):
            nf = str(f["nombre_norm"] or "")
            if nf == norm:
                sumar(f, 70, f"mismo nombre que «{e['valor']}»")
            elif sorted(nf.split()) == tokens:
                sumar(f, 65, f"mismo nombre en otro orden que «{e['valor']}»")
            elif personas.tokens_foneticos(nf) == foneticos:
                sumar(f, 50, f"nombre que suena igual a «{e['valor']}»")
            elif set(tokens) <= set(nf.split()):
                sumar(f, 40, f"la ficha contiene el nombre «{e['valor']}»")
    return sorted(mejores.values(), key=lambda p: (-p.puntaje, not p.activo, p.nombre))[:limite]


def decidir(con: sqlite3.Connection, *, nota_id: int, detenido_id: int, accion: str, actor: au.Actor, puntaje: int | None = None,
            motivo: str | None = None) -> str:
    estado = ESTADOS.get(accion)
    if estado is None:
        raise DatoInvalido("Elegí si la persona es la de la nota o no.")
    if not con.execute("SELECT 1 FROM detenidos WHERE id = ?", (detenido_id,)).fetchone():
        raise NoEncontrado("La ficha no existe.")
    previo = con.execute("SELECT estado FROM nota_persona WHERE nota_id = ? AND detenido_id = ?", (nota_id, detenido_id)).fetchone()
    con.execute("""INSERT INTO nota_persona (nota_id, detenido_id, estado, puntaje, motivo, usuario, usuario_id, fecha) VALUES (?,?,?,?,?,?,?,?)
                   ON CONFLICT(nota_id, detenido_id) DO UPDATE SET estado = excluded.estado, usuario = excluded.usuario,
                   usuario_id = excluded.usuario_id, fecha = excluded.fecha""",
                (nota_id, detenido_id, estado, puntaje, (motivo or "")[:300] or None, actor.nombre, actor.id,
                 datetime.now(timezone.utc).isoformat(timespec="seconds")))
    au.registrar(con, accion="Vincular nota con ficha" if estado == "CONFIRMADO" else "Descartar vínculo nota-ficha", entidad="nota",
                 entidad_id=nota_id, antes={"detenido_id": detenido_id, "estado": previo[0] if previo else None},
                 despues={"detenido_id": detenido_id, "estado": estado}, actor=actor, origen="nota_persona")
    return estado


def confirmadas_de_nota(con: sqlite3.Connection, nota_id: int) -> list[dict[str, Any]]:
    return _filas(con, """SELECT d.id, d.nombre_completo, d.dni, d.activo, np.usuario, np.fecha FROM nota_persona np
                          JOIN detenidos d ON d.id = np.detenido_id WHERE np.nota_id = ? AND np.estado = 'CONFIRMADO' ORDER BY d.nombre_completo""",
                  (nota_id,))


def notas_confirmadas(con: sqlite3.Connection, detenido_id: int) -> set[int]:
    return {int(f[0]) for f in con.execute("SELECT nota_id FROM nota_persona WHERE detenido_id = ? AND estado = 'CONFIRMADO'", (detenido_id,))}


def descartadas(con: sqlite3.Connection, detenido_id: int) -> set[int]:
    return {int(f[0]) for f in con.execute("SELECT nota_id FROM nota_persona WHERE detenido_id = ? AND estado = 'DESCARTADO'", (detenido_id,))}
