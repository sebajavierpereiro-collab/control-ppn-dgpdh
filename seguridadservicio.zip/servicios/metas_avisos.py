"""Propuesta 84: avisos internos cuando un indicador de metas PASA a «atrasada» (no cada día que sigue atrasado), y
propuesta 91: qué equipos no cargaron el mes anterior. Solo guarda el último estado; los avisos los manda la capa de arriba
con las notificaciones internas del sistema (nada sale por correo)."""
from __future__ import annotations

import sqlite3
from collections.abc import Iterable
from datetime import date, datetime, timedelta, timezone

from dgpdh.dominio import metas_calculo as mc


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def actualizar_estados(con: sqlite3.Connection, anio: int, estados: Iterable[tuple[int, str, str]], hoy: date) -> list[tuple[int, str]]:
    """estados = [(equipo_id, indicador, estado)]. Guarda el estado nuevo y devuelve los que pasaron a «atrasada».
    Si el estado no cambió, no toca nada (así «desde» dice desde cuándo está así)."""
    cambios: list[tuple[int, str]] = []
    for eid, indicador, estado in estados:
        f = con.execute("SELECT estado FROM metas_estado_aviso WHERE equipo_id = ? AND anio = ? AND indicador = ?", (eid, anio, indicador)).fetchone()
        anterior = str(f[0]) if f else None
        if anterior == estado:
            continue
        if mc.pasa_a_atrasada(anterior, estado):
            cambios.append((eid, indicador))
        con.execute("""INSERT INTO metas_estado_aviso (equipo_id, anio, indicador, estado, desde, avisado_en) VALUES (?, ?, ?, ?, ?, ?)
                       ON CONFLICT(equipo_id, anio, indicador) DO UPDATE SET estado = excluded.estado, desde = excluded.desde,
                       avisado_en = excluded.avisado_en""",
                    (eid, anio, indicador, estado, hoy.isoformat(), _ahora() if mc.pasa_a_atrasada(anterior, estado) else None))
    return cambios


def atrasadas_de_la_semana(con: sqlite3.Connection, anio: int, hoy: date) -> list[tuple[int, str, str]]:
    """[(equipo_id, indicador, desde)] que pasaron a «atrasada» en los últimos 7 días y siguen así (resumen para la Dirección)."""
    desde = (hoy - timedelta(days=7)).isoformat()
    return [(int(e), str(i), str(d)) for e, i, d in con.execute(
        """SELECT equipo_id, indicador, desde FROM metas_estado_aviso WHERE anio = ? AND estado = 'atrasada' AND avisado_en IS NOT NULL
           AND desde >= ? ORDER BY equipo_id, indicador""", (anio, desde))]


def mes_anterior(hoy: date) -> date:
    return hoy.replace(day=1) - timedelta(days=1)


def falta_cargar_mes(periodos: Iterable[str], mes: int) -> bool:
    return not any(mes in mc.meses_de_periodo(p) for p in periodos)
