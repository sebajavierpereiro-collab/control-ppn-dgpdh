"""Propuesta 33: deshacer una unificación de fichas de personas detenidas («Separar fichas»).

Al unificar, la ficha conservada completa lo que le falta con la otra (y toma el alojamiento si la otra venía de un listado más
nuevo); la otra queda de baja «Unificada con #…». Desde ahora, cada unificación guarda cómo estaban las dos fichas antes y
cómo quedó la conservada (`registrar`). Separar:
  - devuelve a la ficha conservada los campos que tomó de la otra, **solo si nadie los cambió después** (si cambiaron, se
    conservan y se informa);
  - devuelve a la otra ficha el estado que tenía (alojada o de baja con su motivo);
  - registra cada cambio en `detenidos_cambios` (origen SEPARACION) y en la auditoría, y marca el par como «personas
    distintas» para que no se vuelva a proponer.
No se borra nada. Las unificaciones anteriores a este cambio se reconstruyen desde `detenidos_cambios` (`reconstruir`).
"""
from __future__ import annotations

import json
import re
import sqlite3
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado
from dgpdh.seguridad import auditoria as au

EXTRA = ("fecha_listado", "fuerza_id", "listado_id")   # se actualizan sin registro de campo al unificar
_MARCA = re.compile(r"^Se le unió la ficha #(\d+)$")
Derivados = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _fila(con: sqlite3.Connection, det_id: int) -> dict[str, Any] | None:
    cur = con.execute("SELECT * FROM detenidos WHERE id = ?", (det_id,))
    nombres = [d[0] for d in cur.description]
    f = cur.fetchone()
    return dict(zip(nombres, tuple(f), strict=True)) if f else None


def _igual(a: object, b: object) -> bool:
    return str("" if a is None else a) == str("" if b is None else b)


@dataclass(frozen=True)
class Unificacion:
    id: int
    mantener_id: int
    absorbida_id: int
    fecha: str
    usuario: str | None
    origen: str
    separada_en: str | None
    separada_por: str | None
    motivo_separacion: str | None
    campos_tomados: tuple[str, ...]


@dataclass
class Resultado:
    restaurados: list[str] = field(default_factory=list)      # campos que volvieron a como estaban
    conservados: list[str] = field(default_factory=list)      # campos que alguien cambió después: no se tocaron
    absorbida_activa: bool = False


def registrar(con: sqlite3.Connection, *, mantener_id: int, absorbida_id: int, antes_mantener: Mapping[str, Any],
              antes_absorbida: Mapping[str, Any], usuario: str | None) -> int:
    """Lo llama `detenidos.unificar` dentro de la misma conexión, después de escribir la unificación."""
    despues = _fila(con, mantener_id) or {}
    cur = con.execute("""INSERT INTO detenidos_unificaciones (mantener_id, absorbida_id, antes_mantener, antes_absorbida, despues_mantener,
                         origen, usuario, fecha) VALUES (?,?,?,?,?,?,?,?)""",
                      (mantener_id, absorbida_id, json.dumps(dict(antes_mantener), ensure_ascii=False, default=str),
                       json.dumps(dict(antes_absorbida), ensure_ascii=False, default=str), json.dumps(despues, ensure_ascii=False, default=str),
                       "SISTEMA", usuario, _ahora()))
    return int(cur.lastrowid or 0)


def _tomados(antes: Mapping[str, Any], despues: Mapping[str, Any], campos: Sequence[str]) -> tuple[str, ...]:
    return tuple(c for c in (*campos, *EXTRA) if c in despues and not _igual(antes.get(c), despues.get(c)))


def _desde_fila(f: Mapping[str, Any], campos: Sequence[str]) -> Unificacion:
    antes = json.loads(f["antes_mantener"] or "{}")
    despues = json.loads(f["despues_mantener"] or "{}")
    return Unificacion(int(f["id"]), int(f["mantener_id"]), int(f["absorbida_id"]), str(f["fecha"]), f["usuario"], str(f["origen"]),
                       f["separada_en"], f["separada_por"], f["motivo_separacion"], _tomados(antes, despues, campos))


def _filas(con: sqlite3.Connection, sql: str, params: Sequence[object]) -> list[dict[str, Any]]:
    cur = con.execute(sql, tuple(params))
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


def reconstruir(con: sqlite3.Connection, det_id: int) -> int:
    """Unificaciones hechas antes de guardar las fotos: se arman desde detenidos_cambios (los campos que tomó la conservada,
    con su valor anterior). Devuelve cuántas se agregaron. La ficha absorbida no tenía foto: se sabe si estaba alojada solo
    cuando la conservada volvió a alojados por la unificación."""
    marcas = _filas(con, "SELECT id, despues, usuario, fecha FROM detenidos_cambios WHERE detenido_id = ? AND campo = 'unificación' "
                         "AND origen = 'UNIFICACION' ORDER BY id", (det_id,))
    ya = {int(f["absorbida_id"]) for f in _filas(con, "SELECT absorbida_id FROM detenidos_unificaciones WHERE mantener_id = ?", (det_id,))}
    agregadas, desde = 0, 0
    for m in marcas:
        x = _MARCA.match(str(m["despues"] or ""))
        if not x:
            desde = int(m["id"])
            continue
        absorbida = int(x.group(1))
        if absorbida in ya:
            desde = int(m["id"])
            continue
        cambios = _filas(con, "SELECT campo, antes, despues FROM detenidos_cambios WHERE detenido_id = ? AND origen = 'UNIFICACION' "
                              "AND id > ? AND id < ? ORDER BY id", (det_id, desde, int(m["id"])))
        antes_m: dict[str, Any] = {}
        despues_m: dict[str, Any] = {}
        absorbida_activa = False
        for c in cambios:
            if c["campo"] == "estado":
                antes_m["activo"], antes_m["motivo_baja"] = 0, c["antes"]
                despues_m["activo"], despues_m["motivo_baja"] = 1, None
                absorbida_activa = True
            elif c["campo"] != "unificación":
                antes_m[c["campo"]], despues_m[c["campo"]] = c["antes"], c["despues"]
        antes_b = {"activo": 1 if absorbida_activa else None, "motivo_baja": None}
        con.execute("""INSERT INTO detenidos_unificaciones (mantener_id, absorbida_id, antes_mantener, antes_absorbida, despues_mantener,
                       origen, usuario, fecha) VALUES (?,?,?,?,?,?,?,?)""",
                    (det_id, absorbida, json.dumps(antes_m, ensure_ascii=False), json.dumps(antes_b, ensure_ascii=False),
                     json.dumps(despues_m, ensure_ascii=False), "RECONSTRUIDA", m["usuario"], m["fecha"]))
        agregadas += 1
        desde = int(m["id"])
    return agregadas


def de_ficha(con: sqlite3.Connection, det_id: int, campos: Sequence[str]) -> list[Unificacion]:
    """Las unificaciones en las que esta ficha fue la conservada (las separadas también, para el historial)."""
    reconstruir(con, det_id)
    return [_desde_fila(f, campos) for f in _filas(con, "SELECT * FROM detenidos_unificaciones WHERE mantener_id = ? ORDER BY id DESC",
                                                   (det_id,))]


def separar(con: sqlite3.Connection, unificacion_id: int, *, campos: Sequence[str], derivados: Derivados, actor: au.Actor,
            motivo: str, clave_par: str) -> Resultado:
    """Separa las dos fichas. `campos`: columnas de la ficha que se pueden devolver; `derivados`: calcula las columnas
    derivadas (nombre normalizado, LPU normalizado, apellido y nombres) a partir de la ficha restaurada; `clave_par`: la
    clave con la que la revisión de la base registra «personas distintas»."""
    motivo = (motivo or "").strip()
    if len(motivo) < 5:
        raise DatoInvalido("Escribí por qué se separan las fichas (por ejemplo: «son hermanos, distinto DNI»).")
    filas = _filas(con, "SELECT * FROM detenidos_unificaciones WHERE id = ?", (unificacion_id,))
    if not filas:
        raise NoEncontrado("Esa unificación no existe.")
    u = filas[0]
    if u["separada_en"]:
        raise Conflicto("Esas fichas ya se separaron.")
    mantener_id, absorbida_id = int(u["mantener_id"]), int(u["absorbida_id"])
    actual_m, actual_b = _fila(con, mantener_id), _fila(con, absorbida_id)
    if actual_m is None or actual_b is None:
        raise NoEncontrado("Alguna de las dos fichas ya no existe.")
    if not str(actual_b.get("motivo_baja") or "").startswith(f"Unificada con #{mantener_id}"):
        raise Conflicto("La otra ficha ya no figura como unificada con esta: revisala a mano.")
    antes_m = json.loads(u["antes_mantener"] or "{}")
    despues_m = json.loads(u["despues_mantener"] or "{}")
    antes_b = json.loads(u["antes_absorbida"] or "{}")
    res = Resultado()
    nuevos: dict[str, Any] = {}
    for c in (*campos, *EXTRA, "activo", "motivo_baja"):
        if c not in despues_m or _igual(antes_m.get(c), despues_m.get(c)):
            continue
        if _igual(actual_m.get(c), despues_m.get(c)):
            nuevos[c] = antes_m.get(c)
            res.restaurados.append(c)
        else:
            res.conservados.append(c)
    quien, ahora = actor.nombre, _ahora()
    log = ("INSERT INTO detenidos_cambios (detenido_id, campo, antes, despues, usuario, origen, fecha) VALUES (?,?,?,?,?,?,?)")
    if nuevos:
        restaurada = {**actual_m, **nuevos}
        nuevos.update({k: v for k, v in derivados(restaurada).items() if k in actual_m})
        nuevos.update({"actualizado_por": quien, "actualizado_en": ahora})
        con.execute(f"UPDATE detenidos SET {', '.join(f'{k} = ?' for k in nuevos)} WHERE id = ?", (*nuevos.values(), mantener_id))
        for c in res.restaurados:
            con.execute(log, (mantener_id, c, None if actual_m.get(c) is None else str(actual_m.get(c)),
                              None if nuevos[c] is None else str(nuevos[c]), quien, "SEPARACION", ahora))
    activa_b = antes_b.get("activo")
    activa_b = 1 if activa_b in (1, "1", True) else 0
    motivo_b = None if activa_b else (antes_b.get("motivo_baja") or f"Separada de #{mantener_id}: revisar si sigue alojada")
    con.execute("UPDATE detenidos SET activo = ?, motivo_baja = ?, actualizado_por = ?, actualizado_en = ? WHERE id = ?",
                (activa_b, motivo_b, quien, ahora, absorbida_id))
    res.absorbida_activa = bool(activa_b)
    con.execute(log, (absorbida_id, "separación", actual_b.get("motivo_baja"), f"Separada de #{mantener_id}: {motivo}"[:300], quien,
                      "SEPARACION", ahora))
    con.execute(log, (mantener_id, "separación", f"Se le había unido la ficha #{absorbida_id}", f"Se separó la ficha #{absorbida_id}: {motivo}"[:300],
                      quien, "SEPARACION", ahora))
    con.execute("""INSERT INTO detenidos_revision (clave, tipo, decision, nota, usuario, fecha) VALUES (?,?,?,?,?,?)
                   ON CONFLICT(clave) DO UPDATE SET decision = excluded.decision, nota = excluded.nota, usuario = excluded.usuario,
                   fecha = excluded.fecha""", (clave_par, "duplicado", "distintas", f"Separadas: {motivo}"[:300], quien, ahora))
    resultado = {"restaurados": res.restaurados, "conservados": res.conservados, "absorbida_activa": res.absorbida_activa}
    con.execute("UPDATE detenidos_unificaciones SET separada_en = ?, separada_por = ?, motivo_separacion = ?, resultado_separacion = ? WHERE id = ?",
                (ahora, quien, motivo[:500], json.dumps(resultado, ensure_ascii=False), unificacion_id))
    au.registrar(con, accion="Separar fichas", entidad="detenido", entidad_id=mantener_id,
                 antes={"mantener": {c: actual_m.get(c) for c in res.restaurados}, "absorbida": {"id": absorbida_id, "activo": actual_b.get("activo"),
                                                                                                 "motivo_baja": actual_b.get("motivo_baja")}},
                 despues={"mantener": {c: nuevos.get(c) for c in res.restaurados}, "absorbida": {"id": absorbida_id, "activo": activa_b,
                                                                                                 "motivo_baja": motivo_b},
                          "conservados": res.conservados},
                 actor=actor, motivo=motivo, origen="detenidos")
    return res
