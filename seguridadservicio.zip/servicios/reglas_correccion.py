"""Propuesta 16: usar los rechazos de párrafo para proponer apagar las reglas de corrección que molestan.

Cada cambio automático sabe qué lo produjo: una regla de LanguageTool (`lt:<ruleId>`), un reemplazo del diccionario
institucional (`dic:<texto>`) o la IA (`ia:<modelo>`). Al decidir la revisión se cuenta, por regla, cuántas veces se aceptó y
cuántas se rechazó, con un motivo opcional de un clic. Cuando una regla supera N rechazos y la mayoría de sus usos fueron
rechazados, se **propone** a la Dirección desactivarla. No se apaga sola: lo decide una persona y queda en la auditoría.
"""
from __future__ import annotations

import sqlite3
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone

from dgpdh.errores import DatoInvalido
from dgpdh.seguridad import auditoria as au

MOTIVOS = {"sentido": "Cambió el sentido", "nombre_propio": "Es un nombre propio", "formula": "Es una fórmula institucional",
           "no_era_error": "No era un error"}
DECISIONES = ("aceptar", "modificar", "rechazar")
MINIMO_RECHAZOS = 10
TASA_RECHAZO = 0.7
PREFIJOS = {"lt": "Regla de ortografía y gramática", "dic": "Reemplazo del diccionario", "ia": "Corrección de la IA"}


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def etiqueta(regla: str) -> str:
    tipo, _, valor = regla.partition(":")
    return f"{PREFIJOS.get(tipo, tipo)}: {valor}" if valor else regla


@dataclass(frozen=True)
class Uso:
    regla: str
    aceptadas: int
    modificadas: int
    rechazadas: int
    motivos: dict[str, int]
    estado: str          # ACTIVA | DESACTIVADA

    @property
    def total(self) -> int:
        return self.aceptadas + self.modificadas + self.rechazadas

    @property
    def tasa_rechazo(self) -> float:
        return self.rechazadas / self.total if self.total else 0.0

    @property
    def etiqueta(self) -> str:
        return etiqueta(self.regla)

    def conviene_desactivar(self, minimo: int = MINIMO_RECHAZOS, tasa: float = TASA_RECHAZO) -> bool:
        return self.estado == "ACTIVA" and not self.regla.startswith("ia:") and self.rechazadas >= minimo and self.tasa_rechazo >= tasa


def registrar_decision(con: sqlite3.Connection, *, nota_id: int, ubicacion: str | None, reglas: Iterable[str], decision: str,
                       motivo: str | None, usuario: str | None) -> int:
    """Una fila por regla que intervino en el párrafo. Devuelve cuántas. El motivo solo se guarda en los rechazos."""
    if decision not in DECISIONES:
        raise DatoInvalido("Decisión desconocida.")
    motivo = motivo if decision == "rechazar" and motivo in MOTIVOS else None
    filas = [(nota_id, ubicacion, r[:200], decision, motivo, usuario, _ahora()) for r in dict.fromkeys(reglas) if r]
    con.executemany("INSERT INTO correccion_reglas_uso (nota_id, ubicacion, regla, decision, motivo, usuario, fecha) VALUES (?,?,?,?,?,?,?)",
                    filas)
    return len(filas)


def desactivadas(con: sqlite3.Connection) -> set[str]:
    return {str(r[0]) for r in con.execute("SELECT regla FROM correccion_reglas_estado WHERE estado = 'DESACTIVADA'")}


def resumen(con: sqlite3.Connection) -> list[Uso]:
    estado = {str(r[0]): str(r[1]) for r in con.execute("SELECT regla, estado FROM correccion_reglas_estado")}
    datos: dict[str, dict[str, int]] = {}
    motivos: dict[str, dict[str, int]] = {}
    for regla, decision, motivo, n in con.execute(
            "SELECT regla, decision, COALESCE(motivo, ''), COUNT(*) FROM correccion_reglas_uso GROUP BY regla, decision, motivo"):
        d = datos.setdefault(str(regla), {"aceptar": 0, "modificar": 0, "rechazar": 0})
        d[str(decision)] = d.get(str(decision), 0) + int(n)
        if motivo:
            m = motivos.setdefault(str(regla), {})
            m[str(motivo)] = m.get(str(motivo), 0) + int(n)
    usos = [Uso(r, d["aceptar"], d["modificar"], d["rechazar"], motivos.get(r, {}), estado.get(r, "ACTIVA")) for r, d in datos.items()]
    return sorted(usos, key=lambda u: (-u.rechazadas, -u.tasa_rechazo, u.regla))


def propuestas(con: sqlite3.Connection, minimo: int = MINIMO_RECHAZOS, tasa: float = TASA_RECHAZO) -> list[Uso]:
    """Reglas que conviene que la Dirección mire para desactivar (la IA no se apaga por acá: se cambia el modelo)."""
    return [u for u in resumen(con) if u.conviene_desactivar(minimo, tasa)]


def cambiar_estado(con: sqlite3.Connection, regla: str, *, desactivar: bool, actor: au.Actor, motivo: str | None = None) -> None:
    regla = (regla or "").strip()
    if not regla or ":" not in regla or regla.startswith("ia:"):
        raise DatoInvalido("Esa regla no se puede desactivar desde acá.")
    previo = con.execute("SELECT estado FROM correccion_reglas_estado WHERE regla = ?", (regla,)).fetchone()
    nuevo = "DESACTIVADA" if desactivar else "ACTIVA"
    con.execute("""INSERT INTO correccion_reglas_estado (regla, estado, motivo, decidido_por, decidido_en) VALUES (?,?,?,?,?)
                   ON CONFLICT(regla) DO UPDATE SET estado = excluded.estado, motivo = excluded.motivo,
                   decidido_por = excluded.decidido_por, decidido_en = excluded.decidido_en""",
                (regla, nuevo, (motivo or "").strip()[:300] or None, actor.nombre, _ahora()))
    au.registrar(con, accion="Desactivar regla de corrección" if desactivar else "Reactivar regla de corrección",
                 entidad="regla_correccion", entidad_id=regla, antes={"estado": previo[0] if previo else "ACTIVA"},
                 despues={"estado": nuevo}, actor=actor, motivo=motivo, origen="correccion")


def reglas_de_cambios(cambios: Sequence[dict[str, object]]) -> list[str]:
    """Las reglas de una propuesta de párrafo (cada cambio puede traer su lista «reglas»)."""
    salida: list[str] = []
    for c in cambios or []:
        valor = c.get("reglas") if isinstance(c, dict) else None
        if isinstance(valor, (list, tuple)):
            salida.extend(str(x) for x in valor if x)
    return list(dict.fromkeys(salida))
