"""Propuesta 3: vínculos con tipo entre documentos.

Una sola tabla para decir «esta nota reitera a la N° 123», «este oficio responde a nuestra nota 456» o «responde a la
NO-2025-…» (referencia externa GDE, propuesta 53). El sistema propone el vínculo cuando el texto cita un número de nota o un
número GDE; una persona lo confirma o lo descarta. Lo confirmado se ve en las dos notas. Todo queda en la auditoría.
"""
from __future__ import annotations

import re
import sqlite3
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from dgpdh.dominio import referencias
from dgpdh.errores import DatoInvalido, NoEncontrado
from dgpdh.seguridad import auditoria as au

TIPOS = {"responde_a": "Responde a", "reitera_a": "Reitera a", "amplia": "Amplía", "anexo_de": "Anexo de", "reemplaza_a": "Reemplaza a"}
_DESDE_GDE = {"responde a": "responde_a", "reitera a": "reitera_a", "amplía": "amplia"}
_NOTA = re.compile(r"\b(?P<antes>(?:en\s+respuesta\s+a|respondiendo\s+a|reiter\w*|ampli\w*|en\s+contestaci[oó]n\s+a)?[^.\n]{0,40}?)"
                   r"\bnota\s*(?:N\s?[°ºo]\.?|nro\.?|n[uú]mero)?\s*(?P<num>\d{1,6}\s*/\s*\d{2,4})", re.I)


def _filas(con: sqlite3.Connection, sql: str, params: Sequence[object] = ()) -> list[dict[str, Any]]:
    cur = con.execute(sql, tuple(params))
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


def _tipo_por_contexto(antes: str) -> str:
    a = antes.lower()
    if "respu" in a or "respond" in a or "contest" in a:
        return "responde_a"
    if "reiter" in a:
        return "reitera_a"
    if "ampli" in a:
        return "amplia"
    return "responde_a"


@dataclass(frozen=True)
class Propuesta:
    tipo: str
    destino_id: int | None
    referencia_externa: str | None
    motivo: str

    @property
    def etiqueta(self) -> str:
        return TIPOS[self.tipo]


def _norm_num(n: str) -> str:
    return re.sub(r"\s+", "", n)


def proponer(con: sqlite3.Connection, nota_id: int, texto: str) -> list[Propuesta]:
    """Vínculos que sugiere el texto y que todavía nadie decidió."""
    ya = {(f["destino_id"], f["referencia_externa"], f["tipo"]) for f in
          _filas(con, "SELECT destino_id, referencia_externa, tipo FROM vinculos_documentos WHERE origen_id = ?", (nota_id,))}
    salida: list[Propuesta] = []
    citas = {(_norm_num(m.group("num")), _tipo_por_contexto(m.group("antes") or "")) for m in _NOTA.finditer(texto or "")}
    if citas:
        nums = sorted({c for c, _ in citas})
        otras = _filas(con, "SELECT id, nro_nota, nombre_original FROM notas WHERE replace(COALESCE(nro_nota, ''), ' ', '') IN (%s) AND id != ?"
                       % ",".join("?" * len(nums)), (*nums, nota_id))
        por_num: dict[str, list[dict[str, Any]]] = {}
        for o in otras:
            por_num.setdefault(_norm_num(str(o["nro_nota"])), []).append(o)
        for num, tipo in sorted(citas):
            for o in por_num.get(num, []):
                if (o["id"], None, tipo) not in ya:
                    salida.append(Propuesta(tipo, int(o["id"]), None, f"el texto cita la nota N° {num}"))
    for g in referencias.gde_del_texto(texto):
        tipo = _DESDE_GDE.get(g.vinculo or "", "responde_a")
        if g.vinculo and (None, g.numero, tipo) not in ya:
            salida.append(Propuesta(tipo, None, g.numero, f"el texto dice que {g.vinculo} {g.texto}"))
    return salida


def decidir(con: sqlite3.Connection, *, origen_id: int, tipo: str, destino_id: int | None, referencia_externa: str | None, confirmar: bool,
            actor: au.Actor, origen_dato: str = "MANUAL") -> int:
    if tipo not in TIPOS:
        raise DatoInvalido("Elegí el tipo de vínculo.")
    if (destino_id is None) == (not referencia_externa):
        raise DatoInvalido("El vínculo va a otra nota del sistema o a una referencia externa (GDE), una de las dos.")
    if destino_id is not None:
        if destino_id == origen_id:
            raise DatoInvalido("Una nota no se vincula consigo misma.")
        if not con.execute("SELECT 1 FROM notas WHERE id = ?", (destino_id,)).fetchone():
            raise NoEncontrado("La otra nota no existe.")
    ref = (referencia_externa or "").strip().upper() or None
    estado = "CONFIRMADO" if confirmar else "DESCARTADO"
    previo = con.execute("SELECT id, estado FROM vinculos_documentos WHERE origen_id = ? AND destino_id IS ? AND referencia_externa IS ? AND tipo = ?",
                         (origen_id, destino_id, ref, tipo)).fetchone()
    ahora = datetime.now(timezone.utc).isoformat(timespec="seconds")
    if previo:
        con.execute("UPDATE vinculos_documentos SET estado = ?, quien = ?, fecha = ? WHERE id = ?", (estado, actor.nombre, ahora, previo[0]))
        vid = int(previo[0])
    else:
        cur = con.execute("""INSERT INTO vinculos_documentos (origen_id, destino_id, referencia_externa, tipo, estado, origen_dato, quien, fecha)
                             VALUES (?,?,?,?,?,?,?,?)""", (origen_id, destino_id, ref, tipo, estado, origen_dato, actor.nombre, ahora))
        vid = int(cur.lastrowid or 0)
    au.registrar(con, accion="Vincular documentos" if confirmar else "Descartar vínculo", entidad="nota", entidad_id=origen_id,
                 antes={"estado": previo[1]} if previo else None,
                 despues={"tipo": tipo, "destino_id": destino_id, "referencia_externa": ref, "estado": estado}, actor=actor, origen="vinculos")
    return vid


def de_nota(con: sqlite3.Connection, nota_id: int) -> list[dict[str, Any]]:
    """Vínculos confirmados de la nota, en las dos direcciones («responde a» / «la responde»)."""
    filas = _filas(con, """SELECT v.*, o.nombre_original AS origen_nombre, o.nro_nota AS origen_nro, d.nombre_original AS destino_nombre,
                              d.nro_nota AS destino_nro FROM vinculos_documentos v LEFT JOIN notas o ON o.id = v.origen_id
                              LEFT JOIN notas d ON d.id = v.destino_id
                              WHERE v.estado = 'CONFIRMADO' AND (v.origen_id = ? OR v.destino_id = ?) ORDER BY v.id""", (nota_id, nota_id))
    for f in filas:
        f["saliente"] = f["origen_id"] == nota_id
        f["etiqueta"] = TIPOS.get(f["tipo"], f["tipo"]) if f["saliente"] else {"responde_a": "Respondida por", "reitera_a": "Reiterada por",
                                                                                "amplia": "Ampliada por", "anexo_de": "Tiene como anexo",
                                                                                "reemplaza_a": "Reemplazada por"}.get(f["tipo"], f["tipo"])
        f["otra_id"] = f["destino_id"] if f["saliente"] else f["origen_id"]
    return filas
