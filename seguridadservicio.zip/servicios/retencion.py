"""Propuesta 5: plan de retención sin borrado físico.

La Dirección (o Archivo / Legales) carga una tabla de series documentales: por tipo documental, el plazo de guarda en años y el
destino final (conservación permanente o «en condiciones de baja»). El sistema solo **marca** lo vencido de las series con
destino «baja» y arma el listado; una persona autoriza el retiro con motivo y el documento pasa a «retirado», **sin borrarse**
(el archivo, el historial y la huella quedan). Sirve como insumo para decidir la política, que sigue pendiente.
"""
from __future__ import annotations

import sqlite3
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any

from dgpdh.errores import Conflicto, DatoInvalido, NoEncontrado
from dgpdh.seguridad import auditoria as au

DESTINOS = {"PERMANENTE": "Conservación permanente", "BAJA": "En condiciones de baja"}
ESTADOS_CERRADOS = ("FIRMADA", "DESPACHADA", "ARCHIVADA", "DESCARTADA", "RECHAZADA")


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _filas(con: sqlite3.Connection, sql: str, params: Sequence[object] = ()) -> list[dict[str, Any]]:
    cur = con.execute(sql, tuple(params))
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


def guardar_serie(con: sqlite3.Connection, *, tipo: str, plazo_anios: int, destino: str, actor: au.Actor) -> None:
    if destino not in DESTINOS:
        raise DatoInvalido("Elegí el destino final.")
    if not 0 < int(plazo_anios) <= 100:
        raise DatoInvalido("El plazo de guarda va de 1 a 100 años.")
    previo = con.execute("SELECT plazo_anios, destino FROM series_documentales WHERE tipo_documental = ?", (tipo,)).fetchone()
    con.execute("""INSERT INTO series_documentales (tipo_documental, plazo_anios, destino, actualizado_por, actualizado_en) VALUES (?,?,?,?,?)
                   ON CONFLICT(tipo_documental) DO UPDATE SET plazo_anios = excluded.plazo_anios, destino = excluded.destino,
                   actualizado_por = excluded.actualizado_por, actualizado_en = excluded.actualizado_en""",
                (tipo, int(plazo_anios), destino, actor.nombre, _ahora()))
    au.registrar(con, accion="Serie documental", entidad="serie_documental", entidad_id=tipo,
                 antes={"plazo_anios": previo[0], "destino": previo[1]} if previo else None,
                 despues={"plazo_anios": int(plazo_anios), "destino": destino}, actor=actor, origen="retencion")


def series(con: sqlite3.Connection) -> dict[str, dict[str, Any]]:
    return {f["tipo_documental"]: f for f in _filas(con, "SELECT * FROM series_documentales")}


def _vence(fecha: str, anios: int) -> str:
    d = date.fromisoformat(fecha[:10])
    try:
        return d.replace(year=d.year + anios).isoformat()
    except ValueError:  # 29 de febrero
        return d.replace(year=d.year + anios, day=28).isoformat()


def marcar_vencidos(con: sqlite3.Connection, hoy: date | None = None) -> int:
    """Marca como VENCIDA (solo marca) lo que superó el plazo en series con destino «baja». Devuelve cuántos marcó."""
    hoy_iso = (hoy or date.today()).isoformat()
    s = {k: v for k, v in series(con).items() if v["destino"] == "BAJA"}
    if not s:
        return 0
    ya = {int(f[0]) for f in con.execute("SELECT nota_id FROM retencion_documentos")}
    notas = _filas(con, "SELECT id, tipo_documental, fecha_nota, creado_en FROM notas WHERE estado IN (%s) AND tipo_documental IN (%s)"
                   % (",".join("?" * len(ESTADOS_CERRADOS)), ",".join("?" * len(s))), (*ESTADOS_CERRADOS, *s))
    n = 0
    for nota in notas:
        if int(nota["id"]) in ya:
            continue
        vence = _vence(str(nota["fecha_nota"] or nota["creado_en"]), int(s[nota["tipo_documental"]]["plazo_anios"]))
        if vence <= hoy_iso:
            con.execute("INSERT INTO retencion_documentos (nota_id, estado, vence_en, marcado_en) VALUES (?, 'VENCIDA', ?, ?)",
                        (nota["id"], vence, _ahora()))
            n += 1
    return n


def listado(con: sqlite3.Connection, estado: str = "VENCIDA") -> list[dict[str, Any]]:
    return _filas(con, """SELECT r.*, n.nombre_original, n.tipo_documental, n.nro_nota, n.estado AS estado_nota FROM retencion_documentos r
                          JOIN notas n ON n.id = r.nota_id WHERE r.estado = ? ORDER BY r.vence_en""", (estado,))


@dataclass(frozen=True)
class Marca:
    estado: str
    vence_en: str | None
    autorizado_por: str | None
    motivo: str | None


def de_nota(con: sqlite3.Connection, nota_id: int) -> Marca | None:
    f = con.execute("SELECT estado, vence_en, autorizado_por, motivo FROM retencion_documentos WHERE nota_id = ?", (nota_id,)).fetchone()
    return Marca(str(f[0]), f[1], f[2], f[3]) if f else None


def autorizar_retiro(con: sqlite3.Connection, nota_id: int, *, actor: au.Actor, motivo: str) -> None:
    """Pasa a «retirado». El documento NO se borra ni cambia su estado en el circuito."""
    if len((motivo or "").strip()) < 5:
        raise DatoInvalido("Escribí el motivo o la resolución que autoriza el retiro.")
    f = con.execute("SELECT estado FROM retencion_documentos WHERE nota_id = ?", (nota_id,)).fetchone()
    if not f:
        raise NoEncontrado("Ese documento no está marcado como vencido.")
    if f[0] != "VENCIDA":
        raise Conflicto("Ese documento ya fue retirado.")
    con.execute("UPDATE retencion_documentos SET estado = 'RETIRADA', autorizado_por = ?, autorizado_en = ?, motivo = ? WHERE nota_id = ?",
                (actor.nombre, _ahora(), motivo.strip()[:300], nota_id))
    au.registrar(con, accion="Retiro autorizado (retención)", entidad="nota", entidad_id=nota_id, antes={"estado": "VENCIDA"},
                 despues={"estado": "RETIRADA"}, actor=actor, motivo=motivo.strip()[:300], origen="retencion")
