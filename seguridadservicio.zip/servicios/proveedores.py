"""Propuesta 64: proveedores de la flota (con baja lógica), días de aviso por tipo de control y avisos internos a la persona
responsable de cada vencimiento. Nada sale por correo: el aviso queda en las notificaciones del sistema."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timezone
from typing import Any

from dgpdh.dominio import avisos_flota as af
from dgpdh.errores import DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au

CAMPOS = ("nombre", "tipo", "cuit", "telefono", "correo", "observaciones")


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _limpiar(datos: dict[str, Any]) -> dict[str, str | None]:
    d = {k: (str(datos.get(k) or "").strip()[:300] or None) for k in CAMPOS}
    if not d["nombre"]:
        raise DatoInvalido("Indicá el nombre del proveedor.")
    if d["tipo"] not in af.TIPOS_PROVEEDOR:
        d["tipo"] = "OTRO"
    return d


def listar(con: sqlite3.Connection, incluir_baja: bool = False) -> list[dict[str, Any]]:
    sql = "SELECT * FROM proveedores" + ("" if incluir_baja else " WHERE activo = 1") + " ORDER BY activo DESC, nombre"
    cur = con.execute(sql)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, f, strict=True)) for f in cur.fetchall()]


def guardar(con: sqlite3.Connection, actor: au.Actor, puede: bool, datos: dict[str, Any], proveedor_id: int | None = None) -> int:
    if not puede:
        raise PermisoDenegado("Los proveedores los carga la coordinación de traslados.")
    d = _limpiar(datos)
    if proveedor_id is None:
        pid = int(con.execute(f"INSERT INTO proveedores ({', '.join(CAMPOS)}, creado_por, creado_en) VALUES ({', '.join('?' * len(CAMPOS))}, ?, ?)",
                              (*d.values(), actor.nombre, _ahora())).lastrowid or 0)
        au.registrar(con, accion="Alta de proveedor", entidad="proveedor", entidad_id=pid, despues=d, actor=actor)
        return pid
    antes = con.execute(f"SELECT {', '.join(CAMPOS)} FROM proveedores WHERE id = ? AND activo = 1", (proveedor_id,)).fetchone()
    if not antes:
        raise DatoInvalido("El proveedor no existe o está dado de baja.")
    con.execute(f"UPDATE proveedores SET {', '.join(f'{c} = ?' for c in CAMPOS)} WHERE id = ?", (*d.values(), proveedor_id))
    au.registrar(con, accion="Edición de proveedor", entidad="proveedor", entidad_id=proveedor_id, antes=dict(zip(CAMPOS, antes, strict=True)), despues=d, actor=actor)
    return proveedor_id


def dar_de_baja(con: sqlite3.Connection, actor: au.Actor, puede: bool, proveedor_id: int, motivo: str | None = None) -> None:
    """Baja lógica: el proveedor deja de ofrecerse, pero los controles que lo citan lo siguen mostrando."""
    if not puede:
        raise PermisoDenegado("Los proveedores los carga la coordinación de traslados.")
    n = con.execute("UPDATE proveedores SET activo = 0, baja_por = ?, baja_en = ? WHERE id = ? AND activo = 1", (actor.nombre, _ahora(), proveedor_id)).rowcount
    if n:
        au.registrar(con, accion="Baja de proveedor", entidad="proveedor", entidad_id=proveedor_id, motivo=motivo, actor=actor)


def dias_configurados(con: sqlite3.Connection) -> dict[str, int]:
    try:
        return {str(f[0]): int(f[1]) for f in con.execute("SELECT tipo, dias FROM controles_dias_aviso")}
    except sqlite3.OperationalError:  # base sin la migración 0053
        return {}


def guardar_dias(con: sqlite3.Connection, actor: au.Actor, puede: bool, tipos: list[str], valores: dict[str, object]) -> int:
    if not puede:
        raise PermisoDenegado("Los días de aviso los fija la coordinación de traslados.")
    antes = dias_configurados(con)
    n = 0
    for t in tipos:
        try:
            v = af.validar_dias(valores.get(t))
        except ValueError as e:
            raise DatoInvalido(str(e)) from e
        if v == antes.get(t):
            continue
        if v is None:
            if t not in antes:
                continue
            au.borrar_con_registro(con, "controles_dias_aviso", "tipo = ?", (t,), actor=actor, motivo="Vuelve al valor por defecto")
            n += 1
            continue
        else:
            con.execute("""INSERT INTO controles_dias_aviso (tipo, dias, actualizado_por, actualizado_en) VALUES (?, ?, ?, ?)
                           ON CONFLICT(tipo) DO UPDATE SET dias = excluded.dias, actualizado_por = excluded.actualizado_por,
                           actualizado_en = excluded.actualizado_en""", (t, v, actor.nombre, _ahora()))
        au.registrar(con, accion="Días de aviso de control", entidad="control_tipo", entidad_id=t, antes=antes.get(t), despues=v, actor=actor)
        n += 1
    return n


def avisar_responsables(con: sqlite3.Connection, hoy: date, nombres: dict[str, str]) -> int:
    """Manda (una vez) el aviso interno «vence pronto» y el de «vencido» a la persona responsable del último control de
    cada tipo y vehículo. nombres = {tipo: etiqueta}."""
    filas = con.execute("""SELECT c.id, c.tipo, c.vence_fecha, c.responsable_id, c.vehiculo_id, v.dominio FROM vehiculo_controles c
                           JOIN vehiculos v ON v.id = c.vehiculo_id
                           WHERE v.estado NOT IN ('BAJA', 'FUERA_DE_CIRCULACION') AND c.id = (SELECT c2.id FROM vehiculo_controles c2
                                 WHERE c2.vehiculo_id = c.vehiculo_id AND c2.tipo = c.tipo ORDER BY c2.fecha DESC, c2.id DESC LIMIT 1)
                             AND c.responsable_id IS NOT NULL AND c.vence_fecha IS NOT NULL""").fetchall()
    ctrl = [dict(zip(("id", "tipo", "vence_fecha", "responsable_id", "vehiculo_id", "dominio"), f, strict=True)) for f in filas]
    enviados = {(int(f[0]), int(f[1]), str(f[2])) for f in con.execute("SELECT control_id, usuario_id, nivel FROM controles_avisos_enviados")}
    n = 0
    for p in af.pendientes(ctrl, dias_configurados(con), hoy, enviados):
        c = p["control"]
        f = str(c["vence_fecha"])
        que = nombres.get(str(c["tipo"]), str(c["tipo"]))
        texto = (f"{que} de {c['dominio']}: venció el {f[8:10]}/{f[5:7]}/{f[:4]}" if p["nivel"] == "vencido"
                 else f"{que} de {c['dominio']}: vence el {f[8:10]}/{f[5:7]}/{f[:4]} (faltan {p['faltan']} días)") + ". Sos la persona responsable."
        con.execute("INSERT INTO notificaciones (usuario_id, texto, url, creada_en) VALUES (?, ?, ?, ?)",
                    (p["usuario_id"], texto, f"/traslados/vehiculos/{c['vehiculo_id']}", _ahora()))
        con.execute("INSERT OR IGNORE INTO controles_avisos_enviados (control_id, usuario_id, nivel, enviado_en) VALUES (?, ?, ?, ?)",
                    (p["control_id"], p["usuario_id"], p["nivel"], _ahora()))
        n += 1
    return n
