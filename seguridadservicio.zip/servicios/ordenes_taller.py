"""Propuesta 65: órdenes de trabajo de taller. La orden se vincula a una o varias novedades mecánicas del vehículo; al
pasar a «En curso» esas novedades quedan «En reparación» y, al terminarla, «Reparada». El cambio de estado del vehículo lo
hace quien llama (flota.etapa_orden) con traslados.estado_vehiculo, que además avisa a los viajes afectados."""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timezone
from typing import Any

from dgpdh.dominio import ordenes_taller as ot
from dgpdh.errores import DatoInvalido, PermisoDenegado
from dgpdh.seguridad import auditoria as au

_COLS = ("id", "vehiculo_id", "etapa", "proveedor_id", "taller", "descripcion", "presupuesto", "fecha_prometida", "costo_final",
         "repuestos", "motivo_cancelacion", "creado_por", "creado_en", "actualizado_en", "iniciada_en", "cerrada_en")


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _texto(v: object, tope: int = 500) -> str | None:
    return str(v or "").strip()[:tope] or None


def _importe(v: object, nombre: str) -> float | None:
    try:
        return ot.importe(v)
    except ValueError as e:
        raise DatoInvalido(f"{nombre}: {e}" if str(e).startswith("El importe") else f"{nombre}: no es un importe válido.") from e


def _fecha(v: object) -> str | None:
    t = _texto(v, 10)
    if not t:
        return None
    try:
        return date.fromisoformat(t).isoformat()
    except ValueError as e:
        raise DatoInvalido("La fecha prometida no es válida.") from e


def _novedad_paso(con: sqlite3.Connection, actor: au.Actor, registro_id: int, estado: str, nota: str) -> None:
    cerrada = estado == "REPARADA"
    con.execute("UPDATE vehiculo_registros SET estado_novedad = ?, resuelta = ?, resuelta_en = ?, resuelta_por = ?, resolucion = ? WHERE id = ?",
                (estado, int(cerrada), _ahora() if cerrada else None, actor.nombre if cerrada else None, nota if cerrada else None, registro_id))
    con.execute("INSERT INTO vehiculo_novedad_estados (registro_id, estado, nota, usuario, fecha) VALUES (?, ?, ?, ?, ?)",
                (registro_id, estado, nota, actor.nombre, _ahora()))


def crear(con: sqlite3.Connection, actor: au.Actor, puede: bool, vehiculo_id: int, datos: dict[str, Any], novedades: list[int]) -> int:
    if not puede:
        raise PermisoDenegado("Las órdenes de trabajo las carga la coordinación de traslados.")
    if not con.execute("SELECT 1 FROM vehiculos WHERE id = ?", (vehiculo_id,)).fetchone():
        raise DatoInvalido("El vehículo no existe.")
    desc = _texto(datos.get("descripcion"))
    if not desc:
        raise DatoInvalido("Contá qué hay que hacer.")
    prov = str(datos.get("proveedor_id") or "")
    prov_id = int(prov) if prov.isdigit() else None
    if prov_id and not con.execute("SELECT 1 FROM proveedores WHERE id = ? AND activo = 1", (prov_id,)).fetchone():
        raise DatoInvalido("El taller elegido no existe o está dado de baja.")
    validas = {int(f[0]) for f in con.execute("SELECT id FROM vehiculo_registros WHERE vehiculo_id = ? AND tipo = 'NOVEDAD' AND resuelta = 0", (vehiculo_id,))}
    nov = sorted(set(novedades) & validas)
    v = {"proveedor_id": prov_id, "taller": _texto(datos.get("taller"), 200), "descripcion": desc,
         "presupuesto": _importe(datos.get("presupuesto"), "Presupuesto"), "fecha_prometida": _fecha(datos.get("fecha_prometida"))}
    oid = int(con.execute("""INSERT INTO ordenes_trabajo (vehiculo_id, etapa, proveedor_id, taller, descripcion, presupuesto, fecha_prometida,
                             creado_por, creado_en, actualizado_en) VALUES (?, 'NUEVA', ?, ?, ?, ?, ?, ?, ?, ?)""",
                          (vehiculo_id, *v.values(), actor.nombre, _ahora(), _ahora())).lastrowid or 0)
    for r in nov:
        con.execute("INSERT INTO orden_trabajo_novedades (orden_id, registro_id) VALUES (?, ?)", (oid, r))
    con.execute("INSERT INTO orden_trabajo_etapas (orden_id, etapa, usuario, fecha) VALUES (?, 'NUEVA', ?, ?)", (oid, actor.nombre, _ahora()))
    au.registrar(con, accion="Orden de trabajo: alta", entidad="orden_trabajo", entidad_id=oid, despues=dict(v, vehiculo_id=vehiculo_id, novedades=nov), actor=actor)
    return oid


def _orden(con: sqlite3.Connection, orden_id: int) -> dict[str, Any]:
    f = con.execute(f"SELECT {', '.join(_COLS)} FROM ordenes_trabajo WHERE id = ?", (orden_id,)).fetchone()
    if not f:
        raise DatoInvalido("La orden de trabajo no existe.")
    return dict(zip(_COLS, f, strict=True))


def editar(con: sqlite3.Connection, actor: au.Actor, puede: bool, orden_id: int, datos: dict[str, Any]) -> None:
    """Presupuesto, fecha prometida, costo final, repuestos y taller (mientras la orden no esté cerrada)."""
    if not puede:
        raise PermisoDenegado("Las órdenes de trabajo las carga la coordinación de traslados.")
    o = _orden(con, orden_id)
    if o["etapa"] in ot.CERRADAS:
        raise DatoInvalido("La orden ya está cerrada: no se puede modificar.")
    nuevo = {"taller": _texto(datos.get("taller"), 200), "presupuesto": _importe(datos.get("presupuesto"), "Presupuesto"),
             "fecha_prometida": _fecha(datos.get("fecha_prometida")), "costo_final": _importe(datos.get("costo_final"), "Costo final"),
             "repuestos": _texto(datos.get("repuestos"), 1000)}
    antes = {k: o[k] for k in nuevo}
    if antes == nuevo:
        return
    con.execute(f"UPDATE ordenes_trabajo SET {', '.join(f'{k} = ?' for k in nuevo)}, actualizado_en = ? WHERE id = ?", (*nuevo.values(), _ahora(), orden_id))
    au.registrar(con, accion="Orden de trabajo: datos", entidad="orden_trabajo", entidad_id=orden_id, antes=antes, despues=nuevo, actor=actor)


def cambiar_etapa(con: sqlite3.Connection, actor: au.Actor, puede: bool, orden_id: int, etapa: str, nota: str | None = None,
                  costo_final: object = None) -> dict[str, Any]:
    """Devuelve {"vehiculo_id", "poner_en_taller", "ofrecer_disponible", "descripcion"} para que quien llama cambie el estado
    del vehículo: a TALLER siempre al pasar a «En curso»; a DISPONIBLE solo si la persona lo confirmó."""
    if not puede:
        raise PermisoDenegado("Las órdenes de trabajo las carga la coordinación de traslados.")
    o = _orden(con, orden_id)
    nota = _texto(nota, 300)
    error = ot.validar(o["etapa"], etapa, nota)
    if error:
        raise DatoInvalido(error)
    costo = _importe(costo_final, "Costo final")
    ahora = _ahora()
    sets: dict[str, object] = {"etapa": etapa, "actualizado_en": ahora}
    if etapa == "EN_CURSO":
        sets["iniciada_en"] = ahora
    if etapa in ot.CERRADAS:
        sets["cerrada_en"] = ahora
    if etapa == "CANCELADA":
        sets["motivo_cancelacion"] = nota
    if costo is not None:
        sets["costo_final"] = costo
    con.execute(f"UPDATE ordenes_trabajo SET {', '.join(f'{k} = ?' for k in sets)} WHERE id = ?", (*sets.values(), orden_id))
    con.execute("INSERT INTO orden_trabajo_etapas (orden_id, etapa, nota, usuario, fecha) VALUES (?, ?, ?, ?, ?)", (orden_id, etapa, nota, actor.nombre, ahora))
    nov = [int(f[0]) for f in con.execute("""SELECT n.registro_id FROM orden_trabajo_novedades n JOIN vehiculo_registros r ON r.id = n.registro_id
                                             WHERE n.orden_id = ? AND r.resuelta = 0""", (orden_id,))]
    if etapa == "EN_CURSO":
        for r in nov:
            _novedad_paso(con, actor, r, "EN_REPARACION", f"Orden de trabajo #{orden_id}")
    elif etapa == "HECHA":
        for r in nov:
            _novedad_paso(con, actor, r, "REPARADA", f"Orden de trabajo #{orden_id}" + (f": {nota}" if nota else ""))
    au.registrar(con, accion="Orden de trabajo: etapa", entidad="orden_trabajo", entidad_id=orden_id, antes=o["etapa"], despues=etapa,
                 motivo=nota, actor=actor)
    otras = int(con.execute("SELECT COUNT(*) FROM ordenes_trabajo WHERE vehiculo_id = ? AND etapa = 'EN_CURSO' AND id != ?",
                            (o["vehiculo_id"], orden_id)).fetchone()[0])
    return {"vehiculo_id": int(o["vehiculo_id"]), "poner_en_taller": ot.pone_en_taller(o["etapa"], etapa),
            "ofrecer_disponible": ot.ofrece_volver(o["etapa"], etapa, otras), "descripcion": o["descripcion"]}


def del_vehiculo(con: sqlite3.Connection, vehiculo_id: int) -> list[dict[str, Any]]:
    filas = con.execute(f"""SELECT {', '.join('o.' + c for c in _COLS)}, p.nombre FROM ordenes_trabajo o LEFT JOIN proveedores p ON p.id = o.proveedor_id
                            WHERE o.vehiculo_id = ? ORDER BY (o.etapa IN ('HECHA', 'CANCELADA')), o.id DESC""", (vehiculo_id,)).fetchall()
    out = []
    for f in filas:
        d = dict(zip(_COLS, f[:-1], strict=True))
        d["proveedor_nombre"] = f[-1]
        d["etapa_etiqueta"] = ot.ETAPAS.get(d["etapa"], d["etapa"])
        d["clase"] = ot.CLASE.get(d["etapa"], "neutro")
        d["siguientes"] = [(e, ot.ETAPAS[e]) for e in ot.siguientes(d["etapa"])]
        d["novedades"] = [{"id": int(n[0]), "detalle": n[1], "fecha": n[2]} for n in con.execute(
            """SELECT r.id, r.detalle, r.fecha FROM orden_trabajo_novedades n JOIN vehiculo_registros r ON r.id = n.registro_id
               WHERE n.orden_id = ? ORDER BY r.fecha""", (d["id"],))]
        d["historial"] = [{"etapa": ot.ETAPAS.get(h[0], h[0]), "nota": h[1], "usuario": h[2], "fecha": h[3]} for h in con.execute(
            "SELECT etapa, nota, usuario, fecha FROM orden_trabajo_etapas WHERE orden_id = ? ORDER BY id", (d["id"],))]
        out.append(d)
    return out
