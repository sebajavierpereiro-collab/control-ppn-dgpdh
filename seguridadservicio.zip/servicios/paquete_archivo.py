"""Propuesta 6: paquete de archivo por expediente o por año, con inventario verificable.

Un .zip con los documentos firmados o despachados (el PDF de despacho si existe; si no, el firmado), un manifiesto con la
huella SHA-256 de cada archivo (en formato `sha256sum`, para volver a verificarlo en cualquier máquina con
`sha256sum -c MANIFIESTO.sha256`), un manifiesto.json con los metadatos y la huella registrada por el sistema, y el historial
de estados en CSV. Se genera solo a pedido y queda en la red interna. Nada se modifica.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import sqlite3
import zipfile
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dgpdh.errores import DatoInvalido
from dgpdh.seguridad import auditoria as au

ESTADOS = ("FIRMADA", "DESPACHADA")
_NOMBRE = re.compile(r"[^\w.\- ]+")


def _sha(ruta: Path) -> str:
    h = hashlib.sha256()
    with ruta.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _filas(con: sqlite3.Connection, sql: str, params: Sequence[object]) -> list[dict[str, Any]]:
    cur = con.execute(sql, tuple(params))
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


@dataclass(frozen=True)
class Paquete:
    ruta: Path
    documentos: int
    faltantes: int
    alterados: int


def generar(con: sqlite3.Connection, destino: Path, *, anio: int | None = None, expediente: str | None = None, actor: au.Actor) -> Paquete:
    if not anio and not (expediente or "").strip():
        raise DatoInvalido("Elegí un año o un expediente.")
    sql = ("SELECT id, nombre_original, estado, nro_nota, nro_expte, fecha_nota, creado_en, ruta_firmada, ruta_despacho_pdf, sha256_firmado, "
           "sha256_despacho FROM notas WHERE estado IN ('FIRMADA', 'DESPACHADA')")
    params: list[object] = []
    if anio:
        sql += " AND substr(COALESCE(fecha_nota, creado_en), 1, 4) = ?"
        params.append(str(anio))
    expte = (expediente or "").strip()
    if expte:
        sql += " AND upper(replace(COALESCE(nro_expte, ''), ' ', '')) = ?"
        params.append(expte.replace(" ", "").upper())
    notas = _filas(con, sql + " ORDER BY id", params)
    destino.parent.mkdir(parents=True, exist_ok=True)
    manifiesto: list[dict[str, Any]] = []
    lineas_sha: list[str] = []
    faltantes = alterados = 0
    hist = io.StringIO()
    w = csv.writer(hist, delimiter=";")
    w.writerow(["nota_id", "estado", "fecha", "usuario", "comentario"])
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for n in notas:
            ruta, registrada = (n["ruta_despacho_pdf"], n["sha256_despacho"]) if n.get("ruta_despacho_pdf") else (n["ruta_firmada"], n["sha256_firmado"])
            item: dict[str, Any] = {k: n.get(k) for k in ("id", "nombre_original", "estado", "nro_nota", "nro_expte", "fecha_nota")}
            p = Path(ruta) if ruta else None
            if p is None or not p.is_file():
                item["archivo"], item["problema"] = None, "falta el archivo"
                faltantes += 1
            else:
                nombre = f"documentos/{n['id']:06d}_{_NOMBRE.sub('_', p.name)}"
                z.write(p, nombre)
                huella = _sha(p)
                item.update(archivo=nombre, sha256=huella, sha256_registrado=registrada)
                if registrada and registrada != huella:
                    item["problema"] = "la huella no coincide con la registrada al firmar o despachar"
                    alterados += 1
                lineas_sha.append(f"{huella}  {nombre}")
            manifiesto.append(item)
            for h in _filas(con, "SELECT estado, fecha, usuario, comentario FROM historial_estados WHERE nota_id = ? ORDER BY id", (n["id"],)):
                w.writerow([n["id"], h["estado"], h["fecha"], h["usuario"] or "", h["comentario"] or ""])
        z.writestr("historial_estados.csv", "﻿" + hist.getvalue())
        z.writestr("MANIFIESTO.sha256", "\n".join(lineas_sha) + "\n")
        z.writestr("manifiesto.json", json.dumps({"generado": datetime.now(timezone.utc).isoformat(timespec="seconds"), "por": actor.nombre,
                                                  "anio": anio, "expediente": expediente, "documentos": manifiesto}, ensure_ascii=False, indent=1))
        z.writestr("LEEME.txt", "Paquete de archivo de la DGPDH (PPN). Para verificar los documentos: sha256sum -c MANIFIESTO.sha256\n"
                               "manifiesto.json tiene los metadatos y la huella que registró el sistema al firmar o despachar.\n"
                               "Contiene datos personales: uso interno, con la reserva de la Ley 25.326.\n")
    au.registrar(con, accion="Paquete de archivo", entidad="archivo", entidad_id=destino.name,
                 despues={"anio": anio, "expediente": expediente, "documentos": len(notas), "faltantes": faltantes, "alterados": alterados,
                          "sha256_paquete": _sha(destino)}, actor=actor, origen="archivo")
    return Paquete(destino, len(notas), faltantes, alterados)
