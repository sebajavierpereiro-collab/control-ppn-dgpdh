"""Paquete nuevo de dgpdh_web (ver ARCHITECTURE.md).

Los módulos históricos (raíz del proyecto) se pasan acá de a uno, separados en capas:
dominio (reglas puras), persistencia (base y migraciones), servicios (casos de uso con auditoría),
ia (IA local), integracion (puertos hacia ppn-sso, ppn-mesa-entradas y ppn-storage), seguridad y web.
Todo lo que vive en este paquete está tipado y se controla con mypy estricto.
"""
__all__ = ["errores"]
