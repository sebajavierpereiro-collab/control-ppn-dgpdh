"""Errores explícitos del sistema. Las capas de dominio y servicios lanzan estos; la capa web los traduce a la respuesta
(mensaje para la persona y código HTTP) en un solo lugar, en vez de que cada ruta decida a mano."""
from __future__ import annotations


class ErrorDGPDH(Exception):
    """Base de todos los errores previstos. `mensaje` está escrito para la persona que usa el sistema."""

    codigo_http: int = 400

    def __init__(self, mensaje: str, *, detalle: str | None = None) -> None:
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.detalle = detalle  # para el registro técnico; no se muestra


class DatoInvalido(ErrorDGPDH):
    """Lo que se cargó no cumple una regla (fecha, formato, campo obligatorio)."""


class NoEncontrado(ErrorDGPDH):
    codigo_http = 404


class PermisoDenegado(ErrorDGPDH):
    codigo_http = 403


class Conflicto(ErrorDGPDH):
    """El estado actual no permite la acción (p. ej. firmar una nota que todavía no está lista, chofer ocupado)."""

    codigo_http = 409


class IntegracionDeshabilitada(ErrorDGPDH):
    """Se intentó usar un sistema externo (ppn-sso, ppn-mesa-entradas, ppn-storage) que no está habilitado."""

    codigo_http = 503
