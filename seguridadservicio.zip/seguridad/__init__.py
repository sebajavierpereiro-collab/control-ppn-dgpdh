"""Seguridad: auditoría única (ADR-0008) y, en el hito 3, la matriz de permisos."""
