"""Auditoría única (ADR-0008): quién hizo qué, cuándo, sobre qué, con el valor anterior y el nuevo.

- `registrar(con, ...)` agrega una fila dentro de la MISMA transacción que el cambio: si el cambio se deshace, el registro
  también, y no queda un cambio sin su registro.
- `borrar_con_registro(con, tabla, donde, parametros, ...)` reemplaza a los DELETE de datos cargados por personas: guarda la
  fila completa en la auditoría antes de quitarla, así nada se pierde (regla «nada se borra físicamente»).
- `sellar(con)` encadena con SHA-256 las filas todavía sin sellar (cada hash incluye el anterior); `verificar(con)` recorre
  la cadena y dice dónde se rompió si alguien editó o borró filas por fuera del sistema.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import sqlite3
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dgpdh.errores import DatoInvalido

SISTEMA = "Sistema"
_NOMBRE_SQL = re.compile(r"^[a-z_][a-z0-9_]*$")
_CAMPOS_HASH = ("id", "fecha", "usuario_id", "usuario", "accion", "entidad", "entidad_id", "antes", "despues", "motivo", "ip", "origen")


@dataclass(frozen=True)
class Actor:
    id: int | None
    nombre: str
    ip: str | None = None

    @classmethod
    def desde(cls, usuario: Mapping[str, Any] | None, ip: str | None = None) -> Actor:
        if not usuario:
            return cls(None, SISTEMA, ip)
        uid = usuario.get("id")
        return cls(int(uid) if uid is not None else None, str(usuario.get("nombre") or usuario.get("usuario") or SISTEMA), ip)


@contextmanager
def _filas(con: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Lee con sqlite3.Row sin cambiarle la configuración a la conexión de quien llama."""
    previo = con.row_factory
    con.row_factory = sqlite3.Row
    try:
        yield con
    finally:
        con.row_factory = previo


def _json(valor: object) -> str | None:
    if valor is None:
        return None
    if isinstance(valor, sqlite3.Row):
        valor = dict(valor)
    return json.dumps(valor, ensure_ascii=False, sort_keys=True, default=str)


def registrar(con: sqlite3.Connection, *, accion: str, entidad: str, entidad_id: object = None, antes: object = None,
              despues: object = None, actor: Actor | None = None, motivo: str | None = None, origen: str | None = None) -> int:
    if not accion.strip() or not entidad.strip():
        raise DatoInvalido("La auditoría necesita la acción y la entidad.")
    a = actor or Actor(None, SISTEMA)
    cur = con.execute(
        """INSERT INTO auditoria (fecha, usuario_id, usuario, accion, entidad, entidad_id, antes, despues, motivo, ip, origen)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (datetime.now(timezone.utc).isoformat(timespec="seconds"), a.id, a.nombre, accion.strip(), entidad.strip(),
         None if entidad_id is None else str(entidad_id), _json(antes), _json(despues), (motivo or None), a.ip, origen))
    return int(cur.lastrowid or 0)


def borrar_con_registro(con: sqlite3.Connection, tabla: str, donde: str, parametros: Sequence[object] = (), *,
                        actor: Actor | None = None, motivo: str | None = None, origen: str | None = None) -> int:
    """DELETE FROM <tabla> WHERE <donde>, pero cada fila queda completa en la auditoría (acción «Baja»). Devuelve cuántas."""
    if not _NOMBRE_SQL.match(tabla):
        raise DatoInvalido(f"Nombre de tabla no válido: {tabla!r}")
    with _filas(con):
        filas = con.execute(f"SELECT * FROM {tabla} WHERE {donde}", tuple(parametros)).fetchall()
    for f in filas:
        d = dict(f)
        registrar(con, accion="Baja", entidad=tabla, entidad_id=d.get("id"), antes=d, actor=actor, motivo=motivo, origen=origen)
    if filas:
        con.execute(f"DELETE FROM {tabla} WHERE {donde}", tuple(parametros))
    return len(filas)


def _hash(anterior: str, fila: Mapping[str, Any], clave: bytes | None = None) -> str:
    contenido = json.dumps([anterior] + [fila[c] for c in _CAMPOS_HASH], ensure_ascii=False, default=str).encode("utf-8")
    if clave:  # HMAC: sin la clave (guardada fuera de la base) no se puede recalcular la cadena
        return hmac.new(clave, contenido, hashlib.sha256).hexdigest()
    return hashlib.sha256(contenido).hexdigest()


@dataclass(frozen=True)
class Ancla:
    """Último punto sellado, guardado FUERA de la base (archivo de solo agregado): permite detectar que alguien borró las
    últimas filas o las reescribió y las dejó «por sellar»."""
    ultimo_id: int
    ultimo_hash: str


def leer_ancla(ruta: Path | None) -> tuple[Ancla | None, int]:
    """(última ancla, «legado hasta»): las filas con id <= legado se sellaron antes de existir la clave (SHA-256 simple)."""
    if ruta is None or not ruta.is_file():
        return None, 0
    ancla, legado = None, 0
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        partes = linea.split()
        if len(partes) >= 2 and partes[0] == "LEGADO" and partes[1].isdigit():
            legado = int(partes[1])
        elif len(partes) >= 3 and partes[1].isdigit():
            ancla = Ancla(int(partes[1]), partes[2])
    return ancla, legado


def sellar(con: sqlite3.Connection, clave: bytes | None = None, ancla: Path | None = None) -> int:
    """Encadena las filas sin sellar, en orden. Conviene llamarla con una conexión propia (es una escritura corta).
    Con `ancla`, agrega al archivo el último id y hash sellados."""
    _, legado = leer_ancla(ancla)
    with _filas(con):
        previa = con.execute("SELECT id, hash FROM auditoria WHERE hash IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()
        pendientes = con.execute("SELECT * FROM auditoria WHERE hash IS NULL ORDER BY id").fetchall()
    anterior = str(previa["hash"]) if previa else ""
    n, ultimo_id = 0, None
    for f in pendientes:
        anterior = _hash(anterior, f, None if int(f["id"]) <= legado else clave)
        con.execute("UPDATE auditoria SET hash = ? WHERE id = ? AND hash IS NULL", (anterior, f["id"]))
        n, ultimo_id = n + 1, int(f["id"])
    if n and ancla is not None:
        con.commit()
        with ancla.open("a", encoding="utf-8") as a:
            a.write(f"{datetime.now(timezone.utc).isoformat(timespec='seconds')} {ultimo_id} {anterior}\n")
    return n


@dataclass(frozen=True)
class Verificacion:
    ok: bool
    selladas: int
    sin_sellar: int
    rota_en: int | None = None
    motivo: str = ""

    @property
    def texto(self) -> str:
        if self.ok:
            return f"Cadena de auditoría íntegra: {self.selladas} registro(s) sellados, {self.sin_sellar} por sellar."
        return (f"La cadena de auditoría está alterada a partir del registro #{self.rota_en}"
                + (f" ({self.motivo})" if self.motivo else "") + ": revisar quién tuvo acceso a la base.")


def verificar(con: sqlite3.Connection, clave: bytes | None = None, ancla: Path | None = None) -> Verificacion:
    ultima, legado = leer_ancla(ancla)
    with _filas(con):
        todas = con.execute("SELECT * FROM auditoria ORDER BY id").fetchall()
    anterior, selladas, sin_sellar, ultimo_sellado = "", 0, 0, True
    hashes: dict[int, str] = {}
    for f in todas:
        fid = int(f["id"])
        if f["hash"] is None:
            if ultima is not None and fid <= ultima.ultimo_id:
                return Verificacion(False, selladas, sin_sellar, fid, "un registro ya sellado quedó sin sello")
            sin_sellar += 1
            ultimo_sellado = False
            continue
        if not ultimo_sellado or f["hash"] != _hash(anterior, f, None if fid <= legado else clave):
            return Verificacion(False, selladas, sin_sellar, fid)
        anterior = str(f["hash"])
        hashes[fid] = anterior
        selladas += 1
    if ultima is not None and hashes.get(ultima.ultimo_id) != ultima.ultimo_hash:
        return Verificacion(False, selladas, sin_sellar, ultima.ultimo_id, "faltan o cambiaron los últimos registros sellados")
    return Verificacion(True, selladas, sin_sellar)


def historial(con: sqlite3.Connection, entidad: str, entidad_id: object) -> list[dict[str, Any]]:
    with _filas(con):
        filas = con.execute("SELECT * FROM auditoria WHERE entidad = ? AND entidad_id = ? ORDER BY id",
                            (entidad, None if entidad_id is None else str(entidad_id))).fetchall()
    out = []
    for f in filas:
        d = dict(f)
        for k in ("antes", "despues"):
            d[k] = json.loads(d[k]) if d[k] else None
        out.append(d)
    return out
