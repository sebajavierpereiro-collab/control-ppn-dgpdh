"""Propuesta 50: huella encadenada de los registros históricos (además de la auditoría única de ADR-0008).

Tablas: `historial_estados` (notas), `detenidos_cambios`, `seguridad_eventos` e `ia_registro`. Cada fila nueva recibe un
sello HMAC-SHA256 que incluye el sello de la anterior, en una tabla aparte (`cadenas_filas`): no se toca la tabla original.
`verificar` recorre la cadena y dice si una fila se modificó o se borró por fuera del sistema. Como en la auditoría, el sello
se hace diferido (cada 10 minutos) para no leer la última fila dentro de cada escritura.

Para el hash se usan solo las columnas con valor: una columna nueva (que queda vacía en las filas viejas) no rompe la cadena.
`seguridad_eventos` e `ia_registro` además no se pueden modificar ni borrar (triggers, migración 0013). `historial_estados` y
`detenidos_cambios` no se bloquean porque «Limpiar notas» (excepción consciente de ADR-0008) borra el historial de las notas de
prueba: en ese caso la cadena se reinicia y queda anotado (`reiniciar`).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import sqlite3
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

TABLAS = ("historial_estados", "detenidos_cambios", "seguridad_eventos", "ia_registro")
LOTE = 5000


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _existe(con: sqlite3.Connection, tabla: str) -> bool:
    return bool(con.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (tabla,)).fetchone())


def _valida(tabla: str) -> str:
    if tabla not in TABLAS:
        raise ValueError(f"Tabla sin cadena: {tabla}")
    return tabla


def huella(anterior: str, fila: dict[str, Any], clave: bytes | None) -> str:
    contenido = json.dumps([anterior, {k: v for k, v in sorted(fila.items()) if v is not None}], ensure_ascii=False,
                           default=str).encode("utf-8")
    if clave:
        return hmac.new(clave, contenido, hashlib.sha256).hexdigest()
    return hashlib.sha256(contenido).hexdigest()


def _filas(con: sqlite3.Connection, sql: str, params: Iterable[object] = ()) -> list[dict[str, Any]]:
    cur = con.execute(sql, tuple(params))
    nombres = [d[0] for d in cur.description]
    return [dict(zip(nombres, tuple(f), strict=True)) for f in cur.fetchall()]


def _cabeza(con: sqlite3.Connection, tabla: str) -> tuple[int, str]:
    f = con.execute("SELECT ultimo_id, ultimo_hash FROM cadenas_registro WHERE tabla = ?", (tabla,)).fetchone()
    return (int(f[0]), str(f[1])) if f else (0, "")


def sellar(con: sqlite3.Connection, tabla: str, clave: bytes | None, lote: int = LOTE) -> tuple[int, int, str]:
    """Sella hasta `lote` filas nuevas. Devuelve (selladas, último id, último hash)."""
    _valida(tabla)
    if not _existe(con, tabla):
        return 0, 0, ""
    ultimo_id, anterior = _cabeza(con, tabla)
    nuevas = _filas(con, f"SELECT * FROM {tabla} WHERE id > ? ORDER BY id LIMIT ?", (ultimo_id, lote))
    for f in nuevas:
        anterior = huella(anterior, f, clave)
        ultimo_id = int(f["id"])
        con.execute("INSERT OR REPLACE INTO cadenas_filas (tabla, fila_id, hash) VALUES (?,?,?)", (tabla, ultimo_id, anterior))
    if nuevas:
        con.execute("""INSERT INTO cadenas_registro (tabla, ultimo_id, ultimo_hash, sellado_en) VALUES (?,?,?,?)
                       ON CONFLICT(tabla) DO UPDATE SET ultimo_id = excluded.ultimo_id, ultimo_hash = excluded.ultimo_hash,
                       sellado_en = excluded.sellado_en""", (tabla, ultimo_id, anterior, _ahora()))
    return len(nuevas), ultimo_id, anterior


def sellar_todas(con: sqlite3.Connection, clave: bytes | None) -> dict[str, tuple[int, int, str]]:
    return {t: sellar(con, t, clave) for t in TABLAS}


def reiniciar(con: sqlite3.Connection, tabla: str, motivo: str) -> None:
    """Después de un borrado autorizado (por ejemplo «Limpiar notas»): la cadena empieza de nuevo y queda el motivo."""
    _valida(tabla)
    if not _existe(con, "cadenas_registro"):
        return
    con.execute("DELETE FROM cadenas_filas WHERE tabla = ?", (tabla,))
    con.execute("""INSERT INTO cadenas_registro (tabla, ultimo_id, ultimo_hash, sellado_en, reiniciada_en, motivo_reinicio)
                   VALUES (?, 0, '', ?, ?, ?) ON CONFLICT(tabla) DO UPDATE SET ultimo_id = 0, ultimo_hash = '',
                   reiniciada_en = excluded.reiniciada_en, motivo_reinicio = excluded.motivo_reinicio""",
                (tabla, _ahora(), _ahora(), motivo[:300]))


@dataclass(frozen=True)
class Resultado:
    tabla: str
    ok: bool
    selladas: int
    borradas: tuple[int, ...] = ()
    modificadas: tuple[int, ...] = ()

    @property
    def texto(self) -> str:
        if self.ok:
            return f"{self.tabla}: {self.selladas} registro(s) sellados, íntegros."
        partes = []
        if self.modificadas:
            partes.append(f"modificados desde el #{self.modificadas[0]} ({len(self.modificadas)})")
        if self.borradas:
            partes.append(f"borrados desde el #{self.borradas[0]} ({len(self.borradas)})")
        return f"{self.tabla}: ALTERADA — registros " + " y ".join(partes) + "."


def verificar(con: sqlite3.Connection, tabla: str, clave: bytes | None) -> Resultado:
    _valida(tabla)
    if not _existe(con, tabla):
        return Resultado(tabla, True, 0)
    sellos = _filas(con, "SELECT fila_id, hash FROM cadenas_filas WHERE tabla = ? ORDER BY fila_id", (tabla,))
    actuales = {int(f["id"]): f for f in _filas(con, f"SELECT * FROM {tabla} WHERE id <= ?", (sellos[-1]["fila_id"] if sellos else 0,))}
    anterior, borradas, modificadas = "", [], []
    for s in sellos:
        fid = int(s["fila_id"])
        fila = actuales.get(fid)
        if fila is None:
            borradas.append(fid)
        elif huella(anterior, fila, clave) != s["hash"]:
            modificadas.append(fid)
        anterior = str(s["hash"])  # se sigue con el sello guardado: así se ve cada fila alterada, no solo la primera
    return Resultado(tabla, not (borradas or modificadas), len(sellos), tuple(borradas), tuple(modificadas))


def verificar_todas(con: sqlite3.Connection, clave: bytes | None) -> list[Resultado]:
    return [verificar(con, t, clave) for t in TABLAS]
